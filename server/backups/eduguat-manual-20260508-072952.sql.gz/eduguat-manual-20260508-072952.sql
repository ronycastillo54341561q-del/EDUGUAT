-- MySQL dump 10.13  Distrib 9.6.0, for Win64 (x86_64)
--
-- Host: localhost    Database: m_lozano
-- ------------------------------------------------------
-- Server version	9.6.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '26f5017b-2d6a-11f1-a2a1-b047e91eb6e3:1-46963';

--
-- Current Database: `m_lozano`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `m_lozano` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `m_lozano`;

--
-- Table structure for table `alumnos`
--

DROP TABLE IF EXISTS `alumnos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `alumnos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `clave` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `codigo_estudiante` varchar(7) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nombre` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `apellido` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fecha_inicio` date DEFAULT NULL,
  `fecha_nacimiento` date DEFAULT NULL,
  `encargado` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `telefono` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `diplomado` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tac` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `asesor` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `direccion` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `establecimiento` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `observaciones` text COLLATE utf8mb4_unicode_ci,
  `dia_clases1` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dia_clases2` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `horario` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `laboratorio` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `estado` enum('activo','inactivo','retirado') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'activo',
  `cuota_mensual` decimal(10,2) NOT NULL DEFAULT '0.00',
  `usuario_id` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `codigo_estudiante` (`clave`),
  UNIQUE KEY `codigo_estudiante_2` (`codigo_estudiante`),
  CONSTRAINT `chk_codigo_estudiante` CHECK (((`codigo_estudiante` is null) or regexp_like(`codigo_estudiante`,_utf8mb4'^[A-Z][0-9]{3}[A-Z]{3}$')))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alumnos`
--

LOCK TABLES `alumnos` WRITE;
/*!40000 ALTER TABLE `alumnos` DISABLE KEYS */;
INSERT INTO `alumnos` VALUES (1,'01',NULL,'Marcus Alexander','Castillo de Leon','2026-03-01','2000-01-01','Byron de Leon','74847574','programador','2',NULL,'San miguel centro','Instituto Cooperativa san miguel','','lunes',NULL,'7:00 a 10:00','1','activo',50.00,2,'2026-04-23 20:23:59');
/*!40000 ALTER TABLE `alumnos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `asistencia_semanal`
--

DROP TABLE IF EXISTS `asistencia_semanal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `asistencia_semanal` (
  `id` int NOT NULL AUTO_INCREMENT,
  `alumno_id` int NOT NULL,
  `anio` smallint NOT NULL,
  `mes` tinyint NOT NULL,
  `semana` tinyint NOT NULL,
  `estado` char(1) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_asist_sem` (`alumno_id`,`anio`,`mes`,`semana`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `asistencia_semanal`
--

LOCK TABLES `asistencia_semanal` WRITE;
/*!40000 ALTER TABLE `asistencia_semanal` DISABLE KEYS */;
/*!40000 ALTER TABLE `asistencia_semanal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `avisos`
--

DROP TABLE IF EXISTS `avisos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `avisos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `autor_id` int DEFAULT NULL,
  `autor_nombre` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `autor_rol` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `titulo` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mensaje` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `scope` enum('global','horario','laboratorio','diplomado','dia','alumno') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'global',
  `filtro_dia` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `filtro_horario` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `filtro_laboratorio` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `filtro_diplomado` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `filtro_alumno_id` int DEFAULT NULL,
  `expira_at` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_avisos_scope` (`scope`),
  KEY `idx_avisos_expira` (`expira_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `avisos`
--

LOCK TABLES `avisos` WRITE;
/*!40000 ALTER TABLE `avisos` DISABLE KEYS */;
/*!40000 ALTER TABLE `avisos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bitacora`
--

DROP TABLE IF EXISTS `bitacora`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bitacora` (
  `id` int NOT NULL AUTO_INCREMENT,
  `usuario_id` int DEFAULT NULL,
  `usuario_nombre` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Sistema',
  `accion` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `modulo` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci,
  `ip` varchar(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bitacora`
--

LOCK TABLES `bitacora` WRITE;
/*!40000 ALTER TABLE `bitacora` DISABLE KEYS */;
INSERT INTO `bitacora` VALUES (1,1,'Admin m_lozano','crear','Alumnos','Alumno creado: Marcus Alexander Castillo de Leon (01)','::1','2026-04-23 20:23:59');
/*!40000 ALTER TABLE `bitacora` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cat_cuentas_bancarias`
--

DROP TABLE IF EXISTS `cat_cuentas_bancarias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cat_cuentas_bancarias` (
  `id` int NOT NULL AUTO_INCREMENT,
  `numero_cuenta` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nombre` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo_cuenta` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cat_cuentas_bancarias`
--

LOCK TABLES `cat_cuentas_bancarias` WRITE;
/*!40000 ALTER TABLE `cat_cuentas_bancarias` DISABLE KEYS */;
/*!40000 ALTER TABLE `cat_cuentas_bancarias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cat_cuotas`
--

DROP TABLE IF EXISTS `cat_cuotas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cat_cuotas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `monto` decimal(10,2) NOT NULL,
  `descripcion` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cat_cuotas`
--

LOCK TABLES `cat_cuotas` WRITE;
/*!40000 ALTER TABLE `cat_cuotas` DISABLE KEYS */;
INSERT INTO `cat_cuotas` VALUES (1,50.00,NULL,1,'2026-04-29 02:26:16');
/*!40000 ALTER TABLE `cat_cuotas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cat_establecimientos`
--

DROP TABLE IF EXISTS `cat_establecimientos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cat_establecimientos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nombre` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=178 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cat_establecimientos`
--

LOCK TABLES `cat_establecimientos` WRITE;
/*!40000 ALTER TABLE `cat_establecimientos` DISABLE KEYS */;
INSERT INTO `cat_establecimientos` VALUES (1,'Instituto Cooperativa san miguel',1,'2026-04-29 02:26:16');
/*!40000 ALTER TABLE `cat_establecimientos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cat_horarios`
--

DROP TABLE IF EXISTS `cat_horarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cat_horarios` (
  `id` int NOT NULL AUTO_INCREMENT,
  `dia1` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dia2` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hora_inicio` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `hora_fin` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cat_horarios`
--

LOCK TABLES `cat_horarios` WRITE;
/*!40000 ALTER TABLE `cat_horarios` DISABLE KEYS */;
INSERT INTO `cat_horarios` VALUES (1,'lunes',NULL,'7:00','10:00',1,'2026-04-29 02:26:16');
/*!40000 ALTER TABLE `cat_horarios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cat_laboratorios`
--

DROP TABLE IF EXISTS `cat_laboratorios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cat_laboratorios` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nombre` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=178 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cat_laboratorios`
--

LOCK TABLES `cat_laboratorios` WRITE;
/*!40000 ALTER TABLE `cat_laboratorios` DISABLE KEYS */;
INSERT INTO `cat_laboratorios` VALUES (1,'1',1,'2026-04-29 02:26:16');
/*!40000 ALTER TABLE `cat_laboratorios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cierre_gastos`
--

DROP TABLE IF EXISTS `cierre_gastos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cierre_gastos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `cierre_id` int NOT NULL,
  `descripcion` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `monto` decimal(10,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id`),
  KEY `idx_cierre_gastos` (`cierre_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cierre_gastos`
--

LOCK TABLES `cierre_gastos` WRITE;
/*!40000 ALTER TABLE `cierre_gastos` DISABLE KEYS */;
/*!40000 ALTER TABLE `cierre_gastos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cierres_diarios`
--

DROP TABLE IF EXISTS `cierres_diarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cierres_diarios` (
  `id` int NOT NULL AUTO_INCREMENT,
  `modulo` enum('recibos','papeleria') COLLATE utf8mb4_unicode_ci NOT NULL,
  `fecha` date NOT NULL,
  `total_dia` decimal(10,2) NOT NULL DEFAULT '0.00',
  `total_gastos` decimal(10,2) NOT NULL DEFAULT '0.00',
  `total_depositar` decimal(10,2) NOT NULL DEFAULT '0.00',
  `cuenta_id` int DEFAULT NULL,
  `cuenta_snapshot` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ultimo_recibo` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `observaciones` text COLLATE utf8mb4_unicode_ci,
  `estado` enum('pendiente','revisado') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pendiente',
  `creado_por_id` int DEFAULT NULL,
  `creado_por_nombre` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `revisado_por_id` int DEFAULT NULL,
  `revisado_por_nombre` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `revisado_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_cierre` (`modulo`,`fecha`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cierres_diarios`
--

LOCK TABLES `cierres_diarios` WRITE;
/*!40000 ALTER TABLE `cierres_diarios` DISABLE KEYS */;
/*!40000 ALTER TABLE `cierres_diarios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `config_pagos`
--

DROP TABLE IF EXISTS `config_pagos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `config_pagos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `anio` int NOT NULL,
  `scope_tipo` enum('global','diplomado','horario','laboratorio','dia','alumno') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'global',
  `scope_valor` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mes_inicio` tinyint NOT NULL,
  `mes_fin` tinyint NOT NULL,
  `multiplicador` decimal(4,2) NOT NULL DEFAULT '1.00',
  `descripcion` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_cfg_anio` (`anio`),
  KEY `idx_cfg_scope` (`scope_tipo`,`scope_valor`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `config_pagos`
--

LOCK TABLES `config_pagos` WRITE;
/*!40000 ALTER TABLE `config_pagos` DISABLE KEYS */;
/*!40000 ALTER TABLE `config_pagos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `configuracion`
--

DROP TABLE IF EXISTS `configuracion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `configuracion` (
  `id` int NOT NULL AUTO_INCREMENT,
  `clave` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `valor` text COLLATE utf8mb4_unicode_ci,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `clave` (`clave`)
) ENGINE=InnoDB AUTO_INCREMENT=1145 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `configuracion`
--

LOCK TABLES `configuracion` WRITE;
/*!40000 ALTER TABLE `configuracion` DISABLE KEYS */;
INSERT INTO `configuracion` VALUES (1,'inst_nombre','EDUGUAT','2026-04-23 20:11:02'),(2,'inst_direccion','Ciudad de Guatemala, Guatemala','2026-04-23 20:11:02'),(3,'inst_telefono','Tel: 2222-3333','2026-04-23 20:11:02'),(4,'inst_email','','2026-04-23 20:11:02');
/*!40000 ALTER TABLE `configuracion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `constancia_plantillas`
--

DROP TABLE IF EXISTS `constancia_plantillas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `constancia_plantillas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ubicacion` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Guatemala',
  `saludo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Estimado(a) Director(a):',
  `cuerpo` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `despedida` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Atentamente,',
  `firma_nombre` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Secretaría',
  `firma_cargo` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mostrar_fecha` tinyint(1) NOT NULL DEFAULT '1',
  `mostrar_firma` tinyint(1) NOT NULL DEFAULT '1',
  `mostrar_telefono` tinyint(1) NOT NULL DEFAULT '1',
  `activa` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `espacio_post_encabezado` tinyint NOT NULL DEFAULT '3',
  `espacio_post_fecha` tinyint NOT NULL DEFAULT '2',
  `espacio_post_saludo` tinyint NOT NULL DEFAULT '1',
  `espacio_post_cuerpo` tinyint NOT NULL DEFAULT '2',
  `espacio_post_despedida` tinyint NOT NULL DEFAULT '3',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `constancia_plantillas`
--

LOCK TABLES `constancia_plantillas` WRITE;
/*!40000 ALTER TABLE `constancia_plantillas` DISABLE KEYS */;
INSERT INTO `constancia_plantillas` VALUES (1,'Constancia de Inscripción','Guatemala','A quien corresponda:','Por medio de la presente hacemos constar que el alumno(a) {{nombre_completo}}, estudiante del establecimiento {{establecimiento}}, se encuentra inscrito(a) actualmente en el curso de Tecnología {{tac}}, en el horario de {{horario}} los días {{dias}} en el laboratorio {{laboratorio}}.\n\nLa presente constancia se extiende a solicitud del interesado para los usos que estime convenientes.','Atentamente,','Secretaría','',1,1,1,1,'2026-04-29 21:07:23','2026-04-29 21:07:23',3,2,1,2,3);
/*!40000 ALTER TABLE `constancia_plantillas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dip_diplomado_objetivos`
--

DROP TABLE IF EXISTS `dip_diplomado_objetivos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dip_diplomado_objetivos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `diplomado_id` int NOT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `orden` smallint NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_dip_obj` (`diplomado_id`,`orden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dip_diplomado_objetivos`
--

LOCK TABLES `dip_diplomado_objetivos` WRITE;
/*!40000 ALTER TABLE `dip_diplomado_objetivos` DISABLE KEYS */;
/*!40000 ALTER TABLE `dip_diplomado_objetivos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dip_diplomados`
--

DROP TABLE IF EXISTS `dip_diplomados`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dip_diplomados` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `objetivo_general` text COLLATE utf8mb4_unicode_ci,
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dip_diplomados`
--

LOCK TABLES `dip_diplomados` WRITE;
/*!40000 ALTER TABLE `dip_diplomados` DISABLE KEYS */;
INSERT INTO `dip_diplomados` VALUES (1,'Operador Windows','',1,'2026-04-26 18:32:27'),(2,'Programador','',1,'2026-04-26 18:32:27'),(3,'Diseño Gráfico','',1,'2026-04-26 18:32:27');
/*!40000 ALTER TABLE `dip_diplomados` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dip_examenes`
--

DROP TABLE IF EXISTS `dip_examenes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dip_examenes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `diplomado_id` int NOT NULL,
  `nombre` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `orden` smallint NOT NULL DEFAULT '0',
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_dip_exam` (`diplomado_id`,`orden`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dip_examenes`
--

LOCK TABLES `dip_examenes` WRITE;
/*!40000 ALTER TABLE `dip_examenes` DISABLE KEYS */;
INSERT INTO `dip_examenes` VALUES (1,1,'Windows',0,1,'2026-04-26 20:24:33'),(2,1,'Word',1,1,'2026-04-26 20:24:33'),(3,1,'Publisher',2,1,'2026-04-26 20:24:33'),(4,1,'PowerPoint',3,1,'2026-04-26 20:24:33'),(5,1,'Parcial',4,1,'2026-04-26 20:24:33'),(6,1,'Excel',5,1,'2026-04-26 20:24:33'),(7,1,'Examen Final',6,1,'2026-04-26 20:24:33'),(8,2,'Scratch',0,1,'2026-04-26 20:24:33'),(9,2,'Python',1,1,'2026-04-26 20:24:33'),(10,2,'Parcial',2,1,'2026-04-26 20:24:33'),(11,2,'C#',3,1,'2026-04-26 20:24:33'),(12,2,'Examen Final',4,1,'2026-04-26 20:24:33'),(13,3,'Photoshop',0,1,'2026-04-26 20:24:33'),(14,3,'Illustrator',1,1,'2026-04-26 20:24:33'),(15,3,'Parcial',2,1,'2026-04-26 20:24:33'),(16,3,'Filmora',3,1,'2026-04-26 20:24:33'),(17,3,'Examen Final',4,1,'2026-04-26 20:24:33');
/*!40000 ALTER TABLE `dip_examenes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dip_programa_contenido`
--

DROP TABLE IF EXISTS `dip_programa_contenido`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dip_programa_contenido` (
  `id` int NOT NULL AUTO_INCREMENT,
  `programa_id` int NOT NULL,
  `semana_num` tinyint NOT NULL,
  `contenido` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_dip_prog_cont` (`programa_id`,`semana_num`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dip_programa_contenido`
--

LOCK TABLES `dip_programa_contenido` WRITE;
/*!40000 ALTER TABLE `dip_programa_contenido` DISABLE KEYS */;
/*!40000 ALTER TABLE `dip_programa_contenido` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dip_programa_objetivos`
--

DROP TABLE IF EXISTS `dip_programa_objetivos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dip_programa_objetivos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `programa_id` int NOT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `orden` smallint NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_prog_obj` (`programa_id`,`orden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dip_programa_objetivos`
--

LOCK TABLES `dip_programa_objetivos` WRITE;
/*!40000 ALTER TABLE `dip_programa_objetivos` DISABLE KEYS */;
/*!40000 ALTER TABLE `dip_programa_objetivos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dip_programas`
--

DROP TABLE IF EXISTS `dip_programas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dip_programas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `diplomado_id` int NOT NULL,
  `nombre` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `objetivo_general` text COLLATE utf8mb4_unicode_ci,
  `duracion_semanas` tinyint NOT NULL DEFAULT '1',
  `orden` smallint NOT NULL DEFAULT '0',
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_prog_dip` (`diplomado_id`,`orden`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dip_programas`
--

LOCK TABLES `dip_programas` WRITE;
/*!40000 ALTER TABLE `dip_programas` DISABLE KEYS */;
INSERT INTO `dip_programas` VALUES (1,1,'Windows','',1,0,1,'2026-04-26 18:32:27'),(2,1,'Word','',1,1,1,'2026-04-26 18:32:27'),(3,1,'Publisher','',1,2,1,'2026-04-26 18:32:27'),(4,1,'PowerPoint','',1,3,1,'2026-04-26 18:32:27'),(5,1,'Parcial','',1,4,1,'2026-04-26 18:32:27'),(6,1,'Excel','',1,5,1,'2026-04-26 18:32:27'),(7,1,'Examen Final','',1,6,1,'2026-04-26 18:32:27'),(8,2,'Scratch','',1,0,1,'2026-04-26 18:32:27'),(9,2,'Python','',1,1,1,'2026-04-26 18:32:27'),(10,2,'Parcial','',1,2,1,'2026-04-26 18:32:27'),(11,2,'C#','',1,3,1,'2026-04-26 18:32:27'),(12,2,'Examen Final','',1,4,1,'2026-04-26 18:32:27'),(13,3,'Photoshop','',1,0,1,'2026-04-26 18:32:27'),(14,3,'Illustrator','',1,1,1,'2026-04-26 18:32:27'),(15,3,'Parcial','',1,2,1,'2026-04-26 18:32:27'),(16,3,'Filmora','',1,3,1,'2026-04-26 18:32:27'),(17,3,'Examen Final','',1,4,1,'2026-04-26 18:32:27');
/*!40000 ALTER TABLE `dip_programas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `diplomado_notas`
--

DROP TABLE IF EXISTS `diplomado_notas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `diplomado_notas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `alumno_id` int NOT NULL,
  `anio` smallint NOT NULL,
  `materia` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nota` smallint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_dip_n` (`alumno_id`,`anio`,`materia`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `diplomado_notas`
--

LOCK TABLES `diplomado_notas` WRITE;
/*!40000 ALTER TABLE `diplomado_notas` DISABLE KEYS */;
/*!40000 ALTER TABLE `diplomado_notas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inscritos_tac`
--

DROP TABLE IF EXISTS `inscritos_tac`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inscritos_tac` (
  `id` int NOT NULL AUTO_INCREMENT,
  `alumno_id` int NOT NULL,
  `anio` smallint NOT NULL,
  `tac` tinyint NOT NULL,
  `estado` enum('inscrito','no_inscrito','pendiente') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'no_inscrito',
  `fecha_actualizacion` datetime DEFAULT NULL,
  `observaciones` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_inscritos_tac` (`alumno_id`,`anio`,`tac`),
  KEY `idx_inscritos_anio_tac` (`anio`,`tac`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inscritos_tac`
--

LOCK TABLES `inscritos_tac` WRITE;
/*!40000 ALTER TABLE `inscritos_tac` DISABLE KEYS */;
/*!40000 ALTER TABLE `inscritos_tac` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `instituciones`
--

DROP TABLE IF EXISTS `instituciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `instituciones` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `resolucion` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `ubicacion` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `extras` longtext COLLATE utf8mb4_unicode_ci,
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `instituciones`
--

LOCK TABLES `instituciones` WRITE;
/*!40000 ALTER TABLE `instituciones` DISABLE KEYS */;
/*!40000 ALTER TABLE `instituciones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mecanografia_notas`
--

DROP TABLE IF EXISTS `mecanografia_notas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mecanografia_notas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `alumno_id` int NOT NULL,
  `anio` smallint NOT NULL,
  `l1` smallint DEFAULT NULL,
  `l2` smallint DEFAULT NULL,
  `l3` smallint DEFAULT NULL,
  `l4` smallint DEFAULT NULL,
  `l5` smallint DEFAULT NULL,
  `l6` smallint DEFAULT NULL,
  `l7` smallint DEFAULT NULL,
  `l8` smallint DEFAULT NULL,
  `l9` smallint DEFAULT NULL,
  `l10` smallint DEFAULT NULL,
  `l11` smallint DEFAULT NULL,
  `l12` smallint DEFAULT NULL,
  `l13` smallint DEFAULT NULL,
  `l14` smallint DEFAULT NULL,
  `l15` smallint DEFAULT NULL,
  `l16` smallint DEFAULT NULL,
  `l17` smallint DEFAULT NULL,
  `l18` smallint DEFAULT NULL,
  `l19` smallint DEFAULT NULL,
  `l20` smallint DEFAULT NULL,
  `examen` smallint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_mec_n` (`alumno_id`,`anio`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mecanografia_notas`
--

LOCK TABLES `mecanografia_notas` WRITE;
/*!40000 ALTER TABLE `mecanografia_notas` DISABLE KEYS */;
/*!40000 ALTER TABLE `mecanografia_notas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mensualidades`
--

DROP TABLE IF EXISTS `mensualidades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mensualidades` (
  `id` int NOT NULL AUTO_INCREMENT,
  `alumno_id` int NOT NULL,
  `mes` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `anio` smallint NOT NULL,
  `monto` decimal(10,2) NOT NULL DEFAULT '0.00',
  `pagado` tinyint(1) NOT NULL DEFAULT '0',
  `anulado` tinyint(1) NOT NULL DEFAULT '0',
  `descuento_100` tinyint(1) NOT NULL DEFAULT '0',
  `no_recibo` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fecha_pago` date DEFAULT NULL,
  `monto_abonado` decimal(10,2) NOT NULL DEFAULT '0.00',
  `acreditado` tinyint(1) NOT NULL DEFAULT '0',
  `acreditado_msg` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_mens` (`alumno_id`,`mes`,`anio`)
) ENGINE=InnoDB AUTO_INCREMENT=3385 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mensualidades`
--

LOCK TABLES `mensualidades` WRITE;
/*!40000 ALTER TABLE `mensualidades` DISABLE KEYS */;
INSERT INTO `mensualidades` VALUES (1,1,'enero',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(2,1,'febrero',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(3,1,'marzo',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(4,1,'abril',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(5,1,'mayo',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(6,1,'junio',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(7,1,'julio',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(8,1,'agosto',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(9,1,'septiembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(10,1,'octubre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(11,1,'noviembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(12,1,'diciembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL);
/*!40000 ALTER TABLE `mensualidades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mis_tablas`
--

DROP TABLE IF EXISTS `mis_tablas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mis_tablas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci,
  `encabezado` text COLLATE utf8mb4_unicode_ci,
  `columnas` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `filas` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mis_tablas`
--

LOCK TABLES `mis_tablas` WRITE;
/*!40000 ALTER TABLE `mis_tablas` DISABLE KEYS */;
/*!40000 ALTER TABLE `mis_tablas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notas_tac_anual`
--

DROP TABLE IF EXISTS `notas_tac_anual`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notas_tac_anual` (
  `id` int NOT NULL AUTO_INCREMENT,
  `alumno_id` int NOT NULL,
  `anio` smallint NOT NULL,
  `nota1` smallint DEFAULT NULL,
  `nota2` smallint DEFAULT NULL,
  `nota3` smallint DEFAULT NULL,
  `nota4` smallint DEFAULT NULL,
  `tac` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_tac_a` (`alumno_id`,`anio`,`tac`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notas_tac_anual`
--

LOCK TABLES `notas_tac_anual` WRITE;
/*!40000 ALTER TABLE `notas_tac_anual` DISABLE KEYS */;
/*!40000 ALTER TABLE `notas_tac_anual` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `papeleria`
--

DROP TABLE IF EXISTS `papeleria`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `papeleria` (
  `id` int NOT NULL AUTO_INCREMENT,
  `no_recibo` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `alumno_id` int DEFAULT NULL,
  `descripcion` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `total` decimal(10,2) DEFAULT NULL,
  `observaciones` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `alumno_texto` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `anulado` tinyint(1) NOT NULL DEFAULT '0',
  `anulado_at` timestamp NULL DEFAULT NULL,
  `no_deposito` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `papeleria`
--

LOCK TABLES `papeleria` WRITE;
/*!40000 ALTER TABLE `papeleria` DISABLE KEYS */;
/*!40000 ALTER TABLE `papeleria` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_resets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `usuario_id` int NOT NULL,
  `token` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expira_at` datetime NOT NULL,
  `usado` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `token` (`token`),
  KEY `idx_pwres_user` (`usuario_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recibos`
--

DROP TABLE IF EXISTS `recibos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `recibos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `no_recibo` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `alumno_id` int DEFAULT NULL,
  `meses` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `total` decimal(10,2) DEFAULT NULL,
  `observaciones` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `descuento` decimal(10,2) NOT NULL DEFAULT '0.00',
  `alumno_texto` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `anulado` tinyint(1) NOT NULL DEFAULT '0',
  `anulado_at` timestamp NULL DEFAULT NULL,
  `no_deposito` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recibos`
--

LOCK TABLES `recibos` WRITE;
/*!40000 ALTER TABLE `recibos` DISABLE KEYS */;
/*!40000 ALTER TABLE `recibos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recibos_diplomados`
--

DROP TABLE IF EXISTS `recibos_diplomados`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `recibos_diplomados` (
  `id` int NOT NULL AUTO_INCREMENT,
  `no_recibo` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `alumno_id` int DEFAULT NULL,
  `diplomado` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `descripcion` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `total` decimal(10,2) DEFAULT NULL,
  `observaciones` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recibos_diplomados`
--

LOCK TABLES `recibos_diplomados` WRITE;
/*!40000 ALTER TABLE `recibos_diplomados` DISABLE KEYS */;
/*!40000 ALTER TABLE `recibos_diplomados` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuarios` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rol` enum('admin','alumno','oficina','maestro') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'alumno',
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuarios`
--

LOCK TABLES `usuarios` WRITE;
/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
INSERT INTO `usuarios` VALUES (1,'Admin m_lozano','admin@m_lozano.local','$2b$10$pnG5Q6BTKpatp/8UrO5zdeDTdZhiuwiMogFJnIMl1FML82aoqQMMq','admin',1,'2026-04-23 20:11:29'),(2,'Marcus Alexander Castillo de Leon','marcus01','$2b$10$D6Xur.VxiUchdIKQAKsvJ.bKgFUlYFaByAP/Vfa7bnXgje8OMsREC','alumno',1,'2026-04-23 20:23:58');
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'm_lozano'
--

--
-- Dumping routines for database 'm_lozano'
--

--
-- Current Database: `sistec_jutiapa`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `sistec_jutiapa` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `sistec_jutiapa`;

--
-- Table structure for table `alumnos`
--

DROP TABLE IF EXISTS `alumnos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `alumnos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `clave` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `codigo_estudiante` varchar(7) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nombre` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `apellido` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fecha_inicio` date DEFAULT NULL,
  `fecha_nacimiento` date DEFAULT NULL,
  `encargado` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `telefono` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `diplomado` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tac` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `asesor` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `direccion` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `establecimiento` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `observaciones` text COLLATE utf8mb4_unicode_ci,
  `dia_clases1` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dia_clases2` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `horario` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `laboratorio` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `estado` enum('activo','inactivo','retirado') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'activo',
  `cuota_mensual` decimal(10,2) NOT NULL DEFAULT '0.00',
  `usuario_id` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `codigo_estudiante` (`clave`),
  UNIQUE KEY `codigo_estudiante_2` (`codigo_estudiante`),
  CONSTRAINT `chk_codigo_estudiante` CHECK (((`codigo_estudiante` is null) or regexp_like(`codigo_estudiante`,_utf8mb4'^[A-Z][0-9]{3}[A-Z]{3}$')))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alumnos`
--

LOCK TABLES `alumnos` WRITE;
/*!40000 ALTER TABLE `alumnos` DISABLE KEYS */;
INSERT INTO `alumnos` VALUES (1,'01',NULL,'Carlos Misael','Mendoza Figeroa','2026-02-01','2010-12-01','Marta de Leon','41415151 58589595','Operador','1',NULL,'Jutiapa centro','Instituto Kjell Eugenio','','lunes','martes','7:00 a 10:00','1','activo',40.00,2,'2026-04-23 20:17:56');
/*!40000 ALTER TABLE `alumnos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `asistencia_semanal`
--

DROP TABLE IF EXISTS `asistencia_semanal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `asistencia_semanal` (
  `id` int NOT NULL AUTO_INCREMENT,
  `alumno_id` int NOT NULL,
  `anio` smallint NOT NULL,
  `mes` tinyint NOT NULL,
  `semana` tinyint NOT NULL,
  `estado` char(1) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_asist_sem` (`alumno_id`,`anio`,`mes`,`semana`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `asistencia_semanal`
--

LOCK TABLES `asistencia_semanal` WRITE;
/*!40000 ALTER TABLE `asistencia_semanal` DISABLE KEYS */;
/*!40000 ALTER TABLE `asistencia_semanal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `avisos`
--

DROP TABLE IF EXISTS `avisos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `avisos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `autor_id` int DEFAULT NULL,
  `autor_nombre` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `autor_rol` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `titulo` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mensaje` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `scope` enum('global','horario','laboratorio','diplomado','dia','alumno') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'global',
  `filtro_dia` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `filtro_horario` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `filtro_laboratorio` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `filtro_diplomado` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `filtro_alumno_id` int DEFAULT NULL,
  `expira_at` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_avisos_scope` (`scope`),
  KEY `idx_avisos_expira` (`expira_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `avisos`
--

LOCK TABLES `avisos` WRITE;
/*!40000 ALTER TABLE `avisos` DISABLE KEYS */;
/*!40000 ALTER TABLE `avisos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bitacora`
--

DROP TABLE IF EXISTS `bitacora`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bitacora` (
  `id` int NOT NULL AUTO_INCREMENT,
  `usuario_id` int DEFAULT NULL,
  `usuario_nombre` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Sistema',
  `accion` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `modulo` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci,
  `ip` varchar(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bitacora`
--

LOCK TABLES `bitacora` WRITE;
/*!40000 ALTER TABLE `bitacora` DISABLE KEYS */;
INSERT INTO `bitacora` VALUES (1,1,'Admin sistec_jutiapa','crear','Alumnos','Alumno creado: Carlos Misael Mendoza Figeroa (01)','::1','2026-04-23 20:17:56');
/*!40000 ALTER TABLE `bitacora` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cat_cuentas_bancarias`
--

DROP TABLE IF EXISTS `cat_cuentas_bancarias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cat_cuentas_bancarias` (
  `id` int NOT NULL AUTO_INCREMENT,
  `numero_cuenta` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nombre` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo_cuenta` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cat_cuentas_bancarias`
--

LOCK TABLES `cat_cuentas_bancarias` WRITE;
/*!40000 ALTER TABLE `cat_cuentas_bancarias` DISABLE KEYS */;
/*!40000 ALTER TABLE `cat_cuentas_bancarias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cat_cuotas`
--

DROP TABLE IF EXISTS `cat_cuotas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cat_cuotas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `monto` decimal(10,2) NOT NULL,
  `descripcion` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cat_cuotas`
--

LOCK TABLES `cat_cuotas` WRITE;
/*!40000 ALTER TABLE `cat_cuotas` DISABLE KEYS */;
INSERT INTO `cat_cuotas` VALUES (1,40.00,NULL,1,'2026-04-29 02:26:16');
/*!40000 ALTER TABLE `cat_cuotas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cat_establecimientos`
--

DROP TABLE IF EXISTS `cat_establecimientos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cat_establecimientos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nombre` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=176 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cat_establecimientos`
--

LOCK TABLES `cat_establecimientos` WRITE;
/*!40000 ALTER TABLE `cat_establecimientos` DISABLE KEYS */;
INSERT INTO `cat_establecimientos` VALUES (1,'Instituto Kjell Eugenio',1,'2026-04-29 02:26:16');
/*!40000 ALTER TABLE `cat_establecimientos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cat_horarios`
--

DROP TABLE IF EXISTS `cat_horarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cat_horarios` (
  `id` int NOT NULL AUTO_INCREMENT,
  `dia1` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dia2` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hora_inicio` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `hora_fin` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cat_horarios`
--

LOCK TABLES `cat_horarios` WRITE;
/*!40000 ALTER TABLE `cat_horarios` DISABLE KEYS */;
INSERT INTO `cat_horarios` VALUES (1,'lunes','martes','7:00','10:00',1,'2026-04-29 02:26:16');
/*!40000 ALTER TABLE `cat_horarios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cat_laboratorios`
--

DROP TABLE IF EXISTS `cat_laboratorios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cat_laboratorios` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nombre` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=176 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cat_laboratorios`
--

LOCK TABLES `cat_laboratorios` WRITE;
/*!40000 ALTER TABLE `cat_laboratorios` DISABLE KEYS */;
INSERT INTO `cat_laboratorios` VALUES (1,'1',1,'2026-04-29 02:26:16');
/*!40000 ALTER TABLE `cat_laboratorios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cierre_gastos`
--

DROP TABLE IF EXISTS `cierre_gastos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cierre_gastos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `cierre_id` int NOT NULL,
  `descripcion` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `monto` decimal(10,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id`),
  KEY `idx_cierre_gastos` (`cierre_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cierre_gastos`
--

LOCK TABLES `cierre_gastos` WRITE;
/*!40000 ALTER TABLE `cierre_gastos` DISABLE KEYS */;
/*!40000 ALTER TABLE `cierre_gastos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cierres_diarios`
--

DROP TABLE IF EXISTS `cierres_diarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cierres_diarios` (
  `id` int NOT NULL AUTO_INCREMENT,
  `modulo` enum('recibos','papeleria') COLLATE utf8mb4_unicode_ci NOT NULL,
  `fecha` date NOT NULL,
  `total_dia` decimal(10,2) NOT NULL DEFAULT '0.00',
  `total_gastos` decimal(10,2) NOT NULL DEFAULT '0.00',
  `total_depositar` decimal(10,2) NOT NULL DEFAULT '0.00',
  `cuenta_id` int DEFAULT NULL,
  `cuenta_snapshot` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ultimo_recibo` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `observaciones` text COLLATE utf8mb4_unicode_ci,
  `estado` enum('pendiente','revisado') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pendiente',
  `creado_por_id` int DEFAULT NULL,
  `creado_por_nombre` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `revisado_por_id` int DEFAULT NULL,
  `revisado_por_nombre` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `revisado_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_cierre` (`modulo`,`fecha`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cierres_diarios`
--

LOCK TABLES `cierres_diarios` WRITE;
/*!40000 ALTER TABLE `cierres_diarios` DISABLE KEYS */;
/*!40000 ALTER TABLE `cierres_diarios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `config_pagos`
--

DROP TABLE IF EXISTS `config_pagos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `config_pagos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `anio` int NOT NULL,
  `scope_tipo` enum('global','diplomado','horario','laboratorio','dia','alumno') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'global',
  `scope_valor` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mes_inicio` tinyint NOT NULL,
  `mes_fin` tinyint NOT NULL,
  `multiplicador` decimal(4,2) NOT NULL DEFAULT '1.00',
  `descripcion` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_cfg_anio` (`anio`),
  KEY `idx_cfg_scope` (`scope_tipo`,`scope_valor`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `config_pagos`
--

LOCK TABLES `config_pagos` WRITE;
/*!40000 ALTER TABLE `config_pagos` DISABLE KEYS */;
/*!40000 ALTER TABLE `config_pagos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `configuracion`
--

DROP TABLE IF EXISTS `configuracion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `configuracion` (
  `id` int NOT NULL AUTO_INCREMENT,
  `clave` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `valor` text COLLATE utf8mb4_unicode_ci,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `clave` (`clave`)
) ENGINE=InnoDB AUTO_INCREMENT=1129 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `configuracion`
--

LOCK TABLES `configuracion` WRITE;
/*!40000 ALTER TABLE `configuracion` DISABLE KEYS */;
INSERT INTO `configuracion` VALUES (1,'inst_nombre','EDUGUAT','2026-04-23 20:11:03'),(2,'inst_direccion','Ciudad de Guatemala, Guatemala','2026-04-23 20:11:03'),(3,'inst_telefono','Tel: 2222-3333','2026-04-23 20:11:03'),(4,'inst_email','','2026-04-23 20:11:03');
/*!40000 ALTER TABLE `configuracion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `constancia_plantillas`
--

DROP TABLE IF EXISTS `constancia_plantillas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `constancia_plantillas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ubicacion` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Guatemala',
  `saludo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Estimado(a) Director(a):',
  `cuerpo` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `despedida` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Atentamente,',
  `firma_nombre` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Secretaría',
  `firma_cargo` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mostrar_fecha` tinyint(1) NOT NULL DEFAULT '1',
  `mostrar_firma` tinyint(1) NOT NULL DEFAULT '1',
  `mostrar_telefono` tinyint(1) NOT NULL DEFAULT '1',
  `activa` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `espacio_post_encabezado` tinyint NOT NULL DEFAULT '3',
  `espacio_post_fecha` tinyint NOT NULL DEFAULT '2',
  `espacio_post_saludo` tinyint NOT NULL DEFAULT '1',
  `espacio_post_cuerpo` tinyint NOT NULL DEFAULT '2',
  `espacio_post_despedida` tinyint NOT NULL DEFAULT '3',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `constancia_plantillas`
--

LOCK TABLES `constancia_plantillas` WRITE;
/*!40000 ALTER TABLE `constancia_plantillas` DISABLE KEYS */;
INSERT INTO `constancia_plantillas` VALUES (1,'Constancia de Inscripción','Guatemala','A quien corresponda:','Por medio de la presente hacemos constar que el alumno(a) {{nombre_completo}}, estudiante del establecimiento {{establecimiento}}, se encuentra inscrito(a) actualmente en el curso de Tecnología {{tac}}, en el horario de {{horario}} los días {{dias}} en el laboratorio {{laboratorio}}.\n\nLa presente constancia se extiende a solicitud del interesado para los usos que estime convenientes.','Atentamente,','Secretaría','',1,1,1,1,'2026-04-29 21:07:24','2026-04-29 21:07:24',3,2,1,2,3);
/*!40000 ALTER TABLE `constancia_plantillas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dip_diplomado_objetivos`
--

DROP TABLE IF EXISTS `dip_diplomado_objetivos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dip_diplomado_objetivos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `diplomado_id` int NOT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `orden` smallint NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_dip_obj` (`diplomado_id`,`orden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dip_diplomado_objetivos`
--

LOCK TABLES `dip_diplomado_objetivos` WRITE;
/*!40000 ALTER TABLE `dip_diplomado_objetivos` DISABLE KEYS */;
/*!40000 ALTER TABLE `dip_diplomado_objetivos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dip_diplomados`
--

DROP TABLE IF EXISTS `dip_diplomados`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dip_diplomados` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `objetivo_general` text COLLATE utf8mb4_unicode_ci,
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dip_diplomados`
--

LOCK TABLES `dip_diplomados` WRITE;
/*!40000 ALTER TABLE `dip_diplomados` DISABLE KEYS */;
INSERT INTO `dip_diplomados` VALUES (1,'Operador Windows','',1,'2026-04-26 18:32:28'),(2,'Programador','',1,'2026-04-26 18:32:28'),(3,'Diseño Gráfico','',1,'2026-04-26 18:32:28');
/*!40000 ALTER TABLE `dip_diplomados` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dip_examenes`
--

DROP TABLE IF EXISTS `dip_examenes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dip_examenes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `diplomado_id` int NOT NULL,
  `nombre` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `orden` smallint NOT NULL DEFAULT '0',
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_dip_exam` (`diplomado_id`,`orden`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dip_examenes`
--

LOCK TABLES `dip_examenes` WRITE;
/*!40000 ALTER TABLE `dip_examenes` DISABLE KEYS */;
INSERT INTO `dip_examenes` VALUES (1,1,'Windows',0,1,'2026-04-26 20:24:33'),(2,1,'Word',1,1,'2026-04-26 20:24:33'),(3,1,'Publisher',2,1,'2026-04-26 20:24:33'),(4,1,'PowerPoint',3,1,'2026-04-26 20:24:33'),(5,1,'Parcial',4,1,'2026-04-26 20:24:33'),(6,1,'Excel',5,1,'2026-04-26 20:24:33'),(7,1,'Examen Final',6,1,'2026-04-26 20:24:33'),(8,2,'Scratch',0,1,'2026-04-26 20:24:33'),(9,2,'Python',1,1,'2026-04-26 20:24:33'),(10,2,'Parcial',2,1,'2026-04-26 20:24:33'),(11,2,'C#',3,1,'2026-04-26 20:24:33'),(12,2,'Examen Final',4,1,'2026-04-26 20:24:33'),(13,3,'Photoshop',0,1,'2026-04-26 20:24:33'),(14,3,'Illustrator',1,1,'2026-04-26 20:24:33'),(15,3,'Parcial',2,1,'2026-04-26 20:24:33'),(16,3,'Filmora',3,1,'2026-04-26 20:24:33'),(17,3,'Examen Final',4,1,'2026-04-26 20:24:33');
/*!40000 ALTER TABLE `dip_examenes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dip_programa_contenido`
--

DROP TABLE IF EXISTS `dip_programa_contenido`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dip_programa_contenido` (
  `id` int NOT NULL AUTO_INCREMENT,
  `programa_id` int NOT NULL,
  `semana_num` tinyint NOT NULL,
  `contenido` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_dip_prog_cont` (`programa_id`,`semana_num`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dip_programa_contenido`
--

LOCK TABLES `dip_programa_contenido` WRITE;
/*!40000 ALTER TABLE `dip_programa_contenido` DISABLE KEYS */;
/*!40000 ALTER TABLE `dip_programa_contenido` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dip_programa_objetivos`
--

DROP TABLE IF EXISTS `dip_programa_objetivos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dip_programa_objetivos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `programa_id` int NOT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `orden` smallint NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_prog_obj` (`programa_id`,`orden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dip_programa_objetivos`
--

LOCK TABLES `dip_programa_objetivos` WRITE;
/*!40000 ALTER TABLE `dip_programa_objetivos` DISABLE KEYS */;
/*!40000 ALTER TABLE `dip_programa_objetivos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dip_programas`
--

DROP TABLE IF EXISTS `dip_programas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dip_programas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `diplomado_id` int NOT NULL,
  `nombre` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `objetivo_general` text COLLATE utf8mb4_unicode_ci,
  `duracion_semanas` tinyint NOT NULL DEFAULT '1',
  `orden` smallint NOT NULL DEFAULT '0',
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_prog_dip` (`diplomado_id`,`orden`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dip_programas`
--

LOCK TABLES `dip_programas` WRITE;
/*!40000 ALTER TABLE `dip_programas` DISABLE KEYS */;
INSERT INTO `dip_programas` VALUES (1,1,'Windows','',1,0,1,'2026-04-26 18:32:28'),(2,1,'Word','',1,1,1,'2026-04-26 18:32:28'),(3,1,'Publisher','',1,2,1,'2026-04-26 18:32:28'),(4,1,'PowerPoint','',1,3,1,'2026-04-26 18:32:28'),(5,1,'Parcial','',1,4,1,'2026-04-26 18:32:28'),(6,1,'Excel','',1,5,1,'2026-04-26 18:32:28'),(7,1,'Examen Final','',1,6,1,'2026-04-26 18:32:28'),(8,2,'Scratch','',1,0,1,'2026-04-26 18:32:28'),(9,2,'Python','',1,1,1,'2026-04-26 18:32:28'),(10,2,'Parcial','',1,2,1,'2026-04-26 18:32:28'),(11,2,'C#','',1,3,1,'2026-04-26 18:32:28'),(12,2,'Examen Final','',1,4,1,'2026-04-26 18:32:28'),(13,3,'Photoshop','',1,0,1,'2026-04-26 18:32:28'),(14,3,'Illustrator','',1,1,1,'2026-04-26 18:32:28'),(15,3,'Parcial','',1,2,1,'2026-04-26 18:32:28'),(16,3,'Filmora','',1,3,1,'2026-04-26 18:32:28'),(17,3,'Examen Final','',1,4,1,'2026-04-26 18:32:28');
/*!40000 ALTER TABLE `dip_programas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `diplomado_notas`
--

DROP TABLE IF EXISTS `diplomado_notas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `diplomado_notas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `alumno_id` int NOT NULL,
  `anio` smallint NOT NULL,
  `materia` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nota` smallint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_dip_n` (`alumno_id`,`anio`,`materia`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `diplomado_notas`
--

LOCK TABLES `diplomado_notas` WRITE;
/*!40000 ALTER TABLE `diplomado_notas` DISABLE KEYS */;
/*!40000 ALTER TABLE `diplomado_notas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inscritos_tac`
--

DROP TABLE IF EXISTS `inscritos_tac`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inscritos_tac` (
  `id` int NOT NULL AUTO_INCREMENT,
  `alumno_id` int NOT NULL,
  `anio` smallint NOT NULL,
  `tac` tinyint NOT NULL,
  `estado` enum('inscrito','no_inscrito','pendiente') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'no_inscrito',
  `fecha_actualizacion` datetime DEFAULT NULL,
  `observaciones` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_inscritos_tac` (`alumno_id`,`anio`,`tac`),
  KEY `idx_inscritos_anio_tac` (`anio`,`tac`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inscritos_tac`
--

LOCK TABLES `inscritos_tac` WRITE;
/*!40000 ALTER TABLE `inscritos_tac` DISABLE KEYS */;
/*!40000 ALTER TABLE `inscritos_tac` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `instituciones`
--

DROP TABLE IF EXISTS `instituciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `instituciones` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `resolucion` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `ubicacion` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `extras` longtext COLLATE utf8mb4_unicode_ci,
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `instituciones`
--

LOCK TABLES `instituciones` WRITE;
/*!40000 ALTER TABLE `instituciones` DISABLE KEYS */;
/*!40000 ALTER TABLE `instituciones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mecanografia_notas`
--

DROP TABLE IF EXISTS `mecanografia_notas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mecanografia_notas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `alumno_id` int NOT NULL,
  `anio` smallint NOT NULL,
  `l1` smallint DEFAULT NULL,
  `l2` smallint DEFAULT NULL,
  `l3` smallint DEFAULT NULL,
  `l4` smallint DEFAULT NULL,
  `l5` smallint DEFAULT NULL,
  `l6` smallint DEFAULT NULL,
  `l7` smallint DEFAULT NULL,
  `l8` smallint DEFAULT NULL,
  `l9` smallint DEFAULT NULL,
  `l10` smallint DEFAULT NULL,
  `l11` smallint DEFAULT NULL,
  `l12` smallint DEFAULT NULL,
  `l13` smallint DEFAULT NULL,
  `l14` smallint DEFAULT NULL,
  `l15` smallint DEFAULT NULL,
  `l16` smallint DEFAULT NULL,
  `l17` smallint DEFAULT NULL,
  `l18` smallint DEFAULT NULL,
  `l19` smallint DEFAULT NULL,
  `l20` smallint DEFAULT NULL,
  `examen` smallint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_mec_n` (`alumno_id`,`anio`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mecanografia_notas`
--

LOCK TABLES `mecanografia_notas` WRITE;
/*!40000 ALTER TABLE `mecanografia_notas` DISABLE KEYS */;
/*!40000 ALTER TABLE `mecanografia_notas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mensualidades`
--

DROP TABLE IF EXISTS `mensualidades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mensualidades` (
  `id` int NOT NULL AUTO_INCREMENT,
  `alumno_id` int NOT NULL,
  `mes` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `anio` smallint NOT NULL,
  `monto` decimal(10,2) NOT NULL DEFAULT '0.00',
  `pagado` tinyint(1) NOT NULL DEFAULT '0',
  `anulado` tinyint(1) NOT NULL DEFAULT '0',
  `descuento_100` tinyint(1) NOT NULL DEFAULT '0',
  `no_recibo` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fecha_pago` date DEFAULT NULL,
  `monto_abonado` decimal(10,2) NOT NULL DEFAULT '0.00',
  `acreditado` tinyint(1) NOT NULL DEFAULT '0',
  `acreditado_msg` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_mens` (`alumno_id`,`mes`,`anio`)
) ENGINE=InnoDB AUTO_INCREMENT=3349 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mensualidades`
--

LOCK TABLES `mensualidades` WRITE;
/*!40000 ALTER TABLE `mensualidades` DISABLE KEYS */;
INSERT INTO `mensualidades` VALUES (1,1,'enero',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(2,1,'febrero',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(3,1,'marzo',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(4,1,'abril',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(5,1,'mayo',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(6,1,'junio',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(7,1,'julio',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(8,1,'agosto',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(9,1,'septiembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(10,1,'octubre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(11,1,'noviembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(12,1,'diciembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL);
/*!40000 ALTER TABLE `mensualidades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mis_tablas`
--

DROP TABLE IF EXISTS `mis_tablas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mis_tablas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci,
  `encabezado` text COLLATE utf8mb4_unicode_ci,
  `columnas` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `filas` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mis_tablas`
--

LOCK TABLES `mis_tablas` WRITE;
/*!40000 ALTER TABLE `mis_tablas` DISABLE KEYS */;
/*!40000 ALTER TABLE `mis_tablas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notas_tac_anual`
--

DROP TABLE IF EXISTS `notas_tac_anual`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notas_tac_anual` (
  `id` int NOT NULL AUTO_INCREMENT,
  `alumno_id` int NOT NULL,
  `anio` smallint NOT NULL,
  `nota1` smallint DEFAULT NULL,
  `nota2` smallint DEFAULT NULL,
  `nota3` smallint DEFAULT NULL,
  `nota4` smallint DEFAULT NULL,
  `tac` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_tac_a` (`alumno_id`,`anio`,`tac`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notas_tac_anual`
--

LOCK TABLES `notas_tac_anual` WRITE;
/*!40000 ALTER TABLE `notas_tac_anual` DISABLE KEYS */;
/*!40000 ALTER TABLE `notas_tac_anual` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `papeleria`
--

DROP TABLE IF EXISTS `papeleria`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `papeleria` (
  `id` int NOT NULL AUTO_INCREMENT,
  `no_recibo` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `alumno_id` int DEFAULT NULL,
  `descripcion` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `total` decimal(10,2) DEFAULT NULL,
  `observaciones` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `alumno_texto` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `anulado` tinyint(1) NOT NULL DEFAULT '0',
  `anulado_at` timestamp NULL DEFAULT NULL,
  `no_deposito` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `papeleria`
--

LOCK TABLES `papeleria` WRITE;
/*!40000 ALTER TABLE `papeleria` DISABLE KEYS */;
/*!40000 ALTER TABLE `papeleria` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_resets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `usuario_id` int NOT NULL,
  `token` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expira_at` datetime NOT NULL,
  `usado` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `token` (`token`),
  KEY `idx_pwres_user` (`usuario_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recibos`
--

DROP TABLE IF EXISTS `recibos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `recibos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `no_recibo` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `alumno_id` int DEFAULT NULL,
  `meses` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `total` decimal(10,2) DEFAULT NULL,
  `observaciones` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `descuento` decimal(10,2) NOT NULL DEFAULT '0.00',
  `alumno_texto` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `anulado` tinyint(1) NOT NULL DEFAULT '0',
  `anulado_at` timestamp NULL DEFAULT NULL,
  `no_deposito` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recibos`
--

LOCK TABLES `recibos` WRITE;
/*!40000 ALTER TABLE `recibos` DISABLE KEYS */;
/*!40000 ALTER TABLE `recibos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recibos_diplomados`
--

DROP TABLE IF EXISTS `recibos_diplomados`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `recibos_diplomados` (
  `id` int NOT NULL AUTO_INCREMENT,
  `no_recibo` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `alumno_id` int DEFAULT NULL,
  `diplomado` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `descripcion` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `total` decimal(10,2) DEFAULT NULL,
  `observaciones` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recibos_diplomados`
--

LOCK TABLES `recibos_diplomados` WRITE;
/*!40000 ALTER TABLE `recibos_diplomados` DISABLE KEYS */;
/*!40000 ALTER TABLE `recibos_diplomados` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuarios` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rol` enum('admin','alumno','oficina','maestro') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'alumno',
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuarios`
--

LOCK TABLES `usuarios` WRITE;
/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
INSERT INTO `usuarios` VALUES (1,'Admin sistec_jutiapa','admin@sistec_jutiapa.local','$2b$10$GliIf/AZ6Hs5v732pWh.auId7U5ZGvIUpeXEnYPJK5UPqEPanD2yW','admin',1,'2026-04-23 20:11:29'),(2,'Carlos Misael Mendoza Figeroa','carlos01','$2b$10$R/mz6lvz8q.nQtjcmC.36uWuHga0JNrCBUHcmuZGqdocNCaDVbO/a','alumno',1,'2026-04-23 20:17:56');
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'sistec_jutiapa'
--

--
-- Dumping routines for database 'sistec_jutiapa'
--

--
-- Current Database: `sistema_escolar`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `sistema_escolar` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `sistema_escolar`;

--
-- Table structure for table `alumnos`
--

DROP TABLE IF EXISTS `alumnos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `alumnos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `clave` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `codigo_estudiante` varchar(7) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nombre` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `apellido` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fecha_inicio` date DEFAULT NULL,
  `fecha_nacimiento` date DEFAULT NULL,
  `encargado` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `telefono` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `diplomado` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tac` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `asesor` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `direccion` text COLLATE utf8mb4_unicode_ci,
  `establecimiento` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `observaciones` text COLLATE utf8mb4_unicode_ci,
  `dia_clases1` enum('lunes','martes','miercoles','jueves','viernes','sabado','domingo') COLLATE utf8mb4_unicode_ci NOT NULL,
  `dia_clases2` enum('lunes','martes','miercoles','jueves','viernes','sabado','domingo') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `horario` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `laboratorio` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `estado` enum('activo','retirado') COLLATE utf8mb4_unicode_ci DEFAULT 'activo',
  `cuota_mensual` decimal(8,2) NOT NULL DEFAULT '0.00',
  `usuario_id` int DEFAULT NULL,
  `creado_en` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `codigo_estudiante` (`clave`),
  UNIQUE KEY `codigo_estudiante_2` (`codigo_estudiante`),
  KEY `usuario_id` (`usuario_id`),
  CONSTRAINT `alumnos_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`),
  CONSTRAINT `chk_codigo_estudiante` CHECK (((`codigo_estudiante` is null) or regexp_like(`codigo_estudiante`,_utf8mb4'^[A-Z][0-9]{3}[A-Z]{3}$')))
) ENGINE=InnoDB AUTO_INCREMENT=677 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alumnos`
--

LOCK TABLES `alumnos` WRITE;
/*!40000 ALTER TABLE `alumnos` DISABLE KEYS */;
INSERT INTO `alumnos` VALUES (1,'01',NULL,'Marcus Samuel','Santos de Leon','2026-02-01','2007-05-01','Byron de Leon','54341561','Técnico Operador','1',NULL,'Flores Costa Cuca','Instituto Aldea Galvez','','lunes',NULL,'07:00 a 10:00','Lab 1','activo',40.00,2,'2026-04-15 22:16:39'),(2,'02',NULL,'Rony Alexander','Castillo Lopez','2026-02-01','2026-08-04','Rony Castillo','54341561 - 41418048','Técnico Programador','2',NULL,'Génova Costa cuca','No estudia','','martes',NULL,'07:00 a 10:00','Lab 2','activo',75.00,3,'2026-04-15 22:41:54'),(3,'03',NULL,'Luis Fernando','Lopez Perez','2026-02-01','2007-06-12','Carlos Lopez','54340001','Técnico Operador','1',NULL,'Coatepeque','INEB','','lunes',NULL,'07:00 a 10:00','Lab 1','activo',50.00,2,'2026-04-17 19:54:18'),(4,'04',NULL,'Ana Sofia','Ramirez Diaz','2026-02-01','2008-03-22','Marta Ramirez','54340002','Técnico Programador','2',NULL,'Genova','Colegio','','martes',NULL,'07:00 a 10:00','Lab 2','activo',75.00,2,'2026-04-17 19:54:18'),(5,'05',NULL,'Jose Carlos','Mendez Ruiz','2026-02-01','2006-11-10','Luis Mendez','54340003','Técnico Operador','1',NULL,'Flores Costa Cuca','Instituto','','miercoles',NULL,'10:00 a 12:00','Lab 1','activo',40.00,2,'2026-04-17 19:54:18'),(6,'06',NULL,'Maria Fernanda','Castillo Lopez','2026-02-01','2007-08-19','Rosa Castillo','54340004','Técnico Programador','2',NULL,'Coatepeque','INEB','','jueves',NULL,'07:00 a 10:00','Lab 2','activo',80.00,2,'2026-04-17 19:54:18'),(7,'07','J123FKO','Kevin Daniel','Perez Gomez','2026-02-01','2005-09-05','Juan Perez','54340005','Técnico Operador','1',NULL,'Genova','Colegio','','viernes',NULL,'10:00 a 12:00','Lab 1','activo',50.00,2,'2026-04-17 19:54:18'),(8,'08','A141ABA','Andrea Lucia','Hernandez Soto','2026-02-01','2008-01-14','Luis Hernandez','54340006','Técnico Programador','2',NULL,'Coatepeque','INEB','','lunes',NULL,'07:00 a 10:00','Lab 2','activo',70.00,2,'2026-04-17 19:54:18'),(9,'09',NULL,'Brayan Estuardo','Diaz Lopez','2026-02-01','2006-04-25','Pedro Diaz','54340007','Técnico Operador','1',NULL,'Flores','Instituto','','martes',NULL,'10:00 a 12:00','Lab 1','activo',40.00,2,'2026-04-17 19:54:18'),(10,'10',NULL,'Sofia Alejandra','Morales Ruiz','2026-02-01','2007-02-18','Ana Morales','54340008','Técnico Programador','2',NULL,'Genova','Colegio','','miercoles',NULL,'07:00 a 10:00','Lab 2','activo',75.00,2,'2026-04-17 19:54:18'),(11,'11',NULL,'Daniel Alejandro','Vasquez Perez','2026-02-01','2005-12-01','Jose Vasquez','54340009','Técnico Operador','1',NULL,'Coatepeque','INEB','','jueves',NULL,'10:00 a 12:00','Lab 1','activo',50.00,2,'2026-04-17 19:54:18'),(12,'12',NULL,'Valeria Nicole','Lopez Garcia','2026-02-01','2008-06-30','Maria Lopez','54340010','Técnico Programador','2',NULL,'Genova','Colegio','','viernes',NULL,'07:00 a 10:00','Lab 2','activo',80.00,2,'2026-04-17 19:54:18'),(13,'13',NULL,'Oscar Eduardo','Gomez Diaz','2026-02-01','2007-07-11','Luis Gomez','54340011','Técnico Operador','1',NULL,'Flores','Instituto','','lunes',NULL,'10:00 a 12:00','Lab 1','activo',40.00,2,'2026-04-17 19:54:18'),(14,'14',NULL,'Karla Michelle','Perez Lopez','2026-02-01','2006-03-09','Ana Perez','54340012','Técnico Programador','2',NULL,'Coatepeque','INEB','','martes',NULL,'07:00 a 10:00','Lab 2','activo',75.00,2,'2026-04-17 19:54:18'),(15,'15',NULL,'Miguel Angel','Ramirez Soto','2026-02-01','2005-10-27','Carlos Ramirez','54340013','Técnico Operador','1',NULL,'Genova','Colegio','','miercoles',NULL,'10:00 a 12:00','Lab 1','activo',50.00,2,'2026-04-17 19:54:18'),(16,'16',NULL,'Fernanda Isabel','Morales Cruz','2026-02-01','2008-09-13','Luis Morales','54340014','Técnico Programador','2',NULL,'Flores','Instituto','','jueves',NULL,'07:00 a 10:00','Lab 2','activo',80.00,2,'2026-04-17 19:54:18'),(17,'17',NULL,'Jorge Luis','Diaz Perez','2026-02-01','2007-01-20','Pedro Diaz','54340015','Técnico Operador','1',NULL,'Coatepeque','INEB','','viernes',NULL,'10:00 a 12:00','Lab 1','activo',40.00,2,'2026-04-17 19:54:18'),(18,'18',NULL,'Andrea Paola','Castillo Ruiz','2026-02-01','2006-08-08','Rosa Castillo','54340016','Técnico Programador','2',NULL,'Genova','Colegio','','lunes',NULL,'07:00 a 10:00','Lab 2','activo',75.00,2,'2026-04-17 19:54:18'),(19,'19',NULL,'Cristian David','Hernandez Lopez','2026-02-01','2005-11-17','Juan Hernandez','54340017','Técnico Operador','1',NULL,'Flores','Instituto','','martes',NULL,'10:00 a 12:00','Lab 1','activo',50.00,2,'2026-04-17 19:54:18'),(20,'20',NULL,'Paola Andrea','Lopez Perez','2026-02-01','2008-02-25','Maria Lopez','54340018','Técnico Programador','2',NULL,'Coatepeque','INEB','','miercoles',NULL,'07:00 a 10:00','Lab 2','activo',80.00,2,'2026-04-17 19:54:18'),(21,'21',NULL,'Mario Esteban','Lopez Ramirez','2026-02-01','2007-04-12','Luis Lopez','54340102','Técnico Operador','1',NULL,'Coatepeque','INEB','','lunes',NULL,'07:00 a 10:00','Lab 1','activo',50.00,2,'2026-04-17 20:02:15'),(22,'22',NULL,'Daniela Sofia','Perez Gomez','2026-02-01','2008-06-18','Ana Perez','54340103','Técnico Programador','2',NULL,'Genova','Colegio','','lunes',NULL,'07:00 a 10:00','Lab 1','activo',75.00,2,'2026-04-17 20:02:15'),(23,'23',NULL,'Kevin Andres','Ramirez Diaz','2026-02-01','2006-09-03','Carlos Ramirez','54340104','Técnico Operador','1',NULL,'Flores','Instituto','','lunes',NULL,'07:00 a 10:00','Lab 1','activo',40.00,2,'2026-04-17 20:02:15'),(24,'24',NULL,'Lucia Fernanda','Morales Lopez','2026-02-01','2007-01-25','Maria Morales','54340105','Técnico Programador','2',NULL,'Coatepeque','INEB','','lunes',NULL,'07:00 a 10:00','Lab 1','activo',80.00,2,'2026-04-17 20:02:15'),(25,'25',NULL,'Jose Manuel','Castillo Perez','2026-02-01','2005-12-11','Pedro Castillo','54340106','Técnico Operador','1',NULL,'Genova','Colegio','','lunes',NULL,'07:00 a 10:00','Lab 1','activo',50.00,2,'2026-04-17 20:02:15'),(26,'26',NULL,'Andrea Nicole','Diaz Ruiz','2026-02-01','2008-03-30','Luis Diaz','54340107','Técnico Programador','2',NULL,'Flores','Instituto','','martes',NULL,'07:00 a 10:00','Lab 2','activo',75.00,2,'2026-04-17 20:02:15'),(27,'27',NULL,'Brayan Josue','Hernandez Lopez','2026-02-01','2007-07-21','Juan Hernandez','54340108','Técnico Operador','1',NULL,'Coatepeque','INEB','','martes',NULL,'07:00 a 10:00','Lab 2','activo',50.00,2,'2026-04-17 20:02:15'),(28,'28',NULL,'Sofia Daniela','Lopez Cruz','2026-02-01','2006-10-09','Ana Lopez','54340109','Técnico Programador','2',NULL,'Genova','Colegio','','martes',NULL,'07:00 a 10:00','Lab 2','activo',80.00,2,'2026-04-17 20:02:15'),(29,'29',NULL,'Carlos Eduardo','Perez Diaz','2026-02-01','2005-08-14','Luis Perez','54340110','Técnico Operador','1',NULL,'Flores','Instituto','','martes',NULL,'07:00 a 10:00','Lab 2','activo',40.00,2,'2026-04-17 20:02:15'),(30,'30',NULL,'Valeria Andrea','Ramirez Soto','2026-02-01','2008-02-27','Maria Ramirez','54340111','Técnico Programador','2',NULL,'Coatepeque','INEB','','martes',NULL,'07:00 a 10:00','Lab 2','activo',75.00,2,'2026-04-17 20:02:15'),(31,'31',NULL,'Miguel Angel','Morales Perez','2026-02-01','2007-05-19','Carlos Morales','54340112','Técnico Operador','1',NULL,'Genova','Colegio','','miercoles',NULL,'10:00 a 12:00','Lab 1','activo',50.00,2,'2026-04-17 20:02:15'),(32,'32',NULL,'Fernanda Isabel','Castillo Lopez','2026-02-01','2006-11-08','Ana Castillo','54340113','Técnico Programador','2',NULL,'Flores','Instituto','','miercoles',NULL,'10:00 a 12:00','Lab 1','activo',80.00,2,'2026-04-17 20:02:15'),(33,'33',NULL,'Jorge Luis','Diaz Ramirez','2026-02-01','2005-03-22','Pedro Diaz','54340114','Técnico Operador','1',NULL,'Coatepeque','INEB','','miercoles',NULL,'10:00 a 12:00','Lab 1','activo',40.00,2,'2026-04-17 20:02:15'),(34,'34',NULL,'Paola Andrea','Hernandez Soto','2026-02-01','2008-07-15','Luis Hernandez','54340115','Técnico Programador','2',NULL,'Genova','Colegio','','miercoles',NULL,'10:00 a 12:00','Lab 1','activo',75.00,2,'2026-04-17 20:02:15'),(35,'35',NULL,'Cristian David','Lopez Perez','2026-02-01','2007-01-03','Juan Lopez','54340116','Técnico Operador','1',NULL,'Flores','Instituto','','miercoles',NULL,'10:00 a 12:00','Lab 1','activo',50.00,2,'2026-04-17 20:02:15'),(36,'36',NULL,'Andrea Paola','Ramirez Cruz','2026-02-01','2006-06-10','Ana Ramirez','54340117','Técnico Programador','2',NULL,'Coatepeque','INEB','','jueves',NULL,'07:00 a 10:00','Lab 2','activo',80.00,2,'2026-04-17 20:02:15'),(37,'37',NULL,'Luis Fernando','Morales Soto','2026-02-01','2005-09-29','Luis Morales','54340118','Técnico Operador','1',NULL,'Genova','Colegio','','jueves',NULL,'07:00 a 10:00','Lab 2','activo',50.00,2,'2026-04-17 20:02:15'),(38,'38',NULL,'Karla Michelle','Diaz Perez','2026-02-01','2008-01-14','Maria Diaz','54340119','Técnico Programador','2',NULL,'Flores','Instituto','','jueves',NULL,'07:00 a 10:00','Lab 2','activo',75.00,2,'2026-04-17 20:02:15'),(39,'39',NULL,'Jose Carlos','Lopez Ruiz','2026-02-01','2007-08-08','Pedro Lopez','54340120','Técnico Operador','1',NULL,'Coatepeque','INEB','','jueves',NULL,'07:00 a 10:00','Lab 2','activo',40.00,2,'2026-04-17 20:02:15'),(40,'40',NULL,'Ana Lucia','Castillo Gomez','2026-02-01','2006-12-21','Ana Castillo','54340121','Técnico Programador','2',NULL,'Genova','Colegio','','jueves',NULL,'07:00 a 10:00','Lab 2','activo',80.00,2,'2026-04-17 20:02:15'),(41,'41',NULL,'Kevin Daniel','Ramirez Lopez','2026-02-01','2005-04-11','Carlos Ramirez','54340122','Técnico Operador','1',NULL,'Flores','Instituto','','viernes',NULL,'10:00 a 12:00','Lab 1','activo',50.00,2,'2026-04-17 20:02:15'),(42,'42',NULL,'Maria Fernanda','Perez Diaz','2026-02-01','2008-09-05','Maria Perez','54340123','Técnico Programador','2',NULL,'Coatepeque','INEB','','viernes',NULL,'10:00 a 12:00','Lab 1','activo',75.00,2,'2026-04-17 20:02:15'),(43,'43',NULL,'Brayan Estuardo','Morales Ruiz','2026-02-01','2007-02-16','Luis Morales','54340124','Técnico Operador','1',NULL,'Genova','Colegio','','viernes',NULL,'10:00 a 12:00','Lab 1','activo',40.00,2,'2026-04-17 20:02:15'),(44,'44',NULL,'Sofia Alejandra','Lopez Soto','2026-02-01','2006-10-30','Ana Lopez','54340125','Técnico Programador','2',NULL,'Flores','Instituto','','viernes',NULL,'10:00 a 12:00','Lab 1','activo',80.00,2,'2026-04-17 20:02:15'),(45,'45',NULL,'Carlos Andres','Diaz Cruz','2026-02-01','2005-07-19','Pedro Diaz','54340126','Técnico Operador','1',NULL,'Coatepeque','INEB','','viernes',NULL,'10:00 a 12:00','Lab 1','activo',50.00,2,'2026-04-17 20:02:15'),(46,'46',NULL,'Valeria Nicole','Ramirez Perez','2026-02-01','2008-03-01','Maria Ramirez','54340127','Técnico Programador','2',NULL,'Genova','Colegio','','lunes',NULL,'07:00 a 10:00','Lab 1','activo',75.00,2,'2026-04-17 20:02:15'),(47,'47',NULL,'Daniel Alejandro','Morales Diaz','2026-02-01','2007-11-23','Luis Morales','54340128','Técnico Operador','1',NULL,'Flores','Instituto','','martes',NULL,'07:00 a 10:00','Lab 2','activo',50.00,2,'2026-04-17 20:02:15'),(48,'48',NULL,'Fernanda Isabel','Lopez Ruiz','2026-02-01','2006-05-14','Ana Lopez','54340129','Técnico Programador','2',NULL,'Coatepeque','INEB','','miercoles',NULL,'10:00 a 12:00','Lab 1','activo',80.00,2,'2026-04-17 20:02:15'),(49,'49',NULL,'Jorge Luis','Perez Soto','2026-02-01','2005-01-28','Pedro Perez','54340130','Técnico Operador','1',NULL,'Genova','Colegio','','jueves',NULL,'07:00 a 10:00','Lab 2','activo',40.00,2,'2026-04-17 20:02:15'),(50,'50',NULL,'Paola Andrea','Diaz Lopez','2026-02-01','2008-08-17','Maria Diaz','54340131','Técnico Programador','2',NULL,'Flores','Instituto','','viernes',NULL,'10:00 a 12:00','Lab 1','activo',75.00,2,'2026-04-17 20:02:15'),(551,'51',NULL,'Diego Andres','Lopez Ramirez','2026-02-01','2007-03-12','Luis Lopez','54340132','Técnico Operador','1',NULL,'Coatepeque','INEB','','lunes',NULL,'07:00 a 10:00','Lab 1','activo',50.00,2,'2026-04-17 20:14:23'),(552,'52',NULL,'Camila Fernanda','Perez Gomez','2026-02-01','2008-07-18','Ana Perez','54340133','Técnico Programador','2',NULL,'Genova','Colegio','','lunes',NULL,'07:00 a 10:00','Lab 1','activo',75.00,2,'2026-04-17 20:14:23'),(553,'53',NULL,'Jose Alejandro','Ramirez Diaz','2026-02-01','2006-09-23','Carlos Ramirez','54340134','Técnico Operador','1',NULL,'Flores','Instituto','','lunes',NULL,'07:00 a 10:00','Lab 1','activo',40.00,2,'2026-04-17 20:14:23'),(554,'54',NULL,'Lucia Andrea','Morales Lopez','2026-02-01','2007-01-05','Maria Morales','54340135','Técnico Programador','2',NULL,'Coatepeque','INEB','','lunes',NULL,'07:00 a 10:00','Lab 1','activo',80.00,2,'2026-04-17 20:14:23'),(555,'55',NULL,'Carlos Manuel','Castillo Perez','2026-02-01','2005-12-19','Pedro Castillo','54340136','Técnico Operador','1',NULL,'Genova','Colegio','','lunes',NULL,'07:00 a 10:00','Lab 1','activo',50.00,2,'2026-04-17 20:14:23'),(556,'56',NULL,'Andrea Sofia','Diaz Ruiz','2026-02-01','2008-04-30','Luis Diaz','54340137','Técnico Programador','2',NULL,'Flores','Instituto','','martes',NULL,'07:00 a 10:00','Lab 2','activo',75.00,2,'2026-04-17 20:14:23'),(557,'57',NULL,'Brayan Daniel','Hernandez Lopez','2026-02-01','2007-06-11','Juan Hernandez','54340138','Técnico Operador','1',NULL,'Coatepeque','INEB','','martes',NULL,'07:00 a 10:00','Lab 2','activo',50.00,2,'2026-04-17 20:14:23'),(558,'58',NULL,'Sofia Isabel','Lopez Cruz','2026-02-01','2006-10-19','Ana Lopez','54340139','Técnico Programador','2',NULL,'Genova','Colegio','','martes',NULL,'07:00 a 10:00','Lab 2','activo',80.00,2,'2026-04-17 20:14:23'),(559,'59',NULL,'Carlos Daniel','Perez Diaz','2026-02-01','2005-07-24','Luis Perez','54340140','Técnico Operador','1',NULL,'Flores','Instituto','','martes',NULL,'07:00 a 10:00','Lab 2','activo',40.00,2,'2026-04-17 20:14:23'),(560,'60',NULL,'Valeria Sofia','Ramirez Soto','2026-02-01','2008-02-11','Maria Ramirez','54340141','Técnico Programador','2',NULL,'Coatepeque','INEB','','martes',NULL,'07:00 a 10:00','Lab 2','activo',75.00,2,'2026-04-17 20:14:23'),(561,'61',NULL,'Miguel Eduardo','Morales Perez','2026-02-01','2007-05-01','Carlos Morales','54340142','Técnico Operador','1',NULL,'Genova','Colegio','','miercoles',NULL,'10:00 a 12:00','Lab 1','activo',50.00,2,'2026-04-17 20:14:23'),(562,'62',NULL,'Fernanda Lucia','Castillo Lopez','2026-02-01','2006-11-28','Ana Castillo','54340143','Técnico Programador','2',NULL,'Flores','Instituto','','miercoles',NULL,'10:00 a 12:00','Lab 1','activo',80.00,2,'2026-04-17 20:14:23'),(563,'63',NULL,'Jorge Andres','Diaz Ramirez','2026-02-01','2005-03-02','Pedro Diaz','54340144','Técnico Operador','1',NULL,'Coatepeque','INEB','','miercoles',NULL,'10:00 a 12:00','Lab 1','activo',40.00,2,'2026-04-17 20:14:23'),(564,'64',NULL,'Paola Sofia','Hernandez Soto','2026-02-01','2008-07-25','Luis Hernandez','54340145','Técnico Programador','2',NULL,'Genova','Colegio','','miercoles',NULL,'10:00 a 12:00','Lab 1','activo',75.00,2,'2026-04-17 20:14:23'),(565,'65',NULL,'Cristian Andres','Lopez Perez','2026-02-01','2007-01-13','Juan Lopez','54340146','Técnico Operador','1',NULL,'Flores','Instituto','','miercoles',NULL,'10:00 a 12:00','Lab 1','activo',50.00,2,'2026-04-17 20:14:23'),(566,'66',NULL,'Andrea Lucia','Ramirez Cruz','2026-02-01','2006-06-20','Ana Ramirez','54340147','Técnico Programador','2',NULL,'Coatepeque','INEB','','jueves',NULL,'07:00 a 10:00','Lab 2','activo',80.00,2,'2026-04-17 20:14:23'),(567,'67',NULL,'Luis Carlos','Morales Soto','2026-02-01','2005-09-09','Luis Morales','54340148','Técnico Operador','1',NULL,'Genova','Colegio','','jueves',NULL,'07:00 a 10:00','Lab 2','activo',50.00,2,'2026-04-17 20:14:23'),(568,'68',NULL,'Karla Sofia','Diaz Perez','2026-02-01','2008-01-04','Maria Diaz','54340149','Técnico Programador','2',NULL,'Flores','Instituto','','jueves',NULL,'07:00 a 10:00','Lab 2','activo',75.00,2,'2026-04-17 20:14:23'),(569,'69',NULL,'Jose Daniel','Lopez Ruiz','2026-02-01','2007-08-28','Pedro Lopez','54340150','Técnico Operador','1',NULL,'Coatepeque','INEB','','jueves',NULL,'07:00 a 10:00','Lab 2','activo',40.00,2,'2026-04-17 20:14:23'),(570,'70',NULL,'Ana Sofia','Castillo Gomez','2026-02-01','2006-12-01','Ana Castillo','54340151','Técnico Programador','2',NULL,'Genova','Colegio','','jueves',NULL,'07:00 a 10:00','Lab 2','activo',80.00,2,'2026-04-17 20:14:23'),(571,'71',NULL,'Kevin Andres','Ramirez Lopez','2026-02-01','2005-04-21','Carlos Ramirez','54340152','Técnico Operador','1',NULL,'Flores','Instituto','','viernes',NULL,'10:00 a 12:00','Lab 1','activo',50.00,2,'2026-04-17 20:14:23'),(572,'72',NULL,'Maria Sofia','Perez Diaz','2026-02-01','2008-09-15','Maria Perez','54340153','Técnico Programador','2',NULL,'Coatepeque','INEB','','viernes',NULL,'10:00 a 12:00','Lab 1','activo',75.00,2,'2026-04-17 20:14:23'),(573,'73',NULL,'Brayan Eduardo','Morales Ruiz','2026-02-01','2007-02-06','Luis Morales','54340154','Técnico Operador','1',NULL,'Genova','Colegio','','viernes',NULL,'10:00 a 12:00','Lab 1','activo',40.00,2,'2026-04-17 20:14:23'),(574,'74',NULL,'Sofia Andrea','Lopez Soto','2026-02-01','2006-10-10','Ana Lopez','54340155','Técnico Programador','2',NULL,'Flores','Instituto','','viernes',NULL,'10:00 a 12:00','Lab 1','activo',80.00,2,'2026-04-17 20:14:23'),(575,'75',NULL,'Carlos Eduardo','Diaz Cruz','2026-02-01','2005-07-29','Pedro Diaz','54340156','Técnico Operador','1',NULL,'Coatepeque','INEB','','viernes',NULL,'10:00 a 12:00','Lab 1','activo',50.00,2,'2026-04-17 20:14:23'),(576,'76',NULL,'Valeria Fernanda','Ramirez Perez','2026-02-01','2008-03-11','Maria Ramirez','54340157','Técnico Programador','2',NULL,'Genova','Colegio','','lunes',NULL,'07:00 a 10:00','Lab 1','activo',75.00,2,'2026-04-17 20:14:23'),(577,'77',NULL,'Daniel Andres','Morales Diaz','2026-02-01','2007-11-03','Luis Morales','54340158','Técnico Operador','1',NULL,'Flores','Instituto','','martes',NULL,'07:00 a 10:00','Lab 2','activo',50.00,2,'2026-04-17 20:14:23'),(578,'78',NULL,'Fernanda Sofia','Lopez Ruiz','2026-02-01','2006-05-04','Ana Lopez','54340159','Técnico Programador','2',NULL,'Coatepeque','INEB','','miercoles',NULL,'10:00 a 12:00','Lab 1','activo',80.00,2,'2026-04-17 20:14:23'),(579,'79',NULL,'Jorge Daniel','Perez Soto','2026-02-01','2005-01-18','Pedro Perez','54340160','Técnico Operador','1',NULL,'Genova','Colegio','','jueves',NULL,'07:00 a 10:00','Lab 2','activo',40.00,2,'2026-04-17 20:14:23'),(580,'80',NULL,'Paola Sofia','Diaz Lopez','2026-02-01','2008-08-27','Maria Diaz','54340161','Técnico Programador','2',NULL,'Flores','Instituto','','viernes',NULL,'10:00 a 12:00','Lab 1','activo',75.00,2,'2026-04-17 20:14:23'),(581,'81',NULL,'Diego Alejandro','Lopez Ramirez','2026-02-01','2007-03-02','Luis Lopez','54340162','Técnico Operador','1',NULL,'Coatepeque','INEB','','lunes',NULL,'07:00 a 10:00','Lab 1','activo',50.00,2,'2026-04-17 20:14:23'),(582,'82',NULL,'Camila Sofia','Perez Gomez','2026-02-01','2008-07-08','Ana Perez','54340163','Técnico Programador','2',NULL,'Genova','Colegio','','lunes',NULL,'07:00 a 10:00','Lab 1','activo',75.00,2,'2026-04-17 20:14:23'),(583,'83',NULL,'Jose Daniel','Ramirez Diaz','2026-02-01','2006-09-13','Carlos Ramirez','54340164','Técnico Operador','1',NULL,'Flores','Instituto','','lunes',NULL,'07:00 a 10:00','Lab 1','activo',40.00,2,'2026-04-17 20:14:23'),(584,'84',NULL,'Lucia Sofia','Morales Lopez','2026-02-01','2007-01-15','Maria Morales','54340165','Técnico Programador','2',NULL,'Coatepeque','INEB','','lunes',NULL,'07:00 a 10:00','Lab 1','activo',80.00,2,'2026-04-17 20:14:23'),(585,'85',NULL,'Carlos Andres','Castillo Perez','2026-02-01','2005-12-09','Pedro Castillo','54340166','Técnico Operador','1',NULL,'Genova','Colegio','','lunes',NULL,'07:00 a 10:00','Lab 1','activo',50.00,2,'2026-04-17 20:14:23'),(586,'86',NULL,'Andrea Fernanda','Diaz Ruiz','2026-02-01','2008-04-10','Luis Diaz','54340167','Técnico Programador','2',NULL,'Flores','Instituto','','martes',NULL,'07:00 a 10:00','Lab 2','activo',75.00,2,'2026-04-17 20:14:23'),(587,'87',NULL,'Brayan Andres','Hernandez Lopez','2026-02-01','2007-06-01','Juan Hernandez','54340168','Técnico Operador','1',NULL,'Coatepeque','INEB','','martes',NULL,'07:00 a 10:00','Lab 2','activo',50.00,2,'2026-04-17 20:14:23'),(588,'88',NULL,'Sofia Fernanda','Lopez Cruz','2026-02-01','2006-10-29','Ana Lopez','54340169','Técnico Programador','2',NULL,'Genova','Colegio','','martes',NULL,'07:00 a 10:00','Lab 2','activo',80.00,2,'2026-04-17 20:14:23'),(589,'89',NULL,'Carlos Andres','Perez Diaz','2026-02-01','2005-07-14','Luis Perez','54340170','Técnico Operador','1',NULL,'Flores','Instituto','','martes',NULL,'07:00 a 10:00','Lab 2','activo',40.00,2,'2026-04-17 20:14:23'),(590,'90',NULL,'Valeria Andrea','Ramirez Soto','2026-02-01','2008-02-21','Maria Ramirez','54340171','Técnico Programador','2',NULL,'Coatepeque','INEB','','martes',NULL,'07:00 a 10:00','Lab 2','activo',75.00,2,'2026-04-17 20:14:23'),(591,'91',NULL,'Miguel Andres','Morales Perez','2026-02-01','2007-05-09','Carlos Morales','54340172','Técnico Operador','1',NULL,'Genova','Colegio','','miercoles',NULL,'10:00 a 12:00','Lab 1','activo',50.00,2,'2026-04-17 20:14:23'),(592,'92',NULL,'Fernanda Sofia','Castillo Lopez','2026-02-01','2006-11-18','Ana Castillo','54340173','Técnico Programador','2',NULL,'Flores','Instituto','','miercoles',NULL,'10:00 a 12:00','Lab 1','activo',80.00,2,'2026-04-17 20:14:23'),(593,'93',NULL,'Jorge Andres','Diaz Ramirez','2026-02-01','2005-03-12','Pedro Diaz','54340174','Técnico Operador','1',NULL,'Coatepeque','INEB','','miercoles',NULL,'10:00 a 12:00','Lab 1','activo',40.00,2,'2026-04-17 20:14:23'),(594,'94',NULL,'Paola Fernanda','Hernandez Soto','2026-02-01','2008-07-05','Luis Hernandez','54340175','Técnico Programador','2',NULL,'Genova','Colegio','','miercoles',NULL,'10:00 a 12:00','Lab 1','activo',75.00,2,'2026-04-17 20:14:23'),(595,'95',NULL,'Cristian Andres','Lopez Perez','2026-02-01','2007-01-23','Juan Lopez','54340176','Técnico Operador','1',NULL,'Flores','Instituto','','miercoles',NULL,'10:00 a 12:00','Lab 1','activo',50.00,2,'2026-04-17 20:14:23'),(596,'96',NULL,'Andrea Sofia','Ramirez Cruz','2026-02-01','2006-06-30','Ana Ramirez','54340177','Técnico Programador','2',NULL,'Coatepeque','INEB','','jueves',NULL,'07:00 a 10:00','Lab 2','activo',80.00,2,'2026-04-17 20:14:23'),(597,'97',NULL,'Luis Andres','Morales Soto','2026-02-01','2005-09-19','Luis Morales','54340178','Técnico Operador','1',NULL,'Genova','Colegio','','jueves',NULL,'07:00 a 10:00','Lab 2','activo',50.00,2,'2026-04-17 20:14:23'),(598,'98',NULL,'Karla Andrea','Diaz Perez','2026-02-01','2008-01-24','Maria Diaz','54340179','Técnico Programador','2',NULL,'Flores','Instituto','','jueves',NULL,'07:00 a 10:00','Lab 2','activo',75.00,2,'2026-04-17 20:14:23'),(600,'100',NULL,'Ana Fernanda','Castillo Gomez','2026-02-01','2006-12-11','Ana Castillo','54340181','Técnico Programador','2',NULL,'Genova','Colegio','','viernes',NULL,'10:00 a 12:00','Lab 1','retirado',80.00,2,'2026-04-17 20:14:23'),(601,'101',NULL,'Pedro Carlos','Mendoza Rodas','2026-02-01','2000-01-01','Juan Lopez','1212-1414 1515-6888','Técnico Operador','3',NULL,'Aldea Galvez','Instituto Aldea Galvez','','lunes','martes','2:00 a 5:00','Lab 1','activo',30.00,4,'2026-04-21 02:16:49'),(602,'102',NULL,'Carmen Juliana','Estrada Mejia','2026-01-05','2010-01-01','Carlos Estrada','5454-8989','Técnico Operador','1',NULL,'Flores Costa Cuca Centro','instituto la Florida','','martes',NULL,'07:00 a 10:00','Lab 1','activo',40.00,5,'2026-04-27 13:55:30'),(603,'103',NULL,'Fredy Ottoniel','Luarca Santizo','2026-01-01','2000-01-01','Carlos Santizo','85857474','Diseño Gráfico','2',NULL,'Flores Costa Cuca Centro','Instituto Aldea Galvez','','lunes',NULL,'07:00 a 10:00','Lab 1','activo',50.00,8,'2026-04-28 13:35:29'),(604,'104','A482QXM','Juan Carlos','García López','2026-02-01','2008-03-14','Juan García','55512345','Técnico Operador','1','Rony Castillo','Flores','INEB',NULL,'lunes',NULL,'07:00 a 10:00','Lab 1','activo',40.00,9,'2026-04-30 03:09:27'),(605,'105','A157LPT','María José','Hernández Pérez','2026-02-02','2008-11-27','María López','55512346','Técnico Operador','2','Ronaldo Garcia','Manantial','Instituto Aldea Galvez',NULL,'martes',NULL,'07:00 a 10:00','Lab 2','activo',50.00,10,'2026-04-30 03:09:27'),(606,'106','A936RKV','Luis Fernando','Martínez Ramírez','2026-02-03','2009-01-09','Carlos Hernández','55512347','Técnico Operador','3','Rony Castillo','Sequivilla','Instituto La Florida',NULL,'miercoles',NULL,'07:00 a 10:00','Lab 1','activo',40.00,11,'2026-04-30 03:09:28'),(607,'107','A204NBG','Ana Sofía','Rodríguez Morales','2026-02-04','2009-07-22','Ana Martínez','55512348','Técnico Operador','1','Ronaldo Garcia','Aldea la florida','INEB',NULL,'jueves',NULL,'07:00 a 10:00','Lab 2','activo',75.00,12,'2026-04-30 03:09:28'),(608,'108','A718WCF','Carlos Alberto','Sánchez Cruz','2026-02-05','2010-05-18','Luis Rodríguez','55512349','Técnico Operador','2','Rony Castillo','Flores','Instituto Aldea Galvez',NULL,'viernes',NULL,'07:00 a 10:00','Lab 1','activo',80.00,13,'2026-04-30 03:09:28'),(609,'109','A365JHY','Laura Isabel','Gómez Castillo','2026-02-06','2010-12-03','Sofía Pérez','55512350','Técnico Operador','3','Ronaldo Garcia','Manantial','Instituto La Florida',NULL,'domingo',NULL,'07:00 a 10:00','Lab 2','activo',75.00,14,'2026-04-30 03:09:28'),(610,'110','A890ZTR','José Manuel','Flores Díaz','2026-02-07','2011-02-11','Diego Sánchez','55512351','Técnico Operador','1','Rony Castillo','Sequivilla','INEB',NULL,'lunes',NULL,'07:00 a 10:00','Lab 1','activo',40.00,15,'2026-04-30 03:09:29'),(611,'111','A541DKP','Daniela Alejandra','Torres Hernández','2026-02-08','2011-09-29','Valeria Ramírez','55512352','Técnico Operador','2','Ronaldo Garcia','Aldea la florida','Instituto Aldea Galvez',NULL,'martes',NULL,'07:00 a 10:00','Lab 2','activo',50.00,16,'2026-04-30 03:09:29'),(612,'112','A276MXS','Miguel Ángel','Rivera López','2026-02-09','2012-04-07','José Torres','55512353','Técnico Operador','3','Rony Castillo','Flores','Instituto La Florida',NULL,'miercoles',NULL,'07:00 a 10:00','Lab 1','activo',40.00,17,'2026-04-30 03:09:29'),(613,'113','A803VQL','Andrea Carolina','Vargas Pérez','2026-02-10','2012-10-15','Camila Flores','55512354','Técnico Operador','1','Ronaldo Garcia','Manantial','INEB',NULL,'jueves',NULL,'07:00 a 10:00','Lab 2','activo',50.00,18,'2026-04-30 03:09:29'),(614,'114','A129FBR','Pedro Antonio','Mendoza Ruiz','2026-02-11','2013-01-26','Miguel Rivera','55512355','Técnico Programador','2','Rony Castillo','Sequivilla','Instituto Aldea Galvez',NULL,'viernes',NULL,'07:00 a 10:00','Lab 1','activo',40.00,19,'2026-04-30 03:09:30'),(615,'115','A674HTN','Camila Fernanda','Ortiz Castro','2026-02-12','2013-06-19','Daniela Gómez','55512356','Técnico Programador','3','Ronaldo Garcia','Aldea la florida','Instituto La Florida',NULL,'domingo',NULL,'07:00 a 10:00','Lab 2','activo',75.00,20,'2026-04-30 03:09:30'),(616,'116','A958CYW','Ricardo Andrés','Jiménez Soto','2026-02-13','2014-03-08','Andrés Díaz','55512357','Técnico Programador','1','Rony Castillo','Flores','INEB',NULL,'lunes',NULL,'07:00 a 10:00','Lab 1','activo',80.00,21,'2026-04-30 03:09:30'),(617,'117','A312PLM','Valeria Nicole','Reyes Aguilar','2026-02-14','2014-08-24','Fernanda Cruz','55512358','Técnico Programador','2','Ronaldo Garcia','Manantial','Instituto Aldea Galvez',NULL,'martes',NULL,'07:00 a 10:00','Lab 2','activo',75.00,22,'2026-04-30 03:09:30'),(618,'118','A487XDG','Diego Alejandro','Romero Méndez','2026-02-15','2015-02-14','Pedro Morales','55512359','Técnico Programador','3','Rony Castillo','Sequivilla','Instituto La Florida',NULL,'miercoles',NULL,'07:00 a 10:00','Lab 1','activo',40.00,23,'2026-04-30 03:09:31'),(619,'119','A721RJF','Sofía Gabriela','Herrera Morales','2026-02-16','2015-11-05','Gabriela Ortiz','55512360','Técnico Programador','1','Ronaldo Garcia','Aldea la florida','INEB',NULL,'jueves',NULL,'07:00 a 10:00','Lab 2','activo',50.00,24,'2026-04-30 03:09:31'),(620,'120','A165BVK','Jorge Eduardo','Castillo León','2026-02-17','2008-06-30','Ricardo Reyes','55512361','Técnico Programador','2','Rony Castillo','Flores','Instituto Aldea Galvez',NULL,'viernes',NULL,'07:00 a 10:00','Lab 1','activo',40.00,25,'2026-04-30 03:09:31'),(621,'121','A849QNS','Natalia Elizabeth','Rojas Cifuentes','2026-02-18','2009-09-12','Natalia Herrera','55512362','Técnico Programador','3','Ronaldo Garcia','Manantial','Instituto La Florida',NULL,'domingo',NULL,'07:00 a 10:00','Lab 2','activo',50.00,26,'2026-04-30 03:09:32'),(622,'122','A230WLT','Francisco Javier','Morales Vásquez','2026-02-19','2010-07-04','Jorge Castillo','55512363','Técnico Programador','1','Rony Castillo','Sequivilla','INEB',NULL,'lunes',NULL,'07:00 a 10:00','Lab 1','activo',40.00,27,'2026-04-30 03:09:32'),(623,'123','A596KCP','Paola Andrea','Cabrera Gómez','2026-02-20','2011-12-21','Paola Vargas','55512364','Técnico Programador','2','Ronaldo Garcia','Aldea la florida','Instituto Aldea Galvez',NULL,'martes',NULL,'07:00 a 10:00','Lab 2','activo',75.00,28,'2026-04-30 03:09:32'),(624,'124','A774YMH','Andrés Felipe','Navarro Sánchez','2026-02-21','2012-05-16','Manuel Mendoza','55512365','Técnico Programador','3','Rony Castillo','Flores','Instituto La Florida',NULL,'miercoles',NULL,'07:00 a 10:00','Lab 1','activo',80.00,29,'2026-04-30 03:09:32'),(625,'125','A418ZFV','Fernanda Lucía','Delgado Martínez','2026-02-22','2013-08-28','Alejandra Romero','55512366','Técnico Programador','1','Ronaldo Garcia','Manantial','INEB',NULL,'jueves',NULL,'07:00 a 10:00','Lab 2','activo',75.00,30,'2026-04-30 03:09:33'),(626,'126','A907TBR','Héctor Daniel','Salazar Ramírez','2026-02-23','2014-11-10','Sergio Aguilar','55512367','Diseño Gráfico','2','Rony Castillo','Sequivilla','Instituto Aldea Galvez',NULL,'viernes',NULL,'07:00 a 10:00','Lab 1','activo',40.00,31,'2026-04-30 03:09:33'),(627,'127','A653NXL','Gabriela Alejandra','Pineda Torres','2026-02-24','2015-04-02','Laura Navarro','55512368','Diseño Gráfico','3','Ronaldo Garcia','Aldea la florida','Instituto La Florida',NULL,'domingo',NULL,'07:00 a 10:00','Lab 2','activo',50.00,32,'2026-04-30 03:09:33'),(628,'128','A284GJD','Sergio Iván','Cruz Herrera','2026-02-25','2008-10-19','Francisco Delgado','55512369','Diseño Gráfico','1','Rony Castillo','Flores','INEB',NULL,'lunes',NULL,'07:00 a 10:00','Lab 1','activo',40.00,33,'2026-04-30 03:09:33'),(629,'129','A791PMC','Alejandra Beatriz','Fuentes López','2026-02-26','2009-04-25','Karla Salazar','55512370','Diseño Gráfico','2','Ronaldo Garcia','Manantial','Instituto Aldea Galvez',NULL,'martes',NULL,'07:00 a 10:00','Lab 2','activo',50.00,34,'2026-04-30 03:09:34'),(630,'130','A346HQS','Manuel Enrique','Chacón Rivera','2026-02-27','2010-09-14','Roberto Pineda','55512371','Diseño Gráfico','3','Rony Castillo','Sequivilla','Instituto La Florida',NULL,'miercoles',NULL,'07:00 a 10:00','Lab 1','activo',40.00,35,'2026-04-30 03:09:34'),(631,'131','A528LVR','Karla Patricia','Estrada Pérez','2026-02-28','2012-01-31','Verónica Estrada','55512372','Diseño Gráfico','1','Ronaldo Garcia','Aldea la florida','INEB',NULL,'jueves',NULL,'07:00 a 10:00','Lab 2','activo',75.00,36,'2026-04-30 03:09:34'),(632,'132','A862XKT','Roberto Nicolás','Aguilar Méndez','2026-02-11','2014-06-17','Héctor Fuentes','55512373','Diseño Gráfico','2','Rony Castillo','Flores','Instituto Aldea Galvez',NULL,'viernes',NULL,'07:00 a 10:00','Lab 1','activo',80.00,37,'2026-04-30 03:09:35'),(633,'133','A195DWN','Verónica Isabel','Velásquez Flores','2026-02-23','2015-07-23','Lucía Cabrera','55512374','Diseño Gráfico','3','Ronaldo Garcia','Manantial','Instituto La Florida',NULL,'domingo',NULL,'07:00 a 10:00','Lab 2','activo',75.00,38,'2026-04-30 03:09:35'),(654,'134',NULL,'Juan Carlos','Pérez López','2026-02-01','2008-03-14','Juan García','55512345','Técnico Operador','1','Rony Castillo','Flores','INEB',NULL,'lunes',NULL,'07:00 a 10:00','Lab 1','activo',40.00,59,'2026-04-30 03:54:46'),(655,'135',NULL,'María Fernanda','García Hernández','2026-02-02','2008-11-27','María López','55512346','Técnico Operador','2','Ronaldo Garcia','Manantial','Instituto Aldea Galvez',NULL,'martes',NULL,'07:00 a 10:00','Lab 2','activo',50.00,60,'2026-04-30 03:54:46'),(656,'136',NULL,'Luis Alberto','Rodríguez Morales','2026-02-03','2009-01-09','Carlos Hernández','55512347','Técnico Operador','3','Rony Castillo','Sequivilla','Instituto La Florida',NULL,'miercoles',NULL,'07:00 a 10:00','Lab 1','activo',40.00,61,'2026-04-30 03:54:46'),(657,'137',NULL,'Ana Sofía','Martínez Ramírez','2026-02-04','2009-07-22','Ana Martínez','55512348','Técnico Operador','1','Ronaldo Garcia','Aldea la florida','INEB',NULL,'jueves',NULL,'07:00 a 10:00','Lab 2','activo',75.00,62,'2026-04-30 03:54:46'),(658,'138',NULL,'Carlos Eduardo','Sánchez Gómez','2026-02-05','2010-05-18','Luis Rodríguez','55512349','Técnico Operador','2','Rony Castillo','Flores','Instituto Aldea Galvez',NULL,'viernes',NULL,'07:00 a 10:00','Lab 1','activo',80.00,63,'2026-04-30 03:54:46'),(659,'139',NULL,'Daniela Isabel','Flores Castillo','2026-02-06','2010-12-03','Sofía Pérez','55512350','Técnico Operador','3','Ronaldo Garcia','Manantial','Instituto La Florida',NULL,'domingo',NULL,'07:00 a 10:00','Lab 2','activo',75.00,64,'2026-04-30 03:54:47'),(660,'140',NULL,'José Miguel','Rivera Torres','2026-02-07','2011-02-11','Diego Sánchez','55512351','Técnico Operador','1','Rony Castillo','Sequivilla','INEB',NULL,'lunes',NULL,'07:00 a 10:00','Lab 1','activo',40.00,65,'2026-04-30 03:54:47'),(661,'141',NULL,'Laura Beatriz','Mendoza Cruz','2026-02-08','2011-09-29','Valeria Ramírez','55512352','Técnico Operador','2','Ronaldo Garcia','Aldea la florida','Instituto Aldea Galvez',NULL,'martes',NULL,'07:00 a 10:00','Lab 2','activo',50.00,66,'2026-04-30 03:54:47'),(662,'142',NULL,'Andrés Felipe','Herrera Vásquez','2026-02-09','2012-04-07','José Torres','55512353','Técnico Operador','3','Rony Castillo','Flores','Instituto La Florida',NULL,'miercoles',NULL,'07:00 a 10:00','Lab 1','activo',40.00,67,'2026-04-30 03:54:47'),(663,'143',NULL,'Camila Alejandra','Ortiz Romero','2026-02-10','2012-10-15','Camila Flores','55512354','Técnico Operador','1','Ronaldo Garcia','Manantial','INEB',NULL,'jueves',NULL,'07:00 a 10:00','Lab 2','activo',50.00,68,'2026-04-30 03:54:47'),(664,'144',NULL,'Kevin Alejandro','López Martínez','2026-02-01','2008-03-14','Juan García','55512345','Técnico Operador','1','Rony Castillo','Flores','INEB',NULL,'lunes',NULL,'07:00 a 10:00','Lab 1','activo',40.00,69,'2026-04-30 05:39:31'),(665,'145',NULL,'Valeria Nicole','Ramírez González','2026-02-02','2008-11-27','María López','55512346','Técnico Operador','2','Ronaldo Garcia','Manantial','Instituto Aldea Galvez',NULL,'martes',NULL,'07:00 a 10:00','Lab 2','activo',50.00,70,'2026-04-30 05:39:31'),(666,'146',NULL,'Diego Sebastián','Morales Castro','2026-02-03','2009-01-09','Carlos Hernández','55512347','Técnico Operador','3','Rony Castillo','Sequivilla','Instituto La Florida',NULL,'miercoles',NULL,'07:00 a 10:00','Lab 1','activo',40.00,71,'2026-04-30 05:39:32'),(667,'147',NULL,'Andrea Paola','Hernández Ruiz','2026-02-04','2009-07-22','Ana Martínez','55512348','Técnico Operador','1','Ronaldo Garcia','Aldea la florida','INEB',NULL,'jueves',NULL,'07:00 a 10:00','Lab 2','activo',75.00,72,'2026-04-30 05:39:32'),(668,'148',NULL,'Samuel Esteban','Pérez Aguilar','2026-02-05','2010-05-18','Luis Rodríguez','55512349','Técnico Operador','2','Rony Castillo','Flores','Instituto Aldea Galvez',NULL,'viernes',NULL,'07:00 a 10:00','Lab 1','activo',80.00,73,'2026-04-30 05:39:32'),(669,'149',NULL,'Natalia Fernanda','Castillo Mendoza','2026-02-06','2010-12-03','Sofía Pérez','55512350','Técnico Operador','3','Ronaldo Garcia','Manantial','Instituto La Florida',NULL,'domingo',NULL,'07:00 a 10:00','Lab 2','activo',75.00,74,'2026-04-30 05:39:33'),(670,'150',NULL,'Bryan Daniel','Torres Vásquez','2026-02-07','2011-02-11','Diego Sánchez','55512351','Técnico Operador','1','Rony Castillo','Sequivilla','INEB',NULL,'lunes',NULL,'07:00 a 10:00','Lab 1','activo',40.00,75,'2026-04-30 05:39:33'),(671,'151',NULL,'Sofía Gabriela','Gómez Rivera','2026-02-08','2011-09-29','Valeria Ramírez','55512352','Técnico Operador','2','Ronaldo Garcia','Aldea la florida','Instituto Aldea Galvez',NULL,'martes',NULL,'07:00 a 10:00','Lab 2','activo',50.00,76,'2026-04-30 05:39:33'),(672,'152',NULL,'Mateo Alejandro','Cruz Herrera','2026-02-09','2012-04-07','José Torres','55512353','Técnico Operador','3','Rony Castillo','Flores','Instituto La Florida',NULL,'miercoles',NULL,'07:00 a 10:00','Lab 1','activo',40.00,77,'2026-04-30 05:39:33'),(673,'153',NULL,'Isabella Lucía','Ortiz Flores','2026-02-10','2012-10-15','Camila Flores','55512354','Técnico Operador','1','Ronaldo Garcia','Manantial','INEB',NULL,'jueves',NULL,'07:00 a 10:00','Lab 2','activo',50.00,78,'2026-04-30 05:39:34'),(674,'154','A123XYZ','Ana Lucía','Pérez Méndez','2026-02-15','2008-09-03','Marta Méndez','55512345','Técnico Programador','1','Rony Castillo','Flores Costa cuca','INEB',NULL,'lunes','martes','10:00 a 11:30','Lab 1','activo',40.00,79,'2026-05-02 02:16:10'),(675,'155','D123JAJ','Erick Yovani','Lopez Rodas','2026-01-10','2026-10-08','Su mami del erick','46465454','Técnico Programador','3','Rony','Callejon manantial','No estudia','','viernes',NULL,'07:00 a 10:00','Lab 1','activo',30.00,80,'2026-05-07 03:10:43'),(676,'156',NULL,'Marcusito','Santos','2026-01-01','2008-08-30','a','54341561','Técnico Programador','2','Rony Castillo','Flores C.C Centro','INEB','','domingo',NULL,'07:00 a 10:00','Lab 1','activo',50.00,81,'2026-05-07 17:33:06');
/*!40000 ALTER TABLE `alumnos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `asistencia`
--

DROP TABLE IF EXISTS `asistencia`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `asistencia` (
  `id` int NOT NULL AUTO_INCREMENT,
  `alumno_id` int NOT NULL,
  `fecha` date NOT NULL,
  `estado` enum('asistio','enfermo','no_asistio','permiso') COLLATE utf8mb4_unicode_ci NOT NULL,
  `observacion` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_asistencia` (`alumno_id`,`fecha`),
  CONSTRAINT `asistencia_ibfk_1` FOREIGN KEY (`alumno_id`) REFERENCES `alumnos` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `asistencia`
--

LOCK TABLES `asistencia` WRITE;
/*!40000 ALTER TABLE `asistencia` DISABLE KEYS */;
INSERT INTO `asistencia` VALUES (1,2,'2026-04-16','asistio',NULL),(2,2,'2026-04-23','asistio',NULL);
/*!40000 ALTER TABLE `asistencia` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `asistencia_semanal`
--

DROP TABLE IF EXISTS `asistencia_semanal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `asistencia_semanal` (
  `id` int NOT NULL AUTO_INCREMENT,
  `alumno_id` int NOT NULL,
  `anio` smallint NOT NULL,
  `mes` tinyint NOT NULL,
  `semana` tinyint NOT NULL,
  `estado` char(1) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_asist_sem` (`alumno_id`,`anio`,`mes`,`semana`)
) ENGINE=InnoDB AUTO_INCREMENT=354 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `asistencia_semanal`
--

LOCK TABLES `asistencia_semanal` WRITE;
/*!40000 ALTER TABLE `asistencia_semanal` DISABLE KEYS */;
INSERT INTO `asistencia_semanal` VALUES (1,9,2026,1,1,'x'),(2,17,2026,1,1,'x'),(3,13,2026,1,1,'x'),(4,19,2026,1,1,'f'),(5,3,2026,1,1,'x'),(6,5,2026,1,1,'x'),(7,7,2026,1,1,'x'),(8,15,2026,1,1,'x'),(9,1,2026,1,1,'x'),(10,11,2026,1,1,'e'),(11,40,2026,1,1,'x'),(12,570,2026,1,2,'x'),(13,570,2026,1,1,'x'),(14,6,2026,1,2,'x'),(15,598,2026,1,3,'x'),(16,38,2026,1,4,'x'),(17,6,2026,1,1,'x'),(18,598,2026,1,1,'x'),(19,598,2026,1,2,'e'),(20,40,2026,1,2,'x'),(21,570,2026,1,3,'x'),(22,40,2026,1,3,'x'),(23,6,2026,1,3,'x'),(24,598,2026,12,5,'x'),(25,38,2026,1,1,'x'),(26,568,2026,1,2,'x'),(27,599,2026,1,1,'x'),(28,568,2026,1,1,'x'),(29,39,2026,1,1,'x'),(30,569,2026,1,1,'x'),(31,16,2026,1,1,'x'),(32,597,2026,1,1,'p'),(33,567,2026,1,1,'x'),(34,567,2026,1,2,'x'),(35,37,2026,1,1,'x'),(36,579,2026,1,1,'x'),(37,49,2026,1,1,'x'),(38,566,2026,1,1,'x'),(39,36,2026,1,1,'p'),(40,596,2026,1,1,'x'),(41,596,2026,1,2,'x'),(42,36,2026,1,2,'x'),(43,566,2026,1,2,'x'),(44,49,2026,1,2,'x'),(45,579,2026,1,2,'x'),(46,37,2026,1,2,'x'),(47,597,2026,1,2,'x'),(48,16,2026,1,2,'x'),(49,569,2026,1,2,'x'),(50,39,2026,1,2,'x'),(51,599,2026,1,2,'x'),(52,38,2026,1,2,'x'),(53,568,2026,1,3,'x'),(54,38,2026,1,3,'x'),(55,599,2026,1,3,'x'),(56,39,2026,1,4,'x'),(57,39,2026,1,3,'x'),(58,599,2026,1,4,'x'),(59,568,2026,1,4,'f'),(60,598,2026,1,4,'x'),(61,6,2026,1,4,'f'),(62,570,2026,1,4,'f'),(63,40,2026,1,4,'x'),(64,569,2026,1,3,'e'),(65,569,2026,1,4,'x'),(66,16,2026,1,3,'x'),(67,16,2026,1,4,'x'),(68,597,2026,1,3,'x'),(69,597,2026,1,4,'x'),(70,567,2026,1,3,'x'),(71,567,2026,1,4,'x'),(72,37,2026,1,3,'x'),(73,37,2026,1,4,'x'),(74,579,2026,1,3,'e'),(75,579,2026,1,4,'x'),(76,49,2026,1,3,'x'),(77,49,2026,1,4,'x'),(78,566,2026,1,3,'x'),(79,566,2026,1,4,'x'),(80,36,2026,1,3,'x'),(81,36,2026,1,4,'x'),(82,596,2026,1,3,'x'),(83,596,2026,1,4,'x'),(92,585,2026,1,1,'x'),(93,555,2026,1,1,'x'),(94,25,2026,1,1,'x'),(96,581,2026,1,1,'x'),(97,551,2026,1,1,'x'),(98,21,2026,1,1,'x'),(99,554,2026,1,1,'x'),(100,24,2026,1,1,'x'),(101,584,2026,1,1,'x'),(102,552,2026,1,1,'x'),(103,582,2026,1,1,'x'),(104,22,2026,1,1,'x'),(105,553,2026,1,1,'x'),(106,23,2026,1,1,'x'),(107,583,2026,1,1,'x'),(108,576,2026,1,1,'x'),(109,46,2026,1,1,'x'),(110,555,2026,1,2,'x'),(111,585,2026,1,2,'x'),(112,25,2026,1,2,'x'),(113,3,2026,1,2,'x'),(114,581,2026,1,2,'x'),(115,551,2026,1,2,'x'),(116,21,2026,1,2,'x'),(117,24,2026,1,2,'x'),(118,554,2026,1,2,'x'),(119,584,2026,1,2,'x'),(120,552,2026,1,2,'x'),(121,582,2026,1,2,'x'),(122,22,2026,1,2,'x'),(123,553,2026,1,2,'x'),(124,583,2026,1,2,'x'),(125,576,2026,1,2,'x'),(126,1,2026,1,2,'x'),(127,46,2026,1,2,'x'),(128,23,2026,1,2,'x'),(129,585,2026,1,5,'p'),(130,555,2026,1,5,'p'),(131,25,2026,1,5,'p'),(132,3,2026,1,5,'p'),(133,581,2026,1,5,'p'),(134,551,2026,1,5,'p'),(135,21,2026,1,5,'p'),(136,554,2026,1,5,'p'),(137,24,2026,1,5,'p'),(138,584,2026,1,5,'p'),(139,552,2026,1,5,'p'),(140,582,2026,1,5,'p'),(141,22,2026,1,5,'p'),(142,553,2026,1,5,'p'),(143,583,2026,1,5,'p'),(144,23,2026,1,5,'p'),(145,576,2026,1,5,'p'),(146,46,2026,1,5,'p'),(147,1,2026,1,5,'p'),(148,2,2026,1,1,'x'),(149,2,2026,1,2,'x'),(150,2,2026,1,3,'x'),(151,2,2026,1,4,'f'),(152,2,2026,2,1,'x'),(153,2,2026,2,2,'x'),(154,2,2026,2,3,'x'),(155,2,2026,2,4,'p'),(156,2,2026,3,1,'x'),(157,2,2026,3,2,'x'),(158,2,2026,3,3,'e'),(159,2,2026,3,4,'p'),(160,2,2026,4,2,'x'),(161,2,2026,4,3,'x'),(162,2,2026,4,4,'x'),(163,2,2026,4,1,'e'),(164,1,2026,1,3,'x'),(165,1,2026,1,4,'x'),(166,1,2026,2,1,'x'),(167,1,2026,2,2,'x'),(168,1,2026,2,3,'e'),(169,1,2026,2,4,'x'),(170,1,2026,3,2,'x'),(171,1,2026,3,3,'x'),(172,1,2026,3,1,'x'),(173,1,2026,3,4,'x'),(174,1,2026,4,2,'p'),(175,1,2026,4,3,'x'),(176,1,2026,4,1,'x'),(177,1,2026,4,4,'e'),(178,1,2026,5,1,'x'),(179,1,2026,5,2,'x'),(180,1,2026,5,3,'p'),(181,1,2026,5,4,'x'),(182,4,2026,1,1,'x'),(183,4,2026,1,2,'x'),(184,4,2026,1,3,'x'),(185,4,2026,1,4,'x'),(186,4,2026,2,1,'x'),(187,4,2026,2,2,'x'),(188,4,2026,2,3,'x'),(189,4,2026,2,4,'x'),(190,4,2026,3,1,'x'),(191,4,2026,3,2,'x'),(192,4,2026,3,3,'x'),(193,4,2026,3,4,'x'),(194,4,2026,4,1,'x'),(195,4,2026,4,2,'x'),(196,4,2026,4,3,'x'),(197,4,2026,4,4,'x'),(198,4,2026,4,5,'x'),(199,4,2026,5,1,'e'),(200,4,2026,5,2,'x'),(201,4,2026,5,3,'x'),(202,4,2026,5,4,'x'),(203,3,2026,4,3,'x'),(204,21,2026,4,3,'x'),(205,22,2026,4,3,'x'),(206,23,2026,4,3,'x'),(207,24,2026,4,3,'x'),(208,25,2026,4,3,'x'),(209,46,2026,4,3,'x'),(210,551,2026,4,3,'x'),(211,552,2026,4,3,'x'),(212,553,2026,4,3,'x'),(213,554,2026,4,3,'x'),(215,585,2026,4,3,'x'),(216,584,2026,4,3,'x'),(217,583,2026,4,3,'x'),(218,582,2026,4,3,'x'),(219,581,2026,4,3,'x'),(220,576,2026,4,3,'x'),(221,555,2026,4,3,'x'),(222,8,2026,4,3,'x'),(223,18,2026,4,3,'x'),(224,13,2026,4,3,'x'),(225,3,2026,1,3,'x'),(226,21,2026,1,3,'x'),(227,22,2026,1,3,'x'),(228,23,2026,1,3,'e'),(229,24,2026,1,3,'e'),(230,25,2026,1,3,'p'),(231,46,2026,1,3,'p'),(232,551,2026,1,3,'p'),(233,552,2026,1,3,'f'),(234,553,2026,1,3,'f'),(235,554,2026,1,3,'f'),(236,555,2026,1,3,'f'),(237,576,2026,1,3,'f'),(238,581,2026,1,3,'f'),(239,582,2026,1,3,'f'),(240,603,2026,1,1,'x'),(241,603,2026,1,2,'x'),(242,603,2026,1,3,'x'),(243,603,2026,1,4,'x'),(244,603,2026,2,1,'x'),(245,603,2026,2,2,'e'),(246,603,2026,2,3,'e'),(247,603,2026,2,4,'x'),(248,603,2026,3,2,'f'),(249,603,2026,3,3,'f'),(250,603,2026,3,1,'x'),(251,603,2026,3,4,'x'),(252,603,2026,4,2,'x'),(253,603,2026,4,1,'x'),(254,603,2026,4,3,'x'),(255,603,2026,4,4,'x'),(275,7,2026,5,1,'x'),(276,12,2026,5,1,'x'),(277,17,2026,5,1,'x'),(278,41,2026,5,1,'x'),(279,42,2026,5,1,'x'),(280,43,2026,5,1,'x'),(281,44,2026,5,1,'x'),(282,45,2026,5,1,'x'),(283,50,2026,5,1,'x'),(284,571,2026,5,1,'x'),(285,572,2026,5,1,'x'),(286,573,2026,5,1,'x'),(287,574,2026,5,1,'x'),(288,575,2026,5,1,'x'),(289,580,2026,5,1,'x'),(290,608,2026,5,1,'x'),(291,614,2026,5,1,'x'),(292,620,2026,5,1,'x'),(293,626,2026,5,1,'x'),(294,632,2026,5,1,'x'),(295,658,2026,5,1,'x'),(296,668,2026,5,1,'x'),(297,674,2026,1,1,'x'),(298,674,2026,1,2,'x'),(299,674,2026,1,3,'x'),(300,674,2026,1,4,'e'),(301,674,2026,2,1,'x'),(302,674,2026,2,2,'x'),(303,674,2026,2,3,'p'),(304,674,2026,2,4,'x'),(305,674,2026,3,1,'p'),(306,674,2026,3,2,'x'),(307,674,2026,3,3,'x'),(308,674,2026,3,4,'x'),(309,674,2026,4,1,'x'),(310,674,2026,4,2,'f'),(311,674,2026,4,3,'f'),(312,674,2026,4,4,'x'),(313,674,2026,5,1,'x'),(314,674,2026,5,2,'x'),(315,674,2026,5,3,'x'),(316,674,2026,5,4,'f'),(317,675,2026,1,2,'x'),(318,675,2026,1,3,'x'),(319,675,2026,1,4,'x'),(320,675,2026,1,5,'x'),(321,675,2026,2,1,'f'),(322,675,2026,2,2,'f'),(323,675,2026,2,3,'x'),(324,675,2026,2,4,'x'),(325,675,2026,3,1,'e'),(326,675,2026,3,2,'x'),(327,675,2026,3,3,'x'),(328,675,2026,3,4,'x'),(329,675,2026,4,1,'x'),(330,675,2026,4,2,'x'),(331,675,2026,4,3,'x'),(332,675,2026,4,4,'p'),(333,675,2026,5,1,'r'),(334,676,2026,1,1,'x'),(335,676,2026,1,2,'x'),(336,676,2026,1,3,'x'),(337,676,2026,1,4,'x'),(338,676,2026,2,1,'x'),(339,676,2026,2,2,'x'),(340,676,2026,2,3,'x'),(341,676,2026,2,4,'f'),(342,676,2026,3,1,'x'),(343,676,2026,3,2,'x'),(344,676,2026,3,3,'x'),(345,676,2026,3,4,'r'),(346,676,2026,4,1,'x'),(347,676,2026,4,2,'x'),(348,676,2026,4,3,'x'),(349,676,2026,4,4,'p'),(350,676,2026,5,2,'x'),(351,676,2026,5,3,'x'),(352,676,2026,5,4,'x'),(353,676,2026,5,1,'e');
/*!40000 ALTER TABLE `asistencia_semanal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `avisos`
--

DROP TABLE IF EXISTS `avisos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `avisos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `autor_id` int DEFAULT NULL,
  `autor_nombre` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `autor_rol` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `titulo` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mensaje` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `scope` enum('global','horario','laboratorio','diplomado','dia','alumno') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'global',
  `filtro_dia` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `filtro_horario` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `filtro_laboratorio` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `filtro_diplomado` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `filtro_alumno_id` int DEFAULT NULL,
  `expira_at` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_avisos_scope` (`scope`),
  KEY `idx_avisos_expira` (`expira_at`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `avisos`
--

LOCK TABLES `avisos` WRITE;
/*!40000 ALTER TABLE `avisos` DISABLE KEYS */;
INSERT INTO `avisos` VALUES (1,1,'Administrador','admin','Examen','El dia jueves hay examen, favor de no faltar a clases','dia','jueves',NULL,NULL,NULL,NULL,'2026-04-24','2026-04-28 13:29:18'),(2,1,'Administrador','admin','Grupos diseñadores','traer fotografias para poder trabajar los diseños','diplomado',NULL,NULL,NULL,'Diseño Gráfico',NULL,'2026-05-01','2026-04-28 13:45:23'),(3,1,'Administrador','admin','Rony','Mensaje para rony','alumno',NULL,NULL,NULL,NULL,2,'2026-04-29','2026-04-28 19:06:45'),(4,1,'Administrador','admin','Examenes','recordar que el jueves hay examenes','dia','jueves',NULL,NULL,NULL,NULL,'2026-04-30','2026-04-30 14:04:17'),(5,1,'Administrador','admin','Examen','examen el jueves','dia','jueves',NULL,NULL,NULL,NULL,'2026-05-01','2026-04-30 14:07:45'),(6,1,'Administrador','admin','Examen','Martes examen','dia','martes',NULL,NULL,NULL,NULL,'2026-06-02','2026-04-30 14:08:46'),(8,1,'Administrador','admin','Hola mundo','hola marcus, este es un aviso','alumno',NULL,NULL,NULL,NULL,676,'2026-05-08','2026-05-07 17:40:16');
/*!40000 ALTER TABLE `avisos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bitacora`
--

DROP TABLE IF EXISTS `bitacora`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bitacora` (
  `id` int NOT NULL AUTO_INCREMENT,
  `usuario_id` int DEFAULT NULL,
  `usuario_nombre` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Sistema',
  `accion` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `modulo` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci,
  `ip` varchar(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=310 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bitacora`
--

LOCK TABLES `bitacora` WRITE;
/*!40000 ALTER TABLE `bitacora` DISABLE KEYS */;
INSERT INTO `bitacora` VALUES (1,1,'Administrador','guardar','Asistencia','Asistencia guardada: 21 celdas año 2026','::1','2026-04-21 01:18:58'),(2,1,'Administrador','editar','Alumnos','Alumno editado ID 600: Ana Fernanda Castillo Gomez','::1','2026-04-21 01:42:37'),(3,1,'Administrador','guardar','Asistencia','Asistencia guardada: 19 celdas año 2026','::1','2026-04-21 01:48:22'),(4,1,'Administrador','guardar','Asistencia','Asistencia guardada: 2 celdas año 2026','::1','2026-04-21 01:48:38'),(5,1,'Administrador','guardar','Asistencia','Asistencia guardada: 1 celdas año 2026','::1','2026-04-21 01:48:50'),(6,1,'Administrador','crear','Alumnos','Alumno creado: Pedro Carlos Mendoza Rodas (101)','::1','2026-04-21 02:16:49'),(7,1,'Administrador','guardar','Notas TAC','Notas TAC guardadas: 1 cambios año 2026','::1','2026-04-21 02:18:08'),(8,1,'Administrador','editar','Recibos','Recibo actualizado ID 1: 1','::1','2026-04-21 20:20:27'),(9,1,'Administrador','editar','Recibos','Recibo actualizado ID 1: 1','::1','2026-04-21 20:21:38'),(10,1,'Administrador','editar','Alumnos','Alumno editado ID 2: Roni Alexanderr Castillo Lopez','::1','2026-04-21 20:24:04'),(11,1,'Administrador','crear','Recibos','Recibo creado: 6 alumno_id=3','::1','2026-04-21 20:25:27'),(12,1,'Administrador','crear','Recibos','Recibo creado: 7 alumno_id=6','::1','2026-04-21 20:25:45'),(13,1,'Administrador','crear','NuevoPago','Recibo 8 - 02 Roni Alexanderr Castillo Lopez - Julio-Abono 5 Agosto - Q80','::1','2026-04-22 01:50:02'),(14,1,'Administrador','crear','NuevoPago','Recibo 100 — 01 Marcus Samuel Santos de Leon — Enero — Q40','::1','2026-04-22 02:21:37'),(15,1,'Administrador','crear','NuevoPago','Recibo 101 — 01 Marcus Samuel Santos de Leon — Febrero - Marzo - Abril - Mayo — Q160','::1','2026-04-22 02:23:57'),(16,1,'Administrador','crear','NuevoPago','Recibo 102 — 01 Marcus Samuel Santos de Leon — Junio - Julio - Abono Q3 Agosto — Q83','::1','2026-04-22 02:25:09'),(17,1,'Administrador','crear','NuevoPago','Recibo 103 — 01 Marcus Samuel Santos de Leon — Agosto — Q37','::1','2026-04-22 02:28:39'),(18,1,'Administrador','crear','NuevoPago','Recibo 104 — 01 Marcus Samuel Santos de Leon — Septiembre - Abono Q5 Octubre — Q45','::1','2026-04-22 02:40:03'),(19,1,'Administrador','crear','Diplomados','Programa: Windows','::1','2026-04-22 03:03:00'),(20,1,'Administrador','crear','Diplomados','Programa: Word','::1','2026-04-22 14:51:37'),(21,1,'Administrador','crear','NuevoPago','Recibo 105 — 02 Roni Alexanderr Castillo Lopez — Enero - Febrero — Q150','::1','2026-04-22 17:45:28'),(22,1,'Administrador','crear','NuevoPago','Recibo 106 — 02 Roni Alexanderr Castillo Lopez — Marzo - Abril - Mayo - Abono Q5 Junio — Q230','::1','2026-04-22 17:46:51'),(23,1,'Administrador','crear','NuevoPago','Recibo 107 — 02 Roni Alexanderr Castillo Lopez — Junio - Julio — Q145','::1','2026-04-22 17:48:00'),(24,1,'Administrador','crear','Diplomados','Programa: publisher','::1','2026-04-22 17:53:58'),(25,1,'Administrador','crear','Mis Tablas','Tabla creada: USB','::1','2026-04-22 20:53:49'),(26,1,'Administrador','editar','Mis Tablas','Tabla editada ID 1: USB','::1','2026-04-22 20:53:50'),(27,1,'Administrador','editar','Mis Tablas','Tabla editada ID 1: USB','::1','2026-04-22 20:55:24'),(28,1,'Administrador','editar','Mis Tablas','Tabla editada ID 1: USB','::1','2026-04-22 20:56:06'),(29,1,'Administrador','editar','Mis Tablas','Tabla editada ID 1: USB','::1','2026-04-22 20:56:18'),(30,1,'Administrador','editar','Mis Tablas','Tabla editada ID 1: USB','::1','2026-04-22 20:56:30'),(31,1,'Administrador','editar','Mis Tablas','Tabla editada ID 1: USB','::1','2026-04-22 20:56:42'),(32,1,'Administrador','editar','Mis Tablas','Tabla editada ID 1: USB','::1','2026-04-22 20:56:51'),(33,1,'Administrador','editar','Mis Tablas','Tabla editada ID 1: USB','::1','2026-04-22 20:57:35'),(34,1,'Administrador','editar','Mis Tablas','Tabla editada ID 1: USB','::1','2026-04-22 20:57:38'),(35,1,'Administrador','editar','Mis Tablas','Tabla editada ID 1: USB','::1','2026-04-22 20:57:44'),(36,1,'Administrador','editar','Mis Tablas','Tabla editada ID 1: USB','::1','2026-04-22 20:58:02'),(37,1,'Administrador','editar','Mis Tablas','Tabla editada ID 1: USB','::1','2026-04-22 20:58:11'),(38,1,'Administrador','editar','Mis Tablas','Tabla editada ID 1: USB','::1','2026-04-22 20:58:23'),(39,1,'Administrador','editar','Mis Tablas','Tabla editada ID 1: USB','::1','2026-04-22 20:58:26'),(40,1,'Administrador','editar','Mis Tablas','Tabla editada ID 1: USB','::1','2026-04-22 20:58:43'),(41,1,'Administrador','editar','Mis Tablas','Tabla editada ID 1: USB','::1','2026-04-22 20:58:51'),(42,1,'Administrador','crear','Mis Tablas','Tabla creada: llamadas','::1','2026-04-22 20:59:19'),(43,1,'Administrador','editar','Mis Tablas','Tabla editada ID 2: llamadas','::1','2026-04-22 20:59:20'),(44,1,'Administrador','editar','Mis Tablas','Tabla editada ID 1: USB','::1','2026-04-22 21:02:34'),(45,1,'Administrador','editar','Mis Tablas','Tabla editada ID 1: USB','::1','2026-04-22 21:02:38'),(46,1,'Administrador','crear','NuevoPago','Recibo 108 — 03 Luis Fernando Lopez Perez — Enero - Febrero - Marzo - Abril - Abono Q48 Mayo — Q248','::1','2026-04-22 21:24:55'),(47,1,'Administrador','crear','Mis Tablas','Tabla creada: USB','::1','2026-04-22 21:28:54'),(48,1,'Administrador','editar','Mis Tablas','Tabla editada ID 3: USB','::1','2026-04-22 21:28:55'),(49,1,'Administrador','editar','Mis Tablas','Tabla editada ID 3: USB','::1','2026-04-22 21:29:08'),(50,1,'Administrador','editar','Mis Tablas','Tabla editada ID 3: USB','::1','2026-04-22 21:29:12'),(51,1,'Administrador','editar','Mis Tablas','Tabla editada ID 3: USB','::1','2026-04-22 21:29:15'),(52,1,'Administrador','editar','Mis Tablas','Tabla editada ID 3: USB','::1','2026-04-22 21:29:23'),(53,1,'Administrador','editar','Mis Tablas','Tabla editada ID 3: USB','::1','2026-04-22 21:29:27'),(54,1,'Administrador','editar','Mis Tablas','Tabla editada ID 3: USB','::1','2026-04-22 21:29:31'),(55,1,'Administrador','editar','Mis Tablas','Tabla editada ID 3: USB','::1','2026-04-22 21:29:36'),(56,1,'Administrador','editar','Mis Tablas','Tabla editada ID 3: USB','::1','2026-04-22 21:29:38'),(57,1,'Administrador','editar','Mis Tablas','Tabla editada ID 3: USB','::1','2026-04-22 21:29:49'),(58,1,'Administrador','crear','Recibos','Recibo creado: 109 alumno_id=2','::1','2026-04-22 21:39:13'),(59,1,'Administrador','guardar','Mensualidades','Grid mensualidades guardado: 1 cambios año 2026','::1','2026-04-22 21:39:33'),(60,1,'Administrador','crear','NuevoPago','Recibo 110 — 02 Roni Alexanderr Castillo Lopez — Abono Q35 Septiembre — Q35','::1','2026-04-22 21:40:43'),(61,1,'Administrador','crear','Recibos','Recibo creado: 111 alumno_id=2','::1','2026-04-22 21:41:45'),(62,1,'Administrador','guardar','Mensualidades','Grid mensualidades guardado: 1 cambios año 2026','::1','2026-04-22 21:42:30'),(63,1,'Administrador','editar','Recibos','Recibo actualizado ID 20: 111','::1','2026-04-22 21:44:01'),(64,1,'Administrador','crear','NuevoPago','Recibo 112 — 02 Roni Alexanderr Castillo Lopez — Octubre — Q75','::1','2026-04-22 21:44:29'),(65,1,'Administrador','crear','NuevoPago','Recibo 113 — 02 Roni Alexanderr Castillo Lopez — Abono Q35 Noviembre — Q35','::1','2026-04-22 21:45:07'),(66,1,'Administrador','crear','NuevoPago','Recibo 114 — 02 Roni Alexanderr Castillo Lopez — Abono Q70 Noviembre — Q35','::1','2026-04-22 21:45:41'),(67,1,'Administrador','crear','NuevoPago','Recibo 115 — 02 Roni Alexanderr Castillo Lopez — Noviembre — Q5','::1','2026-04-22 21:46:44'),(68,1,'Administrador','eliminar','Recibos','Recibo eliminado ID 23','::1','2026-04-22 21:48:14'),(69,1,'Administrador','eliminar','Recibos','Recibo eliminado ID 24','::1','2026-04-22 21:48:56'),(70,1,'Administrador','guardar','Mensualidades','Grid mensualidades guardado: 1 cambios año 2026','::1','2026-04-22 21:49:48'),(71,1,'Administrador','crear','Mis Tablas','Tabla creada: proyecto calendario','::1','2026-04-23 02:27:00'),(72,1,'Administrador','editar','Mis Tablas','Tabla editada ID 4: proyecto calendario','::1','2026-04-23 02:27:01'),(73,1,'Administrador','crear','Mis Tablas','Tabla creada: sdfasdf','::1','2026-04-23 02:27:22'),(74,1,'Administrador','editar','Mis Tablas','Tabla editada ID 5: sdfasdf','::1','2026-04-23 02:27:23'),(75,1,'Administrador','editar','Mis Tablas','Tabla editada ID 5: sdfasdf','::1','2026-04-23 02:27:43'),(76,1,'Administrador','editar','Mis Tablas','Tabla editada ID 5: sdfasdf','::1','2026-04-23 02:27:46'),(77,1,'Administrador','editar','Mis Tablas','Tabla editada ID 5: sdfasdf','::1','2026-04-23 02:27:50'),(78,1,'Administrador','editar','Mis Tablas','Tabla editada ID 5: sdfasdf','::1','2026-04-23 02:27:55'),(79,1,'Administrador','editar','Mis Tablas','Tabla editada ID 5: sdfasdf','::1','2026-04-23 02:28:06'),(80,1,'Administrador','editar','Mis Tablas','Tabla editada ID 5: sdfasdf','::1','2026-04-23 02:28:09'),(81,1,'Administrador','editar','Mis Tablas','Tabla editada ID 5: sdfasdf','::1','2026-04-23 02:28:15'),(82,1,'Administrador','crear','NuevoPago','Recibo 114 — 04 Ana Sofia Ramirez Diaz — Enero - Febrero — Q150','::1','2026-04-23 02:29:27'),(83,1,'Administrador','crear','NuevoPago','Recibo 115 — 05 Jose Carlos Mendez Ruiz — Enero - Abono Q10 Febrero — Q50','::1','2026-04-23 21:45:58'),(84,1,'Administrador','crear','NuevoPago','Recibo 116 — 13 Oscar Eduardo Gomez Diaz — Enero - Febrero - Marzo - Abono Q30 Abril — Q150','::1','2026-04-23 21:47:00'),(85,1,'Administrador','eliminar','Mis Tablas','Tabla eliminada ID 5','::1','2026-04-23 22:28:30'),(86,1,'Administrador','eliminar','Mis Tablas','Tabla eliminada ID 4','::1','2026-04-23 22:28:33'),(87,1,'Administrador','eliminar','Mis Tablas','Tabla eliminada ID 3','::1','2026-04-23 22:28:35'),(88,1,'Administrador','eliminar','Mis Tablas','Tabla eliminada ID 2','::1','2026-04-23 22:28:38'),(89,1,'Administrador','eliminar','Mis Tablas','Tabla eliminada ID 1','::1','2026-04-23 22:28:40'),(90,1,'Administrador','crear','NuevoPago','Recibo 117 — 17 Jorge Luis Diaz Perez — Enero - Febrero - Marzo - Abril - Mayo - Junio — Q240','::1','2026-04-23 22:29:02'),(91,1,'Administrador','guardar','Asistencia','Asistencia guardada: 15 celdas año 2026','::1','2026-04-24 20:51:19'),(92,1,'Administrador','guardar','Notas TAC','Notas TAC guardadas: 1 cambios año 2026','::1','2026-04-24 20:52:33'),(93,1,'Administrador','crear','NuevoPago','Recibo 118 — 07 Kevin Daniel Perez Gomez — Enero - Febrero - Marzo — Q150','::1','2026-04-24 21:02:31'),(94,1,'Administrador','crear','NuevoPago','Recibo 119 — 07 Kevin Daniel Perez Gomez — Abril - Mayo - Abono Q20 Junio — Q120','::1','2026-04-24 21:07:53'),(95,1,'Administrador','crear','NuevoPago','Recibo 120 — 07 Kevin Daniel Perez Gomez — Junio - Julio — Q80','::1','2026-04-24 21:09:04'),(96,1,'Administrador','crear','Mis Tablas','Tabla creada: Proyecto USB','::1','2026-04-24 21:21:23'),(97,1,'Administrador','editar','Mis Tablas','Tabla editada ID 6: Proyecto USB','::1','2026-04-24 21:21:24'),(98,1,'Administrador','editar','Mis Tablas','Tabla editada ID 6: Proyecto USB','::1','2026-04-24 21:21:49'),(99,1,'Administrador','editar','Mis Tablas','Tabla editada ID 6: Proyecto USB','::1','2026-04-24 21:21:52'),(100,1,'Administrador','editar','Mis Tablas','Tabla editada ID 6: Proyecto USB','::1','2026-04-24 21:21:55'),(101,1,'Administrador','editar','Mis Tablas','Tabla editada ID 6: Proyecto USB','::1','2026-04-24 21:21:58'),(102,1,'Administrador','editar','Mis Tablas','Tabla editada ID 6: Proyecto USB','::1','2026-04-24 21:22:17'),(103,1,'Administrador','editar','Mis Tablas','Tabla editada ID 6: Proyecto USB','::1','2026-04-24 21:22:23'),(104,1,'Administrador','editar','Mis Tablas','Tabla editada ID 6: Proyecto USB','::1','2026-04-24 21:22:25'),(105,1,'Administrador','editar','Mis Tablas','Tabla editada ID 6: Proyecto USB','::1','2026-04-24 21:22:27'),(106,1,'Administrador','editar','Mis Tablas','Tabla editada ID 6: Proyecto USB','::1','2026-04-24 21:22:55'),(107,1,'Administrador','editar','Mis Tablas','Tabla editada ID 6: Proyecto USB','::1','2026-04-24 21:23:05'),(108,1,'Administrador','editar','Mis Tablas','Tabla editada ID 6: Proyecto USB','::1','2026-04-24 21:23:12'),(109,1,'Administrador','editar','Mis Tablas','Tabla editada ID 6: Proyecto USB','::1','2026-04-24 21:23:17'),(110,1,'Administrador','editar','Mis Tablas','Tabla editada ID 6: Proyecto USB','::1','2026-04-24 21:23:19'),(111,1,'Administrador','editar','Mis Tablas','Tabla editada ID 6: Proyecto USB','::1','2026-04-24 21:23:23'),(112,1,'Administrador','editar','Mis Tablas','Tabla editada ID 6: Proyecto USB','::1','2026-04-24 21:23:28'),(113,1,'Administrador','editar','Mis Tablas','Tabla editada ID 6: Proyecto USB','::1','2026-04-24 21:23:39'),(114,1,'Administrador','editar','Mis Tablas','Tabla editada ID 6: Proyecto USB','::1','2026-04-24 21:23:45'),(115,1,'Administrador','editar','Mis Tablas','Tabla editada ID 6: Proyecto USB','::1','2026-04-24 21:23:49'),(116,1,'Administrador','editar','Mis Tablas','Tabla editada ID 6: Proyecto USB','::1','2026-04-24 21:23:53'),(117,1,'Administrador','editar','Mis Tablas','Tabla editada ID 6: Proyecto USB','::1','2026-04-24 21:23:57'),(118,1,'Administrador','editar','Mis Tablas','Tabla editada ID 6: Proyecto USB','::1','2026-04-24 21:24:12'),(119,1,'Administrador','editar','Mis Tablas','Tabla editada ID 6: Proyecto USB','::1','2026-04-24 21:24:33'),(120,1,'Administrador','editar','Mis Tablas','Tabla editada ID 6: Proyecto USB','::1','2026-04-24 21:24:38'),(121,1,'Administrador','editar','Mis Tablas','Tabla editada ID 6: Proyecto USB','::1','2026-04-24 21:24:52'),(122,1,'Administrador','editar','Mis Tablas','Tabla editada ID 6: Proyecto USB','::1','2026-04-24 21:25:06'),(123,1,'Administrador','editar','Alumnos','Alumno editado ID 2: Rony Alexander Castillo Lopez','::1','2026-04-24 21:32:57'),(124,1,'Administrador','crear','Catálogos','Cuota: Q40 (—)','::1','2026-04-26 13:45:38'),(125,1,'Administrador','crear','Catálogos','Cuota: Q50 (—)','::1','2026-04-26 13:45:44'),(126,1,'Administrador','crear','Catálogos','nombre: Instituto Aldea Galvez','::1','2026-04-26 13:45:57'),(127,1,'Administrador','crear','Catálogos','nombre: instituto la Florida','::1','2026-04-26 13:46:10'),(128,1,'Administrador','crear','Catálogos','Horario: lunes 07:00 a 12:00','::1','2026-04-26 13:46:46'),(129,1,'Administrador','crear','Catálogos','Horario: martes 07:00 a 12:00','::1','2026-04-26 13:47:01'),(130,1,'Administrador','crear','Catálogos','Horario: lunes-martes 10:00 a 11:30','::1','2026-04-26 13:47:19'),(131,1,'Administrador','crear','Catálogos','nombre: 1','::1','2026-04-26 13:47:27'),(132,1,'Administrador','crear','Catálogos','nombre: 2','::1','2026-04-26 13:47:33'),(133,1,'Administrador','editar','Catálogos','Horario ID 1: lunes 07:00 a 10:00','::1','2026-04-26 16:35:28'),(134,1,'Administrador','editar','Catálogos','Horario ID 2: martes 07:00 a 10:00','::1','2026-04-26 16:35:38'),(135,1,'Administrador','crear','Catálogos','Horario: miercoles 07:00 a 10:00','::1','2026-04-26 16:36:04'),(136,1,'Administrador','crear','Catálogos','Horario: miercoles 07:00 a 10:00','::1','2026-04-26 16:36:18'),(137,1,'Administrador','crear','Catálogos','Horario: jueves 07:00 a 10:00','::1','2026-04-26 16:42:03'),(138,1,'Administrador','eliminar','Catálogos','Horario ID 5','::1','2026-04-26 16:43:21'),(139,1,'Administrador','crear','Catálogos','Horario: viernes 07:00 a 10:00','::1','2026-04-26 16:43:40'),(140,1,'Administrador','eliminar','Diplomados','Programa ID 2','::1','2026-04-26 16:44:06'),(141,1,'Administrador','eliminar','Diplomados','Programa ID 1','::1','2026-04-26 16:44:09'),(142,1,'Administrador','eliminar','Diplomados','Programa ID 3','::1','2026-04-26 16:44:12'),(143,1,'Administrador','crear','Diplomados','Programa: Técnico operador','::1','2026-04-26 16:46:29'),(144,1,'Administrador','editar','Diplomados','Reordenar programas diplomado 4','::1','2026-04-26 18:38:41'),(145,1,'Administrador','editar','Diplomados','Reordenar programas diplomado 4','::1','2026-04-26 18:38:43'),(146,1,'Administrador','editar','Diplomados','Programa ID 8: Windows','::1','2026-04-26 18:39:14'),(147,1,'Administrador','editar','Diplomados','Diplomado ID 4: Técnico operador','::1','2026-04-26 18:40:29'),(148,1,'Administrador','editar','Diplomados','Diplomado ID 4: Técnico operador','::1','2026-04-26 18:40:44'),(149,1,'Administrador','crear','Diplomados','Diplomado: Técnico Programador','::1','2026-04-26 18:41:47'),(150,1,'Administrador','crear','Diplomados','Diplomado: Diseño Gráfico','::1','2026-04-26 18:42:51'),(151,1,'Administrador','editar','Alumnos','Alumno editado ID 601: Pedro Carlos Mendoza Rodas','::1','2026-04-26 18:46:50'),(152,1,'Administrador','editar','Diplomados','Diplomado ID 6: Diseño Gráfico','::1','2026-04-26 18:48:36'),(153,1,'Administrador','editar','Diplomados','Diplomado ID 4: Técnico operador','::1','2026-04-26 18:49:18'),(154,1,'Administrador','editar','Diplomados','Diplomado ID 5: Técnico Programador','::1','2026-04-26 18:49:47'),(155,1,'Administrador','guardar','Notas TAC','Notas TAC guardadas: 2 cambios año 2026','::1','2026-04-26 19:11:29'),(156,1,'Administrador','editar','Diplomados','Diplomado ID 6: Diseño Gráfico','::1','2026-04-26 20:28:25'),(157,1,'Administrador','editar','Diplomados','Diplomado ID 4: Técnico operador','::1','2026-04-26 20:28:35'),(158,1,'Administrador','editar','Diplomados','Diplomado ID 5: Técnico Programador','::1','2026-04-26 20:28:57'),(159,1,'Administrador','editar','Diplomados','Exámenes diplomado 6: 5','::1','2026-04-26 20:29:05'),(160,1,'Administrador','editar','Diplomados','Exámenes diplomado 4: 7','::1','2026-04-26 20:29:11'),(161,1,'Administrador','editar','Diplomados','Exámenes diplomado 5: 6','::1','2026-04-26 20:29:15'),(162,1,'Administrador','crear','NuevoPago','Recibo 121 — 70 Ana Sofia Castillo Gomez — Enero - Febrero — Q160','::1','2026-04-27 13:47:10'),(163,1,'Administrador','editar','Alumnos','Alumno editado ID 601: Pedro Carlos Mendoza Rodas','::1','2026-04-27 13:49:11'),(164,1,'Administrador','crear','Alumnos','Alumno creado: Carmen Juliana Estrada Mejia (102)','::1','2026-04-27 13:55:30'),(165,1,'Administrador','crear','Recibos','Recibo creado: 122 alumno_id=602','::1','2026-04-27 13:57:09'),(166,1,'Administrador','crear','NuevoPago','Recibo 123 — 102 Carmen Juliana Estrada Mejia — Enero - Febrero - Marzo - Abril - Mayo - Junio — Q240','::1','2026-04-27 13:57:32'),(167,7,'Rony castillo','crear','NuevoPago','Recibo 124 — 42 Maria Fernanda Perez Diaz — Enero - Febrero - Abono Q50 Marzo — Q200','::1','2026-04-27 23:18:53'),(168,7,'Rony castillo','crear','NuevoPago','Recibo 125 — 29 Carlos Eduardo Perez Diaz — Enero - Febrero - Marzo - Abril - Mayo - Junio - Julio - Agosto - Septiembre — Q360','::1','2026-04-27 23:19:13'),(169,1,'Administrador','crear','Catálogos','Cuenta bancaria: Banrural Ahorro 1212141415115 (Rony Alexander Castillo López)','::1','2026-04-27 23:21:11'),(170,1,'Administrador','crear','Catálogos','Cuenta bancaria: Banco Industrial 121214141414 (Misael Estrada Mejia)','::1','2026-04-27 23:21:35'),(171,7,'Rony castillo','crear','Cierres','Cierre recibos 2026-04-27: total Q1060.00 - gastos Q150.00 = Q910.00 (Banco Industrial · 121214141414 · Misael Estrada Mejia)','::1','2026-04-27 23:22:56'),(172,7,'Rony castillo','crear','NuevoPago','Recibo 126 — 14 Karla Michelle Perez Lopez — Enero - Abono Q55 Febrero — Q130','::1','2026-04-27 23:23:27'),(173,7,'Rony castillo','crear','NuevoPago','Recibo 127 — 38 Karla Michelle Diaz Perez — Enero - Febrero - Abono Q40 Marzo — Q190','::1','2026-04-27 23:23:42'),(174,1,'Administrador','revisar','Cierres','Cierre ID 1 marcado como revisado','::1','2026-04-27 23:25:00'),(175,1,'Administrador','crear','NuevoPago','Recibo 128 — 06 Maria Fernanda Castillo Lopez — Enero - Febrero - Marzo — Q240','::1','2026-04-28 01:03:49'),(176,1,'Administrador','eliminar','Mis Tablas','Tabla eliminada ID 6','::1','2026-04-28 01:13:31'),(177,1,'Administrador','crear','Avisos','Aviso \"Examen\" (scope: dia)','::1','2026-04-28 13:29:18'),(178,1,'Administrador','editar','Alumnos','Contraseña actualizada para alumno ID 1','::1','2026-04-28 13:31:04'),(179,1,'Administrador','crear','Alumnos','Alumno creado: Fredy Ottoniel Luarca Santizo (103)','::1','2026-04-28 13:35:29'),(180,1,'Administrador','guardar','Asistencia','Asistencia guardada: 34 celdas año 2026','::1','2026-04-28 13:36:38'),(181,1,'Administrador','guardar','Asistencia','Asistencia guardada: 20 celdas año 2026','::1','2026-04-28 13:37:14'),(182,1,'Administrador','guardar','Asistencia','Asistencia guardada: 2 celdas año 2026','::1','2026-04-28 13:37:39'),(183,1,'Administrador','guardar','Mecanografía','Notas mecanografía guardadas: 9 cambios año 2026','::1','2026-04-28 13:40:36'),(184,1,'Administrador','guardar','Notas TAC','Notas TAC guardadas: 3 cambios año 2026','::1','2026-04-28 13:41:53'),(185,1,'Administrador','guardar','Diplomados','Notas diplomados guardadas: 3 cambios año 2026','::1','2026-04-28 13:42:48'),(186,1,'Administrador','crear','Avisos','Aviso \"Grupos diseñadores\" (scope: diplomado)','::1','2026-04-28 13:45:23'),(187,1,'Administrador','crear','NuevoPago','Recibo 129 — 103 Fredy Ottoniel Luarca Santizo — Enero - Febrero - Marzo - Abril - Mayo - Junio — Q300','::1','2026-04-28 13:46:15'),(188,1,'Administrador','editar','Alumnos','Contraseña actualizada para alumno ID 2','::1','2026-04-28 19:04:00'),(189,1,'Administrador','crear','Avisos','Aviso \"Rony\" (scope: alumno)','::1','2026-04-28 19:06:45'),(190,1,'Administrador','editar','Alumnos','Alumno editado ID 603: Fredy Ottoniel Luarca Santizo','::1','2026-04-29 02:03:22'),(191,1,'Administrador','crear','Mis Tablas','Tabla creada: alumnos','::1','2026-04-30 02:40:21'),(192,1,'Administrador','editar','Mis Tablas','Tabla editada ID 7: alumnos','::1','2026-04-30 02:40:23'),(193,1,'Administrador','editar','Mis Tablas','Tabla editada ID 7: alumnos','::1','2026-04-30 02:40:29'),(194,1,'Administrador','importar','Alumnos','Importación masiva: 30 creado(s), 0 con error de 30 fila(s)','::1','2026-04-30 03:09:35'),(195,1,'Administrador','importar','Alumnos','Importación masiva: 0 creado(s), 10 con error de 10 fila(s)','::1','2026-04-30 03:36:34'),(196,1,'Administrador','importar','Alumnos','Importación masiva: 0 creado(s), 10 con error de 10 fila(s)','::1','2026-04-30 03:36:49'),(197,1,'Administrador','importar','Alumnos','Importación masiva: 10 creado(s), 0 con error de 10 fila(s)','::1','2026-04-30 03:54:47'),(198,1,'Administrador','importar','Alumnos','Importación masiva: 10 creado(s), 0 con error de 10 fila(s)','::1','2026-04-30 05:39:34'),(199,1,'Administrador','editar','InscritosTac','Alumno 585 → pendiente (TAC1 2026)','::1','2026-04-30 05:49:58'),(200,1,'Administrador','editar','InscritosTac','Alumno 585 → inscrito (TAC1 2026)','::1','2026-04-30 05:50:01'),(201,1,'Administrador','editar','InscritosTac','Alumno 585 → no_inscrito (TAC1 2026)','::1','2026-04-30 05:50:05'),(202,1,'Administrador','editar','InscritosTac','Alumno 555 → inscrito (TAC1 2026)','::1','2026-04-30 13:56:40'),(203,1,'Administrador','editar','InscritosTac','Alumno 555 → no_inscrito (TAC1 2026)','::1','2026-04-30 13:56:42'),(204,1,'Administrador','crear','NuevoPago','Recibo 130 — 70 Ana Sofia Castillo Gomez — Marzo - Abril - Mayo — Q240','::1','2026-04-30 14:01:39'),(205,1,'Administrador','crear','Avisos','Aviso \"Examenes\" (scope: dia)','::1','2026-04-30 14:04:17'),(206,1,'Administrador','crear','Avisos','Aviso \"Examen\" (scope: dia)','::1','2026-04-30 14:07:45'),(207,1,'Administrador','crear','Avisos','Aviso \"Examen\" (scope: dia)','::1','2026-04-30 14:08:46'),(208,1,'Administrador','guardar','Asistencia','Asistencia guardada: 20 celdas año 2026','::1','2026-05-02 00:13:38'),(209,1,'Administrador','guardar','Asistencia','Asistencia guardada: 2 celdas año 2026','::1','2026-05-02 00:13:52'),(210,1,'Administrador','importar','Asistencia','Importación masiva Asistencia año 2026: 0 ok, 4 con error de 4','::1','2026-05-02 00:19:05'),(211,1,'Administrador','editar','Alumnos','Alumno editado ID 7: Kevin Daniel Perez Gomez','::1','2026-05-02 00:20:04'),(212,1,'Administrador','importar','Asistencia','Importación masiva Asistencia año 2026: 0 ok, 4 con error de 4','::1','2026-05-02 00:20:26'),(213,1,'Administrador','crear','Mis Tablas','Tabla creada: A','::1','2026-05-02 00:21:55'),(214,1,'Administrador','editar','Mis Tablas','Tabla editada ID 8: A','::1','2026-05-02 00:21:56'),(215,1,'Administrador','importar','Notas TAC','Importación masiva Notas TAC año 2026: 0 ok, 5 con error de 5','::1','2026-05-02 00:22:43'),(216,1,'Administrador','importar','Notas Diplomados','Importación masiva Notas Diplomados año 2026: 0 ok, 1 con error de 1','::1','2026-05-02 00:23:19'),(217,1,'Administrador','importar','Pagos','Importación masiva Pagos año 2026: 0 ok, 1 con error de 1','::1','2026-05-02 00:25:00'),(218,1,'Administrador','editar','Alumnos','Alumno editado ID 8: Andrea Lucia Hernandez Soto','::1','2026-05-02 00:25:42'),(219,1,'Administrador','importar','Pagos','Importación masiva Pagos año 2026: 0 ok, 1 con error de 1','::1','2026-05-02 00:26:05'),(220,1,'Administrador','importar','Notas Diplomados','Importación notas diplomados año 2026: 1 ok, 0 con error de 1','::1','2026-05-02 00:37:35'),(221,1,'Administrador','editar','Alumnos','Alumno editado ID 601: Pedro Carlos Mendoza Rodas','::1','2026-05-02 00:39:17'),(222,1,'Administrador','crear','Mis Tablas','Tabla creada: tac 1','::1','2026-05-02 00:45:24'),(223,1,'Administrador','editar','Mis Tablas','Tabla editada ID 9: tac 1','::1','2026-05-02 00:45:25'),(224,1,'Administrador','eliminar','Mis Tablas','Tabla eliminada ID 9','::1','2026-05-02 00:45:32'),(225,1,'Administrador','crear','Mis Tablas','Tabla creada: tac 1','::1','2026-05-02 00:45:44'),(226,1,'Administrador','editar','Mis Tablas','Tabla editada ID 10: tac 1','::1','2026-05-02 00:45:45'),(227,1,'Administrador','importar','Notas TAC','Importación notas TAC año 2026: 0 ok, 68 con error de 68','::1','2026-05-02 00:49:49'),(228,1,'Administrador','importar','Notas TAC','Importación notas TAC año 2026: 68 ok, 0 con error de 68','::1','2026-05-02 00:51:56'),(229,1,'Administrador','editar','Diplomados','Diplomado ID 4: Técnico Operador','::1','2026-05-02 01:38:13'),(230,1,'Administrador','editar','Catálogos','Horario ID 8: lunes 07:00 a 10:00','::1','2026-05-02 01:43:47'),(231,1,'Administrador','editar','Catálogos','Horario ID 11: jueves 07:00 a 10:00','::1','2026-05-02 01:43:56'),(232,1,'Administrador','editar','Catálogos','Horario ID 9: martes 07:00 a 10:00','::1','2026-05-02 01:44:07'),(233,1,'Administrador','editar','Catálogos','Horario ID 18: lunes-martes 02:00 a 05:00','::1','2026-05-02 01:44:37'),(234,1,'Administrador','editar','Catálogos','Horario ID 14: miercoles 07:00 a 10:00','::1','2026-05-02 01:44:53'),(235,1,'Administrador','editar','Catálogos','Horario ID 16: viernes 07:00 a 10:00','::1','2026-05-02 01:45:02'),(236,1,'Administrador','eliminar','Catálogos','ID 1','::1','2026-05-02 01:45:18'),(237,1,'Administrador','eliminar','Catálogos','ID 2','::1','2026-05-02 01:45:20'),(238,1,'Administrador','crear','Mis Tablas','Tabla creada: solo operadores','::1','2026-05-02 01:50:25'),(239,1,'Administrador','editar','Mis Tablas','Tabla editada ID 11: solo operadores','::1','2026-05-02 01:50:26'),(240,1,'Administrador','importar','Notas Diplomados','Importación notas diplomados año 2026: 1 ok, 0 con error de 1','::1','2026-05-02 01:54:52'),(241,1,'Administrador','importar','Notas Diplomados','Importación notas diplomados año 2026: 1 ok, 6 con error de 7','::1','2026-05-02 01:58:12'),(242,1,'Administrador','importar','Notas Diplomados','Importación notas diplomados año 2026: 4 ok, 0 con error de 4','::1','2026-05-02 02:00:19'),(243,1,'Administrador','importar','Notas Diplomados','Importación notas diplomados año 2026: 81 ok, 0 con error de 81','::1','2026-05-02 02:02:09'),(244,1,'Administrador','crear','Mis Tablas','Tabla creada: todas las notas','::1','2026-05-02 02:04:27'),(245,1,'Administrador','editar','Mis Tablas','Tabla editada ID 12: todas las notas','::1','2026-05-02 02:04:28'),(246,1,'Administrador','importar','Notas TAC','Importación notas TAC año 2026: 151 ok, 0 con error de 151','::1','2026-05-02 02:07:17'),(247,1,'Administrador','importar','Alumnos','Importación masiva: 1 creado(s), 0 con error de 1 fila(s)','::1','2026-05-02 02:16:10'),(248,1,'Administrador','guardar','Asistencia','Asistencia guardada: 21 celdas año 2026','::1','2026-05-02 02:18:22'),(249,1,'Administrador','guardar','Mecanografía','Notas mecanografía guardadas: 8 cambios año 2026','::1','2026-05-02 02:18:57'),(250,1,'Administrador','guardar','Notas TAC','Notas TAC guardadas: 3 cambios año 2026','::1','2026-05-02 02:19:43'),(251,1,'Administrador','editar','Alumnos','Alumno editado ID 674: Ana Lucía Pérez Méndez','::1','2026-05-02 02:20:39'),(252,1,'Administrador','guardar','Diplomados','Notas diplomados guardadas: 7 cambios año 2026','::1','2026-05-02 02:21:59'),(253,1,'Administrador','guardar','Diplomados','Notas diplomados guardadas: 4 cambios año 2026','::1','2026-05-02 02:22:20'),(254,1,'Administrador','crear','NuevoPago','Recibo 131 — 154 (A123XYZ) Ana Lucía Pérez Méndez — Enero - Febrero - Marzo - Abril — Q160','::1','2026-05-02 02:23:57'),(255,1,'Administrador','crear','Mis Tablas','Tabla creada: lunes 7-10 lab 1','::1','2026-05-02 18:23:20'),(256,1,'Administrador','editar','Mis Tablas','Tabla editada ID 13: lunes 7-10 lab 1','::1','2026-05-02 18:23:21'),(257,1,'Administrador','importar','Asistencia','Importación masiva Asistencia año 2026: 0 ok, 96 con error de 96','::1','2026-05-02 18:27:37'),(258,1,'Administrador','crear','NuevoPago','Recibo 132 — 21 Mario Esteban Lopez Ramirez — Enero - Febrero - Marzo — Q150','186.151.20.15','2026-05-07 03:03:28'),(259,1,'Administrador','crear','OtrosPagos','Recibo 133 (otros) — 02 Rony Alexander Castillo Lopez — Inscripcion — Q100.00','186.151.20.15','2026-05-07 03:04:07'),(260,1,'Administrador','crear','Alumnos','Alumno creado: Erick Yovani Lopez Rodas (clave 155, código D123JAJ)','186.151.20.15','2026-05-07 03:10:43'),(261,1,'Administrador','guardar','Asistencia','Asistencia guardada: 17 celdas año 2026','186.151.20.15','2026-05-07 03:12:17'),(262,1,'Administrador','guardar','Notas TAC','Notas TAC guardadas: 4 cambios año 2026','186.151.20.15','2026-05-07 03:13:36'),(263,1,'Administrador','guardar','Diplomados','Notas diplomados guardadas: 6 cambios año 2026','186.151.20.15','2026-05-07 03:13:58'),(264,1,'Administrador','guardar','Mecanografía','Notas mecanografía guardadas: 12 cambios año 2026','186.151.20.15','2026-05-07 03:14:19'),(265,1,'Administrador','crear','NuevoPago','Recibo 134 — 155 (D123JAJ) Erick Yovani Lopez Rodas — Enero - Febrero - Marzo - Abril - Mayo — Q150','186.151.20.15','2026-05-07 03:15:00'),(266,1,'Administrador','crear','Avisos','Aviso \"Hola erick\" (scope: alumno)','186.151.20.15','2026-05-07 03:15:46'),(267,1,'Administrador','editar','Alumnos','Alumno editado ID 675: Erick Yovani Lopez Rodas','186.151.20.15','2026-05-07 03:17:20'),(268,1,'Administrador','crear','backups','Error al crear backup: spawn mysqldump ENOENT','::1','2026-05-07 15:31:49'),(269,1,'Administrador','eliminar','backups','Eliminó backup eduguat-manual-20260507-093149.sql.gz','::1','2026-05-07 15:43:19'),(270,1,'Administrador','crear','backups','Error al crear backup: spawn mysqldump ENOENT','::1','2026-05-07 15:43:20'),(271,1,'Administrador','crear','backups','Error al crear backup: spawn mysqldump ENOENT','::1','2026-05-07 15:43:25'),(272,1,'Administrador','crear','backups','Error al crear backup: spawn mysqldump ENOENT','::1','2026-05-07 15:43:35'),(273,1,'Administrador','crear','backups','Error al crear backup: spawn mysqldump ENOENT','::1','2026-05-07 15:43:55'),(274,1,'Administrador','eliminar','backups','Eliminó backup eduguat-manual-20260507-094355.sql.gz','::1','2026-05-07 15:45:09'),(275,1,'Administrador','eliminar','backups','Eliminó backup eduguat-manual-20260507-094335.sql.gz','::1','2026-05-07 15:45:11'),(276,1,'Administrador','eliminar','backups','Eliminó backup eduguat-manual-20260507-094325.sql.gz','::1','2026-05-07 15:45:13'),(277,1,'Administrador','eliminar','backups','Eliminó backup eduguat-manual-20260507-094320.sql.gz','::1','2026-05-07 15:45:14'),(278,1,'Administrador','crear','backups','Error al crear backup: spawn mysqldump ENOENT','::1','2026-05-07 15:45:17'),(279,1,'Administrador','eliminar','backups','Eliminó backup eduguat-manual-20260507-094517.sql.gz','::1','2026-05-07 15:49:00'),(280,1,'Administrador','crear','backups','Backup manual creado: eduguat-manual-20260507-094902.sql.gz (172.55 KB)','::1','2026-05-07 15:49:08'),(281,1,'Administrador','descargar','backups','Descargó backup eduguat-manual-20260507-094902.sql.gz','::1','2026-05-07 15:49:16'),(282,1,'Administrador','crear','backups','Backup manual creado: eduguat-manual-20260507-101405.sql.gz (172.73 KB)','::1','2026-05-07 16:14:10'),(283,1,'Administrador','eliminar','backups','Eliminó backup eduguat-manual-20260507-101405.sql.gz','::1','2026-05-07 16:17:32'),(284,1,'Administrador','eliminar','backups','Eliminó backup eduguat-manual-20260507-094902.sql.gz','::1','2026-05-07 16:17:34'),(285,1,'Administrador','crear','backups','Backup manual creado: eduguat-manual-20260507-101735.sql.gz (172.65 KB)','::1','2026-05-07 16:17:41'),(286,1,'Administrador','eliminar','backups','Eliminó backup eduguat-manual-20260507-101735.sql.gz','::1','2026-05-07 16:25:01'),(287,1,'Administrador','crear','backups','Backup manual creado: eduguat-manual-20260507-102502.sql.gz (172.69 KB)','::1','2026-05-07 16:25:07'),(288,1,'Administrador','crear','Alumnos','Alumno creado: Marcusito Santos (clave 156)','2800:98:1a16:73e:81e6:23e7:dea8:3713','2026-05-07 17:33:06'),(289,1,'Administrador','guardar','Asistencia','Asistencia guardada: 21 celdas año 2026','2800:98:1a16:73e:81e6:23e7:dea8:3713','2026-05-07 17:35:19'),(290,1,'Administrador','guardar','Mecanografía','Notas mecanografía guardadas: 11 cambios año 2026','2800:98:1a16:73e:81e6:23e7:dea8:3713','2026-05-07 17:35:58'),(291,1,'Administrador','guardar','Notas TAC','Notas TAC guardadas: 4 cambios año 2026','2800:98:1a16:73e:81e6:23e7:dea8:3713','2026-05-07 17:36:34'),(292,1,'Administrador','guardar','Diplomados','Notas diplomados guardadas: 5 cambios año 2026','2800:98:1a16:73e:81e6:23e7:dea8:3713','2026-05-07 17:36:56'),(293,1,'Administrador','crear','NuevoPago','Recibo 135 — 156 Marcusito Santos — Enero - Febrero - Marzo - Abril - Mayo - Junio - Julio - Agosto - Septiembre - Octubre — Q400','2800:98:1a16:73e:81e6:23e7:dea8:3713','2026-05-07 17:37:34'),(294,1,'Administrador','crear','ConfigPagos','Regla 2026 global meses 1-11 x1','2800:98:1a16:73e:81e6:23e7:dea8:3713','2026-05-07 17:39:00'),(295,1,'Administrador','crear','Avisos','Aviso \"Hola mundo\" (scope: alumno)','2800:98:1a16:73e:81e6:23e7:dea8:3713','2026-05-07 17:40:16'),(296,82,'Marcus','guardar','Mecanografía','Notas mecanografía guardadas: 1 cambios año 2026','2800:98:1b61:a992:1:0:861f:9502','2026-05-07 17:49:32'),(297,82,'Marcus','eliminar','Mis Tablas','Tabla eliminada ID 13','2800:98:1b61:a992:1:0:861f:9502','2026-05-07 17:52:06'),(298,82,'Marcus','eliminar','Mis Tablas','Tabla eliminada ID 12','2800:98:1b61:a992:1:0:861f:9502','2026-05-07 17:52:08'),(299,82,'Marcus','eliminar','Mis Tablas','Tabla eliminada ID 11','2800:98:1b61:a992:1:0:861f:9502','2026-05-07 17:52:09'),(300,82,'Marcus','eliminar','Mis Tablas','Tabla eliminada ID 10','2800:98:1b61:a992:1:0:861f:9502','2026-05-07 17:52:11'),(301,82,'Marcus','eliminar','Mis Tablas','Tabla eliminada ID 8','2800:98:1b61:a992:1:0:861f:9502','2026-05-07 17:52:12'),(302,82,'Marcus','eliminar','Mis Tablas','Tabla eliminada ID 7','2800:98:1b61:a992:1:0:861f:9502','2026-05-07 17:52:14'),(303,82,'Marcus','crear','Mis Tablas','Tabla creada: Datos','2800:98:1b61:a992:1:0:861f:9502','2026-05-07 17:52:36'),(304,83,'marcus santizo','editar','Alumnos','Alumno editado ID 676: Marcusito Santos','2800:98:1b61:a992:1:0:861f:9502','2026-05-07 17:58:09'),(305,83,'marcus santizo','editar','InscritosTac','Alumno 628 → pendiente (TAC1 2026)','2800:98:1b61:a992:1:0:861f:9502','2026-05-07 18:00:54'),(306,83,'marcus santizo','crear','NuevoPago','Recibo 136 — 134 Juan Carlos Pérez López — Enero - Febrero - Marzo — Q120','2800:98:1b61:a992:1:0:861f:9502','2026-05-07 18:02:22'),(307,1,'Administrador','crear','NuevoPago','Recibo 137 — 13 Oscar Eduardo Gomez Diaz — Abril - Mayo — Q50','2800:98:1a16:73e:6407:46db:4112:3cd2','2026-05-07 20:57:39'),(308,1,'Administrador','crear','backups','Backup manual creado: eduguat-manual-20260507-150004.sql.gz (171.57 KB)','::1','2026-05-07 21:00:09'),(309,1,'Administrador','eliminar','Avisos','Aviso \"Hola erick\" eliminado','2800:98:1a16:73e:c520:5e6:6f0a:4dff','2026-05-07 21:00:54');
/*!40000 ALTER TABLE `bitacora` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cat_cuentas_bancarias`
--

DROP TABLE IF EXISTS `cat_cuentas_bancarias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cat_cuentas_bancarias` (
  `id` int NOT NULL AUTO_INCREMENT,
  `numero_cuenta` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nombre` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo_cuenta` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cat_cuentas_bancarias`
--

LOCK TABLES `cat_cuentas_bancarias` WRITE;
/*!40000 ALTER TABLE `cat_cuentas_bancarias` DISABLE KEYS */;
INSERT INTO `cat_cuentas_bancarias` VALUES (1,'1212141415115','Rony Alexander Castillo López','Banrural Ahorro',1,'2026-04-27 23:21:11'),(2,'121214141414','Misael Estrada Mejia','Banco Industrial',1,'2026-04-27 23:21:35');
/*!40000 ALTER TABLE `cat_cuentas_bancarias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cat_cuotas`
--

DROP TABLE IF EXISTS `cat_cuotas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cat_cuotas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `monto` decimal(10,2) NOT NULL,
  `descripcion` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cat_cuotas`
--

LOCK TABLES `cat_cuotas` WRITE;
/*!40000 ALTER TABLE `cat_cuotas` DISABLE KEYS */;
INSERT INTO `cat_cuotas` VALUES (1,40.00,'',1,'2026-04-26 13:45:38'),(2,50.00,'',1,'2026-04-26 13:45:44'),(3,75.00,NULL,1,'2026-04-29 02:26:13'),(4,80.00,NULL,1,'2026-04-29 02:26:13'),(5,70.00,NULL,1,'2026-04-29 02:26:13'),(6,30.00,NULL,1,'2026-04-29 02:26:13');
/*!40000 ALTER TABLE `cat_cuotas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cat_establecimientos`
--

DROP TABLE IF EXISTS `cat_establecimientos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cat_establecimientos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nombre` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=1065 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cat_establecimientos`
--

LOCK TABLES `cat_establecimientos` WRITE;
/*!40000 ALTER TABLE `cat_establecimientos` DISABLE KEYS */;
INSERT INTO `cat_establecimientos` VALUES (1,'Instituto Aldea Galvez',1,'2026-04-26 13:45:57'),(2,'instituto la Florida',1,'2026-04-26 13:46:10'),(4,'No estudia',1,'2026-04-29 02:26:13'),(5,'INEB',1,'2026-04-29 02:26:13'),(6,'Colegio',1,'2026-04-29 02:26:13'),(7,'Instituto',1,'2026-04-29 02:26:13');
/*!40000 ALTER TABLE `cat_establecimientos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cat_horarios`
--

DROP TABLE IF EXISTS `cat_horarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cat_horarios` (
  `id` int NOT NULL AUTO_INCREMENT,
  `dia1` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dia2` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hora_inicio` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `hora_fin` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cat_horarios`
--

LOCK TABLES `cat_horarios` WRITE;
/*!40000 ALTER TABLE `cat_horarios` DISABLE KEYS */;
INSERT INTO `cat_horarios` VALUES (1,'lunes',NULL,'07:00','10:00',1,'2026-04-26 13:46:46'),(2,'martes',NULL,'07:00','10:00',1,'2026-04-26 13:47:01'),(3,'lunes','martes','10:00','11:30',1,'2026-04-26 13:47:19'),(4,'miercoles',NULL,'07:00','10:00',1,'2026-04-26 16:36:04'),(6,'jueves',NULL,'07:00','10:00',1,'2026-04-26 16:42:03'),(7,'viernes',NULL,'07:00','10:00',1,'2026-04-26 16:43:40'),(8,'lunes',NULL,'07:00','10:00',1,'2026-04-29 02:26:13'),(9,'martes',NULL,'07:00','10:00',1,'2026-04-29 02:26:13'),(10,'miercoles',NULL,'10:00','12:00',1,'2026-04-29 02:26:13'),(11,'jueves',NULL,'07:00','10:00',1,'2026-04-29 02:26:13'),(12,'viernes',NULL,'10:00','12:00',1,'2026-04-29 02:26:13'),(13,'martes',NULL,'10:00','12:00',1,'2026-04-29 02:26:13'),(14,'miercoles',NULL,'07:00','10:00',1,'2026-04-29 02:26:13'),(15,'jueves',NULL,'10:00','12:00',1,'2026-04-29 02:26:13'),(16,'viernes',NULL,'07:00','10:00',1,'2026-04-29 02:26:13'),(17,'lunes',NULL,'10:00','12:00',1,'2026-04-29 02:26:13'),(18,'lunes','martes','02:00','05:00',1,'2026-04-29 02:26:13'),(19,'domingo',NULL,'07:00','10:00',1,'2026-04-30 03:15:47'),(20,'lunes','martes','2:00','5:00',1,'2026-05-02 15:11:59');
/*!40000 ALTER TABLE `cat_horarios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cat_laboratorios`
--

DROP TABLE IF EXISTS `cat_laboratorios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cat_laboratorios` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nombre` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=423 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cat_laboratorios`
--

LOCK TABLES `cat_laboratorios` WRITE;
/*!40000 ALTER TABLE `cat_laboratorios` DISABLE KEYS */;
INSERT INTO `cat_laboratorios` VALUES (49,'Lab 1',1,'2026-04-30 03:15:47'),(50,'Lab 2',1,'2026-04-30 03:15:47');
/*!40000 ALTER TABLE `cat_laboratorios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cierre_gastos`
--

DROP TABLE IF EXISTS `cierre_gastos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cierre_gastos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `cierre_id` int NOT NULL,
  `descripcion` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `monto` decimal(10,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id`),
  KEY `idx_cierre_gastos` (`cierre_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cierre_gastos`
--

LOCK TABLES `cierre_gastos` WRITE;
/*!40000 ALTER TABLE `cierre_gastos` DISABLE KEYS */;
INSERT INTO `cierre_gastos` VALUES (1,1,'Compra de papeleria y utiles',150.00);
/*!40000 ALTER TABLE `cierre_gastos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cierres_diarios`
--

DROP TABLE IF EXISTS `cierres_diarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cierres_diarios` (
  `id` int NOT NULL AUTO_INCREMENT,
  `modulo` enum('recibos','papeleria') COLLATE utf8mb4_unicode_ci NOT NULL,
  `fecha` date NOT NULL,
  `total_dia` decimal(10,2) NOT NULL DEFAULT '0.00',
  `total_gastos` decimal(10,2) NOT NULL DEFAULT '0.00',
  `total_depositar` decimal(10,2) NOT NULL DEFAULT '0.00',
  `cuenta_id` int DEFAULT NULL,
  `cuenta_snapshot` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ultimo_recibo` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `observaciones` text COLLATE utf8mb4_unicode_ci,
  `estado` enum('pendiente','revisado') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pendiente',
  `creado_por_id` int DEFAULT NULL,
  `creado_por_nombre` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `revisado_por_id` int DEFAULT NULL,
  `revisado_por_nombre` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `revisado_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_cierre` (`modulo`,`fecha`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cierres_diarios`
--

LOCK TABLES `cierres_diarios` WRITE;
/*!40000 ALTER TABLE `cierres_diarios` DISABLE KEYS */;
INSERT INTO `cierres_diarios` VALUES (1,'recibos','2026-04-27',1060.00,150.00,910.00,2,'Banco Industrial · 121214141414 · Misael Estrada Mejia','125','se compro hojas para impresion ademas de cintas','revisado',7,'Rony castillo',1,'Administrador','2026-04-27 23:25:00','2026-04-27 23:22:56','2026-04-27 23:25:00');
/*!40000 ALTER TABLE `cierres_diarios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `config_pagos`
--

DROP TABLE IF EXISTS `config_pagos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `config_pagos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `anio` int NOT NULL,
  `scope_tipo` enum('global','diplomado','horario','laboratorio','dia','alumno') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'global',
  `scope_valor` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mes_inicio` tinyint NOT NULL,
  `mes_fin` tinyint NOT NULL,
  `multiplicador` decimal(4,2) NOT NULL DEFAULT '1.00',
  `descripcion` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_cfg_anio` (`anio`),
  KEY `idx_cfg_scope` (`scope_tipo`,`scope_valor`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `config_pagos`
--

LOCK TABLES `config_pagos` WRITE;
/*!40000 ALTER TABLE `config_pagos` DISABLE KEYS */;
INSERT INTO `config_pagos` VALUES (1,2026,'global',NULL,1,11,1.00,NULL,'2026-05-07 17:39:00');
/*!40000 ALTER TABLE `config_pagos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `configuracion`
--

DROP TABLE IF EXISTS `configuracion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `configuracion` (
  `id` int NOT NULL AUTO_INCREMENT,
  `clave` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `valor` text COLLATE utf8mb4_unicode_ci,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `clave` (`clave`)
) ENGINE=InnoDB AUTO_INCREMENT=1345 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `configuracion`
--

LOCK TABLES `configuracion` WRITE;
/*!40000 ALTER TABLE `configuracion` DISABLE KEYS */;
INSERT INTO `configuracion` VALUES (1,'inst_nombre','SISTEC COMPUTACIÓN','2026-04-22 02:26:31'),(2,'inst_direccion','Quetzaltenango, Flores costa cuca, Segundo nivel mercado municipal.','2026-04-22 02:26:31'),(3,'inst_telefono','Tel: 7722-2141','2026-04-22 02:26:31'),(4,'inst_email','sistecflores@gmail.com','2026-04-22 02:26:31');
/*!40000 ALTER TABLE `configuracion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `constancia_plantillas`
--

DROP TABLE IF EXISTS `constancia_plantillas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `constancia_plantillas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ubicacion` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Guatemala',
  `saludo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Estimado(a) Director(a):',
  `cuerpo` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `despedida` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Atentamente,',
  `firma_nombre` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Secretaría',
  `firma_cargo` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mostrar_fecha` tinyint(1) NOT NULL DEFAULT '1',
  `mostrar_firma` tinyint(1) NOT NULL DEFAULT '1',
  `mostrar_telefono` tinyint(1) NOT NULL DEFAULT '1',
  `activa` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `espacio_post_encabezado` tinyint NOT NULL DEFAULT '3',
  `espacio_post_fecha` tinyint NOT NULL DEFAULT '2',
  `espacio_post_saludo` tinyint NOT NULL DEFAULT '1',
  `espacio_post_cuerpo` tinyint NOT NULL DEFAULT '2',
  `espacio_post_despedida` tinyint NOT NULL DEFAULT '3',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `constancia_plantillas`
--

LOCK TABLES `constancia_plantillas` WRITE;
/*!40000 ALTER TABLE `constancia_plantillas` DISABLE KEYS */;
INSERT INTO `constancia_plantillas` VALUES (1,'Constancia de Inscripción','Quetzaltengo, Flores Costa Cuca','A quien corresponda:','Por medio de la presente hacemos constar que el alumno(a) {{nombre_completo}}, estudiante del establecimiento {{establecimiento}}, se encuentra inscrito(a) actualmente en el curso de Tecnología {{tac}} se encuentra estudiando en nuestra institución para el ciclo 2026.\n\nLa presente constancia se extiende a solicitud del interesado para los usos que estime convenientes.','Atentamente,','Sistec Flores','Secreataría',1,1,1,1,'2026-04-29 21:07:24','2026-05-02 18:29:11',3,4,2,4,4),(2,'Carta padre de familia','Quetzaltenango Flores Costa cuca','Respetable padre de familia:','Por medio de la presente carta le informo a usted que tendremos una reunión de padres de familia para hablar de temas importantes sobre el alumno: {{nombre}} {{apellido}}, esperamos encarecidamente contar con su presencia. Sin nada más que decir, me despido.','Atentamente:','SISTEC Flores','Oficina',1,1,1,1,'2026-04-30 02:34:47','2026-04-30 02:36:31',2,2,1,0,2);
/*!40000 ALTER TABLE `constancia_plantillas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dip_diplomado_objetivos`
--

DROP TABLE IF EXISTS `dip_diplomado_objetivos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dip_diplomado_objetivos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `diplomado_id` int NOT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `orden` smallint NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_dip_obj` (`diplomado_id`,`orden`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dip_diplomado_objetivos`
--

LOCK TABLES `dip_diplomado_objetivos` WRITE;
/*!40000 ALTER TABLE `dip_diplomado_objetivos` DISABLE KEYS */;
INSERT INTO `dip_diplomado_objetivos` VALUES (1,1,'asdf',0),(2,1,'asdfasdf',1),(3,1,'adsfdsfd',2),(4,1,'3333',3),(5,2,'j',0),(14,6,'aa',0),(16,5,'kkd',0),(17,4,'a',0);
/*!40000 ALTER TABLE `dip_diplomado_objetivos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dip_diplomados`
--

DROP TABLE IF EXISTS `dip_diplomados`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dip_diplomados` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `objetivo_general` text COLLATE utf8mb4_unicode_ci,
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dip_diplomados`
--

LOCK TABLES `dip_diplomados` WRITE;
/*!40000 ALTER TABLE `dip_diplomados` DISABLE KEYS */;
INSERT INTO `dip_diplomados` VALUES (1,'Windows','ñalksdjf',0,'2026-04-26 18:32:25'),(2,'Word','asdf',0,'2026-04-26 18:32:25'),(3,'publisher','',0,'2026-04-26 18:32:25'),(4,'Técnico Operador','a',1,'2026-04-26 18:32:25'),(5,'Técnico Programador','akld',1,'2026-04-26 18:41:47'),(6,'Diseño Gráfico','sss',1,'2026-04-26 18:42:51');
/*!40000 ALTER TABLE `dip_diplomados` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dip_examenes`
--

DROP TABLE IF EXISTS `dip_examenes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dip_examenes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `diplomado_id` int NOT NULL,
  `nombre` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `orden` smallint NOT NULL DEFAULT '0',
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_dip_exam` (`diplomado_id`,`orden`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dip_examenes`
--

LOCK TABLES `dip_examenes` WRITE;
/*!40000 ALTER TABLE `dip_examenes` DISABLE KEYS */;
INSERT INTO `dip_examenes` VALUES (1,4,'Windows',0,1,'2026-04-26 20:24:31'),(2,4,'Word',1,1,'2026-04-26 20:24:31'),(3,4,'Publisher',2,1,'2026-04-26 20:24:31'),(4,4,'PowerPoint',3,1,'2026-04-26 20:24:31'),(5,4,'Examen Parcial',4,1,'2026-04-26 20:24:31'),(6,4,'Excel',5,1,'2026-04-26 20:24:31'),(7,4,'Examen Final',6,1,'2026-04-26 20:24:31'),(8,5,'Scratch',0,1,'2026-04-26 20:24:31'),(9,5,'HTML',1,1,'2026-04-26 20:24:31'),(10,5,'Examen Parcial',2,1,'2026-04-26 20:24:31'),(11,5,'Python',3,1,'2026-04-26 20:24:31'),(12,5,'C#',4,1,'2026-04-26 20:24:31'),(13,5,'Examen Final',5,1,'2026-04-26 20:24:31'),(14,6,'Photoshop',0,1,'2026-04-26 20:24:31'),(15,6,'Examen Parcial',1,1,'2026-04-26 20:24:31'),(16,6,'Illustrator',2,1,'2026-04-26 20:24:31'),(17,6,'Filmora',3,1,'2026-04-26 20:24:31'),(18,6,'Examen Final',4,1,'2026-04-26 20:24:31');
/*!40000 ALTER TABLE `dip_examenes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dip_programa_contenido`
--

DROP TABLE IF EXISTS `dip_programa_contenido`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dip_programa_contenido` (
  `id` int NOT NULL AUTO_INCREMENT,
  `programa_id` int NOT NULL,
  `semana_num` tinyint NOT NULL,
  `contenido` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_dip_prog_cont` (`programa_id`,`semana_num`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dip_programa_contenido`
--

LOCK TABLES `dip_programa_contenido` WRITE;
/*!40000 ALTER TABLE `dip_programa_contenido` DISABLE KEYS */;
INSERT INTO `dip_programa_contenido` VALUES (1,8,1,'a'),(2,8,2,'b'),(3,8,3,'c'),(4,8,4,'d'),(5,8,5,'e');
/*!40000 ALTER TABLE `dip_programa_contenido` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dip_programa_objetivos`
--

DROP TABLE IF EXISTS `dip_programa_objetivos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dip_programa_objetivos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `programa_id` int NOT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `orden` smallint NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_prog_obj` (`programa_id`,`orden`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dip_programa_objetivos`
--

LOCK TABLES `dip_programa_objetivos` WRITE;
/*!40000 ALTER TABLE `dip_programa_objetivos` DISABLE KEYS */;
INSERT INTO `dip_programa_objetivos` VALUES (1,8,'akdjf',0),(2,8,'adsfads',1),(3,8,'asdfasdfasd',2);
/*!40000 ALTER TABLE `dip_programa_objetivos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dip_programas`
--

DROP TABLE IF EXISTS `dip_programas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dip_programas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `diplomado_id` int NOT NULL,
  `nombre` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `objetivo_general` text COLLATE utf8mb4_unicode_ci,
  `duracion_semanas` tinyint NOT NULL DEFAULT '1',
  `orden` smallint NOT NULL DEFAULT '0',
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_prog_dip` (`diplomado_id`,`orden`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dip_programas`
--

LOCK TABLES `dip_programas` WRITE;
/*!40000 ALTER TABLE `dip_programas` DISABLE KEYS */;
INSERT INTO `dip_programas` VALUES (1,1,'Windows','',1,0,1,'2026-04-26 18:32:25'),(2,1,'Word','',1,1,1,'2026-04-26 18:32:25'),(3,1,'Publisher','',1,2,1,'2026-04-26 18:32:25'),(4,1,'PowerPoint','',1,3,1,'2026-04-26 18:32:25'),(5,1,'Parcial','',1,4,1,'2026-04-26 18:32:25'),(6,1,'Excel','',1,5,1,'2026-04-26 18:32:25'),(7,1,'Examen Final','',1,6,1,'2026-04-26 18:32:25'),(8,4,'Windows','lkjhlkjasdfkd',5,0,1,'2026-04-26 18:32:25'),(9,4,'Word','',14,1,1,'2026-04-26 18:32:25'),(10,4,'Publisher','',4,2,1,'2026-04-26 18:40:29'),(11,4,'PowerPoint','',4,3,1,'2026-04-26 18:40:29'),(12,4,'Excel','',14,4,1,'2026-04-26 18:40:29'),(13,5,'Scratch','',8,0,1,'2026-04-26 18:41:47'),(14,5,'HTML','',11,1,1,'2026-04-26 18:41:47'),(15,5,'Python','',14,2,1,'2026-04-26 18:41:47'),(16,5,'C#','',14,3,1,'2026-04-26 18:41:47'),(17,6,'Photoshop','',16,0,1,'2026-04-26 18:42:51'),(18,6,'Illustrator','',12,1,1,'2026-04-26 18:42:51'),(19,6,'Filmora','',8,2,1,'2026-04-26 18:42:51'),(20,6,'Examen Parcial','',1,1,0,'2026-04-26 18:48:36'),(21,6,'Examen Final','',1,4,0,'2026-04-26 18:48:36'),(22,4,'Examen Parcial','',1,4,0,'2026-04-26 18:49:18'),(23,4,'Examen Final','',1,6,0,'2026-04-26 18:49:18'),(24,5,'Examen Parcial','',1,2,0,'2026-04-26 18:49:47'),(25,5,'Examen Final','',1,5,0,'2026-04-26 18:49:47');
/*!40000 ALTER TABLE `dip_programas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `diplomado_notas`
--

DROP TABLE IF EXISTS `diplomado_notas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `diplomado_notas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `alumno_id` int NOT NULL,
  `anio` smallint NOT NULL,
  `materia` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nota` smallint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_dip_n` (`alumno_id`,`anio`,`materia`)
) ENGINE=InnoDB AUTO_INCREMENT=1618 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `diplomado_notas`
--

LOCK TABLES `diplomado_notas` WRITE;
/*!40000 ALTER TABLE `diplomado_notas` DISABLE KEYS */;
INSERT INTO `diplomado_notas` VALUES (1,2,2026,'word',59),(2,2,2026,'publisher',100),(3,2,2026,'powerpoint',95),(4,2,2026,'parcial',68),(5,2,2026,'excel',96),(6,2,2026,'examen_final',100),(7,2,2026,'scratch',50),(8,2,2026,'html',55),(9,2,2026,'python',75),(10,2,2026,'csharp',68),(11,2,2026,'photoshop',84),(12,2,2026,'illustrator',85),(13,2,2026,'filmora',98),(14,1,2026,'word',60),(15,1,2026,'publisher',70),(16,1,2026,'powerpoint',80),(17,1,2026,'parcial',54),(18,1,2026,'excel',100),(20,1,2026,'scratch',60),(21,1,2026,'html',60),(22,1,2026,'python',60),(23,1,2026,'photoshop',60),(24,1,2026,'illustrator',60),(26,1,2026,'filmora',60),(27,603,2026,'Photoshop',87),(28,603,2026,'Examen Parcial',74),(29,603,2026,'Illustrator',75),(30,601,2026,'Photoshop',60),(31,601,2026,'Illustrator',60),(32,601,2026,'Filmora',60),(33,601,2026,'Windows',50),(34,601,2026,'Word',60),(35,601,2026,'Publisher',70),(36,601,2026,'PowerPoint',80),(37,601,2026,'Excel',100),(38,601,2026,'Scratch',60),(39,601,2026,'HTML',60),(40,601,2026,'Python',60),(41,601,2026,'C#',60),(42,669,2026,'Windows',50),(43,669,2026,'Word',60),(44,669,2026,'Publisher',70),(45,669,2026,'PowerPoint',80),(46,669,2026,'Examen Parcial',100),(47,669,2026,'Excel',100),(48,669,2026,'Examen Final',90),(56,669,2026,'Scratch',60),(57,669,2026,'HTML',60),(59,669,2026,'Python',60),(60,669,2026,'C#',60),(62,669,2026,'Photoshop',60),(64,669,2026,'Illustrator',60),(65,669,2026,'Filmora',60),(85,673,2026,'Windows',50),(86,673,2026,'Word',60),(87,673,2026,'Publisher',70),(88,673,2026,'PowerPoint',80),(89,673,2026,'Examen Parcial',100),(90,673,2026,'Excel',100),(91,673,2026,'Examen Final',90),(92,673,2026,'Scratch',60),(93,673,2026,'HTML',60),(95,673,2026,'Python',60),(96,673,2026,'C#',60),(98,673,2026,'Photoshop',60),(100,673,2026,'Illustrator',60),(101,673,2026,'Filmora',60),(103,663,2026,'Windows',50),(104,663,2026,'Word',60),(105,663,2026,'Publisher',70),(106,663,2026,'PowerPoint',80),(107,663,2026,'Examen Parcial',100),(108,663,2026,'Excel',100),(109,663,2026,'Examen Final',90),(110,663,2026,'Scratch',60),(111,663,2026,'HTML',60),(113,663,2026,'Python',60),(114,663,2026,'C#',60),(116,663,2026,'Photoshop',60),(118,663,2026,'Illustrator',60),(119,663,2026,'Filmora',60),(121,668,2026,'Windows',50),(122,668,2026,'Word',60),(123,668,2026,'Publisher',70),(124,668,2026,'PowerPoint',80),(125,668,2026,'Examen Parcial',100),(126,668,2026,'Excel',100),(127,668,2026,'Examen Final',90),(128,668,2026,'Scratch',60),(129,668,2026,'HTML',60),(131,668,2026,'Python',60),(132,668,2026,'C#',60),(134,668,2026,'Photoshop',60),(136,668,2026,'Illustrator',60),(137,668,2026,'Filmora',60),(157,585,2026,'Windows',50),(158,585,2026,'Word',60),(159,585,2026,'Publisher',70),(160,585,2026,'PowerPoint',80),(161,585,2026,'Examen Parcial',100),(162,585,2026,'Excel',100),(163,585,2026,'Examen Final',90),(164,585,2026,'Scratch',60),(165,585,2026,'HTML',60),(167,585,2026,'Python',60),(168,585,2026,'C#',60),(170,585,2026,'Photoshop',60),(172,585,2026,'Illustrator',60),(173,585,2026,'Filmora',60),(175,555,2026,'Windows',50),(176,555,2026,'Word',60),(177,555,2026,'Publisher',70),(178,555,2026,'PowerPoint',80),(179,555,2026,'Examen Parcial',100),(180,555,2026,'Excel',100),(181,555,2026,'Examen Final',90),(182,555,2026,'Scratch',60),(183,555,2026,'HTML',60),(185,555,2026,'Python',60),(186,555,2026,'C#',60),(188,555,2026,'Photoshop',60),(190,555,2026,'Illustrator',60),(191,555,2026,'Filmora',60),(193,25,2026,'Windows',50),(194,25,2026,'Word',60),(195,25,2026,'Publisher',70),(196,25,2026,'PowerPoint',80),(197,25,2026,'Examen Parcial',100),(198,25,2026,'Excel',100),(199,25,2026,'Examen Final',90),(200,25,2026,'Scratch',60),(201,25,2026,'HTML',60),(203,25,2026,'Python',60),(204,25,2026,'C#',60),(206,25,2026,'Photoshop',60),(208,25,2026,'Illustrator',60),(209,25,2026,'Filmora',60),(211,672,2026,'Windows',50),(212,672,2026,'Word',60),(213,672,2026,'Publisher',70),(214,672,2026,'PowerPoint',80),(215,672,2026,'Examen Parcial',100),(216,672,2026,'Excel',100),(217,672,2026,'Examen Final',90),(218,672,2026,'Scratch',60),(219,672,2026,'HTML',60),(221,672,2026,'Python',60),(222,672,2026,'C#',60),(224,672,2026,'Photoshop',60),(226,672,2026,'Illustrator',60),(227,672,2026,'Filmora',60),(229,45,2026,'Windows',50),(230,45,2026,'Word',60),(231,45,2026,'Publisher',70),(232,45,2026,'PowerPoint',80),(233,45,2026,'Examen Parcial',100),(234,45,2026,'Excel',100),(235,45,2026,'Examen Final',90),(236,45,2026,'Scratch',60),(237,45,2026,'HTML',60),(239,45,2026,'Python',60),(240,45,2026,'C#',60),(242,45,2026,'Photoshop',60),(244,45,2026,'Illustrator',60),(245,45,2026,'Filmora',60),(247,575,2026,'Windows',50),(248,575,2026,'Word',60),(249,575,2026,'Publisher',70),(250,575,2026,'PowerPoint',80),(251,575,2026,'Examen Parcial',100),(252,575,2026,'Excel',100),(253,575,2026,'Examen Final',90),(254,575,2026,'Scratch',60),(255,575,2026,'HTML',60),(257,575,2026,'Python',60),(258,575,2026,'C#',60),(260,575,2026,'Photoshop',60),(262,575,2026,'Illustrator',60),(263,575,2026,'Filmora',60),(265,9,2026,'Windows',50),(266,9,2026,'Word',60),(267,9,2026,'Publisher',70),(268,9,2026,'PowerPoint',80),(269,9,2026,'Examen Parcial',100),(270,9,2026,'Excel',100),(271,9,2026,'Examen Final',90),(272,9,2026,'Scratch',60),(273,9,2026,'HTML',60),(275,9,2026,'Python',60),(276,9,2026,'C#',60),(278,9,2026,'Photoshop',60),(280,9,2026,'Illustrator',60),(281,9,2026,'Filmora',60),(283,17,2026,'Windows',50),(284,17,2026,'Word',60),(285,17,2026,'Publisher',70),(286,17,2026,'PowerPoint',80),(287,17,2026,'Examen Parcial',100),(288,17,2026,'Excel',100),(289,17,2026,'Examen Final',90),(290,17,2026,'Scratch',60),(291,17,2026,'HTML',60),(293,17,2026,'Python',60),(294,17,2026,'C#',60),(296,17,2026,'Photoshop',60),(298,17,2026,'Illustrator',60),(299,17,2026,'Filmora',60),(301,563,2026,'Windows',50),(302,563,2026,'Word',60),(303,563,2026,'Publisher',70),(304,563,2026,'PowerPoint',80),(305,563,2026,'Examen Parcial',100),(306,563,2026,'Excel',100),(307,563,2026,'Examen Final',90),(308,563,2026,'Scratch',60),(309,563,2026,'HTML',60),(311,563,2026,'Python',60),(312,563,2026,'C#',60),(314,563,2026,'Photoshop',60),(316,563,2026,'Illustrator',60),(317,563,2026,'Filmora',60),(319,593,2026,'Windows',50),(320,593,2026,'Word',60),(321,593,2026,'Publisher',70),(322,593,2026,'PowerPoint',80),(323,593,2026,'Examen Parcial',100),(324,593,2026,'Excel',100),(325,593,2026,'Examen Final',90),(326,593,2026,'Scratch',60),(327,593,2026,'HTML',60),(329,593,2026,'Python',60),(330,593,2026,'C#',60),(332,593,2026,'Photoshop',60),(334,593,2026,'Illustrator',60),(335,593,2026,'Filmora',60),(337,33,2026,'Windows',50),(338,33,2026,'Word',60),(339,33,2026,'Publisher',70),(340,33,2026,'PowerPoint',80),(341,33,2026,'Examen Parcial',100),(342,33,2026,'Excel',100),(343,33,2026,'Examen Final',90),(344,33,2026,'Scratch',60),(345,33,2026,'HTML',60),(347,33,2026,'Python',60),(348,33,2026,'C#',60),(350,33,2026,'Photoshop',60),(352,33,2026,'Illustrator',60),(353,33,2026,'Filmora',60),(355,602,2026,'Windows',50),(356,602,2026,'Word',60),(357,602,2026,'Publisher',70),(358,602,2026,'PowerPoint',80),(359,602,2026,'Examen Parcial',100),(360,602,2026,'Excel',100),(361,602,2026,'Examen Final',90),(362,602,2026,'Scratch',60),(363,602,2026,'HTML',60),(365,602,2026,'Python',60),(366,602,2026,'C#',60),(368,602,2026,'Photoshop',60),(370,602,2026,'Illustrator',60),(371,602,2026,'Filmora',60),(373,659,2026,'Windows',50),(374,659,2026,'Word',60),(375,659,2026,'Publisher',70),(376,659,2026,'PowerPoint',80),(377,659,2026,'Examen Parcial',100),(378,659,2026,'Excel',100),(379,659,2026,'Examen Final',90),(380,659,2026,'Scratch',60),(381,659,2026,'HTML',60),(383,659,2026,'Python',60),(384,659,2026,'C#',60),(386,659,2026,'Photoshop',60),(388,659,2026,'Illustrator',60),(389,659,2026,'Filmora',60),(391,610,2026,'Windows',50),(392,610,2026,'Word',60),(393,610,2026,'Publisher',70),(394,610,2026,'PowerPoint',80),(395,610,2026,'Examen Parcial',100),(396,610,2026,'Excel',100),(397,610,2026,'Examen Final',90),(398,610,2026,'Scratch',60),(399,610,2026,'HTML',60),(401,610,2026,'Python',60),(402,610,2026,'C#',60),(404,610,2026,'Photoshop',60),(406,610,2026,'Illustrator',60),(407,610,2026,'Filmora',60),(409,655,2026,'Windows',50),(410,655,2026,'Word',60),(411,655,2026,'Publisher',70),(412,655,2026,'PowerPoint',80),(413,655,2026,'Examen Parcial',100),(414,655,2026,'Excel',100),(415,655,2026,'Examen Final',90),(416,655,2026,'Scratch',60),(417,655,2026,'HTML',60),(419,655,2026,'Python',60),(420,655,2026,'C#',60),(422,655,2026,'Photoshop',60),(424,655,2026,'Illustrator',60),(425,655,2026,'Filmora',60),(427,604,2026,'Windows',50),(428,604,2026,'Word',60),(429,604,2026,'Publisher',70),(430,604,2026,'PowerPoint',80),(431,604,2026,'Examen Parcial',100),(432,604,2026,'Excel',100),(433,604,2026,'Examen Final',90),(434,604,2026,'Scratch',60),(435,604,2026,'HTML',60),(437,604,2026,'Python',60),(438,604,2026,'C#',60),(440,604,2026,'Photoshop',60),(442,604,2026,'Illustrator',60),(443,604,2026,'Filmora',60),(445,609,2026,'Windows',50),(446,609,2026,'Word',60),(447,609,2026,'Publisher',70),(448,609,2026,'PowerPoint',80),(449,609,2026,'Examen Parcial',100),(450,609,2026,'Excel',100),(451,609,2026,'Examen Final',90),(452,609,2026,'Scratch',60),(453,609,2026,'HTML',60),(455,609,2026,'Python',60),(456,609,2026,'C#',60),(458,609,2026,'Photoshop',60),(460,609,2026,'Illustrator',60),(461,609,2026,'Filmora',60),(463,13,2026,'Windows',50),(464,13,2026,'Word',60),(465,13,2026,'Publisher',70),(466,13,2026,'PowerPoint',80),(467,13,2026,'Examen Parcial',100),(468,13,2026,'Excel',100),(469,13,2026,'Examen Final',90),(470,13,2026,'Scratch',60),(471,13,2026,'HTML',60),(473,13,2026,'Python',60),(474,13,2026,'C#',60),(476,13,2026,'Photoshop',60),(478,13,2026,'Illustrator',60),(479,13,2026,'Filmora',60),(481,671,2026,'Windows',50),(482,671,2026,'Word',60),(483,671,2026,'Publisher',70),(484,671,2026,'PowerPoint',80),(485,671,2026,'Examen Parcial',100),(486,671,2026,'Excel',100),(487,671,2026,'Examen Final',90),(488,671,2026,'Scratch',60),(489,671,2026,'HTML',60),(491,671,2026,'Python',60),(492,671,2026,'C#',60),(494,671,2026,'Photoshop',60),(496,671,2026,'Illustrator',60),(497,671,2026,'Filmora',60),(499,587,2026,'Windows',50),(500,587,2026,'Word',60),(501,587,2026,'Publisher',70),(502,587,2026,'PowerPoint',80),(503,587,2026,'Examen Parcial',100),(504,587,2026,'Excel',100),(505,587,2026,'Examen Final',90),(506,587,2026,'Scratch',60),(507,587,2026,'HTML',60),(509,587,2026,'Python',60),(510,587,2026,'C#',60),(512,587,2026,'Photoshop',60),(514,587,2026,'Illustrator',60),(515,587,2026,'Filmora',60),(517,557,2026,'Windows',50),(518,557,2026,'Word',60),(519,557,2026,'Publisher',70),(520,557,2026,'PowerPoint',80),(521,557,2026,'Examen Parcial',100),(522,557,2026,'Excel',100),(523,557,2026,'Examen Final',90),(524,557,2026,'Scratch',60),(525,557,2026,'HTML',60),(527,557,2026,'Python',60),(528,557,2026,'C#',60),(530,557,2026,'Photoshop',60),(532,557,2026,'Illustrator',60),(533,557,2026,'Filmora',60),(535,27,2026,'Windows',50),(536,27,2026,'Word',60),(537,27,2026,'Publisher',70),(538,27,2026,'PowerPoint',80),(539,27,2026,'Examen Parcial',100),(540,27,2026,'Excel',100),(541,27,2026,'Examen Final',90),(542,27,2026,'Scratch',60),(543,27,2026,'HTML',60),(545,27,2026,'Python',60),(546,27,2026,'C#',60),(548,27,2026,'Photoshop',60),(550,27,2026,'Illustrator',60),(551,27,2026,'Filmora',60),(553,19,2026,'Windows',50),(554,19,2026,'Word',60),(555,19,2026,'Publisher',70),(556,19,2026,'PowerPoint',80),(557,19,2026,'Examen Parcial',100),(558,19,2026,'Excel',100),(559,19,2026,'Examen Final',90),(560,19,2026,'Scratch',60),(561,19,2026,'HTML',60),(563,19,2026,'Python',60),(564,19,2026,'C#',60),(566,19,2026,'Photoshop',60),(568,19,2026,'Illustrator',60),(569,19,2026,'Filmora',60),(571,605,2026,'Windows',50),(572,605,2026,'Word',60),(573,605,2026,'Publisher',70),(574,605,2026,'PowerPoint',80),(575,605,2026,'Examen Parcial',100),(576,605,2026,'Excel',100),(577,605,2026,'Examen Final',90),(578,605,2026,'Scratch',60),(579,605,2026,'HTML',60),(581,605,2026,'Python',60),(582,605,2026,'C#',60),(584,605,2026,'Photoshop',60),(586,605,2026,'Illustrator',60),(587,605,2026,'Filmora',60),(589,667,2026,'Windows',50),(590,667,2026,'Word',60),(591,667,2026,'Publisher',70),(592,667,2026,'PowerPoint',80),(593,667,2026,'Examen Parcial',100),(594,667,2026,'Excel',100),(595,667,2026,'Examen Final',90),(596,667,2026,'Scratch',60),(597,667,2026,'HTML',60),(599,667,2026,'Python',60),(600,667,2026,'C#',60),(602,667,2026,'Photoshop',60),(604,667,2026,'Illustrator',60),(605,667,2026,'Filmora',60),(607,662,2026,'Windows',50),(608,662,2026,'Word',60),(609,662,2026,'Publisher',70),(610,662,2026,'PowerPoint',80),(611,662,2026,'Examen Parcial',100),(612,662,2026,'Excel',100),(613,662,2026,'Examen Final',90),(614,662,2026,'Scratch',60),(615,662,2026,'HTML',60),(617,662,2026,'Python',60),(618,662,2026,'C#',60),(620,662,2026,'Photoshop',60),(622,662,2026,'Illustrator',60),(623,662,2026,'Filmora',60),(625,664,2026,'Windows',50),(626,664,2026,'Word',60),(627,664,2026,'Publisher',70),(628,664,2026,'PowerPoint',80),(629,664,2026,'Examen Parcial',100),(630,664,2026,'Excel',100),(631,664,2026,'Examen Final',90),(632,664,2026,'Scratch',60),(633,664,2026,'HTML',60),(635,664,2026,'Python',60),(636,664,2026,'C#',60),(638,664,2026,'Photoshop',60),(640,664,2026,'Illustrator',60),(641,664,2026,'Filmora',60),(643,595,2026,'Windows',50),(644,595,2026,'Word',60),(645,595,2026,'Publisher',70),(646,595,2026,'PowerPoint',80),(647,595,2026,'Examen Parcial',100),(648,595,2026,'Excel',100),(649,595,2026,'Examen Final',90),(650,595,2026,'Scratch',60),(651,595,2026,'HTML',60),(653,595,2026,'Python',60),(654,595,2026,'C#',60),(656,595,2026,'Photoshop',60),(658,595,2026,'Illustrator',60),(659,595,2026,'Filmora',60),(661,565,2026,'Windows',50),(662,565,2026,'Word',60),(663,565,2026,'Publisher',70),(664,565,2026,'PowerPoint',80),(665,565,2026,'Examen Parcial',100),(666,565,2026,'Excel',100),(667,565,2026,'Examen Final',90),(668,565,2026,'Scratch',60),(669,565,2026,'HTML',60),(671,565,2026,'Python',60),(672,565,2026,'C#',60),(674,565,2026,'Photoshop',60),(676,565,2026,'Illustrator',60),(677,565,2026,'Filmora',60),(679,35,2026,'Windows',50),(680,35,2026,'Word',60),(681,35,2026,'Publisher',70),(682,35,2026,'PowerPoint',80),(683,35,2026,'Examen Parcial',100),(684,35,2026,'Excel',100),(685,35,2026,'Examen Final',90),(686,35,2026,'Scratch',60),(687,35,2026,'HTML',60),(689,35,2026,'Python',60),(690,35,2026,'C#',60),(692,35,2026,'Photoshop',60),(694,35,2026,'Illustrator',60),(695,35,2026,'Filmora',60),(697,3,2026,'Windows',50),(698,3,2026,'Word',60),(699,3,2026,'Publisher',70),(700,3,2026,'PowerPoint',80),(701,3,2026,'Examen Parcial',100),(702,3,2026,'Excel',100),(703,3,2026,'Examen Final',90),(704,3,2026,'Scratch',60),(705,3,2026,'HTML',60),(707,3,2026,'Python',60),(708,3,2026,'C#',60),(710,3,2026,'Photoshop',60),(712,3,2026,'Illustrator',60),(713,3,2026,'Filmora',60),(715,581,2026,'Windows',50),(716,581,2026,'Word',60),(717,581,2026,'Publisher',70),(718,581,2026,'PowerPoint',80),(719,581,2026,'Examen Parcial',100),(720,581,2026,'Excel',100),(721,581,2026,'Examen Final',90),(722,581,2026,'Scratch',60),(723,581,2026,'HTML',60),(725,581,2026,'Python',60),(726,581,2026,'C#',60),(728,581,2026,'Photoshop',60),(730,581,2026,'Illustrator',60),(731,581,2026,'Filmora',60),(733,551,2026,'Windows',50),(734,551,2026,'Word',60),(735,551,2026,'Publisher',70),(736,551,2026,'PowerPoint',80),(737,551,2026,'Examen Parcial',100),(738,551,2026,'Excel',100),(739,551,2026,'Examen Final',90),(740,551,2026,'Scratch',60),(741,551,2026,'HTML',60),(743,551,2026,'Python',60),(744,551,2026,'C#',60),(746,551,2026,'Photoshop',60),(748,551,2026,'Illustrator',60),(749,551,2026,'Filmora',60),(751,21,2026,'Windows',50),(752,21,2026,'Word',60),(753,21,2026,'Publisher',70),(754,21,2026,'PowerPoint',80),(755,21,2026,'Examen Parcial',100),(756,21,2026,'Excel',100),(757,21,2026,'Examen Final',90),(758,21,2026,'Scratch',60),(759,21,2026,'HTML',60),(761,21,2026,'Python',60),(762,21,2026,'C#',60),(764,21,2026,'Photoshop',60),(766,21,2026,'Illustrator',60),(767,21,2026,'Filmora',60),(769,39,2026,'Windows',50),(770,39,2026,'Word',60),(771,39,2026,'Publisher',70),(772,39,2026,'PowerPoint',80),(773,39,2026,'Examen Parcial',100),(774,39,2026,'Excel',100),(775,39,2026,'Examen Final',90),(776,39,2026,'Scratch',60),(777,39,2026,'HTML',60),(779,39,2026,'Python',60),(780,39,2026,'C#',60),(782,39,2026,'Photoshop',60),(784,39,2026,'Illustrator',60),(785,39,2026,'Filmora',60),(787,569,2026,'Windows',50),(788,569,2026,'Word',60),(789,569,2026,'Publisher',70),(790,569,2026,'PowerPoint',80),(791,569,2026,'Examen Parcial',100),(792,569,2026,'Excel',100),(793,569,2026,'Examen Final',90),(794,569,2026,'Scratch',60),(795,569,2026,'HTML',60),(797,569,2026,'Python',60),(798,569,2026,'C#',60),(800,569,2026,'Photoshop',60),(802,569,2026,'Illustrator',60),(803,569,2026,'Filmora',60),(805,657,2026,'Windows',50),(806,657,2026,'Word',60),(807,657,2026,'Publisher',70),(808,657,2026,'PowerPoint',80),(809,657,2026,'Examen Parcial',100),(810,657,2026,'Excel',100),(811,657,2026,'Examen Final',90),(812,657,2026,'Scratch',60),(813,657,2026,'HTML',60),(815,657,2026,'Python',60),(816,657,2026,'C#',60),(818,657,2026,'Photoshop',60),(820,657,2026,'Illustrator',60),(821,657,2026,'Filmora',60),(823,606,2026,'Windows',50),(824,606,2026,'Word',60),(825,606,2026,'Publisher',70),(826,606,2026,'PowerPoint',80),(827,606,2026,'Examen Parcial',100),(828,606,2026,'Excel',100),(829,606,2026,'Examen Final',90),(830,606,2026,'Scratch',60),(831,606,2026,'HTML',60),(833,606,2026,'Python',60),(834,606,2026,'C#',60),(836,606,2026,'Photoshop',60),(838,606,2026,'Illustrator',60),(839,606,2026,'Filmora',60),(841,5,2026,'Windows',50),(842,5,2026,'Word',60),(843,5,2026,'Publisher',70),(844,5,2026,'PowerPoint',80),(845,5,2026,'Examen Parcial',100),(846,5,2026,'Excel',100),(847,5,2026,'Examen Final',90),(848,5,2026,'Scratch',60),(849,5,2026,'HTML',60),(851,5,2026,'Python',60),(852,5,2026,'C#',60),(854,5,2026,'Photoshop',60),(856,5,2026,'Illustrator',60),(857,5,2026,'Filmora',60),(859,661,2026,'Windows',50),(860,661,2026,'Word',60),(861,661,2026,'Publisher',70),(862,661,2026,'PowerPoint',80),(863,661,2026,'Examen Parcial',100),(864,661,2026,'Excel',100),(865,661,2026,'Examen Final',90),(866,661,2026,'Scratch',60),(867,661,2026,'HTML',60),(869,661,2026,'Python',60),(870,661,2026,'C#',60),(872,661,2026,'Photoshop',60),(874,661,2026,'Illustrator',60),(875,661,2026,'Filmora',60),(881,601,2026,'Examen Parcial',100),(883,601,2026,'Examen Final',90),(895,666,2026,'Windows',50),(896,666,2026,'Word',60),(897,666,2026,'Publisher',70),(898,666,2026,'PowerPoint',80),(899,666,2026,'Examen Parcial',100),(900,666,2026,'Excel',100),(901,666,2026,'Examen Final',90),(902,666,2026,'Scratch',60),(903,666,2026,'HTML',60),(905,666,2026,'Python',60),(906,666,2026,'C#',60),(908,666,2026,'Photoshop',60),(910,666,2026,'Illustrator',60),(911,666,2026,'Filmora',60),(913,47,2026,'Windows',50),(914,47,2026,'Word',60),(915,47,2026,'Publisher',70),(916,47,2026,'PowerPoint',80),(917,47,2026,'Examen Parcial',100),(918,47,2026,'Excel',100),(919,47,2026,'Examen Final',90),(920,47,2026,'Scratch',60),(921,47,2026,'HTML',60),(923,47,2026,'Python',60),(924,47,2026,'C#',60),(926,47,2026,'Photoshop',60),(928,47,2026,'Illustrator',60),(929,47,2026,'Filmora',60),(931,577,2026,'Windows',50),(932,577,2026,'Word',60),(933,577,2026,'Publisher',70),(934,577,2026,'PowerPoint',80),(935,577,2026,'Examen Parcial',100),(936,577,2026,'Excel',100),(937,577,2026,'Examen Final',90),(938,577,2026,'Scratch',60),(939,577,2026,'HTML',60),(941,577,2026,'Python',60),(942,577,2026,'C#',60),(944,577,2026,'Photoshop',60),(946,577,2026,'Illustrator',60),(947,577,2026,'Filmora',60),(949,591,2026,'Windows',50),(950,591,2026,'Word',60),(951,591,2026,'Publisher',70),(952,591,2026,'PowerPoint',80),(953,591,2026,'Examen Parcial',100),(954,591,2026,'Excel',100),(955,591,2026,'Examen Final',90),(956,591,2026,'Scratch',60),(957,591,2026,'HTML',60),(959,591,2026,'Python',60),(960,591,2026,'C#',60),(962,591,2026,'Photoshop',60),(964,591,2026,'Illustrator',60),(965,591,2026,'Filmora',60),(967,31,2026,'Windows',50),(968,31,2026,'Word',60),(969,31,2026,'Publisher',70),(970,31,2026,'PowerPoint',80),(971,31,2026,'Examen Parcial',100),(972,31,2026,'Excel',100),(973,31,2026,'Examen Final',90),(974,31,2026,'Scratch',60),(975,31,2026,'HTML',60),(977,31,2026,'Python',60),(978,31,2026,'C#',60),(980,31,2026,'Photoshop',60),(982,31,2026,'Illustrator',60),(983,31,2026,'Filmora',60),(985,561,2026,'Windows',50),(986,561,2026,'Word',60),(987,561,2026,'Publisher',70),(988,561,2026,'PowerPoint',80),(989,561,2026,'Examen Parcial',100),(990,561,2026,'Excel',100),(991,561,2026,'Examen Final',90),(992,561,2026,'Scratch',60),(993,561,2026,'HTML',60),(995,561,2026,'Python',60),(996,561,2026,'C#',60),(998,561,2026,'Photoshop',60),(1000,561,2026,'Illustrator',60),(1001,561,2026,'Filmora',60),(1003,573,2026,'Windows',50),(1004,573,2026,'Word',60),(1005,573,2026,'Publisher',70),(1006,573,2026,'PowerPoint',80),(1007,573,2026,'Examen Parcial',100),(1008,573,2026,'Excel',100),(1009,573,2026,'Examen Final',90),(1010,573,2026,'Scratch',60),(1011,573,2026,'HTML',60),(1013,573,2026,'Python',60),(1014,573,2026,'C#',60),(1016,573,2026,'Photoshop',60),(1018,573,2026,'Illustrator',60),(1019,573,2026,'Filmora',60),(1021,43,2026,'Windows',50),(1022,43,2026,'Word',60),(1023,43,2026,'Publisher',70),(1024,43,2026,'PowerPoint',80),(1025,43,2026,'Examen Parcial',100),(1026,43,2026,'Excel',100),(1027,43,2026,'Examen Final',90),(1028,43,2026,'Scratch',60),(1029,43,2026,'HTML',60),(1031,43,2026,'Python',60),(1032,43,2026,'C#',60),(1034,43,2026,'Photoshop',60),(1036,43,2026,'Illustrator',60),(1037,43,2026,'Filmora',60),(1039,597,2026,'Windows',50),(1040,597,2026,'Word',60),(1041,597,2026,'Publisher',70),(1042,597,2026,'PowerPoint',80),(1043,597,2026,'Examen Parcial',100),(1044,597,2026,'Excel',100),(1045,597,2026,'Examen Final',90),(1046,597,2026,'Scratch',60),(1047,597,2026,'HTML',60),(1049,597,2026,'Python',60),(1050,597,2026,'C#',60),(1052,597,2026,'Photoshop',60),(1054,597,2026,'Illustrator',60),(1055,597,2026,'Filmora',60),(1057,567,2026,'Windows',50),(1058,567,2026,'Word',60),(1059,567,2026,'Publisher',70),(1060,567,2026,'PowerPoint',80),(1061,567,2026,'Examen Parcial',100),(1062,567,2026,'Excel',100),(1063,567,2026,'Examen Final',90),(1064,567,2026,'Scratch',60),(1065,567,2026,'HTML',60),(1067,567,2026,'Python',60),(1068,567,2026,'C#',60),(1070,567,2026,'Photoshop',60),(1072,567,2026,'Illustrator',60),(1073,567,2026,'Filmora',60),(1075,37,2026,'Windows',50),(1076,37,2026,'Word',60),(1077,37,2026,'Publisher',70),(1078,37,2026,'PowerPoint',80),(1079,37,2026,'Examen Parcial',100),(1080,37,2026,'Excel',100),(1081,37,2026,'Examen Final',90),(1082,37,2026,'Scratch',60),(1083,37,2026,'HTML',60),(1085,37,2026,'Python',60),(1086,37,2026,'C#',60),(1088,37,2026,'Photoshop',60),(1090,37,2026,'Illustrator',60),(1091,37,2026,'Filmora',60),(1147,589,2026,'Windows',50),(1148,589,2026,'Word',60),(1149,589,2026,'Publisher',70),(1150,589,2026,'PowerPoint',80),(1151,589,2026,'Examen Parcial',100),(1152,589,2026,'Excel',100),(1153,589,2026,'Examen Final',90),(1154,589,2026,'Scratch',60),(1155,589,2026,'HTML',60),(1157,589,2026,'Python',60),(1158,589,2026,'C#',60),(1160,589,2026,'Photoshop',60),(1162,589,2026,'Illustrator',60),(1163,589,2026,'Filmora',60),(1165,559,2026,'Windows',50),(1166,559,2026,'Word',60),(1167,559,2026,'Publisher',70),(1168,559,2026,'PowerPoint',80),(1169,559,2026,'Examen Parcial',100),(1170,559,2026,'Excel',100),(1171,559,2026,'Examen Final',90),(1172,559,2026,'Scratch',60),(1173,559,2026,'HTML',60),(1175,559,2026,'Python',60),(1176,559,2026,'C#',60),(1178,559,2026,'Photoshop',60),(1180,559,2026,'Illustrator',60),(1181,559,2026,'Filmora',60),(1183,29,2026,'Windows',50),(1184,29,2026,'Word',60),(1185,29,2026,'Publisher',70),(1186,29,2026,'PowerPoint',80),(1187,29,2026,'Examen Parcial',100),(1188,29,2026,'Excel',100),(1189,29,2026,'Examen Final',90),(1190,29,2026,'Scratch',60),(1191,29,2026,'HTML',60),(1193,29,2026,'Python',60),(1194,29,2026,'C#',60),(1196,29,2026,'Photoshop',60),(1198,29,2026,'Illustrator',60),(1199,29,2026,'Filmora',60),(1201,7,2026,'Windows',50),(1202,7,2026,'Word',60),(1203,7,2026,'Publisher',70),(1204,7,2026,'PowerPoint',80),(1205,7,2026,'Examen Parcial',100),(1206,7,2026,'Excel',100),(1207,7,2026,'Examen Final',90),(1208,7,2026,'Scratch',60),(1209,7,2026,'HTML',60),(1211,7,2026,'Python',60),(1212,7,2026,'C#',60),(1214,7,2026,'Photoshop',60),(1216,7,2026,'Illustrator',60),(1217,7,2026,'Filmora',60),(1219,654,2026,'Windows',50),(1220,654,2026,'Word',60),(1221,654,2026,'Publisher',70),(1222,654,2026,'PowerPoint',80),(1223,654,2026,'Examen Parcial',100),(1224,654,2026,'Excel',100),(1225,654,2026,'Examen Final',90),(1226,654,2026,'Scratch',60),(1227,654,2026,'HTML',60),(1229,654,2026,'Python',60),(1230,654,2026,'C#',60),(1232,654,2026,'Photoshop',60),(1234,654,2026,'Illustrator',60),(1235,654,2026,'Filmora',60),(1237,579,2026,'Windows',50),(1238,579,2026,'Word',60),(1239,579,2026,'Publisher',70),(1240,579,2026,'PowerPoint',80),(1241,579,2026,'Examen Parcial',100),(1242,579,2026,'Excel',100),(1243,579,2026,'Examen Final',90),(1244,579,2026,'Scratch',60),(1245,579,2026,'HTML',60),(1247,579,2026,'Python',60),(1248,579,2026,'C#',60),(1250,579,2026,'Photoshop',60),(1252,579,2026,'Illustrator',60),(1253,579,2026,'Filmora',60),(1255,49,2026,'Windows',50),(1256,49,2026,'Word',60),(1257,49,2026,'Publisher',70),(1258,49,2026,'PowerPoint',80),(1259,49,2026,'Examen Parcial',100),(1260,49,2026,'Excel',100),(1261,49,2026,'Examen Final',90),(1262,49,2026,'Scratch',60),(1263,49,2026,'HTML',60),(1265,49,2026,'Python',60),(1266,49,2026,'C#',60),(1268,49,2026,'Photoshop',60),(1270,49,2026,'Illustrator',60),(1271,49,2026,'Filmora',60),(1273,553,2026,'Windows',50),(1274,553,2026,'Word',60),(1275,553,2026,'Publisher',70),(1276,553,2026,'PowerPoint',80),(1277,553,2026,'Examen Parcial',100),(1278,553,2026,'Excel',100),(1279,553,2026,'Examen Final',90),(1280,553,2026,'Scratch',60),(1281,553,2026,'HTML',60),(1283,553,2026,'Python',60),(1284,553,2026,'C#',60),(1286,553,2026,'Photoshop',60),(1288,553,2026,'Illustrator',60),(1289,553,2026,'Filmora',60),(1291,583,2026,'Windows',50),(1292,583,2026,'Word',60),(1293,583,2026,'Publisher',70),(1294,583,2026,'PowerPoint',80),(1295,583,2026,'Examen Parcial',100),(1296,583,2026,'Excel',100),(1297,583,2026,'Examen Final',90),(1298,583,2026,'Scratch',60),(1299,583,2026,'HTML',60),(1301,583,2026,'Python',60),(1302,583,2026,'C#',60),(1304,583,2026,'Photoshop',60),(1306,583,2026,'Illustrator',60),(1307,583,2026,'Filmora',60),(1309,23,2026,'Windows',50),(1310,23,2026,'Word',60),(1311,23,2026,'Publisher',70),(1312,23,2026,'PowerPoint',80),(1313,23,2026,'Examen Parcial',100),(1314,23,2026,'Excel',100),(1315,23,2026,'Examen Final',90),(1316,23,2026,'Scratch',60),(1317,23,2026,'HTML',60),(1319,23,2026,'Python',60),(1320,23,2026,'C#',60),(1322,23,2026,'Photoshop',60),(1324,23,2026,'Illustrator',60),(1325,23,2026,'Filmora',60),(1327,665,2026,'Windows',50),(1328,665,2026,'Word',60),(1329,665,2026,'Publisher',70),(1330,665,2026,'PowerPoint',80),(1331,665,2026,'Examen Parcial',100),(1332,665,2026,'Excel',100),(1333,665,2026,'Examen Final',90),(1334,665,2026,'Scratch',60),(1335,665,2026,'HTML',60),(1337,665,2026,'Python',60),(1338,665,2026,'C#',60),(1340,665,2026,'Photoshop',60),(1342,665,2026,'Illustrator',60),(1343,665,2026,'Filmora',60),(1345,571,2026,'Windows',50),(1346,571,2026,'Word',60),(1347,571,2026,'Publisher',70),(1348,571,2026,'PowerPoint',80),(1349,571,2026,'Examen Parcial',100),(1350,571,2026,'Excel',100),(1351,571,2026,'Examen Final',90),(1352,571,2026,'Scratch',60),(1353,571,2026,'HTML',60),(1355,571,2026,'Python',60),(1356,571,2026,'C#',60),(1358,571,2026,'Photoshop',60),(1360,571,2026,'Illustrator',60),(1361,571,2026,'Filmora',60),(1363,41,2026,'Windows',50),(1364,41,2026,'Word',60),(1365,41,2026,'Publisher',70),(1366,41,2026,'PowerPoint',80),(1367,41,2026,'Examen Parcial',100),(1368,41,2026,'Excel',100),(1369,41,2026,'Examen Final',90),(1370,41,2026,'Scratch',60),(1371,41,2026,'HTML',60),(1373,41,2026,'Python',60),(1374,41,2026,'C#',60),(1376,41,2026,'Photoshop',60),(1378,41,2026,'Illustrator',60),(1379,41,2026,'Filmora',60),(1381,15,2026,'Windows',50),(1382,15,2026,'Word',60),(1383,15,2026,'Publisher',70),(1384,15,2026,'PowerPoint',80),(1385,15,2026,'Examen Parcial',100),(1386,15,2026,'Excel',100),(1387,15,2026,'Examen Final',90),(1388,15,2026,'Scratch',60),(1389,15,2026,'HTML',60),(1391,15,2026,'Python',60),(1392,15,2026,'C#',60),(1394,15,2026,'Photoshop',60),(1396,15,2026,'Illustrator',60),(1397,15,2026,'Filmora',60),(1399,612,2026,'Windows',50),(1400,612,2026,'Word',60),(1401,612,2026,'Publisher',70),(1402,612,2026,'PowerPoint',80),(1403,612,2026,'Examen Parcial',100),(1404,612,2026,'Excel',100),(1405,612,2026,'Examen Final',90),(1406,612,2026,'Scratch',60),(1407,612,2026,'HTML',60),(1409,612,2026,'Python',60),(1410,612,2026,'C#',60),(1412,612,2026,'Photoshop',60),(1414,612,2026,'Illustrator',60),(1415,612,2026,'Filmora',60),(1417,660,2026,'Windows',50),(1418,660,2026,'Word',60),(1419,660,2026,'Publisher',70),(1420,660,2026,'PowerPoint',80),(1421,660,2026,'Examen Parcial',100),(1422,660,2026,'Excel',100),(1423,660,2026,'Examen Final',90),(1424,660,2026,'Scratch',60),(1425,660,2026,'HTML',60),(1427,660,2026,'Python',60),(1428,660,2026,'C#',60),(1430,660,2026,'Photoshop',60),(1432,660,2026,'Illustrator',60),(1433,660,2026,'Filmora',60),(1435,607,2026,'Windows',50),(1436,607,2026,'Word',60),(1437,607,2026,'Publisher',70),(1438,607,2026,'PowerPoint',80),(1439,607,2026,'Examen Parcial',100),(1440,607,2026,'Excel',100),(1441,607,2026,'Examen Final',90),(1442,607,2026,'Scratch',60),(1443,607,2026,'HTML',60),(1445,607,2026,'Python',60),(1446,607,2026,'C#',60),(1448,607,2026,'Photoshop',60),(1450,607,2026,'Illustrator',60),(1451,607,2026,'Filmora',60),(1453,656,2026,'Windows',50),(1454,656,2026,'Word',60),(1455,656,2026,'Publisher',70),(1456,656,2026,'PowerPoint',80),(1457,656,2026,'Examen Parcial',100),(1458,656,2026,'Excel',100),(1459,656,2026,'Examen Final',90),(1460,656,2026,'Scratch',60),(1461,656,2026,'HTML',60),(1463,656,2026,'Python',60),(1464,656,2026,'C#',60),(1466,656,2026,'Photoshop',60),(1468,656,2026,'Illustrator',60),(1469,656,2026,'Filmora',60),(1471,608,2026,'Windows',50),(1472,608,2026,'Word',60),(1473,608,2026,'Publisher',70),(1474,608,2026,'PowerPoint',80),(1475,608,2026,'Examen Parcial',100),(1476,608,2026,'Excel',100),(1477,608,2026,'Examen Final',90),(1478,608,2026,'Scratch',60),(1479,608,2026,'HTML',60),(1481,608,2026,'Python',60),(1482,608,2026,'C#',60),(1484,608,2026,'Photoshop',60),(1486,608,2026,'Illustrator',60),(1487,608,2026,'Filmora',60),(1489,658,2026,'Windows',50),(1490,658,2026,'Word',60),(1491,658,2026,'Publisher',70),(1492,658,2026,'PowerPoint',80),(1493,658,2026,'Examen Parcial',100),(1494,658,2026,'Excel',100),(1495,658,2026,'Examen Final',90),(1496,658,2026,'Scratch',60),(1497,658,2026,'HTML',60),(1499,658,2026,'Python',60),(1500,658,2026,'C#',60),(1502,658,2026,'Photoshop',60),(1504,658,2026,'Illustrator',60),(1505,658,2026,'Filmora',60),(1507,1,2026,'Windows',50),(1511,1,2026,'Examen Parcial',100),(1513,1,2026,'Examen Final',90),(1518,1,2026,'C#',60),(1525,611,2026,'Windows',50),(1526,611,2026,'Word',60),(1527,611,2026,'Publisher',70),(1528,611,2026,'PowerPoint',80),(1529,611,2026,'Examen Parcial',100),(1530,611,2026,'Excel',100),(1531,611,2026,'Examen Final',90),(1532,611,2026,'Scratch',60),(1533,611,2026,'HTML',60),(1535,611,2026,'Python',60),(1536,611,2026,'C#',60),(1538,611,2026,'Photoshop',60),(1540,611,2026,'Illustrator',60),(1541,611,2026,'Filmora',60),(1543,670,2026,'Windows',50),(1544,670,2026,'Word',60),(1545,670,2026,'Publisher',70),(1546,670,2026,'PowerPoint',80),(1547,670,2026,'Examen Parcial',100),(1548,670,2026,'Excel',100),(1549,670,2026,'Examen Final',90),(1550,670,2026,'Scratch',60),(1551,670,2026,'HTML',60),(1553,670,2026,'Python',60),(1554,670,2026,'C#',60),(1556,670,2026,'Photoshop',60),(1558,670,2026,'Illustrator',60),(1559,670,2026,'Filmora',60),(1561,613,2026,'Windows',50),(1562,613,2026,'Word',60),(1563,613,2026,'Publisher',70),(1564,613,2026,'PowerPoint',80),(1565,613,2026,'Examen Parcial',100),(1566,613,2026,'Excel',100),(1567,613,2026,'Examen Final',90),(1568,613,2026,'Scratch',60),(1569,613,2026,'HTML',60),(1571,613,2026,'Python',60),(1572,613,2026,'C#',60),(1574,613,2026,'Photoshop',60),(1576,613,2026,'Illustrator',60),(1577,613,2026,'Filmora',60),(1579,11,2026,'Windows',50),(1580,11,2026,'Word',60),(1581,11,2026,'Publisher',70),(1582,11,2026,'PowerPoint',80),(1583,11,2026,'Examen Parcial',100),(1584,11,2026,'Excel',100),(1585,11,2026,'Examen Final',90),(1586,11,2026,'Scratch',60),(1587,11,2026,'HTML',60),(1589,11,2026,'Python',60),(1590,11,2026,'C#',60),(1592,11,2026,'Photoshop',60),(1594,11,2026,'Illustrator',60),(1595,11,2026,'Filmora',60),(1597,674,2026,'Windows',98),(1598,674,2026,'Word',95),(1599,674,2026,'Publisher',99),(1600,674,2026,'PowerPoint',85),(1601,674,2026,'Examen Parcial',75),(1602,674,2026,'Excel',60),(1604,674,2026,'Scratch',98),(1605,674,2026,'HTML',98),(1606,674,2026,'Python',85),(1607,675,2026,'Scratch',100),(1608,675,2026,'HTML',98),(1609,675,2026,'Examen Parcial',99),(1610,675,2026,'Python',100),(1611,675,2026,'C#',99),(1612,675,2026,'Examen Final',99),(1613,676,2026,'Scratch',85),(1614,676,2026,'HTML',87),(1615,676,2026,'Examen Parcial',85),(1616,676,2026,'Python',85),(1617,676,2026,'C#',96);
/*!40000 ALTER TABLE `diplomado_notas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inscritos_tac`
--

DROP TABLE IF EXISTS `inscritos_tac`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inscritos_tac` (
  `id` int NOT NULL AUTO_INCREMENT,
  `alumno_id` int NOT NULL,
  `anio` smallint NOT NULL,
  `tac` tinyint NOT NULL,
  `estado` enum('inscrito','no_inscrito','pendiente') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'no_inscrito',
  `fecha_actualizacion` datetime DEFAULT NULL,
  `observaciones` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_inscritos_tac` (`alumno_id`,`anio`,`tac`),
  KEY `idx_inscritos_anio_tac` (`anio`,`tac`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inscritos_tac`
--

LOCK TABLES `inscritos_tac` WRITE;
/*!40000 ALTER TABLE `inscritos_tac` DISABLE KEYS */;
INSERT INTO `inscritos_tac` VALUES (1,585,2026,1,'no_inscrito','2026-04-29 23:50:05',''),(4,555,2026,1,'no_inscrito','2026-04-30 07:56:42',''),(6,628,2026,1,'pendiente','2026-05-07 12:00:54','');
/*!40000 ALTER TABLE `inscritos_tac` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `instituciones`
--

DROP TABLE IF EXISTS `instituciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `instituciones` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `resolucion` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `ubicacion` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `extras` longtext COLLATE utf8mb4_unicode_ci,
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `instituciones`
--

LOCK TABLES `instituciones` WRITE;
/*!40000 ALTER TABLE `instituciones` DISABLE KEYS */;
/*!40000 ALTER TABLE `instituciones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mecanografia`
--

DROP TABLE IF EXISTS `mecanografia`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mecanografia` (
  `id` int NOT NULL AUTO_INCREMENT,
  `alumno_id` int NOT NULL,
  `leccion` int NOT NULL,
  `punteo` decimal(5,2) DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `completada` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `alumno_id` (`alumno_id`),
  CONSTRAINT `mecanografia_ibfk_1` FOREIGN KEY (`alumno_id`) REFERENCES `alumnos` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mecanografia`
--

LOCK TABLES `mecanografia` WRITE;
/*!40000 ALTER TABLE `mecanografia` DISABLE KEYS */;
INSERT INTO `mecanografia` VALUES (1,2,1,99.99,'2026-04-16',1);
/*!40000 ALTER TABLE `mecanografia` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mecanografia_notas`
--

DROP TABLE IF EXISTS `mecanografia_notas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mecanografia_notas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `alumno_id` int NOT NULL,
  `anio` smallint NOT NULL,
  `l1` smallint DEFAULT NULL,
  `l2` smallint DEFAULT NULL,
  `l3` smallint DEFAULT NULL,
  `l4` smallint DEFAULT NULL,
  `l5` smallint DEFAULT NULL,
  `l6` smallint DEFAULT NULL,
  `l7` smallint DEFAULT NULL,
  `l8` smallint DEFAULT NULL,
  `l9` smallint DEFAULT NULL,
  `l10` smallint DEFAULT NULL,
  `l11` smallint DEFAULT NULL,
  `l12` smallint DEFAULT NULL,
  `l13` smallint DEFAULT NULL,
  `l14` smallint DEFAULT NULL,
  `l15` smallint DEFAULT NULL,
  `l16` smallint DEFAULT NULL,
  `l17` smallint DEFAULT NULL,
  `l18` smallint DEFAULT NULL,
  `l19` smallint DEFAULT NULL,
  `l20` smallint DEFAULT NULL,
  `examen` smallint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_mec_n` (`alumno_id`,`anio`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mecanografia_notas`
--

LOCK TABLES `mecanografia_notas` WRITE;
/*!40000 ALTER TABLE `mecanografia_notas` DISABLE KEYS */;
INSERT INTO `mecanografia_notas` VALUES (1,600,2026,100,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(2,40,2026,56,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(3,570,2026,60,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(5,2,2026,85,85,74,68,61,60,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(6,592,2026,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(7,603,2026,98,98,98,100,75,74,76,76,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(8,674,2026,68,98,71,68,98,74,85,85,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(9,675,2026,98,95,96,96,96,96,96,96,96,96,96,96,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(10,676,2026,98,98,85,85,87,84,86,85,85,82,80,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(11,1,2026,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `mecanografia_notas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mensualidades`
--

DROP TABLE IF EXISTS `mensualidades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mensualidades` (
  `id` int NOT NULL AUTO_INCREMENT,
  `alumno_id` int NOT NULL,
  `mes` enum('enero','febrero','marzo','abril','mayo','junio','julio','agosto','septiembre','octubre','noviembre','diciembre') COLLATE utf8mb4_unicode_ci NOT NULL,
  `anio` year NOT NULL DEFAULT (year(curdate())),
  `monto` decimal(8,2) NOT NULL DEFAULT '0.00',
  `pagado` tinyint(1) DEFAULT '0',
  `anulado` tinyint(1) DEFAULT '0',
  `descuento_100` tinyint(1) DEFAULT '0',
  `no_recibo` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fecha_pago` date DEFAULT NULL,
  `monto_abonado` decimal(10,2) NOT NULL DEFAULT '0.00',
  `acreditado` tinyint(1) NOT NULL DEFAULT '0',
  `acreditado_msg` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_pago` (`alumno_id`,`mes`,`anio`),
  UNIQUE KEY `uk_mens` (`alumno_id`,`mes`,`anio`),
  CONSTRAINT `mensualidades_ibfk_1` FOREIGN KEY (`alumno_id`) REFERENCES `alumnos` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=474471 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mensualidades`
--

LOCK TABLES `mensualidades` WRITE;
/*!40000 ALTER TABLE `mensualidades` DISABLE KEYS */;
INSERT INTO `mensualidades` VALUES (53,1,'enero',2026,40.00,1,0,0,'100','2026-04-21',40.00,0,NULL),(54,1,'febrero',2026,40.00,1,0,0,'101','2026-04-21',40.00,0,NULL),(55,1,'marzo',2026,40.00,1,0,0,'101','2026-04-21',40.00,0,NULL),(56,1,'abril',2026,40.00,1,0,0,'101','2026-04-21',40.00,0,NULL),(57,1,'mayo',2026,40.00,1,0,0,'101','2026-04-21',40.00,0,NULL),(58,1,'junio',2026,40.00,1,0,0,'102','2026-04-22',40.00,0,NULL),(59,1,'julio',2026,40.00,1,0,0,'102','2026-04-22',40.00,0,NULL),(60,1,'agosto',2026,40.00,1,0,0,'103','2026-04-22',40.00,0,NULL),(61,1,'septiembre',2026,40.00,1,0,0,'104','2026-04-22',40.00,0,NULL),(62,1,'octubre',2026,40.00,0,0,0,'104','2026-04-22',5.00,0,NULL),(63,1,'noviembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(64,1,'diciembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(65,2,'enero',2026,75.00,1,0,0,'105','2026-04-22',75.00,0,NULL),(66,2,'febrero',2026,75.00,1,0,0,'105','2026-04-22',75.00,0,NULL),(67,2,'marzo',2026,75.00,1,0,0,'106','2026-04-22',75.00,0,NULL),(68,2,'abril',2026,75.00,1,0,0,'106','2026-04-22',75.00,0,NULL),(69,2,'mayo',2026,75.00,1,0,0,'106','2026-04-22',75.00,0,NULL),(70,2,'junio',2026,75.00,1,0,0,'107','2026-04-22',75.00,0,NULL),(71,2,'julio',2026,75.00,1,0,0,'107','2026-04-22',75.00,0,NULL),(72,2,'agosto',2026,75.00,1,0,0,'109',NULL,0.00,0,NULL),(73,2,'septiembre',2026,75.00,1,0,0,'111','2026-04-23',35.00,0,NULL),(74,2,'octubre',2026,75.00,1,0,0,'112','2026-04-22',75.00,0,NULL),(75,2,'noviembre',2026,75.00,1,0,0,'113','2026-04-23',75.00,0,NULL),(76,2,'diciembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(77,3,'enero',2026,50.00,1,0,0,'108','2026-04-22',50.00,0,NULL),(78,3,'febrero',2026,50.00,1,0,0,'108','2026-04-22',50.00,0,NULL),(79,3,'marzo',2026,50.00,1,0,0,'108','2026-04-22',50.00,0,NULL),(80,3,'abril',2026,50.00,1,0,0,'108','2026-04-22',50.00,0,NULL),(81,3,'mayo',2026,50.00,0,0,0,'108','2026-04-22',48.00,0,NULL),(82,3,'junio',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(83,3,'julio',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(84,3,'agosto',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(85,3,'septiembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(86,3,'octubre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(87,3,'noviembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(88,3,'diciembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(89,4,'enero',2026,75.00,1,0,0,'114','2026-04-22',75.00,0,NULL),(90,4,'febrero',2026,75.00,1,0,0,'114','2026-04-22',75.00,0,NULL),(91,4,'marzo',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(92,4,'abril',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(93,4,'mayo',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(94,4,'junio',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(95,4,'julio',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(96,4,'agosto',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(97,4,'septiembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(98,4,'octubre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(99,4,'noviembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(100,4,'diciembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(101,5,'enero',2026,40.00,1,0,0,'115','2026-04-23',40.00,0,NULL),(102,5,'febrero',2026,40.00,0,0,0,'115','2026-04-23',10.00,0,NULL),(103,5,'marzo',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(104,5,'abril',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(105,5,'mayo',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(106,5,'junio',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(107,5,'julio',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(108,5,'agosto',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(109,5,'septiembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(110,5,'octubre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(111,5,'noviembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(112,5,'diciembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(113,6,'enero',2026,80.00,1,0,0,'128','2026-04-28',80.00,0,NULL),(114,6,'febrero',2026,80.00,1,0,0,'128','2026-04-28',80.00,0,NULL),(115,6,'marzo',2026,80.00,1,0,0,'128','2026-04-28',80.00,0,NULL),(116,6,'abril',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(117,6,'mayo',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(118,6,'junio',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(119,6,'julio',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(120,6,'agosto',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(121,6,'septiembre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(122,6,'octubre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(123,6,'noviembre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(124,6,'diciembre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(125,7,'enero',2026,50.00,1,0,0,'118','2026-04-24',50.00,0,NULL),(126,7,'febrero',2026,50.00,1,0,0,'118','2026-04-24',50.00,0,NULL),(127,7,'marzo',2026,50.00,1,0,0,'118','2026-04-24',50.00,0,NULL),(128,7,'abril',2026,50.00,1,0,0,'119','2026-04-24',50.00,0,NULL),(129,7,'mayo',2026,50.00,1,0,0,'119','2026-04-24',50.00,0,NULL),(130,7,'junio',2026,50.00,1,0,0,'120','2026-04-24',50.00,0,NULL),(131,7,'julio',2026,50.00,1,0,0,'120','2026-04-24',50.00,0,NULL),(132,7,'agosto',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(133,7,'septiembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(134,7,'octubre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(135,7,'noviembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(136,7,'diciembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(137,8,'enero',2026,70.00,0,0,0,NULL,NULL,0.00,0,NULL),(138,8,'febrero',2026,70.00,0,0,0,NULL,NULL,0.00,0,NULL),(139,8,'marzo',2026,70.00,0,0,0,NULL,NULL,0.00,0,NULL),(140,8,'abril',2026,70.00,0,0,0,NULL,NULL,0.00,0,NULL),(141,8,'mayo',2026,70.00,0,0,0,NULL,NULL,0.00,0,NULL),(142,8,'junio',2026,70.00,0,0,0,NULL,NULL,0.00,0,NULL),(143,8,'julio',2026,70.00,0,0,0,NULL,NULL,0.00,0,NULL),(144,8,'agosto',2026,70.00,0,0,0,NULL,NULL,0.00,0,NULL),(145,8,'septiembre',2026,70.00,0,0,0,NULL,NULL,0.00,0,NULL),(146,8,'octubre',2026,70.00,0,0,0,NULL,NULL,0.00,0,NULL),(147,8,'noviembre',2026,70.00,0,0,0,NULL,NULL,0.00,0,NULL),(148,8,'diciembre',2026,70.00,0,0,0,NULL,NULL,0.00,0,NULL),(149,9,'enero',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(150,9,'febrero',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(151,9,'marzo',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(152,9,'abril',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(153,9,'mayo',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(154,9,'junio',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(155,9,'julio',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(156,9,'agosto',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(157,9,'septiembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(158,9,'octubre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(159,9,'noviembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(160,9,'diciembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(161,10,'enero',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(162,10,'febrero',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(163,10,'marzo',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(164,10,'abril',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(165,10,'mayo',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(166,10,'junio',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(167,10,'julio',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(168,10,'agosto',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(169,10,'septiembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(170,10,'octubre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(171,10,'noviembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(172,10,'diciembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(173,11,'enero',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(174,11,'febrero',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(175,11,'marzo',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(176,11,'abril',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(177,11,'mayo',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(178,11,'junio',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(179,11,'julio',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(180,11,'agosto',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(181,11,'septiembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(182,11,'octubre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(183,11,'noviembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(184,11,'diciembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(185,12,'enero',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(186,12,'febrero',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(187,12,'marzo',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(188,12,'abril',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(189,12,'mayo',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(190,12,'junio',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(191,12,'julio',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(192,12,'agosto',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(193,12,'septiembre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(194,12,'octubre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(195,12,'noviembre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(196,12,'diciembre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(197,13,'enero',2026,40.00,1,0,0,'116','2026-04-24',40.00,0,NULL),(198,13,'febrero',2026,40.00,1,0,0,'116','2026-04-24',40.00,0,NULL),(199,13,'marzo',2026,40.00,1,0,0,'116','2026-04-24',40.00,0,NULL),(200,13,'abril',2026,40.00,1,0,0,'137','2026-05-07',40.00,0,NULL),(201,13,'mayo',2026,40.00,1,0,0,'137','2026-05-07',40.00,0,NULL),(202,13,'junio',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(203,13,'julio',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(204,13,'agosto',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(205,13,'septiembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206,13,'octubre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(207,13,'noviembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(208,13,'diciembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(209,14,'enero',2026,75.00,1,0,0,'126','2026-04-28',75.00,0,NULL),(210,14,'febrero',2026,75.00,0,0,0,'126','2026-04-28',55.00,0,NULL),(211,14,'marzo',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(212,14,'abril',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(213,14,'mayo',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(214,14,'junio',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(215,14,'julio',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(216,14,'agosto',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(217,14,'septiembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(218,14,'octubre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(219,14,'noviembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(220,14,'diciembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(221,15,'enero',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(222,15,'febrero',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(223,15,'marzo',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(224,15,'abril',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(225,15,'mayo',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(226,15,'junio',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(227,15,'julio',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(228,15,'agosto',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(229,15,'septiembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(230,15,'octubre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(231,15,'noviembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(232,15,'diciembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(233,16,'enero',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(234,16,'febrero',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(235,16,'marzo',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(236,16,'abril',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(237,16,'mayo',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(238,16,'junio',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(239,16,'julio',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(240,16,'agosto',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(241,16,'septiembre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(242,16,'octubre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(243,16,'noviembre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(244,16,'diciembre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(245,17,'enero',2026,40.00,1,0,0,'117','2026-04-24',40.00,0,NULL),(246,17,'febrero',2026,40.00,1,0,0,'117','2026-04-24',40.00,0,NULL),(247,17,'marzo',2026,40.00,1,0,0,'117','2026-04-24',40.00,0,NULL),(248,17,'abril',2026,40.00,1,0,0,'117','2026-04-24',40.00,0,NULL),(249,17,'mayo',2026,40.00,1,0,0,'117','2026-04-24',40.00,0,NULL),(250,17,'junio',2026,40.00,1,0,0,'117','2026-04-24',40.00,0,NULL),(251,17,'julio',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(252,17,'agosto',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(253,17,'septiembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(254,17,'octubre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(255,17,'noviembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(256,17,'diciembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(257,18,'enero',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(258,18,'febrero',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(259,18,'marzo',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(260,18,'abril',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(261,18,'mayo',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(262,18,'junio',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(263,18,'julio',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(264,18,'agosto',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(265,18,'septiembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(266,18,'octubre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(267,18,'noviembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(268,18,'diciembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(269,19,'enero',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(270,19,'febrero',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(271,19,'marzo',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(272,19,'abril',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(273,19,'mayo',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(274,19,'junio',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(275,19,'julio',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(276,19,'agosto',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(277,19,'septiembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(278,19,'octubre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(279,19,'noviembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(280,19,'diciembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(281,20,'enero',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(282,20,'febrero',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(283,20,'marzo',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(284,20,'abril',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(285,20,'mayo',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(286,20,'junio',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(287,20,'julio',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(288,20,'agosto',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(289,20,'septiembre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(290,20,'octubre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(291,20,'noviembre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(292,20,'diciembre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(293,21,'enero',2026,50.00,1,0,0,'132','2026-05-06',50.00,0,NULL),(294,21,'febrero',2026,50.00,1,0,0,'132','2026-05-06',50.00,0,NULL),(295,21,'marzo',2026,50.00,1,0,0,'132','2026-05-06',50.00,0,NULL),(296,21,'abril',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(297,21,'mayo',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(298,21,'junio',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(299,21,'julio',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(300,21,'agosto',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(301,21,'septiembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(302,21,'octubre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(303,21,'noviembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(304,21,'diciembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(305,22,'enero',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(306,22,'febrero',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(307,22,'marzo',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(308,22,'abril',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(309,22,'mayo',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(310,22,'junio',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(311,22,'julio',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(312,22,'agosto',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(313,22,'septiembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(314,22,'octubre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(315,22,'noviembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(316,22,'diciembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(317,23,'enero',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(318,23,'febrero',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(319,23,'marzo',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(320,23,'abril',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(321,23,'mayo',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(322,23,'junio',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(323,23,'julio',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(324,23,'agosto',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(325,23,'septiembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(326,23,'octubre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(327,23,'noviembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(328,23,'diciembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(329,24,'enero',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(330,24,'febrero',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(331,24,'marzo',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(332,24,'abril',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(333,24,'mayo',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(334,24,'junio',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(335,24,'julio',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(336,24,'agosto',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(337,24,'septiembre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(338,24,'octubre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(339,24,'noviembre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(340,24,'diciembre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(341,25,'enero',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(342,25,'febrero',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(343,25,'marzo',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(344,25,'abril',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(345,25,'mayo',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(346,25,'junio',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(347,25,'julio',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(348,25,'agosto',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(349,25,'septiembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(350,25,'octubre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(351,25,'noviembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(352,25,'diciembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(353,26,'enero',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(354,26,'febrero',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(355,26,'marzo',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(356,26,'abril',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(357,26,'mayo',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(358,26,'junio',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(359,26,'julio',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(360,26,'agosto',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(361,26,'septiembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(362,26,'octubre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(363,26,'noviembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(364,26,'diciembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(365,27,'enero',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(366,27,'febrero',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(367,27,'marzo',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(368,27,'abril',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(369,27,'mayo',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(370,27,'junio',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(371,27,'julio',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(372,27,'agosto',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(373,27,'septiembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(374,27,'octubre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(375,27,'noviembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(376,27,'diciembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(377,28,'enero',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(378,28,'febrero',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(379,28,'marzo',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(380,28,'abril',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(381,28,'mayo',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(382,28,'junio',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(383,28,'julio',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(384,28,'agosto',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(385,28,'septiembre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(386,28,'octubre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(387,28,'noviembre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(388,28,'diciembre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(389,29,'enero',2026,40.00,1,0,0,'125','2026-04-27',40.00,0,NULL),(390,29,'febrero',2026,40.00,1,0,0,'125','2026-04-27',40.00,0,NULL),(391,29,'marzo',2026,40.00,1,0,0,'125','2026-04-27',40.00,0,NULL),(392,29,'abril',2026,40.00,1,0,0,'125','2026-04-27',40.00,0,NULL),(393,29,'mayo',2026,40.00,1,0,0,'125','2026-04-27',40.00,0,NULL),(394,29,'junio',2026,40.00,1,0,0,'125','2026-04-27',40.00,0,NULL),(395,29,'julio',2026,40.00,1,0,0,'125','2026-04-27',40.00,0,NULL),(396,29,'agosto',2026,40.00,1,0,0,'125','2026-04-27',40.00,0,NULL),(397,29,'septiembre',2026,40.00,1,0,0,'125','2026-04-27',40.00,0,NULL),(398,29,'octubre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(399,29,'noviembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(400,29,'diciembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(401,30,'enero',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(402,30,'febrero',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(403,30,'marzo',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(404,30,'abril',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(405,30,'mayo',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(406,30,'junio',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(407,30,'julio',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(408,30,'agosto',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(409,30,'septiembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(410,30,'octubre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(411,30,'noviembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(412,30,'diciembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(413,31,'enero',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(414,31,'febrero',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(415,31,'marzo',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(416,31,'abril',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(417,31,'mayo',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(418,31,'junio',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(419,31,'julio',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(420,31,'agosto',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(421,31,'septiembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(422,31,'octubre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(423,31,'noviembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(424,31,'diciembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(425,32,'enero',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(426,32,'febrero',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(427,32,'marzo',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(428,32,'abril',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(429,32,'mayo',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(430,32,'junio',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(431,32,'julio',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(432,32,'agosto',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(433,32,'septiembre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(434,32,'octubre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(435,32,'noviembre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(436,32,'diciembre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(437,33,'enero',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(438,33,'febrero',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(439,33,'marzo',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(440,33,'abril',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(441,33,'mayo',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(442,33,'junio',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(443,33,'julio',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(444,33,'agosto',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(445,33,'septiembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(446,33,'octubre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(447,33,'noviembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(448,33,'diciembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(449,34,'enero',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(450,34,'febrero',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(451,34,'marzo',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(452,34,'abril',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(453,34,'mayo',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(454,34,'junio',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(455,34,'julio',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(456,34,'agosto',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(457,34,'septiembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(458,34,'octubre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(459,34,'noviembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(460,34,'diciembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(461,35,'enero',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(462,35,'febrero',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(463,35,'marzo',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(464,35,'abril',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(465,35,'mayo',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(466,35,'junio',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(467,35,'julio',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(468,35,'agosto',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(469,35,'septiembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(470,35,'octubre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(471,35,'noviembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(472,35,'diciembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(473,36,'enero',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(474,36,'febrero',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(475,36,'marzo',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(476,36,'abril',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(477,36,'mayo',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(478,36,'junio',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(479,36,'julio',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(480,36,'agosto',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(481,36,'septiembre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(482,36,'octubre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(483,36,'noviembre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(484,36,'diciembre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(485,37,'enero',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(486,37,'febrero',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(487,37,'marzo',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(488,37,'abril',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(489,37,'mayo',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(490,37,'junio',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(491,37,'julio',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(492,37,'agosto',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(493,37,'septiembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(494,37,'octubre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(495,37,'noviembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(496,37,'diciembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(497,38,'enero',2026,75.00,1,0,0,'127','2026-04-28',75.00,0,NULL),(498,38,'febrero',2026,75.00,1,0,0,'127','2026-04-28',75.00,0,NULL),(499,38,'marzo',2026,75.00,0,0,0,'127','2026-04-28',40.00,0,NULL),(500,38,'abril',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(501,38,'mayo',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(502,38,'junio',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(503,38,'julio',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(504,38,'agosto',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(505,38,'septiembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(506,38,'octubre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(507,38,'noviembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(508,38,'diciembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(509,39,'enero',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(510,39,'febrero',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(511,39,'marzo',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(512,39,'abril',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(513,39,'mayo',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(514,39,'junio',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(515,39,'julio',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(516,39,'agosto',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(517,39,'septiembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(518,39,'octubre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(519,39,'noviembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(520,39,'diciembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(521,40,'enero',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(522,40,'febrero',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(523,40,'marzo',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(524,40,'abril',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(525,40,'mayo',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(526,40,'junio',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(527,40,'julio',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(528,40,'agosto',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(529,40,'septiembre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(530,40,'octubre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(531,40,'noviembre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(532,40,'diciembre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(533,41,'enero',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(534,41,'febrero',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(535,41,'marzo',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(536,41,'abril',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(537,41,'mayo',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(538,41,'junio',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(539,41,'julio',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(540,41,'agosto',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(541,41,'septiembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(542,41,'octubre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(543,41,'noviembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(544,41,'diciembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(545,42,'enero',2026,75.00,1,0,0,'124','2026-04-27',75.00,0,NULL),(546,42,'febrero',2026,75.00,1,0,0,'124','2026-04-27',75.00,0,NULL),(547,42,'marzo',2026,75.00,0,0,0,'124','2026-04-27',50.00,0,NULL),(548,42,'abril',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(549,42,'mayo',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(550,42,'junio',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(551,42,'julio',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(552,42,'agosto',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(553,42,'septiembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(554,42,'octubre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(555,42,'noviembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(556,42,'diciembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(557,43,'enero',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(558,43,'febrero',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(559,43,'marzo',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(560,43,'abril',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(561,43,'mayo',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(562,43,'junio',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(563,43,'julio',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(564,43,'agosto',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(565,43,'septiembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(566,43,'octubre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(567,43,'noviembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(568,43,'diciembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(569,44,'enero',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(570,44,'febrero',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(571,44,'marzo',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(572,44,'abril',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(573,44,'mayo',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(574,44,'junio',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(575,44,'julio',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(576,44,'agosto',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(577,44,'septiembre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(578,44,'octubre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(579,44,'noviembre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(580,44,'diciembre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(581,45,'enero',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(582,45,'febrero',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(583,45,'marzo',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(584,45,'abril',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(585,45,'mayo',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(586,45,'junio',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(587,45,'julio',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(588,45,'agosto',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(589,45,'septiembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(590,45,'octubre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(591,45,'noviembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(592,45,'diciembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(593,46,'enero',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(594,46,'febrero',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(595,46,'marzo',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(596,46,'abril',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(597,46,'mayo',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(598,46,'junio',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(599,46,'julio',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(600,46,'agosto',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(601,46,'septiembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(602,46,'octubre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(603,46,'noviembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(604,46,'diciembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(605,47,'enero',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(606,47,'febrero',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(607,47,'marzo',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(608,47,'abril',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(609,47,'mayo',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(610,47,'junio',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(611,47,'julio',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(612,47,'agosto',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(613,47,'septiembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(614,47,'octubre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(615,47,'noviembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(616,47,'diciembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(617,48,'enero',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(618,48,'febrero',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(619,48,'marzo',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(620,48,'abril',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(621,48,'mayo',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(622,48,'junio',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(623,48,'julio',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(624,48,'agosto',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(625,48,'septiembre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(626,48,'octubre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(627,48,'noviembre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(628,48,'diciembre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(629,49,'enero',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(630,49,'febrero',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(631,49,'marzo',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(632,49,'abril',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(633,49,'mayo',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(634,49,'junio',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(635,49,'julio',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(636,49,'agosto',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(637,49,'septiembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(638,49,'octubre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(639,49,'noviembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(640,49,'diciembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(641,50,'enero',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(642,50,'febrero',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(643,50,'marzo',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(644,50,'abril',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(645,50,'mayo',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(646,50,'junio',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(647,50,'julio',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(648,50,'agosto',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(649,50,'septiembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(650,50,'octubre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(651,50,'noviembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(652,50,'diciembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(653,551,'enero',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(654,551,'febrero',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(655,551,'marzo',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(656,551,'abril',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(657,551,'mayo',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(658,551,'junio',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(659,551,'julio',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(660,551,'agosto',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(661,551,'septiembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(662,551,'octubre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(663,551,'noviembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(664,551,'diciembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(665,552,'enero',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(666,552,'febrero',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(667,552,'marzo',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(668,552,'abril',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(669,552,'mayo',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(670,552,'junio',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(671,552,'julio',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(672,552,'agosto',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(673,552,'septiembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(674,552,'octubre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(675,552,'noviembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(676,552,'diciembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(677,553,'enero',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(678,553,'febrero',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(679,553,'marzo',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(680,553,'abril',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(681,553,'mayo',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(682,553,'junio',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(683,553,'julio',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(684,553,'agosto',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(685,553,'septiembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(686,553,'octubre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(687,553,'noviembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(688,553,'diciembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(689,554,'enero',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(690,554,'febrero',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(691,554,'marzo',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(692,554,'abril',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(693,554,'mayo',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(694,554,'junio',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(695,554,'julio',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(696,554,'agosto',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(697,554,'septiembre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(698,554,'octubre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(699,554,'noviembre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(700,554,'diciembre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(701,555,'enero',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(702,555,'febrero',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(703,555,'marzo',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(704,555,'abril',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(705,555,'mayo',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(706,555,'junio',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(707,555,'julio',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(708,555,'agosto',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(709,555,'septiembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(710,555,'octubre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(711,555,'noviembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(712,555,'diciembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(713,556,'enero',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(714,556,'febrero',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(715,556,'marzo',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(716,556,'abril',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(717,556,'mayo',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(718,556,'junio',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(719,556,'julio',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(720,556,'agosto',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(721,556,'septiembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(722,556,'octubre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(723,556,'noviembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(724,556,'diciembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(725,557,'enero',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(726,557,'febrero',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(727,557,'marzo',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(728,557,'abril',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(729,557,'mayo',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(730,557,'junio',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(731,557,'julio',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(732,557,'agosto',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(733,557,'septiembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(734,557,'octubre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(735,557,'noviembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(736,557,'diciembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(737,558,'enero',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(738,558,'febrero',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(739,558,'marzo',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(740,558,'abril',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(741,558,'mayo',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(742,558,'junio',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(743,558,'julio',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(744,558,'agosto',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(745,558,'septiembre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(746,558,'octubre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(747,558,'noviembre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(748,558,'diciembre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(749,559,'enero',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(750,559,'febrero',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(751,559,'marzo',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(752,559,'abril',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(753,559,'mayo',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(754,559,'junio',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(755,559,'julio',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(756,559,'agosto',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(757,559,'septiembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(758,559,'octubre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(759,559,'noviembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(760,559,'diciembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(761,560,'enero',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(762,560,'febrero',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(763,560,'marzo',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(764,560,'abril',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(765,560,'mayo',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(766,560,'junio',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(767,560,'julio',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(768,560,'agosto',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(769,560,'septiembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(770,560,'octubre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(771,560,'noviembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(772,560,'diciembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(773,561,'enero',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(774,561,'febrero',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(775,561,'marzo',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(776,561,'abril',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(777,561,'mayo',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(778,561,'junio',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(779,561,'julio',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(780,561,'agosto',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(781,561,'septiembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(782,561,'octubre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(783,561,'noviembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(784,561,'diciembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(785,562,'enero',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(786,562,'febrero',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(787,562,'marzo',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(788,562,'abril',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(789,562,'mayo',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(790,562,'junio',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(791,562,'julio',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(792,562,'agosto',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(793,562,'septiembre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(794,562,'octubre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(795,562,'noviembre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(796,562,'diciembre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(797,563,'enero',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(798,563,'febrero',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(799,563,'marzo',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(800,563,'abril',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(801,563,'mayo',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(802,563,'junio',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(803,563,'julio',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(804,563,'agosto',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(805,563,'septiembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(806,563,'octubre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(807,563,'noviembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(808,563,'diciembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(809,564,'enero',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(810,564,'febrero',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(811,564,'marzo',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(812,564,'abril',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(813,564,'mayo',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(814,564,'junio',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(815,564,'julio',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(816,564,'agosto',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(817,564,'septiembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(818,564,'octubre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(819,564,'noviembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(820,564,'diciembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(821,565,'enero',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(822,565,'febrero',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(823,565,'marzo',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(824,565,'abril',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(825,565,'mayo',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(826,565,'junio',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(827,565,'julio',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(828,565,'agosto',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(829,565,'septiembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(830,565,'octubre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(831,565,'noviembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(832,565,'diciembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(833,566,'enero',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(834,566,'febrero',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(835,566,'marzo',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(836,566,'abril',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(837,566,'mayo',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(838,566,'junio',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(839,566,'julio',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(840,566,'agosto',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(841,566,'septiembre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(842,566,'octubre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(843,566,'noviembre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(844,566,'diciembre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(845,567,'enero',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(846,567,'febrero',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(847,567,'marzo',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(848,567,'abril',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(849,567,'mayo',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(850,567,'junio',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(851,567,'julio',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(852,567,'agosto',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(853,567,'septiembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(854,567,'octubre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(855,567,'noviembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(856,567,'diciembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(857,568,'enero',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(858,568,'febrero',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(859,568,'marzo',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(860,568,'abril',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(861,568,'mayo',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(862,568,'junio',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(863,568,'julio',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(864,568,'agosto',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(865,568,'septiembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(866,568,'octubre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(867,568,'noviembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(868,568,'diciembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(869,569,'enero',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(870,569,'febrero',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(871,569,'marzo',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(872,569,'abril',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(873,569,'mayo',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(874,569,'junio',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(875,569,'julio',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(876,569,'agosto',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(877,569,'septiembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(878,569,'octubre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(879,569,'noviembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(880,569,'diciembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(881,570,'enero',2026,80.00,1,0,0,'121','2026-04-27',80.00,0,NULL),(882,570,'febrero',2026,80.00,1,0,0,'121','2026-04-27',80.00,0,NULL),(883,570,'marzo',2026,80.00,1,0,0,'130','2026-04-30',80.00,0,NULL),(884,570,'abril',2026,80.00,1,0,0,'130','2026-04-30',80.00,0,NULL),(885,570,'mayo',2026,80.00,1,0,0,'130','2026-04-30',80.00,0,NULL),(886,570,'junio',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(887,570,'julio',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(888,570,'agosto',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(889,570,'septiembre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(890,570,'octubre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(891,570,'noviembre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(892,570,'diciembre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(893,571,'enero',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(894,571,'febrero',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(895,571,'marzo',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(896,571,'abril',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(897,571,'mayo',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(898,571,'junio',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(899,571,'julio',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(900,571,'agosto',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(901,571,'septiembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(902,571,'octubre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(903,571,'noviembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(904,571,'diciembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(905,572,'enero',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(906,572,'febrero',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(907,572,'marzo',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(908,572,'abril',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(909,572,'mayo',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(910,572,'junio',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(911,572,'julio',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(912,572,'agosto',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(913,572,'septiembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(914,572,'octubre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(915,572,'noviembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(916,572,'diciembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(917,573,'enero',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(918,573,'febrero',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(919,573,'marzo',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(920,573,'abril',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(921,573,'mayo',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(922,573,'junio',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(923,573,'julio',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(924,573,'agosto',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(925,573,'septiembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(926,573,'octubre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(927,573,'noviembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(928,573,'diciembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(929,574,'enero',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(930,574,'febrero',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(931,574,'marzo',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(932,574,'abril',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(933,574,'mayo',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(934,574,'junio',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(935,574,'julio',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(936,574,'agosto',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(937,574,'septiembre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(938,574,'octubre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(939,574,'noviembre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(940,574,'diciembre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(941,575,'enero',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(942,575,'febrero',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(943,575,'marzo',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(944,575,'abril',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(945,575,'mayo',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(946,575,'junio',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(947,575,'julio',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(948,575,'agosto',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(949,575,'septiembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(950,575,'octubre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(951,575,'noviembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(952,575,'diciembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(953,576,'enero',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(954,576,'febrero',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(955,576,'marzo',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(956,576,'abril',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(957,576,'mayo',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(958,576,'junio',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(959,576,'julio',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(960,576,'agosto',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(961,576,'septiembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(962,576,'octubre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(963,576,'noviembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(964,576,'diciembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(965,577,'enero',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(966,577,'febrero',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(967,577,'marzo',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(968,577,'abril',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(969,577,'mayo',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(970,577,'junio',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(971,577,'julio',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(972,577,'agosto',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(973,577,'septiembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(974,577,'octubre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(975,577,'noviembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(976,577,'diciembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(977,578,'enero',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(978,578,'febrero',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(979,578,'marzo',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(980,578,'abril',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(981,578,'mayo',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(982,578,'junio',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(983,578,'julio',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(984,578,'agosto',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(985,578,'septiembre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(986,578,'octubre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(987,578,'noviembre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(988,578,'diciembre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(989,579,'enero',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(990,579,'febrero',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(991,579,'marzo',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(992,579,'abril',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(993,579,'mayo',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(994,579,'junio',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(995,579,'julio',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(996,579,'agosto',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(997,579,'septiembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(998,579,'octubre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(999,579,'noviembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(1000,579,'diciembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(1001,580,'enero',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(1002,580,'febrero',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(1003,580,'marzo',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(1004,580,'abril',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(1005,580,'mayo',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(1006,580,'junio',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(1007,580,'julio',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(1008,580,'agosto',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(1009,580,'septiembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(1010,580,'octubre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(1011,580,'noviembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(1012,580,'diciembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(1013,581,'enero',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(1014,581,'febrero',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(1015,581,'marzo',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(1016,581,'abril',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(1017,581,'mayo',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(1018,581,'junio',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(1019,581,'julio',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(1020,581,'agosto',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(1021,581,'septiembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(1022,581,'octubre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(1023,581,'noviembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(1024,581,'diciembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(1025,582,'enero',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(1026,582,'febrero',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(1027,582,'marzo',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(1028,582,'abril',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(1029,582,'mayo',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(1030,582,'junio',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(1031,582,'julio',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(1032,582,'agosto',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(1033,582,'septiembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(1034,582,'octubre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(1035,582,'noviembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(1036,582,'diciembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(1037,583,'enero',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(1038,583,'febrero',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(1039,583,'marzo',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(1040,583,'abril',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(1041,583,'mayo',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(1042,583,'junio',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(1043,583,'julio',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(1044,583,'agosto',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(1045,583,'septiembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(1046,583,'octubre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(1047,583,'noviembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(1048,583,'diciembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(1049,584,'enero',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(1050,584,'febrero',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(1051,584,'marzo',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(1052,584,'abril',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(1053,584,'mayo',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(1054,584,'junio',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(1055,584,'julio',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(1056,584,'agosto',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(1057,584,'septiembre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(1058,584,'octubre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(1059,584,'noviembre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(1060,584,'diciembre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(1061,585,'enero',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(1062,585,'febrero',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(1063,585,'marzo',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(1064,585,'abril',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(1065,585,'mayo',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(1066,585,'junio',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(1067,585,'julio',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(1068,585,'agosto',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(1069,585,'septiembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(1070,585,'octubre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(1071,585,'noviembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(1072,585,'diciembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(1073,586,'enero',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(1074,586,'febrero',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(1075,586,'marzo',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(1076,586,'abril',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(1077,586,'mayo',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(1078,586,'junio',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(1079,586,'julio',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(1080,586,'agosto',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(1081,586,'septiembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(1082,586,'octubre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(1083,586,'noviembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(1084,586,'diciembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(1085,587,'enero',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(1086,587,'febrero',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(1087,587,'marzo',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(1088,587,'abril',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(1089,587,'mayo',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(1090,587,'junio',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(1091,587,'julio',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(1092,587,'agosto',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(1093,587,'septiembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(1094,587,'octubre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(1095,587,'noviembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(1096,587,'diciembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(1097,588,'enero',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(1098,588,'febrero',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(1099,588,'marzo',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(1100,588,'abril',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(1101,588,'mayo',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(1102,588,'junio',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(1103,588,'julio',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(1104,588,'agosto',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(1105,588,'septiembre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(1106,588,'octubre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(1107,588,'noviembre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(1108,588,'diciembre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(1109,589,'enero',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(1110,589,'febrero',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(1111,589,'marzo',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(1112,589,'abril',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(1113,589,'mayo',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(1114,589,'junio',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(1115,589,'julio',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(1116,589,'agosto',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(1117,589,'septiembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(1118,589,'octubre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(1119,589,'noviembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(1120,589,'diciembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(1121,590,'enero',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(1122,590,'febrero',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(1123,590,'marzo',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(1124,590,'abril',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(1125,590,'mayo',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(1126,590,'junio',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(1127,590,'julio',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(1128,590,'agosto',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(1129,590,'septiembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(1130,590,'octubre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(1131,590,'noviembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(1132,590,'diciembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(1133,591,'enero',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(1134,591,'febrero',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(1135,591,'marzo',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(1136,591,'abril',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(1137,591,'mayo',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(1138,591,'junio',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(1139,591,'julio',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(1140,591,'agosto',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(1141,591,'septiembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(1142,591,'octubre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(1143,591,'noviembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(1144,591,'diciembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(1145,592,'enero',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(1146,592,'febrero',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(1147,592,'marzo',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(1148,592,'abril',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(1149,592,'mayo',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(1150,592,'junio',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(1151,592,'julio',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(1152,592,'agosto',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(1153,592,'septiembre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(1154,592,'octubre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(1155,592,'noviembre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(1156,592,'diciembre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(1157,593,'enero',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(1158,593,'febrero',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(1159,593,'marzo',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(1160,593,'abril',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(1161,593,'mayo',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(1162,593,'junio',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(1163,593,'julio',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(1164,593,'agosto',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(1165,593,'septiembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(1166,593,'octubre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(1167,593,'noviembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(1168,593,'diciembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(1169,594,'enero',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(1170,594,'febrero',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(1171,594,'marzo',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(1172,594,'abril',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(1173,594,'mayo',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(1174,594,'junio',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(1175,594,'julio',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(1176,594,'agosto',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(1177,594,'septiembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(1178,594,'octubre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(1179,594,'noviembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(1180,594,'diciembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(1181,595,'enero',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(1182,595,'febrero',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(1183,595,'marzo',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(1184,595,'abril',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(1185,595,'mayo',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(1186,595,'junio',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(1187,595,'julio',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(1188,595,'agosto',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(1189,595,'septiembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(1190,595,'octubre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(1191,595,'noviembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(1192,595,'diciembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(1193,596,'enero',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(1194,596,'febrero',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(1195,596,'marzo',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(1196,596,'abril',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(1197,596,'mayo',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(1198,596,'junio',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(1199,596,'julio',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(1200,596,'agosto',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(1201,596,'septiembre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(1202,596,'octubre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(1203,596,'noviembre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(1204,596,'diciembre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(1205,597,'enero',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(1206,597,'febrero',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(1207,597,'marzo',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(1208,597,'abril',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(1209,597,'mayo',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(1210,597,'junio',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(1211,597,'julio',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(1212,597,'agosto',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(1213,597,'septiembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(1214,597,'octubre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(1215,597,'noviembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(1216,597,'diciembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(1217,598,'enero',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(1218,598,'febrero',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(1219,598,'marzo',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(1220,598,'abril',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(1221,598,'mayo',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(1222,598,'junio',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(1223,598,'julio',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(1224,598,'agosto',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(1225,598,'septiembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(1226,598,'octubre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(1227,598,'noviembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(1228,598,'diciembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(1229,601,'enero',2026,30.00,0,0,0,NULL,NULL,0.00,0,NULL),(1230,601,'febrero',2026,30.00,0,0,0,NULL,NULL,0.00,0,NULL),(1231,601,'marzo',2026,30.00,0,0,0,NULL,NULL,0.00,0,NULL),(1232,601,'abril',2026,30.00,0,0,0,NULL,NULL,0.00,0,NULL),(1233,601,'mayo',2026,30.00,0,0,0,NULL,NULL,0.00,0,NULL),(1234,601,'junio',2026,30.00,0,0,0,NULL,NULL,0.00,0,NULL),(1235,601,'julio',2026,30.00,0,0,0,NULL,NULL,0.00,0,NULL),(1236,601,'agosto',2026,30.00,0,0,0,NULL,NULL,0.00,0,NULL),(1237,601,'septiembre',2026,30.00,0,0,0,NULL,NULL,0.00,0,NULL),(1238,601,'octubre',2026,30.00,0,0,0,NULL,NULL,0.00,0,NULL),(1239,601,'noviembre',2026,30.00,0,0,0,NULL,NULL,0.00,0,NULL),(1240,601,'diciembre',2026,30.00,0,0,0,NULL,NULL,0.00,0,NULL),(90923,602,'enero',2026,40.00,1,0,0,'123','2026-04-27',40.00,0,NULL),(90924,602,'febrero',2026,40.00,1,0,0,'123','2026-04-27',40.00,0,NULL),(90925,602,'marzo',2026,40.00,1,0,0,'123','2026-04-27',40.00,0,NULL),(90926,602,'abril',2026,40.00,1,0,0,'123','2026-04-27',40.00,0,NULL),(90927,602,'mayo',2026,40.00,1,0,0,'123','2026-04-27',40.00,0,NULL),(90928,602,'junio',2026,40.00,1,0,0,'123','2026-04-27',40.00,0,NULL),(90929,602,'julio',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(90930,602,'agosto',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(90931,602,'septiembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(90932,602,'octubre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(90933,602,'noviembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(90934,602,'diciembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(142367,603,'enero',2026,50.00,1,0,0,'129','2026-04-28',50.00,0,NULL),(142368,603,'febrero',2026,50.00,1,0,0,'129','2026-04-28',50.00,0,NULL),(142369,603,'marzo',2026,50.00,1,0,0,'129','2026-04-28',50.00,0,NULL),(142370,603,'abril',2026,50.00,1,0,0,'129','2026-04-28',50.00,0,NULL),(142371,603,'mayo',2026,50.00,1,0,0,'129','2026-04-28',50.00,0,NULL),(142372,603,'junio',2026,50.00,1,0,0,'129','2026-04-28',50.00,0,NULL),(142373,603,'julio',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(142374,603,'agosto',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(142375,603,'septiembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(142376,603,'octubre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(142377,603,'noviembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(142378,603,'diciembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(206319,604,'enero',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206320,604,'febrero',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206321,604,'marzo',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206322,604,'abril',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206323,604,'mayo',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206324,604,'junio',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206325,604,'julio',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206326,604,'agosto',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206327,604,'septiembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206328,604,'octubre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206329,604,'noviembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206330,604,'diciembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206331,605,'enero',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(206332,605,'febrero',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(206333,605,'marzo',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(206334,605,'abril',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(206335,605,'mayo',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(206336,605,'junio',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(206337,605,'julio',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(206338,605,'agosto',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(206339,605,'septiembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(206340,605,'octubre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(206341,605,'noviembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(206342,605,'diciembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(206343,606,'enero',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206344,606,'febrero',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206345,606,'marzo',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206346,606,'abril',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206347,606,'mayo',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206348,606,'junio',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206349,606,'julio',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206350,606,'agosto',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206351,606,'septiembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206352,606,'octubre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206353,606,'noviembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206354,606,'diciembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206355,607,'enero',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(206356,607,'febrero',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(206357,607,'marzo',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(206358,607,'abril',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(206359,607,'mayo',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(206360,607,'junio',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(206361,607,'julio',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(206362,607,'agosto',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(206363,607,'septiembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(206364,607,'octubre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(206365,607,'noviembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(206366,607,'diciembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(206367,608,'enero',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(206368,608,'febrero',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(206369,608,'marzo',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(206370,608,'abril',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(206371,608,'mayo',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(206372,608,'junio',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(206373,608,'julio',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(206374,608,'agosto',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(206375,608,'septiembre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(206376,608,'octubre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(206377,608,'noviembre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(206378,608,'diciembre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(206379,609,'enero',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(206380,609,'febrero',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(206381,609,'marzo',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(206382,609,'abril',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(206383,609,'mayo',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(206384,609,'junio',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(206385,609,'julio',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(206386,609,'agosto',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(206387,609,'septiembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(206388,609,'octubre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(206389,609,'noviembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(206390,609,'diciembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(206391,610,'enero',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206392,610,'febrero',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206393,610,'marzo',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206394,610,'abril',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206395,610,'mayo',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206396,610,'junio',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206397,610,'julio',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206398,610,'agosto',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206399,610,'septiembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206400,610,'octubre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206401,610,'noviembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206402,610,'diciembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206403,611,'enero',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(206404,611,'febrero',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(206405,611,'marzo',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(206406,611,'abril',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(206407,611,'mayo',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(206408,611,'junio',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(206409,611,'julio',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(206410,611,'agosto',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(206411,611,'septiembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(206412,611,'octubre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(206413,611,'noviembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(206414,611,'diciembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(206415,612,'enero',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206416,612,'febrero',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206417,612,'marzo',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206418,612,'abril',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206419,612,'mayo',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206420,612,'junio',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206421,612,'julio',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206422,612,'agosto',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206423,612,'septiembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206424,612,'octubre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206425,612,'noviembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206426,612,'diciembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206427,613,'enero',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(206428,613,'febrero',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(206429,613,'marzo',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(206430,613,'abril',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(206431,613,'mayo',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(206432,613,'junio',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(206433,613,'julio',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(206434,613,'agosto',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(206435,613,'septiembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(206436,613,'octubre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(206437,613,'noviembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(206438,613,'diciembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(206439,614,'enero',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206440,614,'febrero',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206441,614,'marzo',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206442,614,'abril',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206443,614,'mayo',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206444,614,'junio',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206445,614,'julio',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206446,614,'agosto',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206447,614,'septiembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206448,614,'octubre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206449,614,'noviembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206450,614,'diciembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206451,615,'enero',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(206452,615,'febrero',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(206453,615,'marzo',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(206454,615,'abril',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(206455,615,'mayo',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(206456,615,'junio',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(206457,615,'julio',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(206458,615,'agosto',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(206459,615,'septiembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(206460,615,'octubre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(206461,615,'noviembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(206462,615,'diciembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(206463,616,'enero',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(206464,616,'febrero',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(206465,616,'marzo',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(206466,616,'abril',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(206467,616,'mayo',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(206468,616,'junio',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(206469,616,'julio',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(206470,616,'agosto',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(206471,616,'septiembre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(206472,616,'octubre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(206473,616,'noviembre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(206474,616,'diciembre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(206475,617,'enero',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(206476,617,'febrero',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(206477,617,'marzo',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(206478,617,'abril',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(206479,617,'mayo',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(206480,617,'junio',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(206481,617,'julio',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(206482,617,'agosto',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(206483,617,'septiembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(206484,617,'octubre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(206485,617,'noviembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(206486,617,'diciembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(206487,618,'enero',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206488,618,'febrero',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206489,618,'marzo',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206490,618,'abril',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206491,618,'mayo',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206492,618,'junio',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206493,618,'julio',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206494,618,'agosto',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206495,618,'septiembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206496,618,'octubre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206497,618,'noviembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206498,618,'diciembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206499,619,'enero',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(206500,619,'febrero',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(206501,619,'marzo',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(206502,619,'abril',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(206503,619,'mayo',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(206504,619,'junio',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(206505,619,'julio',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(206506,619,'agosto',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(206507,619,'septiembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(206508,619,'octubre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(206509,619,'noviembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(206510,619,'diciembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(206511,620,'enero',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206512,620,'febrero',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206513,620,'marzo',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206514,620,'abril',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206515,620,'mayo',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206516,620,'junio',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206517,620,'julio',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206518,620,'agosto',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206519,620,'septiembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206520,620,'octubre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206521,620,'noviembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206522,620,'diciembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206523,621,'enero',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(206524,621,'febrero',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(206525,621,'marzo',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(206526,621,'abril',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(206527,621,'mayo',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(206528,621,'junio',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(206529,621,'julio',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(206530,621,'agosto',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(206531,621,'septiembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(206532,621,'octubre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(206533,621,'noviembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(206534,621,'diciembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(206535,622,'enero',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206536,622,'febrero',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206537,622,'marzo',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206538,622,'abril',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206539,622,'mayo',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206540,622,'junio',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206541,622,'julio',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206542,622,'agosto',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206543,622,'septiembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206544,622,'octubre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206545,622,'noviembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206546,622,'diciembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206547,623,'enero',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(206548,623,'febrero',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(206549,623,'marzo',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(206550,623,'abril',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(206551,623,'mayo',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(206552,623,'junio',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(206553,623,'julio',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(206554,623,'agosto',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(206555,623,'septiembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(206556,623,'octubre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(206557,623,'noviembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(206558,623,'diciembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(206559,624,'enero',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(206560,624,'febrero',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(206561,624,'marzo',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(206562,624,'abril',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(206563,624,'mayo',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(206564,624,'junio',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(206565,624,'julio',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(206566,624,'agosto',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(206567,624,'septiembre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(206568,624,'octubre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(206569,624,'noviembre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(206570,624,'diciembre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(206571,625,'enero',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(206572,625,'febrero',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(206573,625,'marzo',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(206574,625,'abril',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(206575,625,'mayo',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(206576,625,'junio',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(206577,625,'julio',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(206578,625,'agosto',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(206579,625,'septiembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(206580,625,'octubre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(206581,625,'noviembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(206582,625,'diciembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(206583,626,'enero',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206584,626,'febrero',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206585,626,'marzo',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206586,626,'abril',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206587,626,'mayo',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206588,626,'junio',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206589,626,'julio',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206590,626,'agosto',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206591,626,'septiembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206592,626,'octubre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206593,626,'noviembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206594,626,'diciembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206595,627,'enero',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(206596,627,'febrero',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(206597,627,'marzo',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(206598,627,'abril',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(206599,627,'mayo',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(206600,627,'junio',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(206601,627,'julio',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(206602,627,'agosto',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(206603,627,'septiembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(206604,627,'octubre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(206605,627,'noviembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(206606,627,'diciembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(206607,628,'enero',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206608,628,'febrero',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206609,628,'marzo',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206610,628,'abril',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206611,628,'mayo',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206612,628,'junio',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206613,628,'julio',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206614,628,'agosto',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206615,628,'septiembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206616,628,'octubre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206617,628,'noviembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206618,628,'diciembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206619,629,'enero',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(206620,629,'febrero',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(206621,629,'marzo',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(206622,629,'abril',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(206623,629,'mayo',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(206624,629,'junio',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(206625,629,'julio',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(206626,629,'agosto',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(206627,629,'septiembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(206628,629,'octubre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(206629,629,'noviembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(206630,629,'diciembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(206631,630,'enero',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206632,630,'febrero',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206633,630,'marzo',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206634,630,'abril',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206635,630,'mayo',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206636,630,'junio',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206637,630,'julio',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206638,630,'agosto',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206639,630,'septiembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206640,630,'octubre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206641,630,'noviembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206642,630,'diciembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(206643,631,'enero',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(206644,631,'febrero',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(206645,631,'marzo',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(206646,631,'abril',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(206647,631,'mayo',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(206648,631,'junio',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(206649,631,'julio',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(206650,631,'agosto',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(206651,631,'septiembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(206652,631,'octubre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(206653,631,'noviembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(206654,631,'diciembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(206655,632,'enero',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(206656,632,'febrero',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(206657,632,'marzo',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(206658,632,'abril',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(206659,632,'mayo',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(206660,632,'junio',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(206661,632,'julio',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(206662,632,'agosto',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(206663,632,'septiembre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(206664,632,'octubre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(206665,632,'noviembre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(206666,632,'diciembre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(206667,633,'enero',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(206668,633,'febrero',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(206669,633,'marzo',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(206670,633,'abril',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(206671,633,'mayo',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(206672,633,'junio',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(206673,633,'julio',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(206674,633,'agosto',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(206675,633,'septiembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(206676,633,'octubre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(206677,633,'noviembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(206678,633,'diciembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(211395,654,'enero',2026,40.00,1,0,0,'136','2026-05-07',40.00,0,NULL),(211396,654,'febrero',2026,40.00,1,0,0,'136','2026-05-07',40.00,0,NULL),(211397,654,'marzo',2026,40.00,1,0,0,'136','2026-05-07',40.00,0,NULL),(211398,654,'abril',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(211399,654,'mayo',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(211400,654,'junio',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(211401,654,'julio',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(211402,654,'agosto',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(211403,654,'septiembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(211404,654,'octubre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(211405,654,'noviembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(211406,654,'diciembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(211407,655,'enero',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(211408,655,'febrero',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(211409,655,'marzo',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(211410,655,'abril',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(211411,655,'mayo',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(211412,655,'junio',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(211413,655,'julio',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(211414,655,'agosto',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(211415,655,'septiembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(211416,655,'octubre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(211417,655,'noviembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(211418,655,'diciembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(211419,656,'enero',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(211420,656,'febrero',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(211421,656,'marzo',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(211422,656,'abril',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(211423,656,'mayo',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(211424,656,'junio',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(211425,656,'julio',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(211426,656,'agosto',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(211427,656,'septiembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(211428,656,'octubre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(211429,656,'noviembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(211430,656,'diciembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(211431,657,'enero',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(211432,657,'febrero',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(211433,657,'marzo',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(211434,657,'abril',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(211435,657,'mayo',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(211436,657,'junio',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(211437,657,'julio',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(211438,657,'agosto',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(211439,657,'septiembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(211440,657,'octubre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(211441,657,'noviembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(211442,657,'diciembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(211443,658,'enero',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(211444,658,'febrero',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(211445,658,'marzo',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(211446,658,'abril',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(211447,658,'mayo',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(211448,658,'junio',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(211449,658,'julio',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(211450,658,'agosto',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(211451,658,'septiembre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(211452,658,'octubre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(211453,658,'noviembre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(211454,658,'diciembre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(211455,659,'enero',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(211456,659,'febrero',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(211457,659,'marzo',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(211458,659,'abril',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(211459,659,'mayo',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(211460,659,'junio',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(211461,659,'julio',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(211462,659,'agosto',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(211463,659,'septiembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(211464,659,'octubre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(211465,659,'noviembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(211466,659,'diciembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(211467,660,'enero',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(211468,660,'febrero',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(211469,660,'marzo',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(211470,660,'abril',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(211471,660,'mayo',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(211472,660,'junio',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(211473,660,'julio',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(211474,660,'agosto',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(211475,660,'septiembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(211476,660,'octubre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(211477,660,'noviembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(211478,660,'diciembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(211479,661,'enero',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(211480,661,'febrero',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(211481,661,'marzo',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(211482,661,'abril',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(211483,661,'mayo',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(211484,661,'junio',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(211485,661,'julio',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(211486,661,'agosto',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(211487,661,'septiembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(211488,661,'octubre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(211489,661,'noviembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(211490,661,'diciembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(211491,662,'enero',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(211492,662,'febrero',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(211493,662,'marzo',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(211494,662,'abril',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(211495,662,'mayo',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(211496,662,'junio',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(211497,662,'julio',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(211498,662,'agosto',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(211499,662,'septiembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(211500,662,'octubre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(211501,662,'noviembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(211502,662,'diciembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(211503,663,'enero',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(211504,663,'febrero',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(211505,663,'marzo',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(211506,663,'abril',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(211507,663,'mayo',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(211508,663,'junio',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(211509,663,'julio',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(211510,663,'agosto',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(211511,663,'septiembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(211512,663,'octubre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(211513,663,'noviembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(211514,663,'diciembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(214899,664,'enero',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(214900,664,'febrero',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(214901,664,'marzo',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(214902,664,'abril',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(214903,664,'mayo',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(214904,664,'junio',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(214905,664,'julio',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(214906,664,'agosto',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(214907,664,'septiembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(214908,664,'octubre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(214909,664,'noviembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(214910,664,'diciembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(214911,665,'enero',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(214912,665,'febrero',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(214913,665,'marzo',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(214914,665,'abril',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(214915,665,'mayo',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(214916,665,'junio',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(214917,665,'julio',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(214918,665,'agosto',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(214919,665,'septiembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(214920,665,'octubre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(214921,665,'noviembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(214922,665,'diciembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(214923,666,'enero',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(214924,666,'febrero',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(214925,666,'marzo',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(214926,666,'abril',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(214927,666,'mayo',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(214928,666,'junio',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(214929,666,'julio',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(214930,666,'agosto',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(214931,666,'septiembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(214932,666,'octubre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(214933,666,'noviembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(214934,666,'diciembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(214935,667,'enero',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(214936,667,'febrero',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(214937,667,'marzo',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(214938,667,'abril',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(214939,667,'mayo',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(214940,667,'junio',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(214941,667,'julio',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(214942,667,'agosto',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(214943,667,'septiembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(214944,667,'octubre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(214945,667,'noviembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(214946,667,'diciembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(214947,668,'enero',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(214948,668,'febrero',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(214949,668,'marzo',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(214950,668,'abril',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(214951,668,'mayo',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(214952,668,'junio',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(214953,668,'julio',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(214954,668,'agosto',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(214955,668,'septiembre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(214956,668,'octubre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(214957,668,'noviembre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(214958,668,'diciembre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(214959,669,'enero',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(214960,669,'febrero',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(214961,669,'marzo',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(214962,669,'abril',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(214963,669,'mayo',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(214964,669,'junio',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(214965,669,'julio',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(214966,669,'agosto',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(214967,669,'septiembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(214968,669,'octubre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(214969,669,'noviembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(214970,669,'diciembre',2026,75.00,0,0,0,NULL,NULL,0.00,0,NULL),(214971,670,'enero',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(214972,670,'febrero',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(214973,670,'marzo',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(214974,670,'abril',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(214975,670,'mayo',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(214976,670,'junio',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(214977,670,'julio',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(214978,670,'agosto',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(214979,670,'septiembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(214980,670,'octubre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(214981,670,'noviembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(214982,670,'diciembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(214983,671,'enero',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(214984,671,'febrero',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(214985,671,'marzo',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(214986,671,'abril',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(214987,671,'mayo',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(214988,671,'junio',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(214989,671,'julio',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(214990,671,'agosto',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(214991,671,'septiembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(214992,671,'octubre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(214993,671,'noviembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(214994,671,'diciembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(214995,672,'enero',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(214996,672,'febrero',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(214997,672,'marzo',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(214998,672,'abril',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(214999,672,'mayo',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(215000,672,'junio',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(215001,672,'julio',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(215002,672,'agosto',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(215003,672,'septiembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(215004,672,'octubre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(215005,672,'noviembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(215006,672,'diciembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(215007,673,'enero',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(215008,673,'febrero',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(215009,673,'marzo',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(215010,673,'abril',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(215011,673,'mayo',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(215012,673,'junio',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(215013,673,'julio',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(215014,673,'agosto',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(215015,673,'septiembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(215016,673,'octubre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(215017,673,'noviembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(215018,673,'diciembre',2026,50.00,0,0,0,NULL,NULL,0.00,0,NULL),(262787,674,'enero',2026,40.00,1,0,0,'131','2026-05-01',40.00,0,NULL),(262788,674,'febrero',2026,40.00,1,0,0,'131','2026-05-01',40.00,0,NULL),(262789,674,'marzo',2026,40.00,1,0,0,'131','2026-05-01',40.00,0,NULL),(262790,674,'abril',2026,40.00,1,0,0,'131','2026-05-01',40.00,0,NULL),(262791,674,'mayo',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(262792,674,'junio',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(262793,674,'julio',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(262794,674,'agosto',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(262795,674,'septiembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(262796,674,'octubre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(262797,674,'noviembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(262798,674,'diciembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(454862,675,'enero',2026,30.00,1,0,0,'134','2026-05-06',30.00,0,NULL),(454863,675,'febrero',2026,30.00,1,0,0,'134','2026-05-06',30.00,0,NULL),(454864,675,'marzo',2026,30.00,1,0,0,'134','2026-05-06',30.00,0,NULL),(454865,675,'abril',2026,30.00,1,0,0,'134','2026-05-06',30.00,0,NULL),(454866,675,'mayo',2026,30.00,1,0,0,'134','2026-05-06',30.00,0,NULL),(454867,675,'junio',2026,30.00,0,0,0,NULL,NULL,0.00,0,NULL),(454868,675,'julio',2026,30.00,0,0,0,NULL,NULL,0.00,0,NULL),(454869,675,'agosto',2026,30.00,0,0,0,NULL,NULL,0.00,0,NULL),(454870,675,'septiembre',2026,30.00,0,0,0,NULL,NULL,0.00,0,NULL),(454871,675,'octubre',2026,30.00,0,0,0,NULL,NULL,0.00,0,NULL),(454872,675,'noviembre',2026,30.00,0,0,0,NULL,NULL,0.00,0,NULL),(454873,675,'diciembre',2026,30.00,0,0,0,NULL,NULL,0.00,0,NULL),(470695,676,'enero',2026,40.00,1,0,0,'135','2026-05-07',40.00,0,NULL),(470696,676,'febrero',2026,40.00,1,0,0,'135','2026-05-07',40.00,0,NULL),(470697,676,'marzo',2026,40.00,1,0,0,'135','2026-05-07',40.00,0,NULL),(470698,676,'abril',2026,40.00,1,0,0,'135','2026-05-07',40.00,0,NULL),(470699,676,'mayo',2026,40.00,1,0,0,'135','2026-05-07',40.00,0,NULL),(470700,676,'junio',2026,40.00,1,0,0,'135','2026-05-07',40.00,0,NULL),(470701,676,'julio',2026,40.00,1,0,0,'135','2026-05-07',40.00,0,NULL),(470702,676,'agosto',2026,40.00,1,0,0,'135','2026-05-07',40.00,0,NULL),(470703,676,'septiembre',2026,40.00,1,0,0,'135','2026-05-07',40.00,0,NULL),(470704,676,'octubre',2026,40.00,1,0,0,'135','2026-05-07',40.00,0,NULL),(470705,676,'noviembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL),(470706,676,'diciembre',2026,40.00,0,0,0,NULL,NULL,0.00,0,NULL);
/*!40000 ALTER TABLE `mensualidades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mis_tablas`
--

DROP TABLE IF EXISTS `mis_tablas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mis_tablas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci,
  `encabezado` text COLLATE utf8mb4_unicode_ci,
  `columnas` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `filas` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mis_tablas`
--

LOCK TABLES `mis_tablas` WRITE;
/*!40000 ALTER TABLE `mis_tablas` DISABLE KEYS */;
INSERT INTO `mis_tablas` VALUES (14,'Datos','','','[{\"key\":\"codigo_estudiante\",\"label\":\"Código\",\"tipo\":\"texto\"},{\"key\":\"nombre\",\"label\":\"Nombre\",\"tipo\":\"texto\"},{\"key\":\"apellido\",\"label\":\"Apellido\",\"tipo\":\"texto\"},{\"key\":\"clave\",\"label\":\"Clave\",\"tipo\":\"texto\"},{\"key\":\"encargado\",\"label\":\"Encargado\",\"tipo\":\"texto\"},{\"key\":\"telefono\",\"label\":\"Teléfono\",\"tipo\":\"texto\"}]','[{\"codigo_estudiante\":\"\",\"nombre\":\"Carlos Andres\",\"apellido\":\"Castillo Perez\",\"clave\":\"85\",\"encargado\":\"Pedro Castillo\",\"telefono\":\"54340166\"},{\"codigo_estudiante\":\"\",\"nombre\":\"Carlos Manuel\",\"apellido\":\"Castillo Perez\",\"clave\":\"55\",\"encargado\":\"Pedro Castillo\",\"telefono\":\"54340136\"},{\"codigo_estudiante\":\"\",\"nombre\":\"Jose Manuel\",\"apellido\":\"Castillo Perez\",\"clave\":\"25\",\"encargado\":\"Pedro Castillo\",\"telefono\":\"54340106\"},{\"codigo_estudiante\":\"A284GJD\",\"nombre\":\"Sergio Iván\",\"apellido\":\"Cruz Herrera\",\"clave\":\"128\",\"encargado\":\"Francisco Delgado\",\"telefono\":\"55512369\"},{\"codigo_estudiante\":\"A890ZTR\",\"nombre\":\"José Manuel\",\"apellido\":\"Flores Díaz\",\"clave\":\"110\",\"encargado\":\"Diego Sánchez\",\"telefono\":\"55512351\"},{\"codigo_estudiante\":\"A482QXM\",\"nombre\":\"Juan Carlos\",\"apellido\":\"García López\",\"clave\":\"104\",\"encargado\":\"Juan García\",\"telefono\":\"55512345\"},{\"codigo_estudiante\":\"A958CYW\",\"nombre\":\"Ricardo Andrés\",\"apellido\":\"Jiménez Soto\",\"clave\":\"116\",\"encargado\":\"Andrés Díaz\",\"telefono\":\"55512357\"},{\"codigo_estudiante\":\"\",\"nombre\":\"Kevin Alejandro\",\"apellido\":\"López Martínez\",\"clave\":\"144\",\"encargado\":\"Juan García\",\"telefono\":\"55512345\"},{\"codigo_estudiante\":\"\",\"nombre\":\"Luis Fernando\",\"apellido\":\"Lopez Perez\",\"clave\":\"03\",\"encargado\":\"Carlos Lopez\",\"telefono\":\"54340001\"},{\"codigo_estudiante\":\"\",\"nombre\":\"Diego Alejandro\",\"apellido\":\"Lopez Ramirez\",\"clave\":\"81\",\"encargado\":\"Luis Lopez\",\"telefono\":\"54340162\"},{\"codigo_estudiante\":\"\",\"nombre\":\"Diego Andres\",\"apellido\":\"Lopez Ramirez\",\"clave\":\"51\",\"encargado\":\"Luis Lopez\",\"telefono\":\"54340132\"},{\"codigo_estudiante\":\"\",\"nombre\":\"Mario Esteban\",\"apellido\":\"Lopez Ramirez\",\"clave\":\"21\",\"encargado\":\"Luis Lopez\",\"telefono\":\"54340102\"},{\"codigo_estudiante\":\"\",\"nombre\":\"Fredy Ottoniel\",\"apellido\":\"Luarca Santizo\",\"clave\":\"103\",\"encargado\":\"Carlos Santizo\",\"telefono\":\"85857474\"},{\"codigo_estudiante\":\"\",\"nombre\":\"Lucia Andrea\",\"apellido\":\"Morales Lopez\",\"clave\":\"54\",\"encargado\":\"Maria Morales\",\"telefono\":\"54340135\"},{\"codigo_estudiante\":\"\",\"nombre\":\"Lucia Fernanda\",\"apellido\":\"Morales Lopez\",\"clave\":\"24\",\"encargado\":\"Maria Morales\",\"telefono\":\"54340105\"},{\"codigo_estudiante\":\"\",\"nombre\":\"Lucia Sofia\",\"apellido\":\"Morales Lopez\",\"clave\":\"84\",\"encargado\":\"Maria Morales\",\"telefono\":\"54340165\"},{\"codigo_estudiante\":\"A230WLT\",\"nombre\":\"Francisco Javier\",\"apellido\":\"Morales Vásquez\",\"clave\":\"122\",\"encargado\":\"Jorge Castillo\",\"telefono\":\"55512363\"},{\"codigo_estudiante\":\"\",\"nombre\":\"Camila Fernanda\",\"apellido\":\"Perez Gomez\",\"clave\":\"52\",\"encargado\":\"Ana Perez\",\"telefono\":\"54340133\"},{\"codigo_estudiante\":\"\",\"nombre\":\"Camila Sofia\",\"apellido\":\"Perez Gomez\",\"clave\":\"82\",\"encargado\":\"Ana Perez\",\"telefono\":\"54340163\"},{\"codigo_estudiante\":\"\",\"nombre\":\"Daniela Sofia\",\"apellido\":\"Perez Gomez\",\"clave\":\"22\",\"encargado\":\"Ana Perez\",\"telefono\":\"54340103\"},{\"codigo_estudiante\":\"\",\"nombre\":\"Juan Carlos\",\"apellido\":\"Pérez López\",\"clave\":\"134\",\"encargado\":\"Juan García\",\"telefono\":\"55512345\"},{\"codigo_estudiante\":\"\",\"nombre\":\"Jose Alejandro\",\"apellido\":\"Ramirez Diaz\",\"clave\":\"53\",\"encargado\":\"Carlos Ramirez\",\"telefono\":\"54340134\"},{\"codigo_estudiante\":\"\",\"nombre\":\"Jose Daniel\",\"apellido\":\"Ramirez Diaz\",\"clave\":\"83\",\"encargado\":\"Carlos Ramirez\",\"telefono\":\"54340164\"},{\"codigo_estudiante\":\"\",\"nombre\":\"Kevin Andres\",\"apellido\":\"Ramirez Diaz\",\"clave\":\"23\",\"encargado\":\"Carlos Ramirez\",\"telefono\":\"54340104\"},{\"codigo_estudiante\":\"\",\"nombre\":\"Valeria Fernanda\",\"apellido\":\"Ramirez Perez\",\"clave\":\"76\",\"encargado\":\"Maria Ramirez\",\"telefono\":\"54340157\"},{\"codigo_estudiante\":\"\",\"nombre\":\"Valeria Nicole\",\"apellido\":\"Ramirez Perez\",\"clave\":\"46\",\"encargado\":\"Maria Ramirez\",\"telefono\":\"54340127\"},{\"codigo_estudiante\":\"\",\"nombre\":\"José Miguel\",\"apellido\":\"Rivera Torres\",\"clave\":\"140\",\"encargado\":\"Diego Sánchez\",\"telefono\":\"55512351\"},{\"codigo_estudiante\":\"\",\"nombre\":\"Marcus Samuel\",\"apellido\":\"Santos de Leon\",\"clave\":\"01\",\"encargado\":\"Byron de Leon\",\"telefono\":\"54341561\"},{\"codigo_estudiante\":\"\",\"nombre\":\"Bryan Daniel\",\"apellido\":\"Torres Vásquez\",\"clave\":\"150\",\"encargado\":\"Diego Sánchez\",\"telefono\":\"55512351\"}]','2026-05-07 17:52:36','2026-05-07 17:52:36');
/*!40000 ALTER TABLE `mis_tablas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notas_diplomados`
--

DROP TABLE IF EXISTS `notas_diplomados`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notas_diplomados` (
  `id` int NOT NULL AUTO_INCREMENT,
  `alumno_id` int NOT NULL,
  `diplomado` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nota` decimal(5,2) DEFAULT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci,
  `fecha` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `alumno_id` (`alumno_id`),
  CONSTRAINT `notas_diplomados_ibfk_1` FOREIGN KEY (`alumno_id`) REFERENCES `alumnos` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notas_diplomados`
--

LOCK TABLES `notas_diplomados` WRITE;
/*!40000 ALTER TABLE `notas_diplomados` DISABLE KEYS */;
/*!40000 ALTER TABLE `notas_diplomados` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notas_tac`
--

DROP TABLE IF EXISTS `notas_tac`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notas_tac` (
  `id` int NOT NULL AUTO_INCREMENT,
  `alumno_id` int NOT NULL,
  `unidad1` decimal(5,2) DEFAULT NULL,
  `unidad2` decimal(5,2) DEFAULT NULL,
  `unidad3` decimal(5,2) DEFAULT NULL,
  `unidad4` decimal(5,2) DEFAULT NULL,
  `promedio` decimal(5,2) GENERATED ALWAYS AS (((((coalesce(`unidad1`,0) + coalesce(`unidad2`,0)) + coalesce(`unidad3`,0)) + coalesce(`unidad4`,0)) / 4)) STORED,
  PRIMARY KEY (`id`),
  UNIQUE KEY `alumno_id` (`alumno_id`),
  CONSTRAINT `notas_tac_ibfk_1` FOREIGN KEY (`alumno_id`) REFERENCES `alumnos` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notas_tac`
--

LOCK TABLES `notas_tac` WRITE;
/*!40000 ALTER TABLE `notas_tac` DISABLE KEYS */;
INSERT INTO `notas_tac` (`id`, `alumno_id`, `unidad1`, `unidad2`, `unidad3`, `unidad4`) VALUES (1,2,60.00,60.00,60.00,60.00);
/*!40000 ALTER TABLE `notas_tac` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notas_tac_anual`
--

DROP TABLE IF EXISTS `notas_tac_anual`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notas_tac_anual` (
  `id` int NOT NULL AUTO_INCREMENT,
  `alumno_id` int NOT NULL,
  `anio` smallint NOT NULL,
  `nota1` smallint DEFAULT NULL,
  `nota2` smallint DEFAULT NULL,
  `nota3` smallint DEFAULT NULL,
  `nota4` smallint DEFAULT NULL,
  `tac` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_tac_a` (`alumno_id`,`anio`,`tac`)
) ENGINE=InnoDB AUTO_INCREMENT=319 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notas_tac_anual`
--

LOCK TABLES `notas_tac_anual` WRITE;
/*!40000 ALTER TABLE `notas_tac_anual` DISABLE KEYS */;
INSERT INTO `notas_tac_anual` VALUES (1,2,2026,68,88,90,96,'2'),(2,1,2026,50,59,77,76,'1'),(5,3,2026,74,71,68,59,'1'),(6,603,2026,95,98,97,NULL,'2'),(7,585,2026,76,82,73,86,'1'),(8,555,2026,73,55,88,81,'1'),(9,25,2026,73,91,67,77,'1'),(10,628,2026,59,86,90,100,'1'),(11,625,2026,78,98,82,94,'1'),(12,45,2026,79,79,88,79,'1'),(13,575,2026,67,77,74,55,'1'),(14,9,2026,62,70,100,72,'1'),(15,17,2026,77,53,56,89,'1'),(16,563,2026,58,92,63,81,'1'),(17,593,2026,54,84,91,82,'1'),(18,33,2026,54,62,95,82,'1'),(19,602,2026,90,54,62,80,'1'),(20,631,2026,75,51,79,100,'1'),(21,610,2026,95,73,74,69,'1'),(22,604,2026,95,85,91,60,'1'),(23,13,2026,93,89,69,62,'1'),(24,587,2026,86,58,83,91,'1'),(25,557,2026,89,100,53,92,'1'),(26,27,2026,97,57,83,67,'1'),(27,19,2026,93,85,99,100,'1'),(28,667,2026,64,55,66,92,'1'),(29,619,2026,73,84,59,58,'1'),(30,616,2026,81,94,80,55,'1'),(31,664,2026,58,51,54,52,'1'),(32,595,2026,79,56,86,56,'1'),(33,565,2026,63,83,92,55,'1'),(34,35,2026,68,74,84,79,'1'),(36,581,2026,58,84,53,66,'1'),(37,551,2026,60,74,73,68,'1'),(38,21,2026,100,96,98,96,'1'),(39,39,2026,60,58,91,98,'1'),(40,569,2026,83,79,70,52,'1'),(41,657,2026,99,67,69,97,'1'),(42,5,2026,82,55,84,98,'1'),(43,47,2026,73,65,56,55,'1'),(44,577,2026,81,77,80,61,'1'),(45,591,2026,96,74,70,64,'1'),(46,31,2026,96,54,86,61,'1'),(47,561,2026,80,90,85,62,'1'),(48,573,2026,95,95,87,91,'1'),(49,43,2026,51,59,80,94,'1'),(50,597,2026,88,86,85,65,'1'),(51,567,2026,97,66,71,83,'1'),(52,37,2026,69,95,91,54,'1'),(53,622,2026,60,93,80,83,'1'),(54,673,2026,76,82,85,52,'1'),(55,663,2026,64,71,91,61,'1'),(56,589,2026,96,58,96,62,'1'),(57,559,2026,60,79,51,77,'1'),(58,29,2026,84,56,52,87,'1'),(59,7,2026,74,83,87,98,'1'),(60,654,2026,71,51,65,80,'1'),(61,579,2026,95,68,54,66,'1'),(62,49,2026,70,52,69,57,'1'),(63,553,2026,89,68,50,56,'1'),(64,583,2026,77,91,65,76,'1'),(65,23,2026,67,90,91,62,'1'),(66,571,2026,77,51,52,69,'1'),(67,41,2026,58,61,80,65,'1'),(68,15,2026,59,58,73,93,'1'),(69,660,2026,97,66,79,75,'1'),(70,607,2026,77,82,67,82,'1'),(72,670,2026,89,75,58,98,'1'),(73,613,2026,97,55,62,51,'1'),(74,11,2026,58,74,59,58,'1'),(75,632,2026,92,79,73,69,'1'),(76,632,2026,53,64,87,98,'2'),(77,623,2026,50,74,62,59,'1'),(78,623,2026,77,69,67,52,'2'),(79,40,2026,88,66,93,55,'1'),(80,40,2026,76,83,66,75,'2'),(81,570,2026,68,52,74,67,'1'),(82,570,2026,69,91,84,68,'2'),(83,620,2026,97,80,78,59,'1'),(84,620,2026,60,64,56,61,'2'),(85,32,2026,52,86,86,81,'1'),(86,32,2026,77,72,74,88,'2'),(87,562,2026,71,91,70,62,'1'),(88,562,2026,74,86,76,56,'2'),(89,592,2026,53,63,69,68,'1'),(90,592,2026,85,85,84,50,'2'),(91,6,2026,90,95,72,81,'1'),(92,6,2026,94,62,72,89,'2'),(93,2,2026,73,50,58,80,'1'),(95,669,2026,70,70,63,59,'1'),(96,669,2026,80,50,99,89,'2'),(98,585,2026,59,96,53,89,'2'),(100,555,2026,96,96,65,83,'2'),(102,25,2026,99,76,67,71,'2'),(103,18,2026,82,88,59,85,'1'),(104,18,2026,52,53,62,97,'2'),(105,630,2026,63,97,71,79,'1'),(106,630,2026,89,63,89,89,'2'),(107,672,2026,63,69,73,91,'1'),(108,672,2026,68,71,94,99,'2'),(110,628,2026,79,100,62,53,'2'),(112,625,2026,96,65,90,50,'2'),(114,45,2026,84,53,59,50,'2'),(116,575,2026,62,65,89,52,'2'),(118,9,2026,94,58,80,76,'2'),(119,50,2026,78,60,72,65,'1'),(120,50,2026,95,68,94,67,'2'),(121,580,2026,90,74,79,62,'1'),(122,580,2026,75,83,100,92,'2'),(124,17,2026,83,64,70,92,'2'),(125,598,2026,52,57,71,84,'1'),(126,598,2026,65,52,74,82,'2'),(127,38,2026,99,100,86,99,'1'),(128,568,2026,68,52,54,64,'1'),(132,586,2026,88,67,85,74,'1'),(133,26,2026,97,59,54,83,'1'),(134,556,2026,90,96,56,61,'1'),(137,659,2026,60,58,97,55,'1'),(139,629,2026,100,81,100,88,'1'),(140,655,2026,79,71,70,55,'1'),(142,609,2026,95,73,77,96,'1'),(144,671,2026,55,70,62,76,'1'),(149,605,2026,80,70,54,62,'1'),(151,8,2026,53,58,89,96,'1'),(152,34,2026,73,77,81,84,'1'),(153,594,2026,76,67,95,58,'1'),(154,564,2026,82,70,100,78,'1'),(156,662,2026,66,83,80,59,'1'),(158,28,2026,71,77,94,64,'1'),(159,588,2026,76,85,63,97,'1'),(160,558,2026,77,78,99,56,'1'),(161,12,2026,100,74,79,65,'1'),(167,20,2026,91,53,69,65,'1'),(171,48,2026,79,74,61,72,'1'),(172,578,2026,63,66,94,73,'1'),(175,44,2026,76,73,87,57,'1'),(176,574,2026,59,50,94,84,'1'),(177,603,2026,53,92,85,56,'1'),(179,606,2026,63,94,79,88,'1'),(181,661,2026,69,88,58,86,'1'),(182,601,2026,97,82,85,69,'1'),(183,614,2026,69,96,73,78,'1'),(184,666,2026,86,82,95,65,'1'),(185,16,2026,79,79,54,74,'1'),(188,554,2026,92,66,80,97,'1'),(189,24,2026,68,62,76,57,'1'),(190,584,2026,89,60,69,54,'1'),(196,10,2026,94,50,52,61,'1'),(201,624,2026,64,92,86,84,'1'),(202,615,2026,62,55,90,54,'1'),(205,668,2026,62,72,74,86,'1'),(209,42,2026,85,53,66,53,'1'),(210,572,2026,100,95,95,77,'1'),(211,552,2026,67,85,66,64,'1'),(212,582,2026,66,98,86,88,'1'),(213,22,2026,84,61,69,61,'1'),(216,14,2026,62,97,76,75,'1'),(219,627,2026,53,73,86,68,'1'),(220,566,2026,85,81,86,78,'1'),(221,566,2026,95,57,78,68,'2'),(222,566,2026,75,71,93,54,'3'),(223,36,2026,59,99,83,70,'1'),(224,36,2026,95,53,60,84,'2'),(225,36,2026,82,95,95,98,'3'),(226,596,2026,89,58,51,77,'1'),(227,596,2026,89,78,98,57,'2'),(228,596,2026,70,93,65,64,'3'),(229,4,2026,95,81,73,100,'1'),(230,4,2026,90,61,54,56,'2'),(231,4,2026,80,79,93,66,'3'),(233,553,2026,98,92,97,75,'2'),(234,553,2026,96,94,95,100,'3'),(236,583,2026,76,92,50,62,'2'),(237,583,2026,82,73,58,86,'3'),(239,23,2026,84,97,94,80,'2'),(240,23,2026,67,100,85,75,'3'),(241,665,2026,82,72,54,75,'1'),(242,665,2026,53,88,54,87,'2'),(243,665,2026,72,98,52,80,'3'),(245,571,2026,72,52,88,65,'2'),(246,571,2026,92,62,80,57,'3'),(248,41,2026,57,51,50,68,'2'),(249,41,2026,89,97,78,100,'3'),(250,576,2026,87,87,74,63,'1'),(251,576,2026,96,99,57,85,'2'),(252,576,2026,69,96,77,99,'3'),(253,46,2026,68,76,91,75,'1'),(254,46,2026,57,91,51,91,'2'),(255,46,2026,57,62,70,97,'3'),(257,15,2026,94,97,73,79,'2'),(258,15,2026,97,52,61,94,'3'),(259,30,2026,57,84,74,78,'1'),(260,30,2026,51,57,61,70,'2'),(261,30,2026,79,95,82,74,'3'),(262,590,2026,73,95,69,50,'1'),(263,590,2026,89,68,65,95,'2'),(264,590,2026,74,92,73,98,'3'),(265,560,2026,74,89,67,69,'1'),(266,560,2026,69,88,70,84,'2'),(267,560,2026,52,64,78,59,'3'),(268,617,2026,97,89,52,95,'1'),(269,617,2026,87,82,86,97,'2'),(270,617,2026,88,71,86,89,'3'),(271,612,2026,66,51,84,96,'1'),(272,612,2026,52,96,50,95,'2'),(273,612,2026,59,94,51,79,'3'),(275,660,2026,66,90,90,62,'2'),(276,660,2026,64,70,88,92,'3'),(278,607,2026,78,76,70,87,'2'),(279,607,2026,82,78,89,90,'3'),(280,656,2026,56,54,72,96,'1'),(281,656,2026,53,75,88,73,'2'),(282,656,2026,52,83,61,65,'3'),(283,621,2026,64,74,97,67,'1'),(284,621,2026,80,56,65,77,'2'),(285,621,2026,63,51,83,99,'3'),(286,618,2026,53,97,77,59,'1'),(287,618,2026,93,59,81,52,'2'),(288,618,2026,85,66,72,52,'3'),(289,626,2026,74,53,57,83,'1'),(290,626,2026,62,98,68,59,'2'),(291,626,2026,64,75,73,100,'3'),(292,608,2026,85,71,60,53,'1'),(293,608,2026,52,91,65,94,'2'),(294,608,2026,98,87,51,79,'3'),(295,658,2026,99,67,71,94,'1'),(296,658,2026,50,57,51,83,'2'),(297,658,2026,68,50,69,59,'3'),(299,1,2026,79,90,80,54,'2'),(300,1,2026,92,88,82,50,'3'),(301,611,2026,71,92,92,85,'1'),(302,611,2026,71,62,85,66,'2'),(303,611,2026,93,96,86,100,'3'),(305,670,2026,90,85,72,87,'2'),(306,670,2026,100,69,96,67,'3'),(308,613,2026,69,94,82,86,'2'),(309,613,2026,50,76,80,65,'3'),(311,11,2026,97,99,93,59,'2'),(312,11,2026,72,69,100,76,'3'),(313,633,2026,98,53,61,95,'1'),(314,633,2026,100,58,96,96,'2'),(315,633,2026,98,65,100,96,'3'),(316,674,2026,98,98,85,NULL,'1'),(317,675,2026,98,96,96,96,'3'),(318,676,2026,50,50,57,87,'2');
/*!40000 ALTER TABLE `notas_tac_anual` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `papeleria`
--

DROP TABLE IF EXISTS `papeleria`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `papeleria` (
  `id` int NOT NULL AUTO_INCREMENT,
  `no_recibo` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `alumno_id` int DEFAULT NULL,
  `descripcion` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `total` decimal(10,2) DEFAULT NULL,
  `observaciones` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `alumno_texto` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `anulado` tinyint(1) NOT NULL DEFAULT '0',
  `anulado_at` timestamp NULL DEFAULT NULL,
  `no_deposito` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `papeleria`
--

LOCK TABLES `papeleria` WRITE;
/*!40000 ALTER TABLE `papeleria` DISABLE KEYS */;
/*!40000 ALTER TABLE `papeleria` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_resets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `usuario_id` int NOT NULL,
  `token` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expira_at` datetime NOT NULL,
  `usado` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `token` (`token`),
  KEY `idx_pwres_user` (`usuario_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recibos`
--

DROP TABLE IF EXISTS `recibos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `recibos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `no_recibo` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `alumno_id` int DEFAULT NULL,
  `meses` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `total` decimal(10,2) DEFAULT NULL,
  `observaciones` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `descuento` decimal(10,2) NOT NULL DEFAULT '0.00',
  `alumno_texto` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `anulado` tinyint(1) NOT NULL DEFAULT '0',
  `anulado_at` timestamp NULL DEFAULT NULL,
  `no_deposito` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recibos`
--

LOCK TABLES `recibos` WRITE;
/*!40000 ALTER TABLE `recibos` DISABLE KEYS */;
INSERT INTO `recibos` VALUES (9,'100',1,'Enero','2026-04-21',40.00,NULL,'2026-04-22 02:21:37',0.00,NULL,0,NULL,NULL),(10,'101',1,'Febrero - Marzo - Abril - Mayo','2026-04-21',160.00,NULL,'2026-04-22 02:23:57',0.00,NULL,0,NULL,NULL),(11,'102',1,'Junio - Julio - Abono Q3 Agosto','2026-04-22',83.00,NULL,'2026-04-22 02:25:09',0.00,NULL,0,NULL,NULL),(12,'103',1,'Agosto','2026-04-22',37.00,NULL,'2026-04-22 02:28:39',0.00,NULL,0,NULL,NULL),(13,'104',1,'Septiembre - Abono Q5 Octubre','2026-04-22',45.00,NULL,'2026-04-22 02:40:03',0.00,NULL,0,NULL,NULL),(14,'105',2,'Enero - Febrero','2026-04-22',150.00,NULL,'2026-04-22 17:45:28',0.00,NULL,0,NULL,NULL),(15,'106',2,'Marzo - Abril - Mayo - Abono Q5 Junio','2026-04-22',230.00,NULL,'2026-04-22 17:46:51',0.00,NULL,0,NULL,NULL),(16,'107',2,'Junio - Julio','2026-04-22',145.00,NULL,'2026-04-22 17:48:00',0.00,NULL,0,NULL,NULL),(17,'108',3,'Enero - Febrero - Marzo - Abril - Abono Q48 Mayo','2026-04-22',248.00,NULL,'2026-04-22 21:24:55',0.00,NULL,0,NULL,NULL),(18,'109',2,'Agosto','2026-04-23',75.00,NULL,'2026-04-22 21:39:13',0.00,NULL,0,NULL,NULL),(19,'110',2,'Abono Q35 Septiembre','2026-04-23',35.00,NULL,'2026-04-22 21:40:43',0.00,NULL,0,NULL,NULL),(20,'111',2,'Septiembre','2026-04-23',40.00,NULL,'2026-04-22 21:41:45',0.00,NULL,0,NULL,NULL),(21,'112',2,'Octubre','2026-04-22',75.00,NULL,'2026-04-22 21:44:29',0.00,NULL,0,NULL,NULL),(22,'113',2,'Abono Q35 Noviembre','2026-04-23',35.00,NULL,'2026-04-22 21:45:07',0.00,NULL,0,NULL,NULL),(25,'114',4,'Enero - Febrero','2026-04-22',150.00,NULL,'2026-04-23 02:29:27',0.00,NULL,0,NULL,NULL),(26,'115',5,'Enero - Abono Q10 Febrero','2026-04-23',50.00,NULL,'2026-04-23 21:45:58',0.00,NULL,0,NULL,NULL),(27,'116',13,'Enero - Febrero - Marzo - Abono Q30 Abril','2026-04-24',150.00,NULL,'2026-04-23 21:47:00',0.00,NULL,0,NULL,NULL),(28,'117',17,'Enero - Febrero - Marzo - Abril - Mayo - Junio','2026-04-24',240.00,NULL,'2026-04-23 22:29:02',0.00,NULL,0,NULL,NULL),(29,'118',7,'Enero - Febrero - Marzo','2026-04-24',150.00,NULL,'2026-04-24 21:02:31',0.00,NULL,0,NULL,NULL),(30,'119',7,'Abril - Mayo - Abono Q20 Junio','2026-04-24',120.00,NULL,'2026-04-24 21:07:53',0.00,NULL,0,NULL,NULL),(31,'120',7,'Junio - Julio','2026-04-24',80.00,NULL,'2026-04-24 21:09:04',0.00,NULL,0,NULL,NULL),(32,'121',570,'Enero - Febrero','2026-04-27',160.00,NULL,'2026-04-27 13:47:10',0.00,NULL,0,NULL,NULL),(33,'122',602,'Inscripcion de alumno','2026-04-27',100.00,NULL,'2026-04-27 13:57:09',0.00,NULL,0,NULL,NULL),(34,'123',602,'Enero - Febrero - Marzo - Abril - Mayo - Junio','2026-04-27',240.00,NULL,'2026-04-27 13:57:32',0.00,NULL,0,NULL,NULL),(35,'124',42,'Enero - Febrero - Abono Q50 Marzo','2026-04-27',200.00,NULL,'2026-04-27 23:18:53',0.00,NULL,0,NULL,NULL),(36,'125',29,'Enero - Febrero - Marzo - Abril - Mayo - Junio - Julio - Agosto - Septiembre','2026-04-27',360.00,NULL,'2026-04-27 23:19:13',0.00,NULL,0,NULL,NULL),(37,'126',14,'Enero - Abono Q55 Febrero','2026-04-28',130.00,NULL,'2026-04-27 23:23:27',0.00,NULL,0,NULL,NULL),(38,'127',38,'Enero - Febrero - Abono Q40 Marzo','2026-04-28',190.00,NULL,'2026-04-27 23:23:42',0.00,NULL,0,NULL,NULL),(39,'128',6,'Enero - Febrero - Marzo','2026-04-28',240.00,NULL,'2026-04-28 01:03:49',0.00,NULL,0,NULL,NULL),(40,'129',603,'Enero - Febrero - Marzo - Abril - Mayo - Junio','2026-04-28',300.00,NULL,'2026-04-28 13:46:15',0.00,NULL,0,NULL,NULL),(41,'130',570,'Marzo - Abril - Mayo','2026-04-30',240.00,NULL,'2026-04-30 14:01:39',0.00,NULL,0,NULL,NULL),(42,'131',674,'Enero - Febrero - Marzo - Abril','2026-05-01',160.00,NULL,'2026-05-02 02:23:57',0.00,NULL,0,NULL,NULL),(43,'132',21,'Enero - Febrero - Marzo','2026-05-06',150.00,NULL,'2026-05-07 03:03:28',0.00,NULL,0,NULL,NULL),(44,'133',2,'Inscripcion','2026-05-06',100.00,'Inscripcion','2026-05-07 03:04:07',0.00,NULL,0,NULL,NULL),(45,'134',675,'Enero - Febrero - Marzo - Abril - Mayo','2026-05-06',150.00,NULL,'2026-05-07 03:15:00',0.00,NULL,0,NULL,NULL),(46,'135',676,'Enero - Febrero - Marzo - Abril - Mayo - Junio - Julio - Agosto - Septiembre - Octubre','2026-05-07',400.00,NULL,'2026-05-07 17:37:34',0.00,NULL,0,NULL,NULL),(47,'136',654,'Enero - Febrero - Marzo','2026-05-07',120.00,NULL,'2026-05-07 18:02:22',0.00,NULL,0,NULL,NULL),(48,'137',13,'Abril - Mayo','2026-05-07',50.00,NULL,'2026-05-07 20:57:39',0.00,NULL,0,NULL,NULL);
/*!40000 ALTER TABLE `recibos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recibos_diplomados`
--

DROP TABLE IF EXISTS `recibos_diplomados`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `recibos_diplomados` (
  `id` int NOT NULL AUTO_INCREMENT,
  `no_recibo` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `alumno_id` int DEFAULT NULL,
  `diplomado` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `descripcion` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `total` decimal(10,2) DEFAULT NULL,
  `observaciones` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recibos_diplomados`
--

LOCK TABLES `recibos_diplomados` WRITE;
/*!40000 ALTER TABLE `recibos_diplomados` DISABLE KEYS */;
/*!40000 ALTER TABLE `recibos_diplomados` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuarios` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rol` enum('admin','alumno','oficina','maestro') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'alumno',
  `activo` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=84 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuarios`
--

LOCK TABLES `usuarios` WRITE;
/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
INSERT INTO `usuarios` VALUES (1,'Administrador','admin@escuela.com','$2b$10$2W0QgNIXX1W3JDU9G0.OTuWdCQ/IcPJ/E2kU5RcqGxMzan3qW4.Ay','admin',1,'2026-04-09 14:46:33'),(2,'Marcus Samuel Santos de Leon','marcussamuel@sistec.com','$2b$10$T1B4WXVzeAOOMzLqNbE8Ju6OmV0DBigxXIS09kesuqjpg.n35Fp/e','alumno',1,'2026-04-15 22:16:39'),(3,'Rony Alexander Castillo Lopez','ronycastillo@gmail.com','$2b$10$Y.O9Xe8ELX1q2g5vv9rnOu/k7LtrKlJ3u1NKfT56KDexcP4bTyOv2','alumno',1,'2026-04-15 22:41:54'),(4,'Pedro Carlos Mendoza Rodas','pedro101','$2b$10$5/scXoFUdLkY./OmqUnoMusqnQlK/12b6Fj97gnZHRahUv8JHsJNm','alumno',1,'2026-04-21 02:16:49'),(5,'Carmen Juliana Estrada Mejia','carmen102','$2b$10$ktyemmtxUvAZdbyQbwO3ROsL5YkD0w63AJYQJ1cp3KGKy4XhOs./u','alumno',1,'2026-04-27 13:55:30'),(6,'Rony Castillo','ronymaestro@gmail.com','$2b$10$qowue6JOGcGLoK2AN6PPW.mgozx9VNdEfl4373jRhIMoJ9Gr0BOXO','maestro',1,'2026-04-27 15:45:49'),(7,'Rony castillo','ronyoficina@gmail.com','$2b$10$US5Z2nRDJ0yR4VbgdqF/ee7SL6CQIKK0pAAg.8X4HFKtCkkjgbBQW','oficina',1,'2026-04-27 15:56:15'),(8,'Fredy Ottoniel Luarca Santizo','fredy103','$2b$10$3umQO30MmTVDe8JFfkBT3eL0dn4mBYTXBe5603PH1UgsyTd91/vpS','alumno',1,'2026-04-28 13:35:29'),(9,'Juan Carlos García López','juan260001','$2b$10$3/oeoWsLQIZBcl/6gJ1LAumne6uXLRSumFc53MwD0gfH.rXjcK8ku','alumno',1,'2026-04-30 03:09:27'),(10,'María José Hernández Pérez','maria260002','$2b$10$N3cHow/u6.wKlFDtCSJQi.QOgjR125HaXwjZ4E1VQNvFYWqAgLJgS','alumno',1,'2026-04-30 03:09:27'),(11,'Luis Fernando Martínez Ramírez','luis260003','$2b$10$hWa9evc.0mZQnZ9XXHVM7uN8TGpV.YexbkxTfWwY4Jr.Gh1wFEvxa','alumno',1,'2026-04-30 03:09:28'),(12,'Ana Sofía Rodríguez Morales','ana260004','$2b$10$mJRMLD3VerEDp6iIXqBQNu4aPrgqQMjH4zScs8adrXNX3T/YZg90u','alumno',1,'2026-04-30 03:09:28'),(13,'Carlos Alberto Sánchez Cruz','carlos260005','$2b$10$wHQ0K0kz2JZIXUZQ3eB4qOALaOe0G36ed8axTaQ9cZ/nKR4iwTHXq','alumno',1,'2026-04-30 03:09:28'),(14,'Laura Isabel Gómez Castillo','laura260006','$2b$10$Uqvd.XUA6SGFm/qv72KuXuhX0gla/lXy9ADhzlz0wICmZnIFucdV6','alumno',1,'2026-04-30 03:09:28'),(15,'José Manuel Flores Díaz','jose260007','$2b$10$BOUbkjXMcCbAYxmKqcDazOz.ts4z.6.bGdrcAx5WeM2gfWMELN97C','alumno',1,'2026-04-30 03:09:29'),(16,'Daniela Alejandra Torres Hernández','daniela260008','$2b$10$m2JibHZs7rpuKm95lcK00OZFEByO9iC158k6kfkR73stlRA4Fyg0m','alumno',1,'2026-04-30 03:09:29'),(17,'Miguel Ángel Rivera López','miguel260009','$2b$10$1B.hZ85o4hTloSnIadoE5uEYCPynEvUL51cBLHFZsiI4UUJv6IHyy','alumno',1,'2026-04-30 03:09:29'),(18,'Andrea Carolina Vargas Pérez','andrea260010','$2b$10$kgaW86e.Tg1SLrdk.Q8EYuQzH8Q00HdxS9Ho1IA4BzjYJg1ROwJVG','alumno',1,'2026-04-30 03:09:29'),(19,'Pedro Antonio Mendoza Ruiz','pedro260011','$2b$10$oXL8DLLdB.sG.rRHMmCEt.unwGE0LQscgQf4edF2tB6TCm7wVSFXW','alumno',1,'2026-04-30 03:09:30'),(20,'Camila Fernanda Ortiz Castro','camila260012','$2b$10$1/TpuwyaYhSRyV5T2OIo3.lONmUg.lE3Fm.trZB.FV1yMzvDDAPly','alumno',1,'2026-04-30 03:09:30'),(21,'Ricardo Andrés Jiménez Soto','ricardo260013','$2b$10$Pw6XiKZT07hQgH01rhjeaetiD0ePBZVp6NS6kvB41hnQvy50p5pru','alumno',1,'2026-04-30 03:09:30'),(22,'Valeria Nicole Reyes Aguilar','valeria260014','$2b$10$3F.AJ0YqpErd6.lbY//aTeRk3fMfrF6w7k0nwk5Wg2W6KNnYvKjze','alumno',1,'2026-04-30 03:09:30'),(23,'Diego Alejandro Romero Méndez','diego260015','$2b$10$aYX6IiMeNX8aPbsEymwfAuzeIlZYwXh7gkXI4QY28Xsg2tfKuk8SK','alumno',1,'2026-04-30 03:09:31'),(24,'Sofía Gabriela Herrera Morales','sofia260016','$2b$10$0rshyUJMDIiuO11PFmXv8edHD5jqGOE4HP.HjW9H.uYpcP92AE.Ta','alumno',1,'2026-04-30 03:09:31'),(25,'Jorge Eduardo Castillo León','jorge260017','$2b$10$c7mhjYYgECU9W5h1k5stMOmb2YIyoiOxk10SOnXsXBTajLE3S/lNe','alumno',1,'2026-04-30 03:09:31'),(26,'Natalia Elizabeth Rojas Cifuentes','natalia260018','$2b$10$4c1i6fBj134iNnm5lHA2vesGLdbcWOyFhsJnsNxnayrWu687TwpZm','alumno',1,'2026-04-30 03:09:32'),(27,'Francisco Javier Morales Vásquez','francisco260019','$2b$10$IVEFiNEwdAI3iUjaHTOup.33wQqh3SYb7DqT5UujVF3N847tyY9A2','alumno',1,'2026-04-30 03:09:32'),(28,'Paola Andrea Cabrera Gómez','paola260020','$2b$10$RzuuPPxRxn/vJCI/AvOfOOrS7YPnYXXhXINIeJwlsgag3TnZVLwry','alumno',1,'2026-04-30 03:09:32'),(29,'Andrés Felipe Navarro Sánchez','andres260021','$2b$10$njAg9DQ7Bvh770VxbL0uTuY9U1SzQ2WtWCTywWDEfBS0HxP9DKxMe','alumno',1,'2026-04-30 03:09:32'),(30,'Fernanda Lucía Delgado Martínez','fernanda260022','$2b$10$TxUF/Cl1CMVi0PpqMnc99eb0m7jA3UbfwgmNF.LqcyTKB5ebiTgM2','alumno',1,'2026-04-30 03:09:33'),(31,'Héctor Daniel Salazar Ramírez','hector260023','$2b$10$YYgaDJDqMA4iOtwPUdVbwe8Ttuo5SF/XUOP/ScvyXdT3IB978lpGO','alumno',1,'2026-04-30 03:09:33'),(32,'Gabriela Alejandra Pineda Torres','gabriela260024','$2b$10$bI2qyMVapXw1iXY/Xd0V4uHHb6TtRg6vo4T58V0uAEo1mztCKZWKq','alumno',1,'2026-04-30 03:09:33'),(33,'Sergio Iván Cruz Herrera','sergio260025','$2b$10$6L6W1f929VKswLOBt0LsKeNPAUdxguJyUm3ZVDLeot8o37nq7GQSq','alumno',1,'2026-04-30 03:09:33'),(34,'Alejandra Beatriz Fuentes López','alejandra260026','$2b$10$rbljiZNBIQuxRH4n8otT/OLNKIYA4SyW04viD1uqJVCd.lGiWHmU2','alumno',1,'2026-04-30 03:09:34'),(35,'Manuel Enrique Chacón Rivera','manuel260027','$2b$10$Rys78K0lMkAwOzEE.mROqO6YpTQ.XndSBPcbz7wZ.wUSShRkemWmO','alumno',1,'2026-04-30 03:09:34'),(36,'Karla Patricia Estrada Pérez','karla260028','$2b$10$CqwuImOjs24Q0UI6BvQIKexFTj56./zj/6/ToGgTw2.FkQHP70Byq','alumno',1,'2026-04-30 03:09:34'),(37,'Roberto Nicolás Aguilar Méndez','roberto260029','$2b$10$IAAF0eYip0FCfk2O/x1s5OZ9Ea/T1wBbqbtD0oyYKHV/OFbTE3cr.','alumno',1,'2026-04-30 03:09:35'),(38,'Verónica Isabel Velásquez Flores','veronica260030','$2b$10$fUyiJE2Zo03.7/eS79S8DOZEpBrSFgrhXZd0QXXc5n.QwctRH3QqG','alumno',1,'2026-04-30 03:09:35'),(59,'Juan Carlos Pérez López','juan260134','$2b$10$R9H33MZm9.Tb222hiyvZWOClsBq4IGDW0yktdEmj0rnnNdDtS/NS.','alumno',1,'2026-04-30 03:54:46'),(60,'María Fernanda García Hernández','maria260135','$2b$10$gIiaF9.m5whISji4d6M/uuWyJ71it.Oc5FK9TVldCojflPYhuf9yC','alumno',1,'2026-04-30 03:54:46'),(61,'Luis Alberto Rodríguez Morales','luis260136','$2b$10$AnW1q4OXJTo1UHoRMZME/eGGtuId/Rn2PUznWMHiAAjz6WkOpMwxS','alumno',1,'2026-04-30 03:54:46'),(62,'Ana Sofía Martínez Ramírez','ana260137','$2b$10$Q6ZFzrqtpAxDfHRLsMMGx.hYQe8DQoKYQsRPcj24jk0tqJz.dY7wS','alumno',1,'2026-04-30 03:54:46'),(63,'Carlos Eduardo Sánchez Gómez','carlos260138','$2b$10$S1MWJjY7SWSAgOjXZywpOeCczWn/2cKdsxWfg4ubnvQmgLaXZH9zO','alumno',1,'2026-04-30 03:54:46'),(64,'Daniela Isabel Flores Castillo','daniela260139','$2b$10$fUdy3Df/ub6nYs2cxy/M0.UcrM0ZRWORFiY/OuXhMj1ALxn4RufcC','alumno',1,'2026-04-30 03:54:47'),(65,'José Miguel Rivera Torres','jose260140','$2b$10$VvqSMyXPg28EPC7VZqEOoebAg6jKa8QPYhwOWlt0mVmaouO4KKzdC','alumno',1,'2026-04-30 03:54:47'),(66,'Laura Beatriz Mendoza Cruz','laura260141','$2b$10$2AfnVve61hdQAZwbiXjuI.95qut6nhJfmqB3qeEbx9SvMPhLCMjxu','alumno',1,'2026-04-30 03:54:47'),(67,'Andrés Felipe Herrera Vásquez','andres260142','$2b$10$4pWK09T7f4Z2nlvzjLcEiOd8AGNPDMk5Bh2tQMrHczSZkBo5Gu6De','alumno',1,'2026-04-30 03:54:47'),(68,'Camila Alejandra Ortiz Romero','camila260143','$2b$10$r7rIGcknvUt0BQA7e0Nta.Kv14V37pZirK5N82sfHIPtof7f.r2nG','alumno',1,'2026-04-30 03:54:47'),(69,'Kevin Alejandro López Martínez','kevin144','$2b$10$EGczw88VoCU1UaNbJvKCq.HIHpwtnsWGixpYay1C/BK1by859pUvO','alumno',1,'2026-04-30 05:39:31'),(70,'Valeria Nicole Ramírez González','valeria145','$2b$10$1TuhP4jSB75Olluo8d1ptuq/xDEmJtRkpLmIHbqTftKPKcRm0dFlC','alumno',1,'2026-04-30 05:39:31'),(71,'Diego Sebastián Morales Castro','diego146','$2b$10$wmzq9YZ/pMHgu7xzFKjcI.G2.T8PwFgx516PVTnFDPJotbw8PXu9q','alumno',1,'2026-04-30 05:39:32'),(72,'Andrea Paola Hernández Ruiz','andrea147','$2b$10$ZHKFbvYdO8q/g.qYqBp3su2rZZkOQfTH6n0jNDirDsLqCbLtT/YRm','alumno',1,'2026-04-30 05:39:32'),(73,'Samuel Esteban Pérez Aguilar','samuel148','$2b$10$s8K4IZp1lAfixImIh7.wNeK.vpxbRLyUCMwAKrOI5foeEm2CvindS','alumno',1,'2026-04-30 05:39:32'),(74,'Natalia Fernanda Castillo Mendoza','natalia149','$2b$10$aPZ9ulPH9tqR2i/db.5Jg.Tljfq92t/MQyKl038DHiaPXYrp24Ake','alumno',1,'2026-04-30 05:39:33'),(75,'Bryan Daniel Torres Vásquez','bryan150','$2b$10$UTETJFp7r8N97VRIIiNOU.6VvJv27rO4WJx/J4jsS7/IFDpti1lwa','alumno',1,'2026-04-30 05:39:33'),(76,'Sofía Gabriela Gómez Rivera','sofia151','$2b$10$LcwK0ix5UK7X4yOfMj2i6.GnIF24LzSoP/KJu0AEDr.qY7hW74xsi','alumno',1,'2026-04-30 05:39:33'),(77,'Mateo Alejandro Cruz Herrera','mateo152','$2b$10$nJgjl58R1sFX8GPebbYtjObMhiZ1ombHqPaz4Q1r7ud3s9xHmdKEG','alumno',1,'2026-04-30 05:39:33'),(78,'Isabella Lucía Ortiz Flores','isabella153','$2b$10$ue2Uyobqez9Yfd/vW4Ia0.aIvaNeUNOsG/qD4bij0EKWKX4VX7c62','alumno',1,'2026-04-30 05:39:34'),(79,'Ana Lucía Pérez Méndez','ana154','$2b$10$o.fmySWl612Eh6pBHGn/CeHjb7xBq50OdMWd66TKtWW9q0dSMpxCy','alumno',1,'2026-05-02 02:16:10'),(80,'Erick Yovani Lopez Rodas','erick155','$2b$10$dGtcB1oE4ouro.0Io26klubwe5wzx4T4MifUDRRMuX12nf9/LhoLC','alumno',1,'2026-05-07 03:10:43'),(81,'Marcusito Santos','marcusito156','$2b$10$6BV.RR2fjcBarh1YbDlhMugASpDNPDzhNJWP.Y7UgQVRz.y4yZr7q','alumno',1,'2026-05-07 17:33:06'),(82,'Marcus','marcus@sistec.com','$2b$10$MME3IrtZakjS1IJtRHaVHO1gZuwolStQ7dxpGwZJLAU/7EOz1hi4K','maestro',1,'2026-05-07 17:46:56'),(83,'marcus santizo','marcusoficina@sistec.com','$2b$10$RxaeBTjwgwzrDefeZ27bEeuCR4l7O4QSbh4B3bzu.T6P2Y1yHCz2a','oficina',1,'2026-05-07 17:55:00');
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'sistema_escolar'
--

--
-- Dumping routines for database 'sistema_escolar'
--

--
-- Current Database: `sistec_xela`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `sistec_xela` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `sistec_xela`;

--
-- Table structure for table `alumnos`
--

DROP TABLE IF EXISTS `alumnos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `alumnos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `clave` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `codigo_estudiante` varchar(7) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nombre` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `apellido` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fecha_inicio` date DEFAULT NULL,
  `fecha_nacimiento` date DEFAULT NULL,
  `encargado` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `telefono` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `diplomado` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tac` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `asesor` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `direccion` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `establecimiento` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `observaciones` text COLLATE utf8mb4_unicode_ci,
  `dia_clases1` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dia_clases2` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `horario` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `laboratorio` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `estado` enum('activo','inactivo','retirado') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'activo',
  `cuota_mensual` decimal(10,2) NOT NULL DEFAULT '0.00',
  `usuario_id` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `clave` (`clave`),
  UNIQUE KEY `codigo_estudiante` (`codigo_estudiante`),
  CONSTRAINT `chk_codigo_estudiante` CHECK (((`codigo_estudiante` is null) or regexp_like(`codigo_estudiante`,_utf8mb4'^[A-Z][0-9]{3}[A-Z]{3}$')))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alumnos`
--

LOCK TABLES `alumnos` WRITE;
/*!40000 ALTER TABLE `alumnos` DISABLE KEYS */;
INSERT INTO `alumnos` VALUES (1,'260001','J515SDE','Juan Carlos','Mendoza Rodas','2026-01-01','2010-01-01','Juan Estrada','96969898','Reparacion de computadoras','2','Rony Castillo','Xela','INEB Xela','','lunes',NULL,'07:00 a 12:00','1','activo',60.00,2,'2026-04-29 20:53:05');
/*!40000 ALTER TABLE `alumnos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `asistencia_semanal`
--

DROP TABLE IF EXISTS `asistencia_semanal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `asistencia_semanal` (
  `id` int NOT NULL AUTO_INCREMENT,
  `alumno_id` int NOT NULL,
  `anio` smallint NOT NULL,
  `mes` tinyint NOT NULL,
  `semana` tinyint NOT NULL,
  `estado` char(1) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_asist_sem` (`alumno_id`,`anio`,`mes`,`semana`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `asistencia_semanal`
--

LOCK TABLES `asistencia_semanal` WRITE;
/*!40000 ALTER TABLE `asistencia_semanal` DISABLE KEYS */;
/*!40000 ALTER TABLE `asistencia_semanal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `avisos`
--

DROP TABLE IF EXISTS `avisos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `avisos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `autor_id` int DEFAULT NULL,
  `autor_nombre` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `autor_rol` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `titulo` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mensaje` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `scope` enum('global','horario','laboratorio','diplomado','dia','alumno') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'global',
  `filtro_dia` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `filtro_horario` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `filtro_laboratorio` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `filtro_diplomado` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `filtro_alumno_id` int DEFAULT NULL,
  `expira_at` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_avisos_scope` (`scope`),
  KEY `idx_avisos_expira` (`expira_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `avisos`
--

LOCK TABLES `avisos` WRITE;
/*!40000 ALTER TABLE `avisos` DISABLE KEYS */;
/*!40000 ALTER TABLE `avisos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bitacora`
--

DROP TABLE IF EXISTS `bitacora`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bitacora` (
  `id` int NOT NULL AUTO_INCREMENT,
  `usuario_id` int DEFAULT NULL,
  `usuario_nombre` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Sistema',
  `accion` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `modulo` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci,
  `ip` varchar(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bitacora`
--

LOCK TABLES `bitacora` WRITE;
/*!40000 ALTER TABLE `bitacora` DISABLE KEYS */;
INSERT INTO `bitacora` VALUES (1,1,'Admin Sistec Xela','crear','Diplomados','Diplomado: Reparacion de computadoras','::1','2026-04-29 20:48:56'),(2,1,'Admin Sistec Xela','editar','Diplomados','Exámenes diplomado 4: 4','::1','2026-04-29 20:49:21'),(3,1,'Admin Sistec Xela','crear','Catálogos','Horario: lunes 07:00 a 12:00','::1','2026-04-29 20:51:02'),(4,1,'Admin Sistec Xela','crear','Catálogos','nombre: 1','::1','2026-04-29 20:51:08'),(5,1,'Admin Sistec Xela','crear','Catálogos','nombre: INEB Xela','::1','2026-04-29 20:51:18'),(6,1,'Admin Sistec Xela','crear','Catálogos','Cuota: Q60 (Diplomado)','::1','2026-04-29 20:51:29'),(7,1,'Admin Sistec Xela','crear','Catálogos','Cuenta bancaria: Banrural 4141 (Sistec Xela Cuenta)','::1','2026-04-29 20:51:47'),(8,1,'Admin Sistec Xela','crear','Alumnos','Alumno creado: Juan Carlos Mendoza Rodas (clave 260001, código J515SDE)','::1','2026-04-29 20:53:05'),(9,1,'Admin Sistec Xela','crear','NuevoPago','Recibo 100 — 260001 (J515SDE) Juan Carlos Mendoza Rodas — Enero - Febrero — Q120','::1','2026-04-29 20:55:27'),(10,1,'Admin Sistec Xela','crear','Cierres','Cierre recibos 2026-04-29: total Q120.00 - gastos Q0.00 = Q120.00 (Banrural · 4141 · Sistec Xela Cuenta)','::1','2026-04-29 20:56:37'),(11,1,'Admin Sistec Xela','revisar','Cierres','Cierre ID 1 marcado como revisado','::1','2026-04-29 20:57:05');
/*!40000 ALTER TABLE `bitacora` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cat_cuentas_bancarias`
--

DROP TABLE IF EXISTS `cat_cuentas_bancarias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cat_cuentas_bancarias` (
  `id` int NOT NULL AUTO_INCREMENT,
  `numero_cuenta` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nombre` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo_cuenta` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cat_cuentas_bancarias`
--

LOCK TABLES `cat_cuentas_bancarias` WRITE;
/*!40000 ALTER TABLE `cat_cuentas_bancarias` DISABLE KEYS */;
INSERT INTO `cat_cuentas_bancarias` VALUES (1,'4141','Sistec Xela Cuenta','Banrural',1,'2026-04-29 20:51:47');
/*!40000 ALTER TABLE `cat_cuentas_bancarias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cat_cuotas`
--

DROP TABLE IF EXISTS `cat_cuotas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cat_cuotas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `monto` decimal(10,2) NOT NULL,
  `descripcion` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cat_cuotas`
--

LOCK TABLES `cat_cuotas` WRITE;
/*!40000 ALTER TABLE `cat_cuotas` DISABLE KEYS */;
INSERT INTO `cat_cuotas` VALUES (1,60.00,'Diplomado',1,'2026-04-29 20:51:28');
/*!40000 ALTER TABLE `cat_cuotas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cat_establecimientos`
--

DROP TABLE IF EXISTS `cat_establecimientos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cat_establecimientos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nombre` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=148 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cat_establecimientos`
--

LOCK TABLES `cat_establecimientos` WRITE;
/*!40000 ALTER TABLE `cat_establecimientos` DISABLE KEYS */;
INSERT INTO `cat_establecimientos` VALUES (1,'INEB Xela',1,'2026-04-29 20:51:18');
/*!40000 ALTER TABLE `cat_establecimientos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cat_horarios`
--

DROP TABLE IF EXISTS `cat_horarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cat_horarios` (
  `id` int NOT NULL AUTO_INCREMENT,
  `dia1` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dia2` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hora_inicio` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `hora_fin` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cat_horarios`
--

LOCK TABLES `cat_horarios` WRITE;
/*!40000 ALTER TABLE `cat_horarios` DISABLE KEYS */;
INSERT INTO `cat_horarios` VALUES (1,'lunes',NULL,'07:00','12:00',1,'2026-04-29 20:51:02');
/*!40000 ALTER TABLE `cat_horarios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cat_laboratorios`
--

DROP TABLE IF EXISTS `cat_laboratorios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cat_laboratorios` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nombre` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=148 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cat_laboratorios`
--

LOCK TABLES `cat_laboratorios` WRITE;
/*!40000 ALTER TABLE `cat_laboratorios` DISABLE KEYS */;
INSERT INTO `cat_laboratorios` VALUES (1,'1',1,'2026-04-29 20:51:08');
/*!40000 ALTER TABLE `cat_laboratorios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cierre_gastos`
--

DROP TABLE IF EXISTS `cierre_gastos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cierre_gastos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `cierre_id` int NOT NULL,
  `descripcion` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `monto` decimal(10,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id`),
  KEY `idx_cierre_gastos` (`cierre_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cierre_gastos`
--

LOCK TABLES `cierre_gastos` WRITE;
/*!40000 ALTER TABLE `cierre_gastos` DISABLE KEYS */;
/*!40000 ALTER TABLE `cierre_gastos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cierres_diarios`
--

DROP TABLE IF EXISTS `cierres_diarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cierres_diarios` (
  `id` int NOT NULL AUTO_INCREMENT,
  `modulo` enum('recibos','papeleria') COLLATE utf8mb4_unicode_ci NOT NULL,
  `fecha` date NOT NULL,
  `total_dia` decimal(10,2) NOT NULL DEFAULT '0.00',
  `total_gastos` decimal(10,2) NOT NULL DEFAULT '0.00',
  `total_depositar` decimal(10,2) NOT NULL DEFAULT '0.00',
  `cuenta_id` int DEFAULT NULL,
  `cuenta_snapshot` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ultimo_recibo` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `observaciones` text COLLATE utf8mb4_unicode_ci,
  `estado` enum('pendiente','revisado') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pendiente',
  `creado_por_id` int DEFAULT NULL,
  `creado_por_nombre` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `revisado_por_id` int DEFAULT NULL,
  `revisado_por_nombre` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `revisado_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_cierre` (`modulo`,`fecha`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cierres_diarios`
--

LOCK TABLES `cierres_diarios` WRITE;
/*!40000 ALTER TABLE `cierres_diarios` DISABLE KEYS */;
INSERT INTO `cierres_diarios` VALUES (1,'recibos','2026-04-29',120.00,0.00,120.00,1,'Banrural · 4141 · Sistec Xela Cuenta','100',NULL,'revisado',1,'Admin Sistec Xela',1,'Admin Sistec Xela','2026-04-29 20:57:05','2026-04-29 20:56:37','2026-04-29 20:57:05');
/*!40000 ALTER TABLE `cierres_diarios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `config_pagos`
--

DROP TABLE IF EXISTS `config_pagos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `config_pagos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `anio` int NOT NULL,
  `scope_tipo` enum('global','diplomado','horario','laboratorio','dia','alumno') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'global',
  `scope_valor` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mes_inicio` tinyint NOT NULL,
  `mes_fin` tinyint NOT NULL,
  `multiplicador` decimal(4,2) NOT NULL DEFAULT '1.00',
  `descripcion` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_cfg_anio` (`anio`),
  KEY `idx_cfg_scope` (`scope_tipo`,`scope_valor`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `config_pagos`
--

LOCK TABLES `config_pagos` WRITE;
/*!40000 ALTER TABLE `config_pagos` DISABLE KEYS */;
/*!40000 ALTER TABLE `config_pagos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `configuracion`
--

DROP TABLE IF EXISTS `configuracion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `configuracion` (
  `id` int NOT NULL AUTO_INCREMENT,
  `clave` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `valor` text COLLATE utf8mb4_unicode_ci,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `clave` (`clave`)
) ENGINE=InnoDB AUTO_INCREMENT=589 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `configuracion`
--

LOCK TABLES `configuracion` WRITE;
/*!40000 ALTER TABLE `configuracion` DISABLE KEYS */;
INSERT INTO `configuracion` VALUES (1,'inst_nombre','EDUGUAT','2026-04-29 20:45:40'),(2,'inst_direccion','Ciudad de Guatemala, Guatemala','2026-04-29 20:45:40'),(3,'inst_telefono','Tel: 2222-3333','2026-04-29 20:45:40'),(4,'inst_email','','2026-04-29 20:45:40');
/*!40000 ALTER TABLE `configuracion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `constancia_plantillas`
--

DROP TABLE IF EXISTS `constancia_plantillas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `constancia_plantillas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ubicacion` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Guatemala',
  `saludo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Estimado(a) Director(a):',
  `cuerpo` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `despedida` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Atentamente,',
  `firma_nombre` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Secretaría',
  `firma_cargo` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mostrar_fecha` tinyint(1) NOT NULL DEFAULT '1',
  `mostrar_firma` tinyint(1) NOT NULL DEFAULT '1',
  `mostrar_telefono` tinyint(1) NOT NULL DEFAULT '1',
  `activa` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `espacio_post_encabezado` tinyint NOT NULL DEFAULT '3',
  `espacio_post_fecha` tinyint NOT NULL DEFAULT '2',
  `espacio_post_saludo` tinyint NOT NULL DEFAULT '1',
  `espacio_post_cuerpo` tinyint NOT NULL DEFAULT '2',
  `espacio_post_despedida` tinyint NOT NULL DEFAULT '3',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `constancia_plantillas`
--

LOCK TABLES `constancia_plantillas` WRITE;
/*!40000 ALTER TABLE `constancia_plantillas` DISABLE KEYS */;
INSERT INTO `constancia_plantillas` VALUES (1,'Constancia de Inscripción','Guatemala','A quien corresponda:','Por medio de la presente hacemos constar que el alumno(a) {{nombre_completo}}, estudiante del establecimiento {{establecimiento}}, se encuentra inscrito(a) actualmente en el curso de Tecnología {{tac}}, en el horario de {{horario}} los días {{dias}} en el laboratorio {{laboratorio}}.\n\nLa presente constancia se extiende a solicitud del interesado para los usos que estime convenientes.','Atentamente,','Secretaría','',1,1,1,1,'2026-04-29 21:07:27','2026-04-29 21:07:27',3,2,1,2,3);
/*!40000 ALTER TABLE `constancia_plantillas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dip_diplomado_objetivos`
--

DROP TABLE IF EXISTS `dip_diplomado_objetivos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dip_diplomado_objetivos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `diplomado_id` int NOT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `orden` smallint NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_dip_obj` (`diplomado_id`,`orden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dip_diplomado_objetivos`
--

LOCK TABLES `dip_diplomado_objetivos` WRITE;
/*!40000 ALTER TABLE `dip_diplomado_objetivos` DISABLE KEYS */;
/*!40000 ALTER TABLE `dip_diplomado_objetivos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dip_diplomados`
--

DROP TABLE IF EXISTS `dip_diplomados`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dip_diplomados` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `objetivo_general` text COLLATE utf8mb4_unicode_ci,
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dip_diplomados`
--

LOCK TABLES `dip_diplomados` WRITE;
/*!40000 ALTER TABLE `dip_diplomados` DISABLE KEYS */;
INSERT INTO `dip_diplomados` VALUES (1,'Operador Windows','',1,'2026-04-29 20:45:40'),(2,'Programador','',1,'2026-04-29 20:45:40'),(3,'Diseño Gráfico','',1,'2026-04-29 20:45:41'),(4,'Reparacion de computadoras','',1,'2026-04-29 20:48:56');
/*!40000 ALTER TABLE `dip_diplomados` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dip_examenes`
--

DROP TABLE IF EXISTS `dip_examenes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dip_examenes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `diplomado_id` int NOT NULL,
  `nombre` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `orden` smallint NOT NULL DEFAULT '0',
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_dip_exam` (`diplomado_id`,`orden`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dip_examenes`
--

LOCK TABLES `dip_examenes` WRITE;
/*!40000 ALTER TABLE `dip_examenes` DISABLE KEYS */;
INSERT INTO `dip_examenes` VALUES (1,1,'Windows',0,1,'2026-04-29 20:45:40'),(2,1,'Word',1,1,'2026-04-29 20:45:40'),(3,1,'Publisher',2,1,'2026-04-29 20:45:40'),(4,1,'PowerPoint',3,1,'2026-04-29 20:45:40'),(5,1,'Parcial',4,1,'2026-04-29 20:45:40'),(6,1,'Excel',5,1,'2026-04-29 20:45:40'),(7,1,'Examen Final',6,1,'2026-04-29 20:45:40'),(8,2,'Scratch',0,1,'2026-04-29 20:45:40'),(9,2,'Python',1,1,'2026-04-29 20:45:40'),(10,2,'Parcial',2,1,'2026-04-29 20:45:40'),(11,2,'C#',3,1,'2026-04-29 20:45:40'),(12,2,'Examen Final',4,1,'2026-04-29 20:45:41'),(13,3,'Photoshop',0,1,'2026-04-29 20:45:41'),(14,3,'Illustrator',1,1,'2026-04-29 20:45:41'),(15,3,'Parcial',2,1,'2026-04-29 20:45:41'),(16,3,'Filmora',3,1,'2026-04-29 20:45:41'),(17,3,'Examen Final',4,1,'2026-04-29 20:45:41'),(18,4,'Examen1',0,1,'2026-04-29 20:49:21'),(19,4,'Examen2',1,1,'2026-04-29 20:49:21'),(20,4,'Examen3',2,1,'2026-04-29 20:49:21'),(21,4,'Examen4',3,1,'2026-04-29 20:49:21');
/*!40000 ALTER TABLE `dip_examenes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dip_programa_contenido`
--

DROP TABLE IF EXISTS `dip_programa_contenido`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dip_programa_contenido` (
  `id` int NOT NULL AUTO_INCREMENT,
  `programa_id` int NOT NULL,
  `semana_num` tinyint NOT NULL,
  `contenido` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_dip_prog_cont` (`programa_id`,`semana_num`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dip_programa_contenido`
--

LOCK TABLES `dip_programa_contenido` WRITE;
/*!40000 ALTER TABLE `dip_programa_contenido` DISABLE KEYS */;
/*!40000 ALTER TABLE `dip_programa_contenido` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dip_programa_objetivos`
--

DROP TABLE IF EXISTS `dip_programa_objetivos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dip_programa_objetivos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `programa_id` int NOT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `orden` smallint NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_prog_obj` (`programa_id`,`orden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dip_programa_objetivos`
--

LOCK TABLES `dip_programa_objetivos` WRITE;
/*!40000 ALTER TABLE `dip_programa_objetivos` DISABLE KEYS */;
/*!40000 ALTER TABLE `dip_programa_objetivos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dip_programas`
--

DROP TABLE IF EXISTS `dip_programas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dip_programas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `diplomado_id` int NOT NULL,
  `nombre` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `objetivo_general` text COLLATE utf8mb4_unicode_ci,
  `duracion_semanas` tinyint NOT NULL DEFAULT '1',
  `orden` smallint NOT NULL DEFAULT '0',
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_prog_dip` (`diplomado_id`,`orden`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dip_programas`
--

LOCK TABLES `dip_programas` WRITE;
/*!40000 ALTER TABLE `dip_programas` DISABLE KEYS */;
INSERT INTO `dip_programas` VALUES (1,1,'Windows','',1,0,1,'2026-04-29 20:45:40'),(2,1,'Word','',1,1,1,'2026-04-29 20:45:40'),(3,1,'Publisher','',1,2,1,'2026-04-29 20:45:40'),(4,1,'PowerPoint','',1,3,1,'2026-04-29 20:45:40'),(5,1,'Parcial','',1,4,1,'2026-04-29 20:45:40'),(6,1,'Excel','',1,5,1,'2026-04-29 20:45:40'),(7,1,'Examen Final','',1,6,1,'2026-04-29 20:45:40'),(8,2,'Scratch','',1,0,1,'2026-04-29 20:45:40'),(9,2,'Python','',1,1,1,'2026-04-29 20:45:40'),(10,2,'Parcial','',1,2,1,'2026-04-29 20:45:40'),(11,2,'C#','',1,3,1,'2026-04-29 20:45:40'),(12,2,'Examen Final','',1,4,1,'2026-04-29 20:45:40'),(13,3,'Photoshop','',1,0,1,'2026-04-29 20:45:41'),(14,3,'Illustrator','',1,1,1,'2026-04-29 20:45:41'),(15,3,'Parcial','',1,2,1,'2026-04-29 20:45:41'),(16,3,'Filmora','',1,3,1,'2026-04-29 20:45:41'),(17,3,'Examen Final','',1,4,1,'2026-04-29 20:45:41'),(18,4,'Test1','',1,0,1,'2026-04-29 20:48:56'),(19,4,'Test2','',1,1,1,'2026-04-29 20:48:56'),(20,4,'Test3','',1,2,1,'2026-04-29 20:48:56'),(21,4,'Test4','',1,3,1,'2026-04-29 20:48:56');
/*!40000 ALTER TABLE `dip_programas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `diplomado_notas`
--

DROP TABLE IF EXISTS `diplomado_notas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `diplomado_notas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `alumno_id` int NOT NULL,
  `anio` smallint NOT NULL,
  `materia` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nota` smallint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_dip_n` (`alumno_id`,`anio`,`materia`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `diplomado_notas`
--

LOCK TABLES `diplomado_notas` WRITE;
/*!40000 ALTER TABLE `diplomado_notas` DISABLE KEYS */;
/*!40000 ALTER TABLE `diplomado_notas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inscritos_tac`
--

DROP TABLE IF EXISTS `inscritos_tac`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inscritos_tac` (
  `id` int NOT NULL AUTO_INCREMENT,
  `alumno_id` int NOT NULL,
  `anio` smallint NOT NULL,
  `tac` tinyint NOT NULL,
  `estado` enum('inscrito','no_inscrito','pendiente') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'no_inscrito',
  `fecha_actualizacion` datetime DEFAULT NULL,
  `observaciones` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_inscritos_tac` (`alumno_id`,`anio`,`tac`),
  KEY `idx_inscritos_anio_tac` (`anio`,`tac`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inscritos_tac`
--

LOCK TABLES `inscritos_tac` WRITE;
/*!40000 ALTER TABLE `inscritos_tac` DISABLE KEYS */;
/*!40000 ALTER TABLE `inscritos_tac` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `instituciones`
--

DROP TABLE IF EXISTS `instituciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `instituciones` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `resolucion` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `ubicacion` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `extras` longtext COLLATE utf8mb4_unicode_ci,
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `instituciones`
--

LOCK TABLES `instituciones` WRITE;
/*!40000 ALTER TABLE `instituciones` DISABLE KEYS */;
/*!40000 ALTER TABLE `instituciones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mecanografia_notas`
--

DROP TABLE IF EXISTS `mecanografia_notas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mecanografia_notas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `alumno_id` int NOT NULL,
  `anio` smallint NOT NULL,
  `l1` smallint DEFAULT NULL,
  `l2` smallint DEFAULT NULL,
  `l3` smallint DEFAULT NULL,
  `l4` smallint DEFAULT NULL,
  `l5` smallint DEFAULT NULL,
  `l6` smallint DEFAULT NULL,
  `l7` smallint DEFAULT NULL,
  `l8` smallint DEFAULT NULL,
  `l9` smallint DEFAULT NULL,
  `l10` smallint DEFAULT NULL,
  `l11` smallint DEFAULT NULL,
  `l12` smallint DEFAULT NULL,
  `l13` smallint DEFAULT NULL,
  `l14` smallint DEFAULT NULL,
  `l15` smallint DEFAULT NULL,
  `l16` smallint DEFAULT NULL,
  `l17` smallint DEFAULT NULL,
  `l18` smallint DEFAULT NULL,
  `l19` smallint DEFAULT NULL,
  `l20` smallint DEFAULT NULL,
  `examen` smallint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_mec_n` (`alumno_id`,`anio`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mecanografia_notas`
--

LOCK TABLES `mecanografia_notas` WRITE;
/*!40000 ALTER TABLE `mecanografia_notas` DISABLE KEYS */;
/*!40000 ALTER TABLE `mecanografia_notas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mensualidades`
--

DROP TABLE IF EXISTS `mensualidades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mensualidades` (
  `id` int NOT NULL AUTO_INCREMENT,
  `alumno_id` int NOT NULL,
  `mes` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `anio` smallint NOT NULL,
  `monto` decimal(10,2) NOT NULL DEFAULT '0.00',
  `pagado` tinyint(1) NOT NULL DEFAULT '0',
  `anulado` tinyint(1) NOT NULL DEFAULT '0',
  `descuento_100` tinyint(1) NOT NULL DEFAULT '0',
  `no_recibo` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fecha_pago` date DEFAULT NULL,
  `monto_abonado` decimal(10,2) NOT NULL DEFAULT '0.00',
  `acreditado` tinyint(1) NOT NULL DEFAULT '0',
  `acreditado_msg` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_mens` (`alumno_id`,`mes`,`anio`)
) ENGINE=InnoDB AUTO_INCREMENT=1778 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mensualidades`
--

LOCK TABLES `mensualidades` WRITE;
/*!40000 ALTER TABLE `mensualidades` DISABLE KEYS */;
INSERT INTO `mensualidades` VALUES (1,1,'enero',2026,60.00,1,0,0,'100','2026-04-29',60.00,0,NULL),(2,1,'febrero',2026,60.00,1,0,0,'100','2026-04-29',60.00,0,NULL),(3,1,'marzo',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(4,1,'abril',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(5,1,'mayo',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(6,1,'junio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(7,1,'julio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(8,1,'agosto',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(9,1,'septiembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(10,1,'octubre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(11,1,'noviembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(12,1,'diciembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL);
/*!40000 ALTER TABLE `mensualidades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mis_tablas`
--

DROP TABLE IF EXISTS `mis_tablas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mis_tablas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci,
  `encabezado` text COLLATE utf8mb4_unicode_ci,
  `columnas` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `filas` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mis_tablas`
--

LOCK TABLES `mis_tablas` WRITE;
/*!40000 ALTER TABLE `mis_tablas` DISABLE KEYS */;
/*!40000 ALTER TABLE `mis_tablas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notas_tac_anual`
--

DROP TABLE IF EXISTS `notas_tac_anual`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notas_tac_anual` (
  `id` int NOT NULL AUTO_INCREMENT,
  `alumno_id` int NOT NULL,
  `anio` smallint NOT NULL,
  `nota1` smallint DEFAULT NULL,
  `nota2` smallint DEFAULT NULL,
  `nota3` smallint DEFAULT NULL,
  `nota4` smallint DEFAULT NULL,
  `tac` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_tac_a` (`alumno_id`,`anio`,`tac`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notas_tac_anual`
--

LOCK TABLES `notas_tac_anual` WRITE;
/*!40000 ALTER TABLE `notas_tac_anual` DISABLE KEYS */;
/*!40000 ALTER TABLE `notas_tac_anual` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `papeleria`
--

DROP TABLE IF EXISTS `papeleria`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `papeleria` (
  `id` int NOT NULL AUTO_INCREMENT,
  `no_recibo` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `alumno_id` int DEFAULT NULL,
  `descripcion` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `total` decimal(10,2) DEFAULT NULL,
  `observaciones` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `alumno_texto` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `anulado` tinyint(1) NOT NULL DEFAULT '0',
  `anulado_at` timestamp NULL DEFAULT NULL,
  `no_deposito` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `papeleria`
--

LOCK TABLES `papeleria` WRITE;
/*!40000 ALTER TABLE `papeleria` DISABLE KEYS */;
/*!40000 ALTER TABLE `papeleria` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_resets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `usuario_id` int NOT NULL,
  `token` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expira_at` datetime NOT NULL,
  `usado` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `token` (`token`),
  KEY `idx_pwres_user` (`usuario_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recibos`
--

DROP TABLE IF EXISTS `recibos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `recibos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `no_recibo` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `alumno_id` int DEFAULT NULL,
  `meses` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `total` decimal(10,2) DEFAULT NULL,
  `observaciones` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `descuento` decimal(10,2) NOT NULL DEFAULT '0.00',
  `alumno_texto` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `anulado` tinyint(1) NOT NULL DEFAULT '0',
  `anulado_at` timestamp NULL DEFAULT NULL,
  `no_deposito` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recibos`
--

LOCK TABLES `recibos` WRITE;
/*!40000 ALTER TABLE `recibos` DISABLE KEYS */;
INSERT INTO `recibos` VALUES (1,'100',1,'Enero - Febrero','2026-04-29',120.00,NULL,'2026-04-29 20:55:27',0.00,NULL,0,NULL,NULL);
/*!40000 ALTER TABLE `recibos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recibos_diplomados`
--

DROP TABLE IF EXISTS `recibos_diplomados`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `recibos_diplomados` (
  `id` int NOT NULL AUTO_INCREMENT,
  `no_recibo` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `alumno_id` int DEFAULT NULL,
  `diplomado` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `descripcion` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `total` decimal(10,2) DEFAULT NULL,
  `observaciones` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recibos_diplomados`
--

LOCK TABLES `recibos_diplomados` WRITE;
/*!40000 ALTER TABLE `recibos_diplomados` DISABLE KEYS */;
/*!40000 ALTER TABLE `recibos_diplomados` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuarios` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rol` enum('admin','alumno','oficina','maestro') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'alumno',
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuarios`
--

LOCK TABLES `usuarios` WRITE;
/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
INSERT INTO `usuarios` VALUES (1,'Admin Sistec Xela','sistecxela@gmail.com','$2b$10$wUwg/5AirFlvJI6xuoduT.A2WiJlMIWSY3H/yTO/Ml9Fw35ZXoAyi','admin',1,'2026-04-29 20:45:41'),(2,'Juan Carlos Mendoza Rodas','juan260001','$2b$10$Mv1.OWYXB3P1Yv0Pe.2/EO6idR0qWimdeGhoHCrofvn5j01plytZq','alumno',1,'2026-04-29 20:53:05');
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'sistec_xela'
--

--
-- Dumping routines for database 'sistec_xela'
--

--
-- Current Database: `testimport1`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `testimport1` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `testimport1`;

--
-- Table structure for table `alumnos`
--

DROP TABLE IF EXISTS `alumnos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `alumnos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `clave` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `codigo_estudiante` varchar(7) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nombre` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `apellido` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fecha_inicio` date DEFAULT NULL,
  `fecha_nacimiento` date DEFAULT NULL,
  `encargado` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `telefono` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `diplomado` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tac` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `asesor` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `direccion` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `establecimiento` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `observaciones` text COLLATE utf8mb4_unicode_ci,
  `dia_clases1` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dia_clases2` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `horario` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `laboratorio` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `estado` enum('activo','inactivo','retirado') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'activo',
  `cuota_mensual` decimal(10,2) NOT NULL DEFAULT '0.00',
  `usuario_id` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `clave` (`clave`),
  UNIQUE KEY `codigo_estudiante` (`codigo_estudiante`),
  CONSTRAINT `chk_codigo_estudiante` CHECK (((`codigo_estudiante` is null) or regexp_like(`codigo_estudiante`,_utf8mb4'^[A-Z][0-9]{3}[A-Z]{3}$')))
) ENGINE=InnoDB AUTO_INCREMENT=76 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alumnos`
--

LOCK TABLES `alumnos` WRITE;
/*!40000 ALTER TABLE `alumnos` DISABLE KEYS */;
INSERT INTO `alumnos` VALUES (1,'1','J045MGS','Hernandez Cabrera','Hazel Daniela','2024-10-28','2011-08-31','Julieta Cabrera','4232-0431','Programador','2',NULL,'San Isidro','Instituto Cooperativa San Miguel',NULL,'domingo',NULL,'07:00 a 12:00','1','activo',60.00,2,'2026-05-03 15:28:12'),(2,'2','K100YAN','De Leon Gomez','Cecilia','2024-10-28','2010-10-03','Glendy Gomez','4538-0551 4565-6453','Programador','2',NULL,'San Miguelito, Vista Hermosa','Instituto Cooperativa San Miguel',NULL,'domingo',NULL,'07:00 a 12:00','1','activo',60.00,3,'2026-05-03 15:28:12'),(3,'3','I730VAV','Juarez de Leon','Miguel de Jesus','2024-10-28','2009-03-25','Norma Leticia de Leon','31157779','Programador','2',NULL,'San Miguelito, Vista Hermosa','Instituto Cooperativa San Miguel',NULL,'domingo',NULL,'07:00 a 12:00','1','activo',60.00,4,'2026-05-03 15:28:12'),(4,'4','K300WMG','Lara Tiu','Natalia Lucita','2024-10-28','2011-12-13','Maria Vail','53072022','Programador','2',NULL,'San Miguelito, los Olivos','Instituto Cooperativa San Miguel',NULL,'domingo',NULL,'07:00 a 12:00','1','activo',60.00,5,'2026-05-03 15:28:12'),(5,'5','K500CZC','Estrada del Toro','Diego Alejandro','2024-10-28','2012-02-26','Mynor Estrada','59002116','Programador','2',NULL,'San Miguelito, los Olivos','Instituto Cooperativa San Miguel',NULL,'domingo',NULL,'07:00 a 12:00','1','activo',60.00,6,'2026-05-03 15:28:12'),(6,'6','J046RPG','Cuyuch Domiguez','Sergio Ottoniel','2024-10-28','2011-08-10','Maria Dolores Domiguez','50623244','Programador','2',NULL,'San Miguelito, los Olivos','Instituto Cooperativa San Miguel',NULL,'domingo',NULL,'07:00 a 12:00','1','activo',60.00,7,'2026-05-03 15:28:12'),(7,'7','J743JPZ','Garcia Perez','Jorge Danilo','2024-10-28','2012-06-23','Nury Anay Perez','53460791','Programador','2',NULL,'San Miguelito, Vista Hermosa','Instituto Cooperativa San Miguel',NULL,'domingo',NULL,'07:00 a 12:00','1','activo',60.00,8,'2026-05-03 15:28:12'),(8,'8','J043MBJ','Chavez Lorenzo','Yeimi Josefina','2024-10-28','2011-08-09','Mata Amelia Chavez','32201071-59089422','Programador','2',NULL,'San Miguelito, Vista Hermosa','Instituto Plan fin de semana san miguelito',NULL,'sabado',NULL,'07:00 a 12:00','1','activo',60.00,9,'2026-05-03 15:28:12'),(9,'9','I739FRH','Perez Perez','Milton Aron','2024-10-28','2011-04-23','Maria Perez','56181649-39450613','Programador','1',NULL,'San Isidro','Instituto Cooperativa San Miguel',NULL,'domingo',NULL,'07:00 a 12:00','1','activo',60.00,10,'2026-05-03 15:28:13'),(10,'10','G758GIP','Shlaj Lucas','Eduardo Apolinario','2024-10-28','2009-11-07','Paula Maria Lucas','40626213','Programador','2',NULL,'San Miguelito, Vista Hermosa','Instituto Cooperativa San Miguel',NULL,'sabado',NULL,'07:00 a 12:00','1','activo',60.00,11,'2026-05-03 15:28:13'),(11,'11','J442HPE','Juarez Lucas','Alison Alondra','2024-10-28','2011-09-14','Teresa Lucas','53596840','Programador','2',NULL,'San Miguelito, Vista Hermosa','Instituto Cooperativa San Miguel',NULL,'domingo',NULL,'07:00 a 12:00','1','activo',60.00,12,'2026-05-03 15:28:13'),(12,'12','K501KNZ','Velasquez Cabrera','Elisa Lisbeth','2024-10-28','2012-03-05','Evelyn Cabrera','51952944','Operador','2',NULL,'San Miguelito, el Milagro','Instituto Cooperativa San Miguel',NULL,'viernes',NULL,'07:00 a 12:00','1','activo',60.00,13,'2026-05-03 15:28:13'),(13,'13','J144ZQJ','Suchite Cabrera','Cristian Wilfredo','2024-10-29','2011-08-10','Israel Suchite','4724-9729','Programador','2',NULL,'San Miguelito Centro','Instituto Cooperativa San Miguel',NULL,'domingo',NULL,'07:00 a 12:00','1','activo',60.00,14,'2026-05-03 15:28:13'),(14,'14','J943THM','Cabrera Giron','Doris Aimar','2024-10-29','2011-09-17','Doris Giron','5346-3010','Programador','2',NULL,'San Miguelito Centro','Instituto Cooperativa San Miguel',NULL,'domingo',NULL,'07:00 a 12:00','1','activo',60.00,15,'2026-05-03 15:28:13'),(15,'15','K500DQZ','Orozco Rojas','Elmer Nehemias','2024-10-29','2011-10-28','Olimpia Rojas','5194-3849','Operador','2',NULL,'San Miguelito Centro','Instituto Cooperativa San Miguel',NULL,'viernes',NULL,'07:00 a 12:00','1','activo',60.00,16,'2026-05-03 15:28:13'),(16,'16','I133ZUF','Castillo Ovalle','Jade Maria','2024-10-29','2012-03-09','Carmen Ovalle Lopez','4201-4072','Programador','2',NULL,'San Miguelito Centro','Instituto Cooperativa San Miguel',NULL,'sabado',NULL,'07:00 a 12:00','1','activo',60.00,17,'2026-05-03 15:28:13'),(17,'17','L404XUS','Garcia Romero','Ivana Jassmin','2024-10-29','2010-09-24','Elvira Yohana Romera','5523-2086','Programador','2',NULL,'San Miguelito Laloma','Instituto Cooperativa San Miguel',NULL,'domingo',NULL,'07:00 a 12:00','1','activo',60.00,18,'2026-05-03 15:28:13'),(18,'18','K200EPK','De Paz Fuentes','Angel Ferreyn','2024-10-29','2011-10-30','Lesli Margot','5424-7203 4018-8882','Programador','1',NULL,'San Miguelito Centro','Instituto Cooperativa San Miguel',NULL,'domingo',NULL,'12:00 a 05:00','1','activo',60.00,19,'2026-05-03 15:28:13'),(19,'19','K100TBN','Molina','Guillermo Lucas','2024-10-29','2011-07-22','Nanci Lucas','3337-0320','Programador','2',NULL,'San Miguelito Centro','Instituto Cooperativa San Miguel',NULL,'domingo',NULL,'07:00 a 12:00','1','activo',60.00,20,'2026-05-03 15:28:14'),(20,'20','J943NLK','Cigarroa Barrios','Angel David','2024-10-29','2011-10-27','Emma Barrios','3714-1210 3366-3650','Programador','2',NULL,'San Miguelito Centro','Instituto Cooperativa San Miguel',NULL,'domingo',NULL,'12:00 a 05:00','1','activo',60.00,21,'2026-05-03 15:28:14'),(21,'21','I638BYE','Jimenez Perez','Antonio Isai','2024-10-30','2010-11-21','Antonio Jimenez','5919-8598','Programador','2',NULL,'Caserio San Isidro','Instituto Cooperativa San Miguel',NULL,'domingo',NULL,'12:00 a 05:00','1','activo',60.00,22,'2026-05-03 15:28:14'),(22,'22','J242ADF','Contreras Lopez','Sergio Alexander','2024-10-30','2009-11-16','Maria lopez','5059-3465 3748-8348','Programador','2',NULL,'El Mangalito','Instituto Morazan Centro',NULL,'sabado',NULL,'07:00 a 12:00','1','activo',60.00,23,'2026-05-03 15:28:14'),(23,'23','I440CQR','Rojop Garcia','Fatima Nalleli','2024-10-30','2010-05-12','Doris Garcia','4239-1212',NULL,'1',NULL,'San Isidro','estudiara en linea',NULL,'viernes',NULL,'07:00 a 12:00','1','activo',60.00,24,'2026-05-03 15:28:14'),(24,'24','J042SBS','Lara Lopez','Gerson Elias','2024-11-03','2011-10-20','Maria Lopez','5756-8039','Programador','2',NULL,'San Martin','Instituto Talzachum',NULL,'sabado',NULL,'07:00 a 12:00','1','activo',60.00,25,'2026-05-03 15:28:14'),(25,'25','H790XMD','Cuyuch Ordoñez','Estefani Yoana','2024-11-03','2011-03-10','Nieve Solis','5050-0052','Operador','2',NULL,'San Martin','Instituto Talzachum',NULL,'sabado',NULL,'07:00 a 12:00','1','activo',60.00,26,'2026-05-03 15:28:14'),(26,'26','J642LEB','Lopez Ramirez','Nestor Antonio','2024-11-03','2011-10-20','Elsa Perez Lopez','4537-2399 51515400','Programador','2',NULL,'San Martin','Instituto Talzachum',NULL,'sabado',NULL,'07:00 a 12:00','1','activo',60.00,27,'2026-05-03 15:28:14'),(27,'27','L503GBC','Cabrera Lopez','Brayan Yobani','2024-11-03','2011-08-01','Edgar Cabrera','3085-9695','Programador',NULL,NULL,'Talzachun','No estudiara',NULL,'sabado',NULL,'07:00 a 12:00','1','activo',60.00,28,'2026-05-03 15:28:14'),(28,'28','K002IAJ','Sales Garcia','Kervin Ventura','2024-11-03','2012-03-19','Yohana Paola Sales','5814-6310','Programador','2',NULL,'Los Cocos Talzachun','Instituto Talzachum',NULL,'sabado',NULL,'07:00 a 12:00','1','activo',60.00,29,'2026-05-03 15:28:14'),(29,'29','K801FYT','Velasquez Meza','Katerin Elizani','2024-11-03','2011-09-14','Milca Meza','4751-7103','Programador','2',NULL,'Talzachun la rueda','Instituto Talzachum',NULL,'sabado',NULL,'07:00 a 12:00','1','activo',60.00,30,'2026-05-03 15:28:14'),(30,'30','K500JNB','Vasquez Paxtor','Juan Miguel','2024-11-12','2012-06-16','Marco Antonio Vasquez','44762934-39098897-32436060','Programador','2',NULL,'Cable San Miguelito','Instituto Cooperativa San Miguel',NULL,'domingo',NULL,'07:00 a 12:00','1','activo',60.00,31,'2026-05-03 15:28:15'),(31,'31','J244VTS','Pablo de Leon','Ricardo Alberto','2024-11-14','2011-09-23','Melecia de Leon Gomez','4889-8715','Programador','1',NULL,'Colonia El Milagro','Instituto Cooperativa San Miguel',NULL,'domingo',NULL,'12:00 a 05:00','1','activo',60.00,32,'2026-05-03 15:28:15'),(32,'32','K801UKZ','Vicente Perez','Neftali Odiel','2024-11-14','2011-12-06','Mariela Vicente','30426911','Programador','2',NULL,'Colonia El Milagro','Instituto Cooperativa San Miguel',NULL,'domingo',NULL,'12:00 a 05:00','1','activo',60.00,33,'2026-05-03 15:28:15'),(33,'33','J642MRJ','Vicente Diaz','Nataly Celeste','2024-11-14','2011-08-27','Jose Angel Vicente','41159160','Programador','2',NULL,'Colonia El Milagro','Instituto Cooperativa San Miguel',NULL,'domingo',NULL,'12:00 a 05:00','1','activo',60.00,34,'2026-05-03 15:28:15'),(34,'34','J744DMN','Gomez','Maria Ines','2024-11-14','2010-09-26','Rosa Gomez','31471466','Programador','1',NULL,'Colonia El Milagro','Instituto Cooperativa San Miguel',NULL,'domingo',NULL,'12:00 a 05:00','1','activo',60.00,35,'2026-05-03 15:28:15'),(35,'35','J843JGK','Molina Perez','Diana Aurora','2024-11-22','2011-08-30','Roberto Molina','4499-4722-37123555','Programador','2',NULL,'Caserio Hacienda Vieja','Instituto Cooperativa San Miguel',NULL,'domingo',NULL,'12:00 a 05:00','1','activo',60.00,36,'2026-05-03 15:28:15'),(36,'36','J844KPA','de Leon Molina','Marvin Estuardo','2024-11-22','2011-01-09','Julia Molina','3307-5612','Programador','2',NULL,'Caserio Hacienda Vieja','Instituto Cooperativa San Miguel',NULL,'domingo',NULL,'12:00 a 05:00','1','activo',60.00,37,'2026-05-03 15:28:15'),(37,'37','J644UUZ','Perez Orozco','Lilian Delfina','2024-11-22','2011-12-21','Rubelio Perez','33312823','Programador','2',NULL,'Caserio Hacienda Vieja','Instituto Cooperativa San Miguel',NULL,'domingo',NULL,'12:00 a 05:00','1','activo',60.00,38,'2026-05-03 15:28:15'),(38,'38','I430ISI','Chavalan Jasinto','Jose Enrique','2024-11-22','2011-03-01','Blanca Jasinto','4236-9413','Programador','2',NULL,'Caserio Hacienda Vieja','Instituto Cooperativa San Miguel',NULL,'domingo',NULL,'12:00 a 05:00','1','activo',60.00,39,'2026-05-03 15:28:15'),(39,'39','J043LES','Gonzalez Maldonado','Jorge Daniel','2024-11-22','2011-03-13','Marcotulio Gonzalez','5574-7496','Programador','2',NULL,'Caserio El Reposo','Instituto Reposo',NULL,'sabado',NULL,'12:00 a 05:00','1','activo',60.00,40,'2026-05-03 15:28:15'),(40,'40','J744KPV','Guzman Gomez','Walfred Antonio','2024-11-22','2012-06-12','Marta Gomez','4018-9598','Programador','2',NULL,'Caserio El Reposo','Instituto Reposo',NULL,'sabado',NULL,'12:00 a 05:00','1','activo',60.00,41,'2026-05-03 15:28:16'),(41,'41','J943CQJ','Garcia Porrez','Marilin Selyna','2024-11-22','2012-07-08','Maria Lopez','4996-3787 4908-1543','Programador','2',NULL,'Caserio El Reposo','Instituto Reposo',NULL,'sabado',NULL,'12:00 a 05:00','1','activo',60.00,42,'2026-05-03 15:28:16'),(42,'42','I130LIL','Garcia Mendez','Marelin Yoseni','2024-11-22','2011-07-12','Amalia Mendez','3116-5385','Programador','2',NULL,'Caserio El Reposo','Instituto Reposo',NULL,'sabado',NULL,'12:00 a 05:00','1','activo',60.00,43,'2026-05-03 15:28:16'),(43,'43','J142HJR','Ramirez Perez','Delsy Liliana','2024-11-24','2012-01-20','Karina Perez','48037228','Programador','2',NULL,'Caserio El Reposo','Instituto Reposo',NULL,'sabado',NULL,'12:00 a 05:00','1','activo',60.00,44,'2026-05-03 15:28:16'),(44,'44','I232ZGQ','Mendez Vasquez','Sheily Maritza','2024-11-24','2011-07-21','Dora Vasquez','4513-1010','Programador','2',NULL,'Caserio El Reposo','Instituto Reposo',NULL,'sabado',NULL,'12:00 a 05:00','1','activo',60.00,45,'2026-05-03 15:28:16'),(45,'45','J844EFP','Cabrera Alonzo','Emelin Azucena','2024-11-24','2012-02-29','Azucena Hernandez','3260-5014','Programador','2',NULL,'Caserio El Reposo','Instituto Reposo',NULL,'sabado',NULL,'12:00 a 05:00','1','activo',60.00,46,'2026-05-03 15:28:16'),(46,'46','I531LUW','Lopez Lopez','Angel Abraham','2024-11-24','2012-01-18','Isabel Lopez Cortes','4554-6180','Programador','2',NULL,'Caserio El Reposo','Instituto Reposo',NULL,'sabado',NULL,'12:00 a 05:00','1','activo',60.00,47,'2026-05-03 15:28:16'),(47,'47','I932LQD','Perez Perez','Ines','2024-11-24','2011-09-30','Maria Elena','4868-8132','Programador','2',NULL,'Caserio El Reposo','Instituto Reposo',NULL,'sabado',NULL,'12:00 a 05:00','1','activo',60.00,48,'2026-05-03 15:28:16'),(48,'48','I932JWQ','Giron Mendez','Jean Carlos','2024-11-24','2009-12-28','Adelaida Mendoza','5723-5619','Programador','2',NULL,'Caserio El Reposo','Instituto Reposo',NULL,'domingo',NULL,'12:00 a 05:00','1','activo',60.00,49,'2026-05-03 15:28:16'),(49,'49','J643IPD','Molina Vasquez','Lesly Yasmin','2024-11-24','2012-08-15','Sandra Vasquez','3119-3530','Programador','2',NULL,'Caserio El Reposo','Instituto Reposo',NULL,'sabado',NULL,'12:00 a 05:00','1','activo',60.00,50,'2026-05-03 15:28:16'),(50,'50','K001WCH','Lopez Garcia','Eduardo Alberto','2024-11-24','2011-02-11','Catarina Garcia','3197-6046','Programador','2',NULL,'Caserio El Reposo','Instituto Reposo',NULL,'sabado',NULL,'12:00 a 05:00','1','activo',60.00,51,'2026-05-03 15:28:17'),(51,'51','J144HDI','Garcia Perez','Nancy Marisol','2024-11-24','2011-08-26','Teresa Perez','4979-1774','Programador','2',NULL,'Caserio El Reposo','Instituto Reposo',NULL,'sabado',NULL,'12:00 a 05:00','1','activo',60.00,52,'2026-05-03 15:28:17'),(52,'52','J762CVT','Alonzo Lopez','Francis Noe Misael','2024-11-24','2012-06-05','Alejandrina Lopez','4069-8112 3342-4866','Programador','2',NULL,'Caserio El Reposo','Instituto Reposo',NULL,'sabado',NULL,'12:00 a 05:00','1','activo',60.00,53,'2026-05-03 15:28:17'),(53,'53','I130LTV','Rojop Dominguez','Juan Miguel','2024-11-24','2010-09-29','Juan Rene Rojop','4623-1662','Programador','2',NULL,'Caserio El Reposo','Instituto Reposo',NULL,'sabado',NULL,'12:00 a 05:00','1','activo',60.00,54,'2026-05-03 15:28:17'),(54,'54','I830IFB','Vasquez Perez','Adriana Marisol','2024-11-24','2012-01-17','Griselda Azucena Perez','37113408','Programador','2',NULL,'Caserio El Reposo','Instituto Reposo',NULL,'sabado',NULL,'12:00 a 05:00','1','activo',60.00,55,'2026-05-03 15:28:17'),(55,'55','G850PKW','Cruz Vicente','Jimena Dayana','2024-12-04','2010-02-25','Veronica Vicente Lopez','32067130','Programador','2',NULL,'Caserio El Reposo','Instituto Reposo',NULL,'domingo',NULL,'07:00 a 12:00','1','activo',60.00,56,'2026-05-03 15:28:17'),(56,'56','J147NAK','Jimenez Gomez','Byron Jeremias','2025-01-05','2010-12-30','Felicia Gomez','5050-8204','Programador','2',NULL,'Talzachun','Instituto Talzachum',NULL,'sabado',NULL,'07:00 a 12:00','1','activo',60.00,57,'2026-05-03 15:28:17'),(57,'57','J943TDN','Contreras Lopez','Rosa Leticia','2025-02-05','2012-01-07','Maria Catarina','5059-3465 3748-8348','Programador','2',NULL,'Mangalito','Instituto Morazan Centro',NULL,'sabado',NULL,'07:00 a 12:00','1','activo',60.00,58,'2026-05-03 15:28:17'),(58,'58','J185CSM','Castillo Coy','Emilia Elizabeth','2025-04-27','2009-09-16','Yesmini Coy','53757498-38252952','Operador','2',NULL,'Caserio El Reposo','Instituto Reposo',NULL,'sabado',NULL,'07:00 a 12:00','1','activo',60.00,59,'2026-05-03 15:28:17'),(59,'59','F474XPB','Castillo Coy','Evelyn Marleny','2025-04-27','2004-09-30','Yesmini Coy','53757498-38252952','Operador','3',NULL,'Caserio El Reposo','Instituto Reposo',NULL,'sabado',NULL,'07:00 a 12:00','1','activo',60.00,60,'2026-05-03 15:28:17'),(60,'60','L103ZDB','Lopez Lucas','Blanca Azucena','2026-01-16','2013-02-13','Rosario Lucas','5384-5140','Operador','1',NULL,'Colonia Vista Hermosa','Instituto Cooperativa San Miguel',NULL,'viernes',NULL,'07:00 a 12:00','1','activo',60.00,61,'2026-05-03 15:28:18'),(61,'61','I530GWL','Felipe Gomez','Jaqueline Mauricia','2026-01-16','2011-09-26','Fabiana Gomez','4952-7678','Operador','2',NULL,'Caserio El Reposo','Instituto Reposo',NULL,'viernes',NULL,'07:00 a 12:00','1','activo',60.00,62,'2026-05-03 15:28:18'),(62,'62','K402PXP','Macario Vicente','Yeimi Roxana','2026-01-16','2011-08-25','Juana Vicente Garcia','4092-5550 4125-5803','Operador','1',NULL,'Caserio El Reposo','Instituto Reposo',NULL,'viernes',NULL,'07:00 a 12:00','1','activo',60.00,63,'2026-05-03 15:28:18'),(63,'63','J944BFG','Galindo Chavez','Julia Amparo','2026-01-16','2011-10-08','Margarita Chavez','3127-4082','Operador','1',NULL,'San Miguelito Centro','Instituto Cooperativa San Miguel',NULL,'viernes',NULL,'07:00 a 12:00','1','activo',60.00,64,'2026-05-03 15:28:18'),(64,'64','K402QXP','Molina','Sofia Joanna','2026-01-16','2013-01-20','Magaly Molina','3069-3602','Operador','1',NULL,'Caserio El Reposo','Instituto Reposo',NULL,'viernes',NULL,'07:00 a 12:00','1','activo',60.00,65,'2026-05-03 15:28:18'),(65,'65','K300GFT','Juarez','Maria Lucas','2026-01-16','2012-11-19','Teresa Lucas','5359-6840','Operador','1',NULL,'Colonia Vista Hermosa','Instituto Cooperativa San Miguel',NULL,'viernes',NULL,'07:00 a 12:00','1','activo',60.00,66,'2026-05-03 15:28:18'),(66,'66','K400KIR','Ramirez Lopez','Crisbel Maricruz','2026-01-16','2013-05-03','Claudia Lopez Perez','3814-5678 4824-8395','Operador','1',NULL,'Colonia Vista Hermosa','Instituto Cooperativa San Miguel',NULL,'viernes',NULL,'07:00 a 12:00','1','activo',60.00,67,'2026-05-03 15:28:18'),(67,'67','K402GML','Bonilla Garcia','Lea Raquel','2026-01-23','2013-07-28','Hector Amilcar Bonilla Calderon','5567-6597 4392-8239','Operador','1',NULL,'Caserio El Reposo','Instituto Reposo',NULL,'viernes',NULL,'07:00 a 12:00','1','activo',60.00,68,'2026-05-03 15:28:18'),(68,'68','J842VQL','Garcia Lopez','Hernan Alexander','2026-01-23','2012-11-17','Beatriz Lopez','4990-1190 4510-2456','Operador','1',NULL,'Caserio Cabañas','Instituto Reposo',NULL,'viernes',NULL,'07:00 a 12:00','1','activo',60.00,69,'2026-05-03 15:28:18'),(69,'69','L103IZA','Gomez Dueñas','Jose Emanuel','2026-02-05','2013-04-30','Delfina Dueñas','4609-2460 40383321','Operador','1',NULL,'Caserio El Reposo','Instituto Reposo',NULL,'viernes',NULL,'07:00 a 12:00','1','activo',60.00,70,'2026-05-03 15:28:18'),(70,'70','L404GBP','Melchor Garcia','Elias Daniel','2026-02-17','2011-08-13','Leonarda Garcia','34621410','Operador','1',NULL,'Parcelamiento el reposo sector B','Instituto Reposo',NULL,'viernes',NULL,'07:00 a 12:00','1','activo',60.00,71,'2026-05-03 15:28:19'),(71,'71','L404PJB','Soto Melchor','Alexi Esai','2026-02-17','2013-05-08','Leonarda Garcia','34621410','Operador','1',NULL,'Parcelamiento el reposo sector B','Instituto Reposo',NULL,'viernes',NULL,'07:00 a 12:00','1','activo',60.00,72,'2026-05-03 15:28:19'),(72,'72','I241QHQ','Mendoza Castillo','Andrea Elizabeth','2026-02-17','2011-08-29','Lisbeth Castillo','53686224','Operador','1',NULL,'Parcelamiento el reposo sector B','Instituto Reposo',NULL,'viernes',NULL,'07:00 a 12:00','1','activo',60.00,73,'2026-05-03 15:28:19'),(73,'73','J944VVG','Berduo Lopez','Kevin Enrique','2026-03-01','2010-09-30','Olga Lopez','53379168','Operador','2',NULL,'Caserio El Reposo','Instituto Reposo',NULL,'domingo',NULL,'12:00 a 05:00','1','activo',60.00,74,'2026-05-03 15:28:19'),(74,'74','F779BAL','Lopez Hernandez','Esperanza Isabel','2026-03-22','2007-03-09','Olga Lopez','53379168',NULL,'2',NULL,'El reposo','Instituto Reposo',NULL,'domingo',NULL,'12:00 a 05:00','1','activo',60.00,75,'2026-05-03 15:28:19'),(75,'75',NULL,'Rony Alexander','Castillo Lopez','0001-01-01','0001-01-01','a','a','Operador','1','LKASJHFHLAK','LSIGFLIKI','estudiara en linea','','domingo',NULL,'07:00 a 12:00','1','activo',60.00,76,'2026-05-04 18:52:48');
/*!40000 ALTER TABLE `alumnos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `asistencia_semanal`
--

DROP TABLE IF EXISTS `asistencia_semanal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `asistencia_semanal` (
  `id` int NOT NULL AUTO_INCREMENT,
  `alumno_id` int NOT NULL,
  `anio` smallint NOT NULL,
  `mes` tinyint NOT NULL,
  `semana` tinyint NOT NULL,
  `estado` char(1) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_asist_sem` (`alumno_id`,`anio`,`mes`,`semana`)
) ENGINE=InnoDB AUTO_INCREMENT=2420 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `asistencia_semanal`
--

LOCK TABLES `asistencia_semanal` WRITE;
/*!40000 ALTER TABLE `asistencia_semanal` DISABLE KEYS */;
INSERT INTO `asistencia_semanal` VALUES (18,1,2024,11,1,'X'),(19,1,2024,11,2,'X'),(20,1,2024,11,3,'X'),(21,1,2024,11,4,'X'),(22,1,2024,11,5,'X'),(23,1,2024,12,1,'X'),(24,2,2024,11,1,'X'),(25,2,2024,11,2,'X'),(26,2,2024,11,3,'X'),(27,2,2024,11,4,'X'),(28,2,2024,11,5,'X'),(29,2,2024,12,1,'X'),(30,3,2024,11,1,'X'),(31,3,2024,11,2,'X'),(32,3,2024,11,3,'X'),(33,3,2024,11,4,'X'),(34,3,2024,11,5,'X'),(35,3,2024,12,1,'X'),(36,4,2024,11,1,'X'),(37,4,2024,11,2,'X'),(38,4,2024,11,3,'X'),(39,4,2024,11,4,'X'),(40,4,2024,11,5,'X'),(41,4,2024,12,1,'X'),(42,5,2024,11,1,'X'),(43,5,2024,11,2,'X'),(44,5,2024,11,3,'X'),(45,5,2024,11,4,'X'),(46,5,2024,11,5,'X'),(47,5,2024,12,1,'X'),(48,6,2024,11,1,'X'),(49,6,2024,11,2,'X'),(50,6,2024,11,3,'X'),(51,6,2024,11,4,'X'),(52,6,2024,11,5,'X'),(53,6,2024,12,1,'X'),(54,7,2024,11,1,'X'),(55,7,2024,11,2,'X'),(56,7,2024,11,3,'X'),(57,7,2024,11,4,'X'),(58,7,2024,11,5,'X'),(59,7,2024,12,1,'X'),(60,8,2024,11,1,'X'),(61,8,2024,11,2,'X'),(62,8,2024,11,3,'X'),(63,8,2024,11,4,'X'),(64,8,2024,11,5,'X'),(65,8,2024,12,1,'X'),(66,9,2024,11,1,'X'),(67,9,2024,11,2,'X'),(68,9,2024,11,3,'X'),(69,9,2024,11,4,'X'),(70,9,2024,11,5,'X'),(71,10,2024,11,1,'X'),(72,10,2024,11,2,'X'),(73,10,2024,11,3,'X'),(74,10,2024,11,4,'X'),(75,10,2024,11,5,'X'),(76,10,2024,12,1,'X'),(77,11,2024,11,1,'X'),(78,11,2024,11,2,'X'),(79,11,2024,11,3,'X'),(80,11,2024,11,4,'X'),(81,11,2024,11,5,'X'),(82,11,2024,12,1,'X'),(83,12,2024,11,1,'X'),(84,12,2024,11,2,'X'),(85,12,2024,11,3,'X'),(86,12,2024,11,4,'X'),(87,12,2024,11,5,'X'),(88,12,2024,12,1,'X'),(89,13,2024,11,1,'X'),(90,13,2024,11,2,'X'),(91,13,2024,11,3,'X'),(92,13,2024,11,4,'X'),(93,13,2024,11,5,'X'),(94,13,2024,12,1,'X'),(95,13,2024,12,2,'X'),(96,14,2024,11,1,'X'),(97,14,2024,11,2,'X'),(98,14,2024,11,3,'X'),(99,14,2024,11,4,'X'),(100,14,2024,11,5,'X'),(101,14,2024,12,1,'X'),(102,14,2024,12,2,'X'),(103,15,2024,11,1,'X'),(104,15,2024,11,2,'X'),(105,15,2024,11,3,'X'),(106,15,2024,11,4,'X'),(107,15,2024,11,5,'X'),(108,15,2024,12,1,'X'),(109,15,2024,12,2,'X'),(110,16,2024,11,1,'X'),(111,16,2024,11,2,'X'),(112,16,2024,11,3,'X'),(113,16,2024,11,4,'X'),(114,16,2024,11,5,'X'),(115,16,2024,12,1,'X'),(116,16,2024,12,2,'X'),(117,17,2024,11,1,'X'),(118,17,2024,11,2,'X'),(119,17,2024,11,3,'X'),(120,17,2024,11,4,'X'),(121,17,2024,11,5,'X'),(122,17,2024,12,1,'X'),(123,17,2024,12,2,'X'),(124,18,2024,11,1,'X'),(125,18,2024,11,2,'X'),(126,18,2024,11,3,'X'),(127,18,2024,11,4,'X'),(128,18,2024,11,5,'X'),(129,18,2024,12,1,'X'),(130,18,2024,12,2,'R'),(131,19,2024,11,1,'X'),(132,19,2024,11,2,'X'),(133,19,2024,11,3,'X'),(134,19,2024,11,4,'X'),(135,19,2024,11,5,'X'),(136,19,2024,12,1,'X'),(137,19,2024,12,2,'X'),(138,20,2024,11,1,'X'),(139,20,2024,11,2,'X'),(140,20,2024,11,3,'X'),(141,20,2024,11,4,'X'),(142,20,2024,11,5,'X'),(143,20,2024,12,1,'X'),(144,20,2024,12,2,'R'),(145,21,2024,11,1,'X'),(146,21,2024,11,2,'X'),(147,21,2024,11,3,'X'),(148,21,2024,11,4,'X'),(149,21,2024,11,5,'X'),(150,21,2024,12,1,'X'),(151,21,2024,12,2,'X'),(152,22,2024,11,1,'X'),(153,22,2024,11,2,'X'),(154,22,2024,11,3,'X'),(155,22,2024,11,5,'X'),(156,22,2024,12,1,'X'),(157,22,2024,12,2,'X'),(158,23,2024,11,1,'X'),(159,23,2024,11,2,'X'),(160,23,2024,11,3,'X'),(161,23,2024,11,4,'X'),(162,23,2024,11,5,'X'),(163,23,2024,12,1,'X'),(164,23,2024,12,2,'X'),(165,24,2024,11,1,'X'),(166,24,2024,11,2,'X'),(167,24,2024,11,3,'X'),(168,24,2024,11,4,'X'),(169,24,2024,12,1,'X'),(170,24,2024,12,2,'X'),(171,25,2024,11,1,'X'),(172,25,2024,11,2,'X'),(173,25,2024,11,3,'X'),(174,25,2024,11,4,'X'),(175,25,2024,12,1,'X'),(176,25,2024,12,2,'X'),(177,26,2024,11,1,'X'),(178,26,2024,11,2,'X'),(179,26,2024,11,3,'X'),(180,26,2024,11,4,'X'),(181,26,2024,12,1,'X'),(182,26,2024,12,2,'X'),(183,27,2024,11,1,'X'),(184,27,2024,11,2,'X'),(185,27,2024,11,3,'X'),(186,27,2024,11,4,'X'),(187,27,2024,12,1,'X'),(188,27,2024,12,2,'X'),(189,28,2024,11,1,'X'),(190,28,2024,11,2,'X'),(191,28,2024,11,3,'X'),(192,28,2024,11,4,'X'),(193,28,2024,12,1,'X'),(194,28,2024,12,2,'X'),(195,29,2024,11,1,'X'),(196,29,2024,11,2,'X'),(197,29,2024,11,3,'X'),(198,29,2024,11,4,'X'),(199,29,2024,12,1,'P'),(200,29,2024,12,2,'X'),(201,30,2024,11,2,'X'),(202,30,2024,11,3,'X'),(203,30,2024,11,4,'X'),(204,30,2024,11,5,'X'),(205,30,2024,12,1,'X'),(206,30,2024,12,2,'X'),(207,31,2024,11,2,'X'),(208,31,2024,11,3,'X'),(209,31,2024,11,4,'X'),(210,32,2024,11,2,'X'),(211,32,2024,11,3,'X'),(212,32,2024,11,4,'X'),(213,32,2024,11,5,'X'),(214,33,2024,11,2,'X'),(215,33,2024,11,3,'X'),(216,33,2024,11,4,'X'),(217,33,2024,11,5,'X'),(218,34,2024,11,2,'X'),(219,34,2024,11,3,'X'),(220,34,2024,11,4,'X'),(221,34,2024,11,5,'X'),(222,35,2024,11,3,'X'),(223,35,2024,11,4,'X'),(224,35,2024,11,5,'X'),(225,36,2024,11,3,'X'),(226,36,2024,11,4,'X'),(227,36,2024,11,5,'X'),(228,37,2024,11,3,'X'),(229,37,2024,11,4,'X'),(230,37,2024,11,5,'X'),(231,38,2024,11,3,'X'),(232,38,2024,11,4,'X'),(233,39,2024,11,3,'P'),(234,39,2024,11,4,'X'),(235,39,2024,11,5,'X'),(236,40,2024,11,3,'P'),(237,40,2024,11,4,'X'),(238,40,2024,11,5,'X'),(239,41,2024,11,3,'P'),(240,41,2024,11,4,'X'),(241,41,2024,11,5,'X'),(242,42,2024,11,3,'P'),(243,42,2024,11,4,'X'),(244,42,2024,11,5,'X'),(245,43,2024,11,4,'X'),(246,43,2024,12,1,'X'),(247,43,2024,12,2,'X'),(248,44,2024,11,4,'X'),(249,44,2024,12,1,'X'),(250,44,2024,12,2,'X'),(251,45,2024,12,1,'X'),(252,45,2024,12,2,'X'),(253,46,2024,11,4,'X'),(254,46,2024,12,1,'X'),(255,46,2024,12,2,'X'),(256,48,2024,11,4,'X'),(257,48,2024,12,1,'X'),(258,48,2024,12,2,'X'),(259,49,2024,11,4,'X'),(260,49,2024,12,1,'X'),(261,49,2024,12,2,'X'),(262,50,2024,11,4,'X'),(263,50,2024,12,1,'X'),(264,50,2024,12,2,'X'),(265,51,2024,11,4,'X'),(266,51,2024,12,1,'X'),(267,51,2024,12,2,'X'),(268,52,2024,11,4,'X'),(269,52,2024,12,1,'X'),(270,52,2024,12,2,'X'),(271,53,2024,11,4,'X'),(272,53,2024,12,1,'X'),(273,54,2024,11,4,'R'),(274,54,2024,12,1,'X'),(275,54,2024,12,2,'X'),(276,55,2024,11,5,'R'),(277,55,2024,12,1,'R'),(297,1,2025,2,1,'X'),(298,1,2025,2,2,'X'),(299,1,2025,3,1,'X'),(300,1,2025,3,2,'X'),(301,1,2025,3,3,'X'),(302,1,2025,4,1,'X'),(303,1,2025,4,2,'X'),(304,1,2025,5,1,'X'),(305,1,2025,5,2,'X'),(306,1,2025,6,1,'X'),(307,1,2025,6,2,'X'),(308,1,2025,7,1,'X'),(309,1,2025,7,2,'X'),(310,1,2025,8,1,'X'),(311,1,2025,8,2,'X'),(312,1,2025,8,3,'X'),(313,1,2025,9,3,'X'),(314,1,2025,10,1,'X'),(315,1,2025,10,2,'X'),(316,1,2025,11,2,'X'),(317,2,2025,2,1,'X'),(318,2,2025,2,2,'X'),(319,2,2025,3,1,'X'),(320,2,2025,3,2,'X'),(321,2,2025,3,3,'X'),(322,2,2025,4,1,'X'),(323,2,2025,4,2,'X'),(324,2,2025,5,1,'X'),(325,2,2025,5,2,'X'),(326,2,2025,6,1,'X'),(327,2,2025,6,2,'X'),(328,2,2025,7,1,'X'),(329,2,2025,7,2,'X'),(330,2,2025,8,1,'X'),(331,2,2025,8,2,'X'),(332,2,2025,8,3,'X'),(333,2,2025,10,1,'X'),(334,2,2025,10,2,'X'),(335,2,2025,11,2,'X'),(336,3,2025,2,1,'X'),(337,3,2025,2,2,'X'),(338,3,2025,3,1,'X'),(339,3,2025,3,2,'X'),(340,3,2025,3,3,'X'),(341,3,2025,4,1,'X'),(342,3,2025,4,2,'X'),(343,3,2025,5,2,'X'),(344,3,2025,6,1,'X'),(345,3,2025,7,1,'X'),(346,3,2025,7,2,'X'),(347,3,2025,8,1,'X'),(348,3,2025,8,2,'X'),(349,3,2025,8,3,'X'),(350,3,2025,10,1,'X'),(351,3,2025,10,2,'X'),(352,3,2025,11,2,'X'),(353,4,2025,2,1,'X'),(354,4,2025,2,2,'X'),(355,4,2025,3,1,'X'),(356,4,2025,3,2,'X'),(357,4,2025,3,3,'X'),(358,4,2025,4,1,'X'),(359,4,2025,4,2,'X'),(360,4,2025,5,1,'X'),(361,4,2025,5,2,'X'),(362,4,2025,6,1,'X'),(363,4,2025,6,2,'X'),(364,4,2025,7,1,'X'),(365,4,2025,7,2,'X'),(366,4,2025,8,1,'X'),(367,4,2025,8,2,'X'),(368,4,2025,8,3,'X'),(369,4,2025,9,3,'X'),(370,4,2025,10,1,'X'),(371,4,2025,10,2,'X'),(372,4,2025,11,2,'X'),(373,5,2025,2,1,'X'),(374,5,2025,2,2,'X'),(375,5,2025,3,1,'X'),(376,5,2025,3,2,'X'),(377,5,2025,3,3,'X'),(378,5,2025,4,1,'X'),(379,5,2025,4,2,'X'),(380,5,2025,5,1,'X'),(381,5,2025,5,2,'X'),(382,5,2025,6,1,'X'),(383,5,2025,7,1,'X'),(384,5,2025,7,2,'X'),(385,5,2025,8,1,'X'),(386,5,2025,8,2,'X'),(387,5,2025,8,3,'X'),(388,5,2025,9,3,'X'),(389,5,2025,10,1,'X'),(390,5,2025,10,2,'X'),(391,5,2025,11,2,'X'),(392,6,2025,2,1,'X'),(393,6,2025,2,2,'X'),(394,6,2025,3,1,'X'),(395,6,2025,3,2,'X'),(396,6,2025,3,3,'X'),(397,6,2025,4,1,'X'),(398,6,2025,4,2,'X'),(399,6,2025,5,1,'X'),(400,6,2025,5,2,'X'),(401,6,2025,6,1,'X'),(402,6,2025,6,2,'X'),(403,6,2025,7,2,'X'),(404,6,2025,8,1,'X'),(405,6,2025,8,2,'X'),(406,6,2025,8,3,'X'),(407,6,2025,9,3,'X'),(408,6,2025,10,1,'X'),(409,6,2025,10,2,'X'),(410,6,2025,11,2,'X'),(411,7,2025,2,1,'X'),(412,7,2025,2,2,'X'),(413,7,2025,3,1,'X'),(414,7,2025,3,3,'X'),(415,7,2025,4,1,'X'),(416,7,2025,4,2,'X'),(417,7,2025,5,1,'X'),(418,7,2025,5,2,'X'),(419,7,2025,6,1,'X'),(420,7,2025,6,2,'X'),(421,7,2025,7,2,'X'),(422,7,2025,8,1,'X'),(423,7,2025,8,2,'X'),(424,7,2025,8,3,'X'),(425,7,2025,9,3,'X'),(426,7,2025,10,1,'X'),(427,7,2025,10,2,'X'),(428,7,2025,11,2,'X'),(429,8,2025,2,1,'X'),(430,8,2025,2,2,'X'),(431,8,2025,3,1,'X'),(432,8,2025,3,3,'X'),(433,8,2025,4,1,'X'),(434,8,2025,4,2,'X'),(435,8,2025,5,2,'X'),(436,8,2025,6,1,'X'),(437,8,2025,6,2,'X'),(438,8,2025,7,2,'X'),(439,8,2025,8,1,'X'),(440,8,2025,8,2,'X'),(441,8,2025,8,3,'X'),(442,8,2025,9,3,'X'),(443,8,2025,10,1,'R'),(444,8,2025,11,2,'X'),(445,9,2025,2,1,'X'),(446,9,2025,2,2,'X'),(447,9,2025,3,1,'X'),(448,9,2025,3,2,'X'),(449,9,2025,3,3,'X'),(450,9,2025,4,1,'X'),(451,9,2025,4,2,'X'),(452,9,2025,5,2,'X'),(453,9,2025,6,1,'X'),(454,9,2025,6,2,'X'),(455,9,2025,7,1,'X'),(456,9,2025,7,2,'X'),(457,9,2025,8,1,'X'),(458,9,2025,8,2,'X'),(459,9,2025,8,3,'X'),(460,9,2025,9,3,'X'),(461,9,2025,10,1,'X'),(462,9,2025,11,2,'X'),(463,10,2025,2,1,'X'),(464,10,2025,2,2,'X'),(465,10,2025,3,1,'X'),(466,10,2025,3,2,'X'),(467,10,2025,4,1,'X'),(468,10,2025,4,2,'X'),(469,10,2025,5,1,'X'),(470,10,2025,5,2,'X'),(471,10,2025,6,1,'X'),(472,10,2025,7,1,'X'),(473,10,2025,7,2,'X'),(474,10,2025,8,1,'X'),(475,10,2025,8,2,'X'),(476,10,2025,8,3,'X'),(477,10,2025,9,3,'R'),(478,10,2025,10,1,'X'),(479,10,2025,10,2,'X'),(480,10,2025,11,2,'X'),(481,11,2025,2,1,'X'),(482,11,2025,2,2,'X'),(483,11,2025,3,1,'X'),(484,11,2025,3,2,'X'),(485,11,2025,4,1,'E'),(486,11,2025,4,2,'X'),(487,11,2025,5,1,'X'),(488,11,2025,5,2,'X'),(489,11,2025,6,1,'X'),(490,11,2025,6,2,'X'),(491,11,2025,7,1,'X'),(492,11,2025,7,2,'X'),(493,11,2025,8,1,'X'),(494,11,2025,8,2,'X'),(495,11,2025,8,3,'X'),(496,11,2025,9,3,'X'),(497,11,2025,10,1,'X'),(498,11,2025,10,2,'X'),(499,11,2025,11,2,'X'),(500,12,2025,11,2,'X'),(501,13,2025,2,1,'X'),(502,13,2025,2,2,'X'),(503,13,2025,3,1,'X'),(504,13,2025,3,2,'X'),(505,13,2025,3,3,'X'),(506,13,2025,4,1,'X'),(507,13,2025,4,2,'X'),(508,13,2025,5,1,'X'),(509,13,2025,5,2,'X'),(510,13,2025,6,1,'X'),(511,13,2025,6,2,'X'),(512,13,2025,7,1,'X'),(513,13,2025,7,2,'X'),(514,13,2025,8,1,'X'),(515,13,2025,8,2,'X'),(516,13,2025,8,3,'X'),(517,13,2025,9,3,'X'),(518,13,2025,10,1,'X'),(519,13,2025,10,2,'X'),(520,13,2025,11,2,'X'),(521,14,2025,3,1,'X'),(522,14,2025,3,2,'X'),(523,14,2025,3,3,'X'),(524,14,2025,4,1,'X'),(525,14,2025,4,2,'X'),(526,14,2025,5,1,'X'),(527,14,2025,5,2,'X'),(528,14,2025,6,1,'X'),(529,14,2025,6,2,'X'),(530,14,2025,7,1,'X'),(531,14,2025,7,2,'X'),(532,14,2025,8,1,'X'),(533,14,2025,8,2,'X'),(534,14,2025,9,1,'X'),(535,14,2025,9,2,'X'),(536,14,2025,9,3,'X'),(537,14,2025,10,1,'X'),(538,14,2025,10,2,'X'),(539,14,2025,11,2,'X'),(540,15,2025,11,2,'X'),(541,16,2025,2,1,'X'),(542,16,2025,2,2,'X'),(543,16,2025,3,1,'X'),(544,16,2025,3,2,'X'),(545,16,2025,4,1,'X'),(546,16,2025,4,2,'X'),(547,16,2025,5,2,'X'),(548,16,2025,6,1,'R'),(549,16,2025,6,2,'X'),(550,16,2025,7,1,'X'),(551,16,2025,7,2,'X'),(552,16,2025,8,1,'X'),(553,16,2025,8,2,'X'),(554,16,2025,8,3,'X'),(555,16,2025,9,3,'X'),(556,16,2025,10,1,'X'),(557,16,2025,10,2,'X'),(558,16,2025,11,2,'X'),(559,17,2025,2,1,'X'),(560,17,2025,2,2,'X'),(561,17,2025,3,1,'X'),(562,17,2025,3,2,'X'),(563,17,2025,3,3,'X'),(564,17,2025,4,1,'X'),(565,17,2025,4,2,'X'),(566,17,2025,5,1,'X'),(567,17,2025,5,2,'X'),(568,17,2025,6,1,'X'),(569,17,2025,6,2,'X'),(570,17,2025,7,1,'X'),(571,17,2025,7,2,'X'),(572,17,2025,8,1,'X'),(573,17,2025,8,2,'X'),(574,17,2025,8,3,'X'),(575,17,2025,9,3,'X'),(576,17,2025,10,1,'X'),(577,17,2025,10,2,'X'),(578,17,2025,11,2,'X'),(579,18,2025,2,1,'E'),(580,18,2025,2,2,'X'),(581,18,2025,3,1,'X'),(582,18,2025,3,2,'X'),(583,18,2025,3,3,'X'),(584,18,2025,4,1,'X'),(585,18,2025,4,2,'X'),(586,18,2025,5,1,'X'),(587,18,2025,5,2,'X'),(588,18,2025,6,1,'X'),(589,18,2025,6,2,'X'),(590,18,2025,7,1,'X'),(591,18,2025,7,2,'X'),(592,18,2025,8,1,'X'),(593,18,2025,8,2,'X'),(594,18,2025,8,3,'X'),(595,18,2025,9,3,'X'),(596,18,2025,10,1,'X'),(597,18,2025,10,2,'X'),(598,18,2025,11,2,'X'),(599,19,2025,2,1,'X'),(600,19,2025,2,2,'X'),(601,19,2025,3,1,'X'),(602,19,2025,3,2,'X'),(603,19,2025,3,3,'X'),(604,19,2025,4,1,'X'),(605,19,2025,4,2,'X'),(606,19,2025,5,1,'X'),(607,19,2025,5,2,'X'),(608,19,2025,6,1,'X'),(609,19,2025,6,2,'X'),(610,19,2025,7,1,'X'),(611,19,2025,7,2,'X'),(612,19,2025,8,1,'X'),(613,19,2025,8,2,'X'),(614,19,2025,8,3,'X'),(615,19,2025,9,3,'X'),(616,19,2025,10,1,'X'),(617,19,2025,10,2,'X'),(618,19,2025,11,2,'X'),(619,20,2025,2,1,'X'),(620,20,2025,2,2,'X'),(621,20,2025,3,1,'X'),(622,20,2025,3,2,'X'),(623,20,2025,3,3,'X'),(624,20,2025,4,1,'X'),(625,20,2025,4,2,'X'),(626,20,2025,5,1,'X'),(627,20,2025,5,2,'X'),(628,20,2025,6,1,'X'),(629,20,2025,6,2,'X'),(630,20,2025,7,1,'X'),(631,20,2025,8,1,'X'),(632,20,2025,8,2,'X'),(633,20,2025,8,3,'X'),(634,20,2025,9,3,'X'),(635,20,2025,10,1,'X'),(636,20,2025,10,2,'X'),(637,20,2025,11,2,'X'),(638,21,2025,2,2,'X'),(639,21,2025,3,1,'R'),(640,21,2025,3,2,'X'),(641,21,2025,3,3,'X'),(642,21,2025,4,1,'X'),(643,21,2025,4,2,'X'),(644,21,2025,5,1,'X'),(645,21,2025,5,2,'X'),(646,21,2025,6,1,'X'),(647,21,2025,6,2,'X'),(648,21,2025,7,1,'X'),(649,21,2025,7,2,'X'),(650,21,2025,8,1,'X'),(651,21,2025,8,2,'X'),(652,21,2025,9,1,'X'),(653,21,2025,9,2,'X'),(654,21,2025,9,3,'X'),(655,21,2025,10,1,'X'),(656,21,2025,10,2,'X'),(657,21,2025,11,2,'X'),(658,22,2025,2,1,'X'),(659,22,2025,2,2,'X'),(660,22,2025,3,1,'X'),(661,22,2025,3,2,'X'),(662,22,2025,3,3,'X'),(663,22,2025,4,1,'X'),(664,22,2025,4,2,'X'),(665,22,2025,5,1,'X'),(666,22,2025,5,2,'X'),(667,22,2025,6,1,'X'),(668,22,2025,6,2,'X'),(669,22,2025,7,1,'X'),(670,22,2025,7,2,'X'),(671,22,2025,8,1,'X'),(672,22,2025,8,2,'X'),(673,22,2025,9,1,'X'),(674,22,2025,9,2,'X'),(675,22,2025,9,3,'X'),(676,22,2025,10,1,'X'),(677,22,2025,10,2,'X'),(678,22,2025,11,2,'X'),(679,23,2025,2,1,'X'),(680,23,2025,2,2,'X'),(681,23,2025,3,1,'X'),(682,23,2025,3,2,'X'),(683,23,2025,3,3,'X'),(684,23,2025,4,1,'X'),(685,23,2025,4,2,'X'),(686,23,2025,5,2,'X'),(687,23,2025,11,2,'X'),(688,24,2025,1,4,'X'),(689,24,2025,2,2,'X'),(690,24,2025,2,4,'X'),(691,24,2025,3,2,'X'),(692,24,2025,4,1,'X'),(693,24,2025,5,1,'X'),(694,24,2025,5,2,'X'),(695,24,2025,5,3,'X'),(696,24,2025,6,1,'X'),(697,24,2025,6,2,'X'),(698,24,2025,7,1,'X'),(699,24,2025,7,2,'X'),(700,24,2025,8,1,'X'),(701,24,2025,8,2,'X'),(702,24,2025,9,1,'X'),(703,24,2025,9,3,'X'),(704,24,2025,10,1,'X'),(705,24,2025,10,2,'X'),(706,24,2025,11,1,'X'),(707,25,2025,2,2,'X'),(708,25,2025,2,4,'X'),(709,25,2025,3,2,'X'),(710,25,2025,3,4,'X'),(711,25,2025,4,1,'X'),(712,25,2025,5,1,'X'),(713,25,2025,5,2,'X'),(714,25,2025,5,3,'X'),(715,25,2025,6,1,'R'),(716,25,2025,6,2,'X'),(717,25,2025,7,1,'R'),(718,25,2025,7,2,'X'),(719,25,2025,8,1,'X'),(720,25,2025,8,2,'X'),(721,25,2025,9,1,'R'),(722,25,2025,9,3,'R'),(723,25,2025,10,1,'R'),(724,26,2025,1,4,'X'),(725,26,2025,2,2,'X'),(726,26,2025,2,4,'X'),(727,26,2025,3,2,'X'),(728,26,2025,3,4,'X'),(729,26,2025,4,1,'X'),(730,26,2025,5,1,'X'),(731,26,2025,5,2,'X'),(732,26,2025,5,3,'X'),(733,26,2025,6,1,'X'),(734,26,2025,6,2,'X'),(735,26,2025,7,1,'X'),(736,26,2025,7,2,'X'),(737,26,2025,8,1,'X'),(738,26,2025,8,2,'X'),(739,26,2025,9,1,'X'),(740,26,2025,9,3,'X'),(741,26,2025,10,1,'X'),(742,26,2025,10,2,'X'),(743,26,2025,11,1,'X'),(744,27,2025,1,4,'X'),(745,27,2025,2,2,'X'),(746,27,2025,2,4,'X'),(747,27,2025,3,2,'X'),(748,27,2025,3,4,'X'),(749,27,2025,4,1,'X'),(750,27,2025,5,1,'X'),(751,27,2025,5,2,'X'),(752,27,2025,5,3,'X'),(753,27,2025,6,1,'X'),(754,27,2025,6,2,'X'),(755,27,2025,7,1,'X'),(756,27,2025,7,2,'X'),(757,27,2025,8,1,'X'),(758,27,2025,8,2,'X'),(759,27,2025,9,1,'X'),(760,27,2025,9,3,'X'),(761,27,2025,10,1,'X'),(762,27,2025,10,2,'X'),(763,27,2025,11,1,'X'),(764,28,2025,1,4,'X'),(765,28,2025,2,2,'X'),(766,28,2025,2,4,'X'),(767,28,2025,3,2,'X'),(768,28,2025,3,4,'X'),(769,28,2025,4,1,'X'),(770,28,2025,5,1,'X'),(771,28,2025,5,2,'X'),(772,28,2025,5,3,'X'),(773,28,2025,6,1,'X'),(774,28,2025,6,2,'X'),(775,28,2025,7,1,'X'),(776,28,2025,7,2,'X'),(777,28,2025,8,1,'X'),(778,28,2025,8,2,'X'),(779,28,2025,9,1,'X'),(780,28,2025,9,3,'X'),(781,28,2025,10,1,'X'),(782,28,2025,10,2,'X'),(783,28,2025,11,1,'X'),(784,29,2025,1,4,'X'),(785,29,2025,2,2,'X'),(786,29,2025,2,4,'X'),(787,29,2025,3,2,'X'),(788,29,2025,3,4,'X'),(789,29,2025,4,1,'X'),(790,29,2025,5,1,'X'),(791,29,2025,5,2,'X'),(792,29,2025,5,3,'X'),(793,29,2025,6,1,'X'),(794,29,2025,6,2,'X'),(795,29,2025,7,1,'X'),(796,29,2025,7,2,'X'),(797,29,2025,8,1,'X'),(798,29,2025,8,2,'X'),(799,29,2025,9,1,'X'),(800,29,2025,9,3,'X'),(801,29,2025,10,1,'X'),(802,29,2025,10,2,'X'),(803,29,2025,11,1,'X'),(804,30,2025,2,1,'X'),(805,30,2025,2,2,'X'),(806,30,2025,3,1,'X'),(807,30,2025,3,2,'X'),(808,30,2025,3,3,'X'),(809,30,2025,4,1,'X'),(810,30,2025,4,2,'X'),(811,30,2025,5,1,'X'),(812,30,2025,5,2,'X'),(813,30,2025,6,1,'X'),(814,30,2025,6,2,'X'),(815,30,2025,7,1,'X'),(816,30,2025,7,2,'X'),(817,30,2025,8,1,'X'),(818,30,2025,8,2,'X'),(819,30,2025,8,3,'X'),(820,30,2025,9,3,'X'),(821,30,2025,10,1,'X'),(822,30,2025,10,2,'X'),(823,30,2025,11,2,'X'),(824,31,2025,2,1,'X'),(825,31,2025,2,2,'X'),(826,31,2025,3,1,'X'),(827,31,2025,3,2,'X'),(828,31,2025,3,3,'X'),(829,31,2025,4,2,'X'),(830,31,2025,5,1,'X'),(831,31,2025,5,2,'X'),(832,31,2025,6,2,'X'),(833,31,2025,7,1,'X'),(834,31,2025,7,2,'X'),(835,31,2025,8,1,'X'),(836,31,2025,9,2,'X'),(837,31,2025,9,3,'X'),(838,31,2025,10,1,'X'),(839,31,2025,10,2,'X'),(840,31,2025,11,2,'X'),(841,32,2025,3,1,'X'),(842,32,2025,3,2,'X'),(843,32,2025,3,3,'X'),(844,32,2025,4,2,'X'),(845,32,2025,5,2,'X'),(846,32,2025,6,1,'X'),(847,32,2025,6,2,'X'),(848,32,2025,7,1,'X'),(849,32,2025,7,2,'X'),(850,32,2025,8,1,'X'),(851,32,2025,8,2,'X'),(852,32,2025,9,1,'X'),(853,32,2025,9,2,'X'),(854,32,2025,9,3,'X'),(855,32,2025,10,2,'X'),(856,32,2025,11,2,'X'),(857,33,2025,3,1,'X'),(858,33,2025,3,2,'X'),(859,33,2025,3,3,'X'),(860,33,2025,4,1,'X'),(861,33,2025,4,2,'X'),(862,33,2025,5,1,'X'),(863,33,2025,5,2,'X'),(864,33,2025,6,1,'X'),(865,33,2025,6,2,'X'),(866,33,2025,7,1,'X'),(867,33,2025,7,2,'X'),(868,33,2025,8,1,'X'),(869,33,2025,8,2,'X'),(870,33,2025,9,1,'X'),(871,33,2025,9,2,'X'),(872,33,2025,9,3,'X'),(873,33,2025,10,2,'X'),(874,33,2025,11,2,'X'),(875,34,2025,2,1,'X'),(876,34,2025,2,2,'X'),(877,34,2025,3,1,'X'),(878,34,2025,3,2,'X'),(879,34,2025,3,3,'X'),(880,34,2025,4,1,'X'),(881,34,2025,4,2,'X'),(882,34,2025,5,2,'X'),(883,34,2025,6,1,'X'),(884,34,2025,6,2,'X'),(885,34,2025,7,1,'X'),(886,34,2025,7,2,'X'),(887,34,2025,8,1,'X'),(888,34,2025,8,2,'X'),(889,34,2025,9,1,'X'),(890,34,2025,9,2,'X'),(891,34,2025,11,2,'X'),(892,35,2025,1,4,'X'),(893,35,2025,2,2,'X'),(894,35,2025,2,4,'X'),(895,35,2025,3,2,'X'),(896,35,2025,3,4,'X'),(897,35,2025,5,1,'X'),(898,35,2025,5,2,'X'),(899,35,2025,5,3,'X'),(900,35,2025,6,1,'R'),(901,35,2025,6,2,'X'),(902,35,2025,7,1,'X'),(903,35,2025,7,2,'R'),(904,35,2025,8,1,'X'),(905,35,2025,8,2,'X'),(906,35,2025,9,1,'X'),(907,35,2025,9,3,'X'),(908,35,2025,10,1,'X'),(909,35,2025,10,2,'X'),(910,35,2025,11,1,'X'),(911,36,2025,1,4,'X'),(912,36,2025,2,2,'X'),(913,36,2025,2,4,'X'),(914,36,2025,3,2,'X'),(915,36,2025,3,4,'X'),(916,36,2025,4,1,'X'),(917,36,2025,5,1,'X'),(918,36,2025,5,2,'X'),(919,36,2025,5,3,'X'),(920,36,2025,6,1,'X'),(921,36,2025,6,2,'X'),(922,36,2025,7,1,'X'),(923,36,2025,7,2,'X'),(924,36,2025,8,1,'X'),(925,36,2025,8,2,'X'),(926,36,2025,9,1,'X'),(927,36,2025,9,3,'X'),(928,36,2025,10,1,'X'),(929,36,2025,10,2,'X'),(930,36,2025,11,1,'X'),(931,37,2025,1,4,'X'),(932,37,2025,2,2,'X'),(933,37,2025,2,4,'X'),(934,37,2025,3,2,'E'),(935,37,2025,3,4,'X'),(936,37,2025,4,1,'X'),(937,37,2025,5,1,'X'),(938,37,2025,5,2,'X'),(939,37,2025,5,3,'X'),(940,37,2025,6,1,'X'),(941,37,2025,6,2,'X'),(942,37,2025,7,1,'X'),(943,37,2025,7,2,'X'),(944,37,2025,8,1,'X'),(945,37,2025,8,2,'X'),(946,37,2025,9,1,'X'),(947,37,2025,9,3,'X'),(948,37,2025,10,1,'X'),(949,37,2025,10,2,'X'),(950,37,2025,11,1,'X'),(951,38,2025,1,4,'X'),(952,38,2025,2,2,'X'),(953,38,2025,2,4,'X'),(954,38,2025,3,2,'X'),(955,38,2025,3,4,'X'),(956,38,2025,4,1,'X'),(957,38,2025,5,1,'X'),(958,38,2025,5,2,'X'),(959,38,2025,5,3,'X'),(960,38,2025,6,1,'X'),(961,38,2025,7,1,'X'),(962,38,2025,7,2,'X'),(963,38,2025,8,1,'X'),(964,38,2025,8,2,'X'),(965,38,2025,9,1,'X'),(966,38,2025,9,3,'X'),(967,38,2025,10,1,'X'),(968,38,2025,10,2,'X'),(969,38,2025,11,1,'X'),(970,39,2025,1,4,'X'),(971,39,2025,2,2,'X'),(972,39,2025,2,4,'X'),(973,39,2025,3,2,'X'),(974,39,2025,3,4,'X'),(975,39,2025,4,1,'X'),(976,39,2025,5,1,'X'),(977,39,2025,5,2,'X'),(978,39,2025,5,3,'X'),(979,39,2025,6,1,'R'),(980,39,2025,6,2,'X'),(981,39,2025,7,1,'X'),(982,39,2025,7,2,'X'),(983,39,2025,8,1,'X'),(984,39,2025,8,2,'X'),(985,39,2025,9,1,'X'),(986,39,2025,9,2,'X'),(987,39,2025,10,1,'X'),(988,39,2025,10,2,'X'),(989,39,2025,11,1,'X'),(990,40,2025,1,4,'X'),(991,40,2025,2,2,'X'),(992,40,2025,2,4,'X'),(993,40,2025,3,2,'X'),(994,40,2025,3,4,'X'),(995,40,2025,4,1,'X'),(996,40,2025,5,1,'X'),(997,40,2025,5,2,'X'),(998,40,2025,5,3,'X'),(999,40,2025,6,1,'X'),(1000,40,2025,6,2,'X'),(1001,40,2025,7,1,'X'),(1002,40,2025,7,2,'X'),(1003,40,2025,8,1,'X'),(1004,40,2025,8,2,'X'),(1005,40,2025,9,1,'X'),(1006,40,2025,9,2,'X'),(1007,40,2025,10,1,'X'),(1008,40,2025,10,2,'X'),(1009,40,2025,11,1,'X'),(1010,41,2025,1,4,'X'),(1011,41,2025,2,2,'X'),(1012,41,2025,2,4,'X'),(1013,41,2025,3,4,'X'),(1014,41,2025,4,1,'X'),(1015,41,2025,5,1,'X'),(1016,41,2025,5,3,'X'),(1017,41,2025,6,1,'X'),(1018,41,2025,6,2,'X'),(1019,41,2025,7,1,'X'),(1020,41,2025,7,2,'X'),(1021,41,2025,8,1,'X'),(1022,41,2025,8,2,'X'),(1023,41,2025,9,1,'X'),(1024,41,2025,9,2,'X'),(1025,41,2025,10,1,'X'),(1026,41,2025,10,2,'X'),(1027,41,2025,11,1,'X'),(1028,42,2025,1,4,'X'),(1029,42,2025,2,2,'X'),(1030,42,2025,2,4,'X'),(1031,42,2025,3,2,'X'),(1032,42,2025,3,4,'X'),(1033,42,2025,4,1,'X'),(1034,42,2025,5,1,'X'),(1035,42,2025,5,2,'X'),(1036,42,2025,5,3,'X'),(1037,42,2025,6,1,'X'),(1038,42,2025,6,2,'X'),(1039,42,2025,7,1,'X'),(1040,42,2025,7,2,'X'),(1041,42,2025,8,2,'X'),(1042,42,2025,9,1,'X'),(1043,42,2025,9,2,'X'),(1044,42,2025,10,1,'X'),(1045,42,2025,10,2,'X'),(1046,42,2025,11,1,'X'),(1047,43,2025,1,4,'X'),(1048,43,2025,2,4,'X'),(1049,43,2025,3,2,'X'),(1050,43,2025,3,4,'X'),(1051,43,2025,4,1,'X'),(1052,43,2025,5,1,'X'),(1053,43,2025,5,3,'X'),(1054,43,2025,6,1,'X'),(1055,43,2025,6,2,'X'),(1056,43,2025,7,1,'X'),(1057,43,2025,7,2,'X'),(1058,43,2025,8,2,'X'),(1059,43,2025,9,1,'X'),(1060,43,2025,9,2,'X'),(1061,43,2025,10,1,'X'),(1062,43,2025,10,2,'X'),(1063,43,2025,11,1,'X'),(1064,44,2025,1,4,'X'),(1065,44,2025,2,2,'X'),(1066,44,2025,2,4,'X'),(1067,44,2025,3,2,'X'),(1068,44,2025,3,4,'X'),(1069,44,2025,4,1,'X'),(1070,44,2025,5,1,'X'),(1071,44,2025,5,2,'X'),(1072,44,2025,5,3,'X'),(1073,44,2025,6,1,'X'),(1074,44,2025,6,2,'X'),(1075,44,2025,7,1,'X'),(1076,44,2025,7,2,'X'),(1077,44,2025,8,2,'X'),(1078,44,2025,9,1,'R'),(1079,44,2025,9,2,'X'),(1080,44,2025,10,1,'X'),(1081,44,2025,10,2,'X'),(1082,44,2025,11,1,'X'),(1083,45,2025,1,4,'X'),(1084,45,2025,2,2,'X'),(1085,45,2025,2,4,'X'),(1086,45,2025,3,2,'X'),(1087,45,2025,3,4,'X'),(1088,45,2025,4,1,'X'),(1089,45,2025,5,1,'X'),(1090,45,2025,5,2,'X'),(1091,45,2025,5,3,'X'),(1092,45,2025,6,1,'X'),(1093,45,2025,6,2,'X'),(1094,45,2025,7,1,'X'),(1095,45,2025,7,2,'X'),(1096,45,2025,8,1,'X'),(1097,45,2025,8,2,'X'),(1098,45,2025,9,1,'X'),(1099,45,2025,9,2,'R'),(1100,45,2025,10,1,'X'),(1101,45,2025,10,2,'X'),(1102,45,2025,11,1,'X'),(1103,46,2025,1,4,'X'),(1104,46,2025,2,2,'X'),(1105,46,2025,2,4,'X'),(1106,46,2025,3,2,'X'),(1107,46,2025,4,1,'X'),(1108,46,2025,5,1,'X'),(1109,46,2025,5,2,'X'),(1110,46,2025,5,3,'X'),(1111,46,2025,6,1,'X'),(1112,46,2025,6,2,'X'),(1113,46,2025,7,1,'X'),(1114,46,2025,7,2,'X'),(1115,46,2025,8,1,'X'),(1116,46,2025,8,2,'X'),(1117,46,2025,9,1,'X'),(1118,46,2025,10,1,'X'),(1119,46,2025,10,2,'X'),(1120,46,2025,11,1,'X'),(1121,48,2025,1,4,'X'),(1122,48,2025,2,2,'X'),(1123,48,2025,2,4,'X'),(1124,48,2025,3,2,'X'),(1125,48,2025,3,4,'X'),(1126,48,2025,4,1,'X'),(1127,48,2025,5,1,'X'),(1128,48,2025,5,2,'X'),(1129,48,2025,5,3,'X'),(1130,48,2025,6,1,'X'),(1131,48,2025,6,2,'X'),(1132,48,2025,7,1,'X'),(1133,48,2025,7,2,'X'),(1134,48,2025,8,1,'X'),(1135,48,2025,8,2,'X'),(1136,48,2025,9,1,'X'),(1137,48,2025,9,2,'X'),(1138,48,2025,10,1,'X'),(1139,48,2025,10,2,'X'),(1140,48,2025,11,1,'X'),(1141,49,2025,1,4,'X'),(1142,49,2025,2,2,'X'),(1143,49,2025,2,4,'X'),(1144,49,2025,3,2,'X'),(1145,49,2025,3,4,'X'),(1146,49,2025,4,1,'X'),(1147,49,2025,5,1,'X'),(1148,49,2025,5,3,'X'),(1149,49,2025,6,1,'X'),(1150,49,2025,6,2,'X'),(1151,49,2025,7,1,'X'),(1152,49,2025,7,2,'X'),(1153,49,2025,8,1,'X'),(1154,49,2025,8,2,'X'),(1155,49,2025,9,1,'R'),(1156,49,2025,9,2,'X'),(1157,49,2025,10,1,'X'),(1158,49,2025,10,2,'X'),(1159,49,2025,11,1,'X'),(1160,50,2025,1,4,'X'),(1161,50,2025,2,2,'X'),(1162,50,2025,2,4,'X'),(1163,50,2025,3,2,'X'),(1164,50,2025,3,4,'X'),(1165,50,2025,4,1,'X'),(1166,50,2025,5,1,'X'),(1167,50,2025,5,2,'X'),(1168,50,2025,5,3,'X'),(1169,50,2025,6,1,'X'),(1170,50,2025,6,2,'X'),(1171,50,2025,7,1,'X'),(1172,50,2025,7,2,'X'),(1173,50,2025,8,1,'X'),(1174,50,2025,8,2,'X'),(1175,50,2025,9,1,'X'),(1176,50,2025,9,2,'X'),(1177,50,2025,10,1,'X'),(1178,50,2025,10,2,'X'),(1179,50,2025,11,1,'X'),(1180,51,2025,1,4,'X'),(1181,51,2025,2,2,'X'),(1182,51,2025,2,4,'X'),(1183,51,2025,3,2,'X'),(1184,51,2025,3,4,'X'),(1185,51,2025,4,1,'X'),(1186,51,2025,5,1,'X'),(1187,51,2025,5,2,'X'),(1188,51,2025,5,3,'X'),(1189,51,2025,6,1,'X'),(1190,51,2025,6,2,'X'),(1191,51,2025,7,1,'X'),(1192,51,2025,7,2,'X'),(1193,51,2025,8,1,'X'),(1194,51,2025,8,2,'X'),(1195,51,2025,9,1,'X'),(1196,51,2025,9,2,'X'),(1197,51,2025,10,1,'X'),(1198,51,2025,10,2,'X'),(1199,51,2025,11,1,'X'),(1200,52,2025,2,2,'X'),(1201,52,2025,3,1,'X'),(1202,52,2025,3,2,'X'),(1203,52,2025,3,3,'X'),(1204,52,2025,4,1,'X'),(1205,52,2025,4,2,'X'),(1206,52,2025,6,1,'X'),(1207,52,2025,6,2,'X'),(1208,52,2025,7,1,'X'),(1209,52,2025,7,2,'X'),(1210,52,2025,8,1,'X'),(1211,52,2025,9,2,'X'),(1212,52,2025,9,3,'X'),(1213,52,2025,10,1,'X'),(1214,52,2025,10,2,'X'),(1215,52,2025,11,2,'X'),(1216,53,2025,1,4,'X'),(1217,53,2025,2,2,'X'),(1218,53,2025,2,4,'X'),(1219,53,2025,3,2,'X'),(1220,53,2025,3,4,'X'),(1221,53,2025,5,3,'X'),(1222,53,2025,6,1,'X'),(1223,53,2025,6,2,'X'),(1224,53,2025,7,1,'X'),(1225,53,2025,7,2,'X'),(1226,53,2025,8,1,'X'),(1227,53,2025,8,2,'X'),(1228,53,2025,9,1,'X'),(1229,53,2025,9,2,'X'),(1230,53,2025,10,1,'X'),(1231,53,2025,10,2,'X'),(1232,53,2025,11,1,'X'),(1233,54,2025,1,4,'X'),(1234,54,2025,2,2,'X'),(1235,54,2025,2,4,'X'),(1236,54,2025,3,2,'E'),(1237,54,2025,3,4,'X'),(1238,54,2025,4,1,'X'),(1239,54,2025,5,1,'X'),(1240,54,2025,5,2,'X'),(1241,54,2025,5,3,'X'),(1242,54,2025,6,1,'X'),(1243,54,2025,6,2,'X'),(1244,54,2025,7,1,'X'),(1245,54,2025,7,2,'X'),(1246,54,2025,8,1,'X'),(1247,54,2025,8,2,'X'),(1248,54,2025,9,1,'X'),(1249,54,2025,9,2,'X'),(1250,54,2025,10,1,'X'),(1251,54,2025,10,2,'X'),(1252,54,2025,11,1,'X'),(1253,55,2025,1,4,'X'),(1254,55,2025,2,2,'X'),(1255,55,2025,2,4,'X'),(1256,55,2025,3,2,'X'),(1257,55,2025,3,4,'X'),(1258,55,2025,4,1,'X'),(1259,55,2025,5,1,'X'),(1260,55,2025,5,3,'X'),(1261,55,2025,6,1,'X'),(1262,55,2025,7,1,'X'),(1263,55,2025,7,2,'X'),(1264,55,2025,8,2,'X'),(1265,55,2025,9,1,'X'),(1266,55,2025,9,2,'R'),(1267,55,2025,10,1,'X'),(1268,55,2025,10,2,'X'),(1269,55,2025,11,1,'X'),(1270,56,2025,1,4,'X'),(1271,56,2025,2,2,'X'),(1272,56,2025,2,4,'X'),(1273,56,2025,3,2,'X'),(1274,56,2025,3,4,'X'),(1275,56,2025,4,1,'X'),(1276,56,2025,5,1,'X'),(1277,56,2025,5,3,'X'),(1278,56,2025,6,1,'X'),(1279,56,2025,6,2,'X'),(1280,56,2025,7,1,'X'),(1281,56,2025,7,2,'X'),(1282,56,2025,8,1,'X'),(1283,56,2025,8,2,'X'),(1284,56,2025,9,1,'X'),(1285,56,2025,9,3,'X'),(1286,56,2025,10,1,'X'),(1287,56,2025,10,2,'X'),(1288,56,2025,11,1,'X'),(1289,57,2025,2,1,'X'),(1290,57,2025,2,2,'X'),(1291,57,2025,3,1,'X'),(1292,57,2025,3,2,'X'),(1293,57,2025,3,3,'X'),(1294,57,2025,4,1,'X'),(1295,57,2025,4,2,'X'),(1296,57,2025,5,1,'X'),(1297,57,2025,5,2,'X'),(1298,57,2025,6,1,'X'),(1299,57,2025,6,2,'X'),(1300,57,2025,7,1,'X'),(1301,57,2025,7,2,'X'),(1302,57,2025,8,1,'X'),(1303,57,2025,8,2,'X'),(1304,57,2025,9,1,'X'),(1305,57,2025,9,2,'X'),(1306,57,2025,9,3,'X'),(1307,57,2025,10,1,'X'),(1308,57,2025,10,2,'X'),(1309,57,2025,11,2,'X'),(1310,58,2025,4,2,'X'),(1311,58,2025,5,1,'X'),(1312,58,2025,5,2,'X'),(1313,58,2025,6,1,'X'),(1314,58,2025,6,2,'X'),(1315,58,2025,7,1,'X'),(1316,58,2025,7,2,'X'),(1317,58,2025,8,1,'X'),(1318,58,2025,8,2,'X'),(1319,58,2025,9,1,'X'),(1320,58,2025,9,2,'X'),(1321,58,2025,9,3,'X'),(1322,58,2025,10,1,'X'),(1323,58,2025,10,2,'X'),(1324,58,2025,11,2,'X'),(1325,59,2025,4,2,'X'),(1326,59,2025,5,1,'X'),(1327,59,2025,5,2,'X'),(1328,59,2025,6,1,'X'),(1329,59,2025,6,2,'X'),(1330,59,2025,7,1,'X'),(1331,59,2025,7,2,'X'),(1332,59,2025,8,1,'X'),(1333,59,2025,8,2,'X'),(1334,59,2025,9,1,'X'),(1335,59,2025,9,2,'X'),(1336,59,2025,9,3,'X'),(1337,59,2025,10,1,'X'),(1338,59,2025,10,2,'X'),(1339,59,2025,11,2,'X'),(1355,1,2026,1,1,'X'),(1356,1,2026,1,2,'X'),(1357,1,2026,1,3,'X'),(1358,1,2026,1,4,'X'),(1359,1,2026,2,1,'X'),(1360,1,2026,2,2,'X'),(1361,1,2026,2,3,'X'),(1362,1,2026,2,4,'E'),(1363,1,2026,3,1,'X'),(1364,1,2026,3,2,'X'),(1365,1,2026,3,3,'X'),(1366,1,2026,3,4,'X'),(1367,1,2026,3,5,'X'),(1368,1,2026,4,1,'P'),(1369,1,2026,4,2,'X'),(1370,2,2026,1,1,'X'),(1371,2,2026,1,2,'X'),(1372,2,2026,1,3,'X'),(1373,2,2026,1,4,'X'),(1374,2,2026,2,1,'X'),(1375,2,2026,2,2,'X'),(1376,2,2026,2,3,'X'),(1377,2,2026,2,4,'X'),(1378,2,2026,3,1,'X'),(1379,2,2026,3,2,'X'),(1380,2,2026,3,3,'X'),(1381,2,2026,3,4,'X'),(1382,2,2026,3,5,'X'),(1383,2,2026,4,1,'P'),(1384,2,2026,4,2,'X'),(1385,3,2026,1,1,'X'),(1386,3,2026,1,2,'X'),(1387,3,2026,1,3,'X'),(1388,3,2026,1,4,'X'),(1389,3,2026,2,1,'X'),(1390,3,2026,2,2,'X'),(1391,3,2026,2,3,'E'),(1392,3,2026,2,4,'X'),(1393,3,2026,3,1,'X'),(1394,3,2026,3,2,'X'),(1395,3,2026,3,3,'X'),(1396,3,2026,3,4,'X'),(1397,3,2026,3,5,'X'),(1398,3,2026,4,1,'P'),(1399,3,2026,4,2,'X'),(1400,4,2026,1,1,'X'),(1401,4,2026,1,2,'X'),(1402,4,2026,1,3,'X'),(1403,4,2026,1,4,'X'),(1404,4,2026,2,1,'X'),(1405,4,2026,2,2,'X'),(1406,4,2026,2,3,'X'),(1407,4,2026,2,4,'X'),(1408,4,2026,3,1,'X'),(1409,4,2026,3,2,'X'),(1410,4,2026,3,3,'X'),(1411,4,2026,3,4,'X'),(1412,4,2026,3,5,'X'),(1413,4,2026,4,1,'P'),(1414,4,2026,4,2,'X'),(1415,5,2026,1,1,'X'),(1416,5,2026,1,2,'X'),(1417,5,2026,1,3,'X'),(1418,5,2026,1,4,'X'),(1419,5,2026,2,1,'X'),(1420,5,2026,2,2,'X'),(1421,5,2026,2,3,'X'),(1422,5,2026,2,4,'X'),(1423,5,2026,3,1,'X'),(1424,5,2026,3,2,'X'),(1425,5,2026,3,3,'X'),(1426,5,2026,3,4,'X'),(1427,5,2026,3,5,'X'),(1428,5,2026,4,1,'P'),(1429,5,2026,4,2,'X'),(1430,6,2026,1,2,'X'),(1431,6,2026,1,3,'X'),(1432,6,2026,1,4,'X'),(1433,6,2026,2,1,'X'),(1434,6,2026,2,2,'X'),(1435,6,2026,2,3,'X'),(1436,6,2026,2,4,'X'),(1437,6,2026,3,1,'X'),(1438,6,2026,3,2,'X'),(1439,6,2026,3,3,'X'),(1440,6,2026,3,4,'X'),(1441,6,2026,3,5,'X'),(1442,6,2026,4,1,'P'),(1443,6,2026,4,2,'X'),(1444,7,2026,1,1,'X'),(1445,7,2026,1,2,'X'),(1446,7,2026,1,3,'X'),(1447,7,2026,1,4,'X'),(1448,7,2026,2,1,'X'),(1449,7,2026,2,2,'X'),(1450,7,2026,2,3,'X'),(1451,7,2026,2,4,'X'),(1452,7,2026,3,1,'X'),(1453,7,2026,3,2,'X'),(1454,7,2026,3,3,'X'),(1455,7,2026,3,4,'X'),(1456,7,2026,3,5,'X'),(1457,7,2026,4,1,'P'),(1458,7,2026,4,2,'X'),(1459,8,2026,1,1,'X'),(1460,8,2026,1,2,'X'),(1461,8,2026,1,3,'X'),(1462,8,2026,1,4,'X'),(1463,8,2026,2,1,'X'),(1464,8,2026,2,2,'X'),(1465,8,2026,2,4,'X'),(1466,8,2026,3,1,'X'),(1467,8,2026,3,2,'X'),(1468,8,2026,3,3,'E'),(1469,8,2026,3,4,'X'),(1470,8,2026,4,1,'P'),(1471,8,2026,4,2,'X'),(1472,8,2026,4,4,'X'),(1473,9,2026,1,1,'X'),(1474,9,2026,1,2,'X'),(1475,9,2026,1,3,'X'),(1476,9,2026,1,4,'X'),(1477,9,2026,2,1,'X'),(1478,9,2026,2,2,'X'),(1479,9,2026,2,3,'X'),(1480,9,2026,2,4,'X'),(1481,9,2026,3,1,'X'),(1482,9,2026,3,2,'X'),(1483,9,2026,3,3,'X'),(1484,9,2026,3,4,'X'),(1485,9,2026,3,5,'X'),(1486,9,2026,4,1,'P'),(1487,10,2026,1,1,'P'),(1488,10,2026,1,2,'X'),(1489,10,2026,1,3,'X'),(1490,10,2026,1,4,'X'),(1491,10,2026,2,1,'X'),(1492,10,2026,2,2,'X'),(1493,10,2026,2,3,'X'),(1494,10,2026,2,4,'X'),(1495,10,2026,3,1,'X'),(1496,10,2026,3,2,'X'),(1497,10,2026,3,3,'X'),(1498,10,2026,3,4,'X'),(1499,10,2026,4,1,'P'),(1500,10,2026,4,2,'X'),(1501,10,2026,4,4,'X'),(1502,11,2026,1,1,'X'),(1503,11,2026,1,2,'X'),(1504,11,2026,1,3,'X'),(1505,11,2026,1,4,'X'),(1506,11,2026,2,1,'X'),(1507,11,2026,2,2,'X'),(1508,11,2026,2,3,'X'),(1509,11,2026,2,4,'X'),(1510,11,2026,3,1,'X'),(1511,11,2026,3,2,'X'),(1512,11,2026,3,3,'X'),(1513,11,2026,3,5,'X'),(1514,11,2026,4,1,'P'),(1515,11,2026,4,2,'X'),(1516,12,2026,1,2,'X'),(1517,12,2026,1,3,'X'),(1518,12,2026,1,4,'X'),(1519,12,2026,2,1,'X'),(1520,12,2026,2,2,'X'),(1521,12,2026,2,3,'X'),(1522,12,2026,2,4,'X'),(1523,12,2026,3,1,'X'),(1524,12,2026,3,2,'X'),(1525,12,2026,3,3,'X'),(1526,12,2026,3,4,'X'),(1527,12,2026,4,1,'P'),(1528,12,2026,4,2,'X'),(1529,12,2026,4,3,'X'),(1530,12,2026,4,4,'X'),(1531,12,2026,4,5,'X'),(1532,13,2026,1,1,'X'),(1533,13,2026,1,2,'X'),(1534,13,2026,1,3,'X'),(1535,13,2026,1,4,'X'),(1536,13,2026,2,1,'X'),(1537,13,2026,2,2,'X'),(1538,13,2026,2,3,'X'),(1539,13,2026,3,1,'X'),(1540,13,2026,3,2,'X'),(1541,13,2026,3,3,'X'),(1542,13,2026,3,4,'X'),(1543,13,2026,3,5,'P'),(1544,13,2026,4,1,'P'),(1545,13,2026,4,2,'X'),(1546,14,2026,1,1,'X'),(1547,14,2026,1,2,'X'),(1548,14,2026,1,3,'X'),(1549,14,2026,1,4,'X'),(1550,14,2026,2,1,'X'),(1551,14,2026,2,2,'X'),(1552,14,2026,2,3,'X'),(1553,14,2026,2,4,'X'),(1554,14,2026,3,1,'X'),(1555,14,2026,3,2,'X'),(1556,14,2026,3,3,'X'),(1557,14,2026,3,4,'X'),(1558,14,2026,3,5,'X'),(1559,14,2026,4,1,'P'),(1560,14,2026,4,2,'X'),(1561,15,2026,1,2,'X'),(1562,15,2026,1,3,'X'),(1563,15,2026,1,4,'X'),(1564,15,2026,2,1,'X'),(1565,15,2026,2,2,'X'),(1566,15,2026,2,3,'X'),(1567,15,2026,2,4,'X'),(1568,15,2026,3,1,'X'),(1569,15,2026,3,2,'X'),(1570,15,2026,3,3,'X'),(1571,15,2026,3,4,'X'),(1572,15,2026,4,1,'P'),(1573,15,2026,4,2,'E'),(1574,15,2026,4,3,'X'),(1575,15,2026,4,4,'X'),(1576,15,2026,4,5,'P'),(1577,16,2026,1,1,'X'),(1578,16,2026,1,2,'X'),(1579,16,2026,1,3,'X'),(1580,16,2026,1,4,'X'),(1581,16,2026,2,1,'X'),(1582,16,2026,2,2,'X'),(1583,16,2026,2,3,'X'),(1584,16,2026,2,4,'X'),(1585,16,2026,3,1,'X'),(1586,16,2026,3,2,'X'),(1587,16,2026,3,3,'X'),(1588,16,2026,3,4,'X'),(1589,16,2026,4,1,'P'),(1590,16,2026,4,2,'X'),(1591,16,2026,4,4,'X'),(1592,17,2026,1,1,'X'),(1593,17,2026,1,2,'X'),(1594,17,2026,1,3,'X'),(1595,17,2026,1,4,'X'),(1596,17,2026,2,1,'X'),(1597,17,2026,2,2,'X'),(1598,17,2026,2,3,'X'),(1599,17,2026,2,4,'X'),(1600,17,2026,3,1,'X'),(1601,17,2026,3,2,'X'),(1602,17,2026,3,3,'X'),(1603,17,2026,3,5,'X'),(1604,17,2026,4,1,'P'),(1605,17,2026,4,2,'X'),(1606,18,2026,1,1,'P'),(1607,18,2026,1,2,'X'),(1608,18,2026,1,3,'X'),(1609,18,2026,1,4,'X'),(1610,18,2026,2,1,'X'),(1611,18,2026,2,2,'X'),(1612,18,2026,2,3,'X'),(1613,18,2026,2,4,'R'),(1614,18,2026,3,1,'X'),(1615,18,2026,3,2,'X'),(1616,18,2026,3,5,'X'),(1617,18,2026,4,1,'P'),(1618,18,2026,4,2,'X'),(1619,19,2026,1,1,'X'),(1620,19,2026,1,2,'X'),(1621,19,2026,1,3,'X'),(1622,19,2026,1,4,'X'),(1623,19,2026,2,1,'X'),(1624,19,2026,2,2,'X'),(1625,19,2026,2,3,'X'),(1626,19,2026,2,4,'X'),(1627,19,2026,3,1,'X'),(1628,19,2026,3,2,'X'),(1629,19,2026,3,3,'X'),(1630,19,2026,3,4,'X'),(1631,19,2026,3,5,'X'),(1632,19,2026,4,1,'P'),(1633,19,2026,4,2,'X'),(1634,20,2026,1,1,'X'),(1635,20,2026,1,2,'P'),(1636,20,2026,1,3,'X'),(1637,20,2026,1,4,'X'),(1638,20,2026,2,1,'X'),(1639,20,2026,2,2,'X'),(1640,20,2026,2,4,'X'),(1641,20,2026,3,1,'X'),(1642,20,2026,3,3,'E'),(1643,20,2026,3,4,'X'),(1644,20,2026,3,5,'X'),(1645,20,2026,4,1,'P'),(1646,20,2026,4,2,'X'),(1647,21,2026,1,1,'E'),(1648,21,2026,1,2,'X'),(1649,21,2026,1,3,'X'),(1650,21,2026,1,4,'X'),(1651,21,2026,2,1,'X'),(1652,21,2026,2,2,'X'),(1653,21,2026,2,3,'X'),(1654,21,2026,2,4,'X'),(1655,21,2026,3,1,'X'),(1656,21,2026,3,2,'X'),(1657,21,2026,3,3,'X'),(1658,21,2026,3,4,'X'),(1659,21,2026,3,5,'X'),(1660,21,2026,4,1,'P'),(1661,21,2026,4,2,'X'),(1662,22,2026,1,1,'X'),(1663,22,2026,1,2,'X'),(1664,22,2026,1,3,'X'),(1665,22,2026,1,4,'X'),(1666,22,2026,2,1,'X'),(1667,22,2026,2,2,'X'),(1668,22,2026,2,3,'X'),(1669,22,2026,2,4,'X'),(1670,22,2026,3,1,'X'),(1671,22,2026,3,2,'X'),(1672,22,2026,3,3,'X'),(1673,22,2026,3,4,'X'),(1674,22,2026,4,1,'P'),(1675,22,2026,4,2,'X'),(1676,22,2026,4,4,'X'),(1677,23,2026,1,1,'X'),(1678,23,2026,1,2,'X'),(1679,23,2026,1,3,'X'),(1680,23,2026,1,4,'X'),(1681,23,2026,2,1,'X'),(1682,23,2026,2,2,'X'),(1683,23,2026,2,3,'X'),(1684,23,2026,2,4,'X'),(1685,23,2026,3,1,'X'),(1686,23,2026,3,2,'X'),(1687,23,2026,3,3,'X'),(1688,23,2026,4,1,'P'),(1689,24,2026,1,1,'R'),(1690,24,2026,1,2,'X'),(1691,24,2026,1,3,'X'),(1692,24,2026,1,4,'R'),(1693,24,2026,2,1,'X'),(1694,24,2026,2,2,'X'),(1695,24,2026,2,4,'X'),(1696,24,2026,3,1,'X'),(1697,24,2026,3,2,'X'),(1698,24,2026,3,3,'X'),(1699,24,2026,3,4,'X'),(1700,24,2026,4,1,'P'),(1701,24,2026,4,4,'X'),(1702,25,2026,1,1,'R'),(1703,25,2026,1,2,'X'),(1704,25,2026,1,3,'R'),(1705,25,2026,2,1,'X'),(1706,25,2026,2,2,'X'),(1707,25,2026,2,4,'X'),(1708,25,2026,3,1,'X'),(1709,25,2026,3,4,'X'),(1710,25,2026,4,1,'P'),(1711,25,2026,4,2,'X'),(1712,26,2026,1,1,'X'),(1713,26,2026,1,2,'X'),(1714,26,2026,1,3,'X'),(1715,26,2026,1,4,'X'),(1716,26,2026,2,1,'X'),(1717,26,2026,2,2,'X'),(1718,26,2026,2,3,'X'),(1719,26,2026,2,4,'X'),(1720,26,2026,3,1,'X'),(1721,26,2026,3,2,'X'),(1722,26,2026,3,3,'X'),(1723,26,2026,3,4,'X'),(1724,26,2026,4,1,'P'),(1725,26,2026,4,2,'X'),(1726,26,2026,4,4,'X'),(1727,27,2026,1,2,'X'),(1728,27,2026,1,3,'X'),(1729,27,2026,1,4,'X'),(1730,27,2026,2,1,'X'),(1731,27,2026,2,2,'X'),(1732,27,2026,2,3,'X'),(1733,27,2026,2,4,'X'),(1734,27,2026,3,1,'X'),(1735,27,2026,4,1,'P'),(1736,27,2026,4,2,'X'),(1737,28,2026,1,1,'X'),(1738,28,2026,1,2,'X'),(1739,28,2026,1,3,'X'),(1740,28,2026,1,4,'X'),(1741,28,2026,2,1,'X'),(1742,28,2026,2,2,'X'),(1743,28,2026,2,3,'X'),(1744,28,2026,2,4,'X'),(1745,28,2026,3,1,'X'),(1746,28,2026,3,2,'X'),(1747,28,2026,3,3,'X'),(1748,28,2026,3,4,'X'),(1749,28,2026,4,1,'P'),(1750,28,2026,4,4,'X'),(1751,29,2026,1,1,'X'),(1752,29,2026,1,2,'X'),(1753,29,2026,1,3,'X'),(1754,29,2026,1,4,'X'),(1755,29,2026,2,1,'X'),(1756,29,2026,2,2,'X'),(1757,29,2026,2,3,'X'),(1758,29,2026,2,4,'X'),(1759,29,2026,3,1,'X'),(1760,29,2026,3,2,'X'),(1761,29,2026,3,4,'X'),(1762,29,2026,4,1,'P'),(1763,29,2026,4,2,'X'),(1764,29,2026,4,4,'X'),(1765,30,2026,1,1,'X'),(1766,30,2026,1,2,'X'),(1767,30,2026,1,3,'X'),(1768,30,2026,1,4,'X'),(1769,30,2026,2,1,'X'),(1770,30,2026,2,2,'X'),(1771,30,2026,3,1,'X'),(1772,30,2026,3,2,'X'),(1773,30,2026,3,3,'X'),(1774,30,2026,3,4,'X'),(1775,30,2026,3,5,'X'),(1776,30,2026,4,1,'P'),(1777,30,2026,4,2,'X'),(1778,31,2026,1,1,'X'),(1779,31,2026,1,2,'X'),(1780,31,2026,1,3,'X'),(1781,31,2026,1,4,'R'),(1782,31,2026,2,1,'X'),(1783,31,2026,2,2,'X'),(1784,31,2026,2,3,'X'),(1785,31,2026,2,4,'X'),(1786,31,2026,3,1,'X'),(1787,31,2026,3,2,'X'),(1788,31,2026,3,3,'P'),(1789,31,2026,3,4,'X'),(1790,31,2026,3,5,'X'),(1791,31,2026,4,1,'P'),(1792,31,2026,4,2,'X'),(1793,32,2026,1,1,'X'),(1794,32,2026,1,2,'X'),(1795,32,2026,1,3,'X'),(1796,32,2026,1,4,'X'),(1797,32,2026,2,1,'X'),(1798,32,2026,2,2,'X'),(1799,32,2026,2,3,'X'),(1800,32,2026,2,4,'P'),(1801,32,2026,3,1,'X'),(1802,32,2026,3,2,'X'),(1803,32,2026,3,4,'X'),(1804,32,2026,3,5,'X'),(1805,32,2026,4,1,'P'),(1806,32,2026,4,2,'X'),(1807,33,2026,1,1,'X'),(1808,33,2026,1,2,'X'),(1809,33,2026,1,3,'X'),(1810,33,2026,1,4,'X'),(1811,33,2026,2,1,'X'),(1812,33,2026,2,2,'X'),(1813,33,2026,2,3,'X'),(1814,33,2026,2,4,'P'),(1815,33,2026,3,1,'X'),(1816,33,2026,3,2,'X'),(1817,33,2026,3,3,'X'),(1818,33,2026,3,4,'X'),(1819,33,2026,3,5,'X'),(1820,33,2026,4,1,'P'),(1821,33,2026,4,2,'X'),(1822,34,2026,1,1,'P'),(1823,34,2026,1,2,'X'),(1824,34,2026,1,3,'X'),(1825,34,2026,1,4,'R'),(1826,34,2026,2,1,'X'),(1827,34,2026,2,2,'X'),(1828,34,2026,2,3,'X'),(1829,34,2026,2,4,'X'),(1830,34,2026,3,1,'X'),(1831,34,2026,3,3,'X'),(1832,34,2026,3,4,'X'),(1833,34,2026,3,5,'X'),(1834,34,2026,4,1,'P'),(1835,35,2026,1,1,'X'),(1836,35,2026,1,2,'X'),(1837,35,2026,1,3,'X'),(1838,35,2026,1,4,'X'),(1839,35,2026,2,1,'X'),(1840,35,2026,2,2,'X'),(1841,35,2026,2,3,'X'),(1842,35,2026,2,4,'X'),(1843,35,2026,3,1,'X'),(1844,35,2026,3,2,'X'),(1845,35,2026,3,3,'X'),(1846,35,2026,3,4,'X'),(1847,35,2026,3,5,'X'),(1848,35,2026,4,1,'P'),(1849,35,2026,4,2,'X'),(1850,36,2026,1,1,'X'),(1851,36,2026,1,2,'X'),(1852,36,2026,1,3,'X'),(1853,36,2026,1,4,'X'),(1854,36,2026,2,1,'X'),(1855,36,2026,2,2,'X'),(1856,36,2026,2,3,'X'),(1857,36,2026,2,4,'P'),(1858,36,2026,3,1,'X'),(1859,36,2026,3,2,'X'),(1860,36,2026,3,3,'X'),(1861,36,2026,3,4,'X'),(1862,36,2026,3,5,'X'),(1863,36,2026,4,1,'P'),(1864,36,2026,4,2,'X'),(1865,37,2026,1,1,'P'),(1866,37,2026,1,2,'X'),(1867,37,2026,1,3,'X'),(1868,37,2026,1,4,'X'),(1869,37,2026,2,1,'X'),(1870,37,2026,2,2,'X'),(1871,37,2026,2,3,'X'),(1872,37,2026,2,4,'X'),(1873,37,2026,3,1,'X'),(1874,37,2026,3,2,'X'),(1875,37,2026,3,3,'X'),(1876,37,2026,3,4,'X'),(1877,37,2026,3,5,'X'),(1878,37,2026,4,1,'P'),(1879,37,2026,4,2,'X'),(1880,38,2026,1,1,'X'),(1881,38,2026,1,2,'E'),(1882,38,2026,1,3,'X'),(1883,38,2026,1,4,'X'),(1884,38,2026,2,1,'X'),(1885,38,2026,2,2,'X'),(1886,38,2026,2,3,'x'),(1887,38,2026,2,4,'X'),(1888,38,2026,3,1,'X'),(1889,38,2026,3,2,'X'),(1890,38,2026,3,3,'X'),(1891,38,2026,3,4,'X'),(1892,38,2026,3,5,'X'),(1893,38,2026,4,1,'P'),(1894,38,2026,4,2,'X'),(1895,39,2026,1,1,'X'),(1896,39,2026,1,2,'X'),(1897,39,2026,1,3,'X'),(1898,39,2026,1,4,'X'),(1899,39,2026,2,1,'X'),(1900,39,2026,2,2,'X'),(1901,39,2026,2,3,'X'),(1902,39,2026,2,4,'X'),(1903,39,2026,3,1,'X'),(1904,39,2026,3,2,'X'),(1905,39,2026,3,3,'X'),(1906,39,2026,3,4,'P'),(1907,39,2026,4,1,'P'),(1908,39,2026,4,2,'X'),(1909,39,2026,4,4,'P'),(1910,40,2026,1,1,'X'),(1911,40,2026,1,2,'X'),(1912,40,2026,1,3,'X'),(1913,40,2026,1,4,'X'),(1914,40,2026,2,1,'X'),(1915,40,2026,2,2,'X'),(1916,40,2026,2,3,'X'),(1917,40,2026,2,4,'X'),(1918,40,2026,3,1,'X'),(1919,40,2026,3,2,'X'),(1920,40,2026,3,3,'E'),(1921,40,2026,3,4,'P'),(1922,40,2026,4,1,'P'),(1923,40,2026,4,2,'X'),(1924,40,2026,4,4,'X'),(1925,41,2026,1,1,'R'),(1926,41,2026,1,2,'R'),(1927,41,2026,1,3,'R'),(1928,41,2026,1,4,'X'),(1929,41,2026,2,1,'X'),(1930,41,2026,2,2,'P'),(1931,41,2026,2,3,'X'),(1932,41,2026,2,4,'X'),(1933,41,2026,3,1,'X'),(1934,41,2026,3,2,'X'),(1935,41,2026,3,3,'X'),(1936,41,2026,3,4,'P'),(1937,41,2026,4,1,'P'),(1938,41,2026,4,2,'X'),(1939,42,2026,1,1,'X'),(1940,42,2026,1,2,'X'),(1941,42,2026,1,3,'X'),(1942,42,2026,1,4,'X'),(1943,42,2026,2,1,'X'),(1944,42,2026,2,2,'X'),(1945,42,2026,2,3,'X'),(1946,42,2026,2,4,'X'),(1947,42,2026,3,1,'X'),(1948,42,2026,3,2,'X'),(1949,42,2026,3,3,'X'),(1950,42,2026,3,4,'P'),(1951,42,2026,4,1,'P'),(1952,42,2026,4,2,'X'),(1953,42,2026,4,4,'X'),(1954,43,2026,1,1,'X'),(1955,43,2026,1,2,'X'),(1956,43,2026,1,3,'X'),(1957,43,2026,1,4,'X'),(1958,43,2026,2,1,'X'),(1959,43,2026,2,2,'X'),(1960,43,2026,2,3,'X'),(1961,43,2026,2,4,'X'),(1962,43,2026,3,1,'X'),(1963,43,2026,3,2,'X'),(1964,43,2026,3,4,'P'),(1965,43,2026,4,1,'P'),(1966,44,2026,1,1,'X'),(1967,44,2026,1,2,'X'),(1968,44,2026,1,3,'X'),(1969,44,2026,1,4,'X'),(1970,44,2026,2,1,'X'),(1971,44,2026,2,2,'X'),(1972,44,2026,2,4,'X'),(1973,44,2026,3,1,'X'),(1974,44,2026,3,2,'X'),(1975,44,2026,3,3,'X'),(1976,44,2026,3,4,'P'),(1977,44,2026,4,1,'P'),(1978,44,2026,4,2,'X'),(1979,44,2026,4,4,'X'),(1980,45,2026,1,1,'X'),(1981,45,2026,1,2,'X'),(1982,45,2026,1,3,'X'),(1983,45,2026,1,4,'X'),(1984,45,2026,2,1,'X'),(1985,45,2026,2,2,'X'),(1986,45,2026,2,3,'X'),(1987,45,2026,2,4,'X'),(1988,45,2026,3,1,'X'),(1989,45,2026,3,2,'E'),(1990,45,2026,3,3,'X'),(1991,45,2026,3,4,'P'),(1992,45,2026,4,1,'P'),(1993,45,2026,4,2,'X'),(1994,45,2026,4,4,'X'),(1995,46,2026,1,1,'X'),(1996,46,2026,1,2,'X'),(1997,46,2026,1,3,'X'),(1998,46,2026,1,4,'X'),(1999,46,2026,2,1,'X'),(2000,46,2026,2,2,'X'),(2001,46,2026,2,3,'X'),(2002,46,2026,2,4,'X'),(2003,46,2026,3,1,'X'),(2004,46,2026,3,2,'X'),(2005,46,2026,3,3,'X'),(2006,46,2026,3,4,'P'),(2007,46,2026,4,1,'P'),(2008,46,2026,4,2,'X'),(2009,46,2026,4,4,'X'),(2010,48,2026,1,1,'X'),(2011,48,2026,1,2,'X'),(2012,48,2026,1,3,'X'),(2013,48,2026,1,4,'X'),(2014,48,2026,2,1,'X'),(2015,48,2026,2,2,'X'),(2016,48,2026,2,4,'X'),(2017,48,2026,3,1,'X'),(2018,48,2026,3,2,'X'),(2019,48,2026,3,3,'E'),(2020,48,2026,3,4,'X'),(2021,48,2026,3,5,'X'),(2022,48,2026,4,1,'P'),(2023,48,2026,4,2,'X'),(2024,49,2026,1,1,'P'),(2025,49,2026,1,2,'X'),(2026,49,2026,1,3,'X'),(2027,49,2026,1,4,'R'),(2028,49,2026,2,1,'X'),(2029,49,2026,2,2,'X'),(2030,49,2026,2,3,'X'),(2031,49,2026,2,4,'X'),(2032,49,2026,3,1,'X'),(2033,49,2026,3,2,'X'),(2034,49,2026,3,3,'X'),(2035,49,2026,3,4,'P'),(2036,49,2026,4,1,'P'),(2037,49,2026,4,2,'X'),(2038,49,2026,4,4,'X'),(2039,50,2026,1,1,'X'),(2040,50,2026,1,2,'X'),(2041,50,2026,1,3,'X'),(2042,50,2026,1,4,'X'),(2043,50,2026,2,1,'X'),(2044,50,2026,2,2,'X'),(2045,50,2026,2,3,'X'),(2046,50,2026,2,4,'X'),(2047,50,2026,3,1,'X'),(2048,50,2026,3,2,'X'),(2049,50,2026,3,3,'X'),(2050,50,2026,3,4,'P'),(2051,50,2026,4,1,'P'),(2052,50,2026,4,2,'X'),(2053,50,2026,4,4,'X'),(2054,51,2026,1,1,'X'),(2055,51,2026,1,2,'X'),(2056,51,2026,1,3,'X'),(2057,51,2026,1,4,'X'),(2058,51,2026,2,1,'X'),(2059,51,2026,2,2,'X'),(2060,51,2026,2,3,'X'),(2061,51,2026,2,4,'X'),(2062,51,2026,3,1,'X'),(2063,51,2026,3,2,'X'),(2064,51,2026,3,3,'X'),(2065,51,2026,3,4,'P'),(2066,51,2026,4,1,'P'),(2067,51,2026,4,2,'X'),(2068,51,2026,4,4,'X'),(2069,52,2026,1,2,'R'),(2070,52,2026,1,3,'X'),(2071,52,2026,1,4,'X'),(2072,52,2026,2,1,'X'),(2073,52,2026,2,2,'X'),(2074,52,2026,2,3,'X'),(2075,52,2026,2,4,'X'),(2076,52,2026,3,1,'X'),(2077,52,2026,3,2,'X'),(2078,52,2026,3,3,'X'),(2079,52,2026,3,4,'P'),(2080,52,2026,4,1,'P'),(2081,52,2026,4,4,'X'),(2082,53,2026,1,1,'E'),(2083,53,2026,1,2,'X'),(2084,53,2026,1,3,'X'),(2085,53,2026,1,4,'X'),(2086,53,2026,2,1,'X'),(2087,53,2026,2,2,'X'),(2088,53,2026,2,3,'X'),(2089,53,2026,2,4,'X'),(2090,53,2026,3,1,'X'),(2091,53,2026,3,2,'X'),(2092,53,2026,3,3,'X'),(2093,53,2026,3,4,'P'),(2094,53,2026,4,1,'P'),(2095,53,2026,4,4,'X'),(2096,54,2026,1,1,'X'),(2097,54,2026,1,2,'X'),(2098,54,2026,1,3,'X'),(2099,54,2026,1,4,'X'),(2100,54,2026,2,1,'X'),(2101,54,2026,2,2,'X'),(2102,54,2026,2,3,'X'),(2103,54,2026,2,4,'R'),(2104,54,2026,3,2,'X'),(2105,54,2026,3,3,'X'),(2106,54,2026,3,4,'P'),(2107,54,2026,4,1,'P'),(2108,54,2026,4,2,'X'),(2109,54,2026,4,4,'X'),(2110,55,2026,1,2,'R'),(2111,55,2026,1,4,'R'),(2112,55,2026,2,1,'X'),(2113,55,2026,2,2,'X'),(2114,55,2026,2,3,'X'),(2115,55,2026,2,4,'X'),(2116,55,2026,3,1,'X'),(2117,55,2026,3,2,'X'),(2118,55,2026,3,3,'X'),(2119,55,2026,3,4,'X'),(2120,55,2026,3,5,'X'),(2121,55,2026,4,1,'P'),(2122,55,2026,4,2,'X'),(2123,56,2026,1,1,'X'),(2124,56,2026,1,2,'X'),(2125,56,2026,1,3,'X'),(2126,56,2026,1,4,'X'),(2127,56,2026,2,1,'X'),(2128,56,2026,2,2,'X'),(2129,56,2026,2,3,'X'),(2130,56,2026,2,4,'X'),(2131,56,2026,3,1,'X'),(2132,56,2026,3,2,'X'),(2133,56,2026,3,3,'X'),(2134,56,2026,3,4,'X'),(2135,56,2026,4,1,'P'),(2136,56,2026,4,2,'X'),(2137,56,2026,4,4,'X'),(2138,57,2026,1,1,'X'),(2139,57,2026,1,2,'X'),(2140,57,2026,1,3,'X'),(2141,57,2026,1,4,'X'),(2142,57,2026,2,1,'X'),(2143,57,2026,2,2,'X'),(2144,57,2026,2,3,'X'),(2145,57,2026,2,4,'X'),(2146,57,2026,3,1,'X'),(2147,57,2026,3,2,'X'),(2148,57,2026,3,3,'X'),(2149,57,2026,3,4,'X'),(2150,57,2026,4,1,'P'),(2151,57,2026,4,2,'X'),(2152,57,2026,4,4,'X'),(2153,58,2026,1,1,'X'),(2154,58,2026,1,2,'X'),(2155,58,2026,1,3,'X'),(2156,58,2026,1,4,'X'),(2157,58,2026,2,1,'X'),(2158,58,2026,2,2,'X'),(2159,58,2026,2,3,'X'),(2160,58,2026,2,4,'X'),(2161,58,2026,3,1,'X'),(2162,58,2026,3,2,'X'),(2163,58,2026,3,3,'X'),(2164,58,2026,3,4,'X'),(2165,58,2026,4,1,'P'),(2166,58,2026,4,2,'X'),(2167,58,2026,4,4,'X'),(2168,59,2026,1,1,'X'),(2169,59,2026,1,2,'X'),(2170,59,2026,1,3,'X'),(2171,59,2026,1,4,'X'),(2172,59,2026,2,1,'X'),(2173,59,2026,2,2,'X'),(2174,59,2026,2,3,'X'),(2175,59,2026,2,4,'X'),(2176,59,2026,3,1,'X'),(2177,59,2026,3,2,'X'),(2178,59,2026,3,3,'X'),(2179,59,2026,3,4,'X'),(2180,59,2026,4,1,'P'),(2181,59,2026,4,2,'X'),(2182,59,2026,4,4,'X'),(2183,60,2026,1,2,'X'),(2184,60,2026,1,3,'X'),(2185,60,2026,1,4,'X'),(2186,60,2026,2,1,'X'),(2187,60,2026,2,2,'X'),(2188,60,2026,2,3,'X'),(2189,60,2026,2,4,'X'),(2190,60,2026,3,1,'X'),(2191,60,2026,3,2,'X'),(2192,60,2026,3,3,'X'),(2193,60,2026,3,4,'X'),(2194,60,2026,4,2,'P'),(2195,60,2026,4,3,'E'),(2196,60,2026,4,4,'X'),(2197,60,2026,4,5,'P'),(2198,61,2026,1,2,'X'),(2199,61,2026,1,3,'X'),(2200,61,2026,2,1,'X'),(2201,61,2026,2,2,'X'),(2202,61,2026,2,3,'X'),(2203,61,2026,2,4,'X'),(2204,61,2026,3,1,'X'),(2205,61,2026,3,2,'X'),(2206,61,2026,3,3,'E'),(2207,61,2026,3,4,'X'),(2208,61,2026,4,2,'P'),(2209,61,2026,4,3,'X'),(2210,61,2026,4,4,'X'),(2211,61,2026,4,5,'X'),(2212,62,2026,1,2,'X'),(2213,62,2026,1,3,'X'),(2214,62,2026,1,4,'X'),(2215,62,2026,2,1,'X'),(2216,62,2026,2,2,'E'),(2217,62,2026,2,3,'X'),(2218,62,2026,2,4,'X'),(2219,62,2026,3,1,'X'),(2220,62,2026,3,2,'P'),(2221,62,2026,3,3,'X'),(2222,62,2026,3,4,'X'),(2223,62,2026,4,2,'P'),(2224,62,2026,4,3,'X'),(2225,62,2026,4,4,'X'),(2226,63,2026,1,2,'X'),(2227,63,2026,1,3,'X'),(2228,63,2026,1,4,'X'),(2229,63,2026,2,1,'X'),(2230,63,2026,2,2,'X'),(2231,63,2026,2,3,'X'),(2232,63,2026,2,4,'X'),(2233,63,2026,3,1,'X'),(2234,63,2026,3,2,'X'),(2235,63,2026,3,3,'X'),(2236,63,2026,3,4,'X'),(2237,63,2026,4,2,'P'),(2238,63,2026,4,3,'X'),(2239,63,2026,4,4,'E'),(2240,63,2026,4,5,'P'),(2241,64,2026,1,2,'X'),(2242,64,2026,1,3,'X'),(2243,64,2026,1,4,'X'),(2244,64,2026,2,1,'X'),(2245,64,2026,2,2,'X'),(2246,64,2026,2,3,'X'),(2247,64,2026,2,4,'X'),(2248,64,2026,3,1,'X'),(2249,64,2026,3,2,'X'),(2250,64,2026,3,3,'X'),(2251,64,2026,3,4,'X'),(2252,64,2026,4,2,'P'),(2253,64,2026,4,3,'X'),(2254,64,2026,4,4,'X'),(2255,64,2026,4,5,'P'),(2256,65,2026,1,2,'X'),(2257,65,2026,1,3,'X'),(2258,65,2026,1,4,'X'),(2259,65,2026,2,1,'X'),(2260,65,2026,2,2,'X'),(2261,65,2026,2,3,'X'),(2262,65,2026,2,4,'X'),(2263,65,2026,3,1,'X'),(2264,65,2026,3,2,'X'),(2265,65,2026,3,3,'X'),(2266,65,2026,3,4,'X'),(2267,65,2026,4,2,'P'),(2268,65,2026,4,3,'X'),(2269,65,2026,4,4,'X'),(2270,65,2026,4,5,'P'),(2271,66,2026,1,2,'X'),(2272,66,2026,1,3,'X'),(2273,66,2026,1,4,'X'),(2274,66,2026,2,2,'X'),(2275,66,2026,2,3,'X'),(2276,66,2026,2,4,'X'),(2277,66,2026,3,1,'X'),(2278,66,2026,3,2,'X'),(2279,66,2026,3,3,'X'),(2280,66,2026,3,4,'X'),(2281,66,2026,4,2,'P'),(2282,66,2026,4,3,'X'),(2283,66,2026,4,4,'X'),(2284,66,2026,4,5,'P'),(2285,67,2026,1,2,'X'),(2286,67,2026,1,3,'X'),(2287,67,2026,1,4,'X'),(2288,67,2026,2,1,'X'),(2289,67,2026,2,2,'X'),(2290,67,2026,2,3,'X'),(2291,67,2026,2,4,'X'),(2292,67,2026,3,1,'X'),(2293,67,2026,3,2,'X'),(2294,67,2026,3,3,'X'),(2295,67,2026,3,4,'X'),(2296,67,2026,4,2,'P'),(2297,67,2026,4,3,'X'),(2298,67,2026,4,4,'X'),(2299,67,2026,4,5,'X'),(2300,68,2026,1,2,'X'),(2301,68,2026,1,3,'X'),(2302,68,2026,1,4,'X'),(2303,68,2026,2,1,'X'),(2304,68,2026,2,2,'X'),(2305,68,2026,2,3,'X'),(2306,68,2026,2,4,'X'),(2307,68,2026,3,1,'X'),(2308,68,2026,3,2,'X'),(2309,68,2026,3,3,'X'),(2310,68,2026,3,4,'X'),(2311,68,2026,4,2,'P'),(2312,68,2026,4,3,'X'),(2313,68,2026,4,4,'X'),(2314,68,2026,4,5,'X'),(2315,69,2026,1,2,'X'),(2316,69,2026,1,3,'X'),(2317,69,2026,1,4,'X'),(2318,69,2026,2,1,'X'),(2319,69,2026,2,2,'X'),(2320,69,2026,2,3,'X'),(2321,69,2026,2,4,'X'),(2322,69,2026,3,3,'X'),(2323,69,2026,3,4,'X'),(2324,69,2026,4,2,'P'),(2325,69,2026,4,3,'X'),(2326,69,2026,4,4,'X'),(2327,69,2026,4,5,'X'),(2328,70,2026,1,2,'X'),(2329,70,2026,1,3,'X'),(2330,70,2026,2,4,'X'),(2331,70,2026,3,1,'X'),(2332,70,2026,3,2,'X'),(2333,70,2026,3,3,'X'),(2334,70,2026,3,4,'X'),(2335,70,2026,4,2,'P'),(2336,70,2026,4,3,'X'),(2337,70,2026,4,4,'X'),(2338,70,2026,4,5,'X'),(2339,71,2026,1,2,'X'),(2340,71,2026,1,3,'X'),(2341,71,2026,2,4,'X'),(2342,71,2026,3,1,'X'),(2343,71,2026,3,2,'X'),(2344,71,2026,3,3,'X'),(2345,71,2026,3,4,'X'),(2346,71,2026,4,2,'P'),(2347,71,2026,4,3,'X'),(2348,71,2026,4,4,'X'),(2349,71,2026,4,5,'X'),(2350,72,2026,1,2,'X'),(2351,72,2026,1,3,'X'),(2352,72,2026,2,4,'X'),(2353,72,2026,3,1,'X'),(2354,72,2026,3,2,'X'),(2355,72,2026,3,3,'X'),(2356,72,2026,3,4,'X'),(2357,72,2026,4,2,'P'),(2358,72,2026,4,3,'X'),(2359,72,2026,4,4,'X'),(2360,72,2026,4,5,'X'),(2361,73,2026,3,3,'X'),(2362,73,2026,3,4,'X'),(2363,73,2026,4,2,'P'),(2364,74,2026,3,4,'X'),(2365,74,2026,4,2,'P'),(2366,47,2026,1,1,'X'),(2367,47,2026,1,2,'X'),(2368,47,2026,1,3,'X'),(2369,47,2026,1,4,'X'),(2370,47,2026,2,1,'X'),(2371,47,2026,2,2,'X'),(2372,47,2026,2,3,'X'),(2373,47,2026,2,4,'X'),(2374,47,2026,3,1,'X'),(2375,47,2026,3,2,'X'),(2376,47,2026,3,3,'X'),(2377,47,2026,3,4,'P'),(2378,47,2026,4,1,'P'),(2379,47,2026,4,2,'X'),(2380,47,2026,4,4,'X'),(2381,1,2026,5,1,'x'),(2382,2,2026,5,1,'x'),(2383,3,2026,5,1,'x'),(2384,4,2026,5,1,'e'),(2385,5,2026,5,1,'x'),(2386,6,2026,5,1,'x'),(2387,7,2026,5,1,'x'),(2388,14,2026,5,1,'x'),(2389,17,2026,5,1,'x'),(2390,19,2026,5,1,'x'),(2391,30,2026,5,1,'x'),(2392,55,2026,5,1,'x'),(2393,18,2026,5,1,'x'),(2394,20,2026,5,1,'x'),(2395,21,2026,5,1,'p'),(2396,31,2026,5,1,'x'),(2397,32,2026,5,1,'x'),(2398,33,2026,5,1,'x'),(2399,34,2026,5,1,'x'),(2400,35,2026,5,1,'x'),(2401,36,2026,5,1,'x'),(2402,37,2026,5,1,'x'),(2403,38,2026,5,1,'p'),(2404,48,2026,5,1,'x'),(2405,73,2026,5,1,'f'),(2406,74,2026,5,1,'f'),(2407,18,2026,3,3,'f'),(2408,18,2026,3,4,'f'),(2409,20,2026,3,2,'f'),(2410,32,2026,3,3,'f'),(2411,34,2026,3,2,'f'),(2412,34,2026,4,2,'f'),(2414,48,2026,2,3,'f'),(2415,20,2026,2,3,'f'),(2416,9,2026,5,1,'f'),(2417,11,2026,5,1,'f'),(2418,13,2026,5,1,'f');
/*!40000 ALTER TABLE `asistencia_semanal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `avisos`
--

DROP TABLE IF EXISTS `avisos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `avisos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `autor_id` int DEFAULT NULL,
  `autor_nombre` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `autor_rol` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `titulo` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mensaje` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `scope` enum('global','horario','laboratorio','diplomado','dia','alumno') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'global',
  `filtro_dia` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `filtro_horario` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `filtro_laboratorio` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `filtro_diplomado` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `filtro_alumno_id` int DEFAULT NULL,
  `expira_at` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_avisos_scope` (`scope`),
  KEY `idx_avisos_expira` (`expira_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `avisos`
--

LOCK TABLES `avisos` WRITE;
/*!40000 ALTER TABLE `avisos` DISABLE KEYS */;
/*!40000 ALTER TABLE `avisos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bitacora`
--

DROP TABLE IF EXISTS `bitacora`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bitacora` (
  `id` int NOT NULL AUTO_INCREMENT,
  `usuario_id` int DEFAULT NULL,
  `usuario_nombre` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Sistema',
  `accion` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `modulo` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci,
  `ip` varchar(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=143 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bitacora`
--

LOCK TABLES `bitacora` WRITE;
/*!40000 ALTER TABLE `bitacora` DISABLE KEYS */;
INSERT INTO `bitacora` VALUES (1,1,'Admin TestImport1','crear','Catálogos','Horario: domingo 07:00 a 12:00','::1','2026-05-03 14:45:33'),(2,1,'Admin TestImport1','crear','Catálogos','Horario: domingo 12:00 a 05:00','::1','2026-05-03 14:45:46'),(3,1,'Admin TestImport1','crear','Catálogos','Horario: sabado 07:00 a 12:00','::1','2026-05-03 14:46:28'),(4,1,'Admin TestImport1','crear','Catálogos','Horario: sabado 12:00 a 05:00','::1','2026-05-03 14:46:40'),(5,1,'Admin TestImport1','crear','Catálogos','Horario: viernes 07:00 a 12:00','::1','2026-05-03 14:48:26'),(6,1,'Admin TestImport1','crear','Catálogos','nombre: Lab 1','::1','2026-05-03 14:48:35'),(7,1,'Admin TestImport1','importar','Alumnos','Importación masiva: 74 creado(s), 0 con error de 74 fila(s)','::1','2026-05-03 15:28:19'),(8,1,'Admin TestImport1','editar','Catálogos','ID 1: 1','::1','2026-05-03 15:28:37'),(9,1,'Admin TestImport1','eliminar','Catálogos','Horario ID 1','::1','2026-05-03 15:31:06'),(10,1,'Admin TestImport1','eliminar','Catálogos','Horario ID 2','::1','2026-05-03 15:31:08'),(11,1,'Admin TestImport1','eliminar','Catálogos','Horario ID 3','::1','2026-05-03 15:31:11'),(12,1,'Admin TestImport1','eliminar','Catálogos','Horario ID 4','::1','2026-05-03 15:31:13'),(13,1,'Admin TestImport1','eliminar','Catálogos','Horario ID 5','::1','2026-05-03 15:31:15'),(14,1,'Admin TestImport1','editar','Diplomados','Diplomado ID 1: Operador','::1','2026-05-03 15:32:35'),(15,1,'Admin TestImport1','importar','Asistencia','Importación asistencia año 2024: 73 ok, 1 con error de 74','::1','2026-05-03 15:38:47'),(16,1,'Admin TestImport1','guardar','Asistencia','Asistencia guardada: 20 celdas año 2024','::1','2026-05-03 15:39:27'),(17,1,'Admin TestImport1','guardar','Asistencia','Asistencia guardada: 19 celdas año 2024','::1','2026-05-03 15:39:55'),(18,1,'Admin TestImport1','importar','Asistencia','Importación asistencia año 2025: 73 ok, 1 con error de 74','::1','2026-05-03 16:02:01'),(19,1,'Admin TestImport1','guardar','Asistencia','Asistencia guardada: 15 celdas año 2025','::1','2026-05-03 16:02:37'),(20,1,'Admin TestImport1','importar','Asistencia','Importación asistencia año 2026: 73 ok, 1 con error de 74','::1','2026-05-03 16:11:52'),(21,1,'Admin TestImport1','crear','Catálogos','Horario: domingo 07:00 a 12:00','::1','2026-05-03 16:16:31'),(22,1,'Admin TestImport1','crear','Catálogos','Horario: domingo 12:00 a 05:00','::1','2026-05-03 16:16:45'),(23,1,'Admin TestImport1','crear','Catálogos','Horario: sabado 07:00 a 12:00','::1','2026-05-03 16:16:56'),(24,1,'Admin TestImport1','crear','Catálogos','Horario: sabado 12:00 a 05:00','::1','2026-05-03 16:17:10'),(25,1,'Admin TestImport1','crear','Catálogos','Horario: viernes 07:00 a 12:00','::1','2026-05-03 16:17:37'),(26,1,'Admin TestImport1','crear','Catálogos','nombre: Instituto Cooperativa San Miguel','::1','2026-05-03 16:18:46'),(27,1,'Admin TestImport1','crear','Catálogos','nombre: Instituto Morazan Centro','::1','2026-05-03 16:19:13'),(28,1,'Admin TestImport1','crear','Catálogos','nombre: Instituto Plan fin de semana san miguelito','::1','2026-05-03 16:19:39'),(29,1,'Admin TestImport1','crear','Catálogos','nombre: Instituto Reposo','::1','2026-05-03 16:19:55'),(30,1,'Admin TestImport1','crear','Catálogos','nombre: Instituto Talzachum	','::1','2026-05-03 16:20:17'),(31,1,'Admin TestImport1','crear','Catálogos','nombre: No estudiara','::1','2026-05-03 16:20:40'),(32,1,'Admin TestImport1','crear','Catálogos','nombre: estudiara en linea','::1','2026-05-03 16:20:59'),(33,1,'Admin TestImport1','editar','Alumnos','Alumno editado ID 47: Perez Perez Ines','::1','2026-05-03 16:21:41'),(34,1,'Admin TestImport1','importar','Asistencia','Importación asistencia año 2026: 1 ok, 0 con error de 1','::1','2026-05-03 16:22:44'),(35,1,'Admin TestImport1','guardar','Asistencia','Asistencia guardada: 12 celdas año 2026','::1','2026-05-03 16:26:07'),(36,1,'Admin TestImport1','importar','Notas TAC','Importación notas TAC año 2025: 57 ok, 0 con error de 57','::1','2026-05-03 16:44:20'),(37,1,'Admin TestImport1','importar','Notas TAC','Importación notas TAC año 2026: 74 ok, 0 con error de 74','::1','2026-05-03 16:53:47'),(38,1,'Admin TestImport1','guardar','Notas TAC','Notas TAC guardadas: 7 cambios año 2026','::1','2026-05-03 17:17:07'),(39,1,'Admin TestImport1','guardar','Notas TAC','Notas TAC guardadas: 1 cambios año 2026','::1','2026-05-03 17:17:18'),(40,1,'Admin TestImport1','guardar','Notas TAC','Notas TAC guardadas: 2 cambios año 2026','::1','2026-05-03 17:17:37'),(41,1,'Admin TestImport1','importar','Notas Diplomados','Importación notas diplomados año 2026: 69 ok, 0 con error de 69','::1','2026-05-03 17:26:58'),(42,1,'Admin TestImport1','importar','Notas Diplomados','Importación notas diplomados año 2025: 59 ok, 0 con error de 59','::1','2026-05-03 17:28:24'),(43,1,'Admin TestImport1','guardar','Diplomados','Notas diplomados guardadas: 2 cambios año 2025','::1','2026-05-03 17:29:06'),(44,1,'Admin TestImport1','guardar','Diplomados','Notas diplomados guardadas: 54 cambios año 2025','::1','2026-05-03 17:30:53'),(45,1,'Admin TestImport1','guardar','Diplomados','Notas diplomados guardadas: 1 cambios año 2026','::1','2026-05-03 17:35:03'),(46,1,'Admin TestImport1','guardar','Notas TAC','Notas TAC guardadas: 1 cambios año 2025','::1','2026-05-03 18:52:18'),(47,1,'Admin TestImport1','guardar','Notas TAC','Notas TAC guardadas: 1 cambios año 2025','::1','2026-05-03 18:52:25'),(48,1,'Admin TestImport1','guardar','Notas TAC','Notas TAC guardadas: 1 cambios año 2026','::1','2026-05-03 18:52:44'),(49,1,'Admin TestImport1','guardar','Notas TAC','Notas TAC guardadas: 1 cambios año 2026','::1','2026-05-03 18:54:50'),(50,1,'Admin TestImport1','guardar','Notas TAC','Notas TAC guardadas: 5 cambios año 2026','::1','2026-05-03 18:55:18'),(51,1,'Admin TestImport1','guardar','Notas TAC','Notas TAC guardadas: 10 cambios año 2026','::1','2026-05-03 18:59:29'),(52,1,'Admin TestImport1','guardar','Notas TAC','Notas TAC guardadas: 8 cambios año 2026','::1','2026-05-03 19:00:54'),(53,1,'Admin TestImport1','guardar','Notas TAC','Notas TAC guardadas: 9 cambios año 2026','::1','2026-05-03 19:01:47'),(54,1,'Admin TestImport1','guardar','Asistencia','Asistencia guardada: 12 celdas año 2026','::1','2026-05-03 19:52:15'),(55,1,'Admin TestImport1','guardar','Asistencia','Asistencia guardada: 11 celdas año 2026','::1','2026-05-03 19:52:52'),(56,1,'Admin TestImport1','importar','Recibos Diplomados','Importación recibos diplomados año 2026: 49 ok, 7 con error de 56','::1','2026-05-03 21:00:46'),(57,1,'Admin TestImport1','guardar','Asistencia','Asistencia guardada: 3 celdas año 2026','::1','2026-05-03 21:11:48'),(58,1,'Admin TestImport1','importar','Pagos','Importación pagos año 2026: 720 ok, 0 con error de 720','::1','2026-05-04 00:49:27'),(59,1,'Admin TestImport1','importar','Pagos','Importación pagos año 2026: 720 ok, 0 con error de 720','::1','2026-05-04 01:03:50'),(60,1,'Admin TestImport1','importar','Pagos','Importación pagos año 2026: 720 ok, 0 con error de 720','::1','2026-05-04 01:13:27'),(61,1,'Admin TestImport1','importar','Pagos Mensualidades','Importación pagos mensualidades año 2025: 43 ok, 31 con error de 74','::1','2026-05-04 01:33:02'),(62,1,'Admin TestImport1','importar','Pagos Mensualidades','Importación pagos mensualidades año 2025: 74 ok, 0 con error de 74','::1','2026-05-04 01:37:00'),(63,1,'Admin TestImport1','importar','Pagos Mensualidades','Importación pagos mensualidades año 2026: 74 ok, 0 con error de 74','::1','2026-05-04 01:40:09'),(64,1,'Admin TestImport1','importar','Pagos Mensualidades','Importación pagos mensualidades año 2026: 74 ok, 0 con error de 74','::1','2026-05-04 01:41:43'),(65,1,'Admin TestImport1','guardar','Mensualidades','Grid mensualidades guardado: 11 cambios año 2026','::1','2026-05-04 01:42:26'),(66,1,'Admin TestImport1','guardar','Mensualidades','Grid mensualidades guardado: 9 cambios año 2026','::1','2026-05-04 01:42:38'),(67,1,'Admin TestImport1','importar','Pagos Mensualidades','Importación pagos mensualidades año 2026: 74 ok, 0 con error de 74','::1','2026-05-04 01:49:15'),(68,1,'Admin TestImport1','crear','NuevoPago','Recibo 733 — 61 (I530GWL) Felipe Gomez Jaqueline Mauricia — Enero - Febrero — Q120','::1','2026-05-04 01:54:00'),(69,1,'Admin TestImport1','guardar','Asistencia','Asistencia guardada: 1 celdas año 2026','::1','2026-05-04 17:49:28'),(70,1,'Admin TestImport1','guardar','Mecanografía','Notas mecanografía guardadas: 1 cambios año 2026','::1','2026-05-04 17:54:38'),(71,1,'Admin TestImport1','guardar','Notas TAC','Notas TAC guardadas: 1 cambios año 2025','::1','2026-05-04 17:55:51'),(72,1,'Admin TestImport1','guardar','Notas TAC','Notas TAC guardadas: 1 cambios año 2026','::1','2026-05-04 17:57:53'),(73,1,'Admin TestImport1','guardar','Diplomados','Notas diplomados guardadas: 10 cambios año 2026','::1','2026-05-04 18:04:49'),(74,1,'Admin TestImport1','guardar','Diplomados','Notas diplomados guardadas: 10 cambios año 2026','::1','2026-05-04 18:06:25'),(75,1,'Admin TestImport1','crear','Mis Tablas','Tabla creada: Control de fe de edades','::1','2026-05-04 18:08:15'),(76,1,'Admin TestImport1','editar','Mis Tablas','Tabla editada ID 1: Control de fe de edades','::1','2026-05-04 18:08:16'),(77,1,'Admin TestImport1','editar','Mis Tablas','Tabla editada ID 1: Control de fe de edades','::1','2026-05-04 18:08:26'),(78,1,'Admin TestImport1','editar','Mis Tablas','Tabla editada ID 1: Control de fe de edades','::1','2026-05-04 18:08:31'),(79,1,'Admin TestImport1','editar','Mis Tablas','Tabla editada ID 1: Control de fe de edades','::1','2026-05-04 18:08:32'),(80,1,'Admin TestImport1','editar','Mis Tablas','Tabla editada ID 1: Control de fe de edades','::1','2026-05-04 18:08:37'),(81,1,'Admin TestImport1','editar','Mis Tablas','Tabla editada ID 1: Control de fe de edades','::1','2026-05-04 18:08:40'),(82,1,'Admin TestImport1','eliminar','Mis Tablas','Tabla eliminada ID 1','::1','2026-05-04 18:10:10'),(83,1,'Admin TestImport1','crear','Mis Tablas','Tabla creada: usb','::1','2026-05-04 18:11:03'),(84,1,'Admin TestImport1','editar','Mis Tablas','Tabla editada ID 2: usb','::1','2026-05-04 18:11:04'),(85,1,'Admin TestImport1','editar','Mis Tablas','Tabla editada ID 2: usb','::1','2026-05-04 18:11:26'),(86,1,'Admin TestImport1','editar','Mis Tablas','Tabla editada ID 2: usb','::1','2026-05-04 18:11:31'),(87,1,'Admin TestImport1','editar','Mis Tablas','Tabla editada ID 2: usb','::1','2026-05-04 18:11:34'),(88,1,'Admin TestImport1','editar','Mis Tablas','Tabla editada ID 2: usb','::1','2026-05-04 18:11:37'),(89,1,'Admin TestImport1','editar','Mis Tablas','Tabla editada ID 2: usb','::1','2026-05-04 18:11:39'),(90,1,'Admin TestImport1','editar','Mis Tablas','Tabla editada ID 2: usb','::1','2026-05-04 18:11:50'),(91,1,'Admin TestImport1','editar','Mis Tablas','Tabla editada ID 2: usb','::1','2026-05-04 18:11:54'),(92,1,'Admin TestImport1','editar','Mis Tablas','Tabla editada ID 2: usb','::1','2026-05-04 18:12:03'),(93,1,'Admin TestImport1','eliminar','Mis Tablas','Tabla eliminada ID 2','::1','2026-05-04 18:12:14'),(94,1,'Admin TestImport1','editar','InscritosTac','Alumno 71 → inscrito (TAC1 2026)','::1','2026-05-04 18:15:56'),(95,1,'Admin TestImport1','editar','InscritosTac','Alumno 72 → pendiente (TAC1 2026)','::1','2026-05-04 18:16:04'),(96,1,'Admin TestImport1','editar','InscritosTac','Alumno 72 → pendiente (TAC1 2026)','::1','2026-05-04 18:16:11'),(97,1,'Admin TestImport1','editar','InscritosTac','Alumno 18 → inscrito (TAC1 2026)','::1','2026-05-04 18:16:27'),(98,1,'Admin TestImport1','editar','InscritosTac','Alumno 60 → inscrito (TAC1 2026)','::1','2026-05-04 18:16:29'),(99,1,'Admin TestImport1','editar','InscritosTac','Alumno 66 → inscrito (TAC1 2026)','::1','2026-05-04 18:16:31'),(100,1,'Admin TestImport1','crear','NuevoPago','Recibo 734 — 1 (J045MGS) Hernandez Cabrera Hazel Daniela — Julio — Q60','::1','2026-05-04 18:49:28'),(101,1,'Admin TestImport1','crear','NuevoPago','Recibo 735 — 9 (I739FRH) Perez Perez Milton Aron — Marzo - Abril — Q120','::1','2026-05-04 18:51:09'),(102,1,'Admin TestImport1','crear','NuevoPago','Recibo 736 — 3 (I730VAV) Juarez de Leon Miguel de Jesus — Marzo - Abril — Q120','::1','2026-05-04 18:51:21'),(103,1,'Admin TestImport1','crear','NuevoPago','Recibo 737 — 14 (J943THM) Cabrera Giron Doris Aimar — Marzo - Abril - Mayo — Q180','::1','2026-05-04 18:51:32'),(104,1,'Admin TestImport1','crear','Alumnos','Alumno creado: Rony Castllo (clave 75)','::1','2026-05-04 18:52:48'),(105,1,'Admin TestImport1','crear','Recibos','Recibo creado: 738 alumno_id=75','::1','2026-05-04 18:53:31'),(106,1,'Admin TestImport1','editar','Alumnos','Alumno editado ID 75: Rony Alexander Castillo Lopez','::1','2026-05-04 18:53:57'),(107,1,'Admin TestImport1','editar','Recibos','Recibo actualizado ID 3696: 738','::1','2026-05-04 18:54:26'),(108,1,'Admin TestImport1','crear','Catálogos','Cuenta bancaria: Banrural 374603117 (Ruth Noemi Pu Rojas)','::1','2026-05-04 19:09:52'),(109,77,'Rony','crear','Cierres','Cierre recibos 2026-05-04: total Q580.00 - gastos Q100.00 = Q480.00 (Banrural · 374603117 · Ruth Noemi Pu Rojas)','::1','2026-05-04 19:10:17'),(110,77,'Rony','editar','Cierres','Cierre ID 1: total Q580.00 - gastos Q100.00 = Q480.00','::1','2026-05-04 19:10:22'),(111,77,'Rony','editar','Cierres','Cierre ID 1: total Q580.00 - gastos Q125.00 = Q455.00','::1','2026-05-04 19:10:44'),(112,1,'Admin TestImport1','revisar','Cierres','Cierre ID 1 marcado como revisado','::1','2026-05-04 19:11:17'),(113,77,'Rony','crear','Cierres','Cierre recibos 2026-05-03: total Q120.00 - gastos Q0.00 = Q120.00 (Banrural · 374603117 · Ruth Noemi Pu Rojas)','::1','2026-05-04 19:13:16'),(114,77,'Rony','crear','Cierres','Cierre recibos 2026-04-01: total Q1560.00 - gastos Q0.00 = Q1560.00 (Banrural · 374603117 · Ruth Noemi Pu Rojas)','::1','2026-05-04 19:13:27'),(115,77,'Rony','crear','Cierres','Cierre recibos 2026-03-01: total Q3640.00 - gastos Q0.00 = Q3640.00 (Banrural · 374603117 · Ruth Noemi Pu Rojas)','::1','2026-05-04 19:15:17'),(116,77,'Rony','crear','Cierres','Cierre recibos 2026-06-01: total Q240.00 - gastos Q0.00 = Q240.00 (Banrural · 374603117 · Ruth Noemi Pu Rojas)','::1','2026-05-04 19:15:41'),(117,77,'Rony','editar','Recibos','Recibo actualizado ID 3627: 730','::1','2026-05-04 19:16:54'),(118,1,'Admin TestImport1','crear','NuevoPago','Recibo 739 — 17 (L404XUS) Garcia Romero Ivana Jassmin — Abril — Q60','::1','2026-05-05 14:32:10'),(119,1,'Admin TestImport1','crear','NuevoPago','Recibo 740 — 53 (I130LTV) Rojop Dominguez Juan Miguel — Marzo - Abril - Mayo - Junio — Q240','::1','2026-05-06 23:22:26'),(120,1,'Admin TestImport1','crear','Instituciones','Institución: M. Lozano','::1','2026-05-06 23:26:43'),(121,1,'Admin TestImport1','editar','Instituciones','Institución ID 1: M. Lozano','::1','2026-05-06 23:27:05'),(122,1,'Admin TestImport1','crear','OtrosPagos','Recibo 741 (otros) — 1 (J045MGS) Hernandez Cabrera Hazel Daniela — Cuota de inscripción — Q100.00','::1','2026-05-06 23:49:57'),(123,1,'Admin TestImport1','crear','NuevoPago','Recibo 742 — 53 (I130LTV) Rojop Dominguez Juan Miguel — Julio — Q60','::1','2026-05-07 00:06:47'),(124,1,'Admin TestImport1','anular','Recibos','Recibo ID 3700 (no 742) anulado. 1 mensualidad(es) restauradas.','::1','2026-05-07 00:15:30'),(125,1,'Admin TestImport1','crear','NuevoPago','Recibo 743 — 53 (I130LTV) Rojop Dominguez Juan Miguel — Julio - Agosto - Septiembre - Octubre - Noviembre — Q300','::1','2026-05-07 00:16:01'),(126,1,'Admin TestImport1','anular','Recibos','Recibo ID 3701 (no 743) anulado. 5 mensualidad(es) restauradas.','::1','2026-05-07 00:16:18'),(127,1,'Admin TestImport1','crear','ConfigPagos','Regla 2026 global meses 1-11 x1','::1','2026-05-07 00:45:47'),(128,1,'Admin TestImport1','eliminar','ConfigPagos','Regla ID 1 eliminada','::1','2026-05-07 00:46:09'),(129,1,'Admin TestImport1','crear','ConfigPagos','Regla 2026 global meses 1-11 x1','::1','2026-05-07 00:46:13'),(130,1,'Admin TestImport1','crear','ConfigPagos','Regla 2026 alumno=65 meses 1-7 x1','::1','2026-05-07 00:46:38'),(131,1,'Admin TestImport1','editar','ConfigPagos','Regla ID 3 actualizada','::1','2026-05-07 00:48:34'),(132,1,'Admin TestImport1','acreditar','Mensualidades','Mensualidad ID 631 acreditada (Gratis)','::1','2026-05-07 01:02:28'),(133,1,'Admin TestImport1','crear','NuevoPago','Recibo 744 — 53 (I130LTV) Rojop Dominguez Juan Miguel — Agosto — Q60','::1','2026-05-07 01:03:23'),(134,1,'Admin TestImport1','editar','ConfigPagos','Regla ID 3 actualizada','::1','2026-05-07 01:03:53'),(135,1,'Admin TestImport1','crear','Mis Tablas','Tabla creada: l','::1','2026-05-07 02:30:17'),(136,1,'Admin TestImport1','editar','Mis Tablas','Tabla editada ID 3: l','::1','2026-05-07 02:30:18'),(137,1,'Admin TestImport1','editar','Mis Tablas','Tabla editada ID 3: l','::1','2026-05-07 02:30:32'),(138,1,'Admin TestImport1','editar','Mis Tablas','Tabla editada ID 3: l','::1','2026-05-07 02:30:35'),(139,1,'Admin TestImport1','editar','Mis Tablas','Tabla editada ID 3: l','::1','2026-05-07 02:30:41'),(140,1,'Admin TestImport1','editar','Mis Tablas','Tabla editada ID 3: l','::1','2026-05-07 02:30:47'),(141,1,'Admin TestImport1','editar','Mis Tablas','Tabla editada ID 3: l','::1','2026-05-07 02:30:50'),(142,1,'Admin TestImport1','editar','Mis Tablas','Tabla editada ID 3: l','::1','2026-05-07 02:30:54');
/*!40000 ALTER TABLE `bitacora` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cat_cuentas_bancarias`
--

DROP TABLE IF EXISTS `cat_cuentas_bancarias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cat_cuentas_bancarias` (
  `id` int NOT NULL AUTO_INCREMENT,
  `numero_cuenta` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nombre` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo_cuenta` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cat_cuentas_bancarias`
--

LOCK TABLES `cat_cuentas_bancarias` WRITE;
/*!40000 ALTER TABLE `cat_cuentas_bancarias` DISABLE KEYS */;
INSERT INTO `cat_cuentas_bancarias` VALUES (1,'374603117','Ruth Noemi Pu Rojas','Banrural',1,'2026-05-04 19:09:52');
/*!40000 ALTER TABLE `cat_cuentas_bancarias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cat_cuotas`
--

DROP TABLE IF EXISTS `cat_cuotas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cat_cuotas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `monto` decimal(10,2) NOT NULL,
  `descripcion` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cat_cuotas`
--

LOCK TABLES `cat_cuotas` WRITE;
/*!40000 ALTER TABLE `cat_cuotas` DISABLE KEYS */;
INSERT INTO `cat_cuotas` VALUES (1,60.00,NULL,1,'2026-05-03 18:47:34');
/*!40000 ALTER TABLE `cat_cuotas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cat_establecimientos`
--

DROP TABLE IF EXISTS `cat_establecimientos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cat_establecimientos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nombre` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=633 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cat_establecimientos`
--

LOCK TABLES `cat_establecimientos` WRITE;
/*!40000 ALTER TABLE `cat_establecimientos` DISABLE KEYS */;
INSERT INTO `cat_establecimientos` VALUES (1,'Instituto Cooperativa San Miguel',1,'2026-05-03 16:18:46'),(2,'Instituto Morazan Centro',1,'2026-05-03 16:19:13'),(3,'Instituto Plan fin de semana san miguelito',1,'2026-05-03 16:19:39'),(4,'Instituto Reposo',1,'2026-05-03 16:19:55'),(5,'Instituto Talzachum	',1,'2026-05-03 16:20:17'),(6,'No estudiara',1,'2026-05-03 16:20:40'),(7,'estudiara en linea',1,'2026-05-03 16:20:59'),(12,'Instituto Talzachum',1,'2026-05-03 18:47:34');
/*!40000 ALTER TABLE `cat_establecimientos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cat_horarios`
--

DROP TABLE IF EXISTS `cat_horarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cat_horarios` (
  `id` int NOT NULL AUTO_INCREMENT,
  `dia1` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dia2` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hora_inicio` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `hora_fin` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cat_horarios`
--

LOCK TABLES `cat_horarios` WRITE;
/*!40000 ALTER TABLE `cat_horarios` DISABLE KEYS */;
INSERT INTO `cat_horarios` VALUES (6,'domingo',NULL,'07:00','12:00',1,'2026-05-03 16:16:31'),(7,'domingo',NULL,'12:00','05:00',1,'2026-05-03 16:16:45'),(8,'sabado',NULL,'07:00','12:00',1,'2026-05-03 16:16:56'),(9,'sabado',NULL,'12:00','05:00',1,'2026-05-03 16:17:10'),(10,'viernes',NULL,'07:00','12:00',1,'2026-05-03 16:17:37');
/*!40000 ALTER TABLE `cat_horarios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cat_laboratorios`
--

DROP TABLE IF EXISTS `cat_laboratorios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cat_laboratorios` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nombre` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=91 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cat_laboratorios`
--

LOCK TABLES `cat_laboratorios` WRITE;
/*!40000 ALTER TABLE `cat_laboratorios` DISABLE KEYS */;
INSERT INTO `cat_laboratorios` VALUES (1,'1',1,'2026-05-03 14:48:35');
/*!40000 ALTER TABLE `cat_laboratorios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cierre_gastos`
--

DROP TABLE IF EXISTS `cierre_gastos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cierre_gastos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `cierre_id` int NOT NULL,
  `descripcion` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `monto` decimal(10,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id`),
  KEY `idx_cierre_gastos` (`cierre_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cierre_gastos`
--

LOCK TABLES `cierre_gastos` WRITE;
/*!40000 ALTER TABLE `cierre_gastos` DISABLE KEYS */;
INSERT INTO `cierre_gastos` VALUES (3,1,'Ruth agarro 100',100.00),(4,1,'recagrar',25.00);
/*!40000 ALTER TABLE `cierre_gastos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cierres_diarios`
--

DROP TABLE IF EXISTS `cierres_diarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cierres_diarios` (
  `id` int NOT NULL AUTO_INCREMENT,
  `modulo` enum('recibos','papeleria') COLLATE utf8mb4_unicode_ci NOT NULL,
  `fecha` date NOT NULL,
  `total_dia` decimal(10,2) NOT NULL DEFAULT '0.00',
  `total_gastos` decimal(10,2) NOT NULL DEFAULT '0.00',
  `total_depositar` decimal(10,2) NOT NULL DEFAULT '0.00',
  `cuenta_id` int DEFAULT NULL,
  `cuenta_snapshot` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ultimo_recibo` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `observaciones` text COLLATE utf8mb4_unicode_ci,
  `estado` enum('pendiente','revisado') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pendiente',
  `creado_por_id` int DEFAULT NULL,
  `creado_por_nombre` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `revisado_por_id` int DEFAULT NULL,
  `revisado_por_nombre` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `revisado_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_cierre` (`modulo`,`fecha`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cierres_diarios`
--

LOCK TABLES `cierres_diarios` WRITE;
/*!40000 ALTER TABLE `cierres_diarios` DISABLE KEYS */;
INSERT INTO `cierres_diarios` VALUES (1,'recibos','2026-05-04',580.00,125.00,455.00,1,'Banrural · 374603117 · Ruth Noemi Pu Rojas','738',NULL,'revisado',77,'Rony',1,'Admin TestImport1','2026-05-04 19:11:17','2026-05-04 19:10:17','2026-05-04 19:11:17'),(2,'recibos','2026-05-03',120.00,0.00,120.00,1,'Banrural · 374603117 · Ruth Noemi Pu Rojas','733',NULL,'pendiente',77,'Rony',NULL,NULL,NULL,'2026-05-04 19:13:16','2026-05-04 19:13:16'),(3,'recibos','2026-04-01',1560.00,0.00,1560.00,1,'Banrural · 374603117 · Ruth Noemi Pu Rojas','701',NULL,'pendiente',77,'Rony',NULL,NULL,NULL,'2026-05-04 19:13:27','2026-05-04 19:13:27'),(4,'recibos','2026-03-01',3640.00,0.00,3640.00,1,'Banrural · 374603117 · Ruth Noemi Pu Rojas','715',NULL,'pendiente',77,'Rony',NULL,NULL,NULL,'2026-05-04 19:15:17','2026-05-04 19:15:17'),(5,'recibos','2026-06-01',240.00,0.00,240.00,1,'Banrural · 374603117 · Ruth Noemi Pu Rojas','730',NULL,'pendiente',77,'Rony',NULL,NULL,NULL,'2026-05-04 19:15:41','2026-05-04 19:15:41');
/*!40000 ALTER TABLE `cierres_diarios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `config_pagos`
--

DROP TABLE IF EXISTS `config_pagos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `config_pagos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `anio` int NOT NULL,
  `scope_tipo` enum('global','diplomado','horario','laboratorio','dia','alumno') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'global',
  `scope_valor` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mes_inicio` tinyint NOT NULL,
  `mes_fin` tinyint NOT NULL,
  `multiplicador` decimal(4,2) NOT NULL DEFAULT '1.00',
  `descripcion` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_cfg_anio` (`anio`),
  KEY `idx_cfg_scope` (`scope_tipo`,`scope_valor`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `config_pagos`
--

LOCK TABLES `config_pagos` WRITE;
/*!40000 ALTER TABLE `config_pagos` DISABLE KEYS */;
INSERT INTO `config_pagos` VALUES (2,2026,'global',NULL,1,11,1.00,NULL,'2026-05-07 00:46:13'),(3,2026,'alumno','65',1,9,1.00,NULL,'2026-05-07 00:46:38');
/*!40000 ALTER TABLE `config_pagos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `configuracion`
--

DROP TABLE IF EXISTS `configuracion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `configuracion` (
  `id` int NOT NULL AUTO_INCREMENT,
  `clave` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `valor` text COLLATE utf8mb4_unicode_ci,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `clave` (`clave`)
) ENGINE=InnoDB AUTO_INCREMENT=382 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `configuracion`
--

LOCK TABLES `configuracion` WRITE;
/*!40000 ALTER TABLE `configuracion` DISABLE KEYS */;
INSERT INTO `configuracion` VALUES (1,'inst_nombre','M. LOZANO','2026-05-04 14:31:54'),(2,'inst_direccion','San miguelito, Genova.','2026-05-04 14:31:54'),(3,'inst_telefono','Tel: 3779-3789','2026-05-04 14:31:54'),(4,'inst_email','centromlozano@gmail.com','2026-05-04 14:31:54'),(177,'membrete_recibos','{\"usar\":1,\"imagen\":\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAgAAAAIACAIAAAB7GkOtAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsIAAA7CARUoSoAAAAAYdEVYdFNvZnR3YXJlAFBhaW50Lk5FVCA1LjEuN4vW9zkAAAC2ZVhJZklJKgAIAAAABQAaAQUAAQAAAEoAAAAbAQUAAQAAAFIAAAAoAQMAAQAAAAIAAAAxAQIAEAAAAFoAAABphwQAAQAAAGoAAAAAAAAA8nYBAOgDAADydgEA6AMAAFBhaW50Lk5FVCA1LjEuNwADAACQBwAEAAAAMDIzMAGgAwABAAAAAQAAAAWgBAABAAAAlAAAAAAAAAACAAEAAgAEAAAAUjk4AAIABwAEAAAAMDEwMAAAAABCqaniuvll8QAAS4pJREFUeF7t3QmAHFd9J/56VdXn3DM6RiPJuizJtmz55jAGAwuEwBISQjjCZskdrl2HTbJJSPbKBrK7/2xCCBAWCDkIIQnmNhBjY2MLX2AD8iHZkqz71miOnpm+quq9/+91v5Fnqqqrarp7zvf98HMzr6am+lV19/tVt+r9mhkfFQYAAOjHVP8PAACaQQIAANAUEgAAgKaQAAAANIUEAACgqZCrgMR71Q8AALBisI+pHy7BOwAAAE0hAQAAaAoJAABAU0gAAACaQgIAANAUEgAAgKaQAAAANIUEAACgKUwEgxWrMHzOcx2DMdVejoRgptU9sMa0LLUEoFnBiWBIALAycc/7xG++ZfjkUdOy1aJlSAie7eh+70fvyHf3qUUAzcJMYNCI57p0yz13+YbgXN7iS5tgfiABAABoCgkAAEBTSAAAAJpCAgAA0BQSAACAppAAAAA0hQQAAKApJAAAAE0hAQAAaAoJAABAU0gAsDKZlsUFcz3RdHiecCq8UnQXIKpFT6DgAyw4FIODRTMxcuHOj/+xEFy1m7KmP52yQ+p90nDqDj/FvGrTwyr3+OAVa3vWdnI+70Mz9fYbXzowfGrKsv3nZJl85/s+/pWOHhSDg1ahGigsIRdPHfvY+96kGs3aNJTNps3g2TNjxtb1uVTKlINrUzyXX3bjxv71vYK3lKKSoBzzt5/88cmDBTuNBADzBdVAYQlhpkmhGm0nDDpxF5z+J39oIgS9N/EouFf7OGi+A58AwcJDAgAA0BQSAACAppAAAAA0hQQAAKApJAAAAE0hAcDiYabvwps5BzeEvFBHcB4SraKNq44uELo7Ia8+8odpWWoNgLbCPADw+/rH/ufZI89atq3ac0SDcl+P3dNhx4yegjFRtYtHVbNZW2/emOvM0HCt2jOkLEZUowlCpHIpO7UQgy/1/1+/sH/kzKQ5eyIY9Z7Gf961WTCbLXQ+Whyu47z2V377squuV21oH0wEg3if/K13nD38jGrMHZ16rxlID/Skwsbk59FvM2lzy/psCyO03Mjlt27NdWVDE4Bc1MqYSSMubbaVLSRGd3TvV54ZP1c0A7OaKaEeOVVyXEqYasmK95bf+9MrXvgK1YD2wUQwiGdZTZ77N8H/kc4cg8bnmZ/5+EK0+CmQvAPVz4Ug743uVe7U7KAbvTCGcWmB4EADAGgKCQAAQFNIAAAAmkICAADQFBIAAICmkAAAADSFBAAAoCkkAAAATSEBAABoCgkA/ITBfFNqQ8PzhOOGR/0LDjmPDFHbjstbCc/1VKeXPzm32XeIKGoLK5NuecIpNR0Fp1rhbuBhCgY9cKo3AdQT38rzF8xKq3uFeYZaQCtKpTj59IN3t1I7gDG291t/P3nxtGo3QPeQy5qdeSt4V7Qkn7XyWTO6E4Ib2by95cpV8knYPLFqU386a7ewx0sCPWQ/uOvg5EiJWbOPBmVjk9lru5llNl+XwjTGThZKoyXalFoShjFjquSdPFcNrkWjf1+3taY/vTDHefutPzNw2RXcC2R3wddf89Jc94BqwhyhGNwKN3LmxEff89Oq0RR6NmwZymYzNLJHvdZpRFjVk1o7ED4i0LLYJCS4yPbkLr9lS4slzuhthPppOaPDdfiRo+VC2T9GC8PK2Dtftq2VoqS0zeN7T40eHzUpizRGCWB4rPrdx8ZsXxIyDNcTOzfnd2/vpLcj8426ceJceXzSC81Wr3jvR9ZuR6HQJqEY3ApH5+9my6XcaOim8ah22zjkpxPC4+FBg7J//fBoWMo/eahOL3+0K4HjIw8yZUrPpbNh7rrNh+f5H6NgyOPZ+HBSRzxu+P5knkK+71F368dMDFnthKMJAKApJAAAAE0hAQAAaAoJAABAU0gAAACaQgJYUexMduYVMhEhpwU5/gk4Mhx5GUZtFtKs9f0h5HU+jS7VoF9zx+NuZMgV5v+iwuWjNrVt9iGicOR8N7VGC+RDFvuIuNytesUxpzTuD1roVHmjhzsxwb1ykqD+MiavBw0JtSloD8wDWH6cSumxf73DqVR814wzZlamxg9891+EiBky6CHv67YzaZMG8QDRmbdtk8VcXymMbKbBRDAuOtd0da7qiLqokFYTwk7b/et7VFtzwhg5Pe5WXUaD3Gz0KPdv6DUj53BFo22On58oT1aCG5+Jflmq8vMFJ2Qlxqxy1Z6Ykis1RwjLzvev3cXiTjppTx9/cv+xY0csO+SC5jf+7ieGdlynGjBHmAi2EkyNjfzZr7yWzqZUexqNxZk027I+p9qN0Zqb1mU7ciHDN6md3MegYYDWCV2PzjTXXTM0uG0Vj5s1RH8enSS0Iof40NG19sX36udmURaJH7rpTugkImw1Wjp6pnDk0aOm3eR8NCG8THbVjl2vi72Q3zLNO++5/+GH7s9k82rRDL/0oU9v2nWDasAcYSLYisBYOttwlJfTaBLEzHk3vkiyhfo64Rj9StDoLyd5RQZG/5nkpzSBQySjHUeJDrV/s8GQ6/hnkF0Kz6N03uzp/zT5/KL7iAvqr0V5wKRk4Y+WuwCzIAEAAGgKCQAAQFNIAAAAmkICAADQFBIAAICmkAAAADSFBAAAoCkkAAAATSEBAABoCglg+TEtWcKhtWjHFFzaDpezeYMhiwosASwZtTYkQAcrOogQXli4dFv7PSwhqAXUNpOjw9VyqekBhR4Gy2QUqt0AM81iYfSz//U3quWiWjSNRvVM2ty0LhvbBRqih1ZlctnQYnDJCMNKW3bGDm6Au3z1tlWrNva2pYZBK9yqG1cWTzJt07JxJhSlXgvo8KPH4moBCcbMfL4/pGac4Kl016bLb6EV1JIGLNP85r17vv/o99KZkHon7/zgpzZdhVpATUIxuHn0Tx96/4EfPND0d7LTcDnQa6/uSycZlGW9lMBqtCCTYpuH4ovBkRZPfOUov331uh1rQiu+yYotrW2/dXQYDz96tFwoh5c3m8YdPnj14JpN/YuerpYy02Snjo1976sHUtmoBCA4z+a6X/WqN6VSqdCncZLTIySA+YNicPOInv10yz23hfBV52oY9DKil5I/pof1WQsbRFvUNhVi0Uf/OlnWNPDxlD/oPQINVUujw0sZHSQZz3+KGBbyRj4tZFHRMPVNwdKBBAAAoCkkAAAATSEBAABoCgkAAEBTSAAAAJpCAmgb1+FOxWshuFvl3HdZ0Jwj7OK7OfJfJxMaHv0nGl480+DqoCC1fgtoIzO/MnBGqBVWgPqxirX0r2WqPS7x1Nqh2vAEh+dhHoBEA+eFE0dqX0YaSRipVPhcLdNKPfzVD58//rRqzx2Np51Zq6fDrl1J1ySLiV4rwdynSJmurBk3MYp7vG9976pNfZQM1KIZXMdzKy6NW6rdAA0H6VxKNZpVnKpS5gu5LyHOPHm6OlmJmQfgeuuuHlqzpZ97S3VoEUalVI1/VgiRyqbmaUYbPVIn6/MAMpHzAISXzfW8+tU/m06l5fnBbJyLwuRk7I7Qff3o0PFDzx1KpTJq0TTueW+8/X+s23qFasMcYSJYuGJh7C/f/cZKcVK1G6Bn8Pq1me6wMdqteq/4uavWDHYu4nwiOgeslpyD33sudFBOiF63l79ka6472/RGTIudPzJCg6+Zip40JLLd2W0v3tLi24A93zp07siYlQoZ+Lasz6VtFr0bSz0BMDnn7uD3DjslJzaTbbxhY/9Qz3w8A1tPAPTknCqWPvE3f+dUy2pRY2/9wJ/vvPk21YD2wUSwhuQ76FYtyRGkCbQfC7MrrR9yQhsJ205btr2ErIj9qX1KlSBWyitp6UMCAADQFBIAAICmkAAAADSFBAAAoCkkAAAATSEBAABoCgkAAEBTSAAAAJpCAgAA0BQSAACAppAA5mjmN6DOiJrpioxNRRtKUcyFaEDuoFolnuxzMGr/tcHMbTaI2hEPJ+tZJMHbVPdidsfqscCP6XyTh0vexkRtv+UjE6Q2BEsGisFJxcLYR9/z0+WpCdVuwHXFjbu61vanQ8ptCdE1kE9n7KYHE+HxnnU9jeprJkEvsITF4GiFod1D+Z5c6JqZfMq0Ys4MmMkKFyYvPDfMAmvSy7xadKpTlegXvCwG15Pd9qKQYnD0h5Vi9dTTZ+UwGol+f+DA2EShagYKpVEPb3vD9nxHqvZd/RFEKpOyM1bTaYB6W56qnt53Ru75bLSPHf35wctX10bOplwqBld2oo/nvBaDo4M5crpw6OGj0QX+aswyX1s7s5zVDfmYVp3H9h7gcY8Heevv/9nOF6AYXPuhGmi4hAnAccUt1/UMrcrwsNezLCfZ9OvcMDyXr9mxZv2Va5t+AdNrLGEC4B7fdsuWzv6O0DWTjFY04F48NX78sePh9YdN6kvM4B2dAEoT5YN7novZBGHsxLlKqcJDNmKyn/j5qzs6MzFHg9X2t8lDLlFvi4XyIeptoA/0lOjZ0Lv5hg2xj0hDSyYBjJ2dOPH48dg64R4Xh44X6FQp2FnXM46fdZO8RJAA5gmqgbauNlyEBb1I5HcFNBvypDvyFd5etT6HU2vEob6aVoNdbseOmJRkfJsNRvRdcZlmYtBw2fKASV1g4YeCurdwj+k8o4OlnuoRQQfTstKWnZa3/mj1ux+g7ZAAAAA0hQQAAKApJAAAAE0hAQAAaAoJAABAU0gAc8XkNR+16z7mIVq/ICWRtlyaIq/4aKW7sgtR3RCtHYw27GFiC/GoJbuPhehJLOpEi/1YOZdOLXWYByAlnAdQLk297S1v2bZpPffiJ7PMFWPm5OTZ4eFHTTPqajkhhJ22L7tufehcLfqtU3ZVIxJtxLSaf5lZlnn88Mhjdx1KZWy1aJpb8a580fotV6ySEyMiUR5KZf1/TkyTjY+WHvjSfhaY3uVDGWhNfyolL04P3BdjV7388kw+La9ebArd+4WjI6MnRmOnxdHzoTpVVY0ZaHnPUO+m69c3PQ+ARkLH4fd/ZX+pUI1+vOhoD23o6O3JBPeXujG0a11nX76VQzF2tnD8sRPR8wCof44nHvzxWKXKgycZHb0Db/69j9ipmItBqZM9qwbTubxqQ/tgIli4hAmgVCy88xd+efvmjV6C2YxzxUxr5MLx4we/aVo5tSgMvTxSudSOl26TL8Wwl3PCs/umx4I6SgBHD1186OsHgyM4ZaAbX73lit1rPTf+LkK7QQlgbKR09z8/nWRfNq/P5tJmyFYY237r1nSu+QRAA+6p/ecvHDhn2rHTX+UQqX6aoV0J4O4v7JsarwRnO8/EhRhale7ptIO7y12+5cWbu1d3Nt+NuSSA+34wUiqHJIDuVYO3f/LrphmTTWH+YCJYixiNJvPEqFWlYfQqN+nNQGREDotqc3HU2q2hjoQGob1R9xSptpkwgW02CsqCtBV5/GZHfXlLRO0ukjwice9UWjdzl8OD1gn06lKorSwQ+RT1d4+CnhSuo1aBpQEJAABAU0gAAACaQgIAANAUEgAAgKaQAAAANIUEAACgKSQAAABNIQEAAGgKCQAAQFNIAHWiWimpHyMxxqwG5NzH1gghPK/IvXJM8Ir6g+VPTrMNBKvdqjXicI97Dueu5wvP9VqeCryg5F5bs44DBf1Ht65bcqpT0VGtTtHTh/5i1uTbWpimnCfcIiEMz/EfZF94rnwg5BRqWCZQC0hyKqVHvvaPTqUc/ULhnK+2ShlnMljDgJYMrduQz7dQb4uxUrFQGDtDr3m1KJQwzJTo3z7JwurfLJh6LaCH7wyvBXTDq7bsvHqtF10yj9GAwsfOFIJHjIa8yYnqY3tO0uAVjf70xpes7+hKh1S5YUb/+l4rFV4xKQnqxulnz184eCH2m9AbmUMtIGGMni3QCKua0+gIcG4Wzq+jW7WoAXr+FEaOT00co1MUtWgajcu7/822gbVdTX9fvHxyTlYK5ydkemmMfll1+BfvODRZcOjoqaXTugfWvu/jX7bTGdWGBYdicK16+B/+x6GHvqoaM7hO8dWv/dW1a9ZSklCL5o5eXXTKpxoRmMt7nzSYIx++RdJ6AqBdrRSrz373oBEydrOKw0+cD6mv6UPJ4zVvv7qnLxeSdwUNnU2Od3ULmQCo/wf2HK6Ml3x1e2gn7FTnldf/TMpORxc3skzrR088/uTee1Mpfx1Nt+q94s1XDq7vbuWA1J6b1LeoLcjHtOJ96iOPjZ4rWzYSwJKDYnCtYsxOpTtCItNFz361UrNoFOA0ZsSGLBu3IjDDsi0z5Q86bY+twHwJDWo0vHIvEK2N/guP0ozvOMig42OZ9KDHo30WnJJWaKj7aIF8cspn3+yD7I/a03OZHXitIQEAAGgKCQAAQFNIAAAAmkICAADQFBIAAICmkADmhgVm2dTDZPLKSDUlLFJbvhNVXtpBW7JqU4dmxIJ/+V84ecVgoG8hYTLPN8etFnLhAk52q/U25GDSQmF4yabmNbxiVT435IMVF6YpeJV7Jf+WKehQJLuuhnPuVAq+CWIU1cokMw3LpudnTLTpeiF5aVZIhFyrC4sM8wDm5p5P/dEzD35TNWbwPPe6a2/u6+mOvghOCN7T079haEMLrwXGhTM88T0haIic9XKlTdppa9XGvgWYHkCDRaN5AJ7Lt145sHFT7FXngoms7W0Jjm40Dk1OTn7/sT2xV9bSYXzVW3f19uXi7qshuovJkamJ4amw3Mktb4PFe2lAUwvCUPqoVqaGzz7mezgIdS/TmelZ15Pg4WYpdxsTqeDF/nQ0evqG6F5UuwHakYsjFwsT45Ru1KLnsQo76bKR6BM+GqG7+3Ibt/Q1/eSkh6ta9b70d09OjVUoq6ml0zr61rztQ/9ipzAPYNFgIlirvvzh/7r3vjtVYwZ6yaxfzfJZ+UME1y1uv+JlL7z51qbni9H7DdetPvvE11xnyjco0FlWtie3/datseNm6yISAA3Fq3vs/m47+lAI7mY71u3c/ZPB3tKS8cL4t+/6XOyo13oCoNP8s4cunH7itJUKTqAtbb7i9QNrNtGBVYvCUG+LU+MHn/5yaG+ph0JOiIt5RBizrrj+Z9OZfNgTiO4/0bOFhv7Qt4CUQh5+5MED+x6y7ZxaFMateluvX3vLq7a2kE0Np8rvuWNfaaIS7Emud83rP/CPFhLA4sFEsFbJl1hY0HI6tUml83HRZZr+gWZO5EuTyWFLzhvyh8USz5+aR0LIo+TvWyDkbC+mprbNDjngcX9RhHkjeyunnvm6Z5u1lMDV7KbIoDFebSyA0oOczBXYeDBqn5L4t1yLpOcK8u8bYKZIZVOprBUVOdtqds7zTDLn0RuZQCT8IAsWEhIAAICmkAAAADSFBAAAoCkkAAAATSEBAABoCgkAAEBTSAAAAJpCAgAA0BQSAACAppAA5oa7rvopgMmQdQ2iQ84alkW3WDASqa0XV1mgJbW7iSVXU3+wVNU7GsuQtRZcEQjOHTl/tUXCY3wqPkTREK7BvZAQXm22eTxmCP/f1kPQbdXwRg2vEBXuGBPVxk9EtUOwkqAW0Nx89/Of2P/wd6xUWrWnCYNlnLOmV4oeMTy3umnL7uuvvTF0fj+9gm2LRW+BXoae5xw7dK/nligbqKU1gotMd/byF29u8cVaLTnc4zJZNWZZ7MSRsce+czSV8Ve24Fys6U8P9KaiR08h3GxucNuVrw72loa7scLYPXf/k28Hg0RkLaBKkUbw6MNpmKZROOuOn3SDd0VZYe3Q7u7eQRH5JczU/1Jx/NC+r4X1lnNrlZvbVquEEIWG3at23ZTOZIJrUnaaOHNceHTmEfWIUCfzqwbTnd3BLVBueGzv/iPHT1lWVBkSzzM2rHevv3aK88AdCWGlrFTGX/fJhx5Jp8rv/sLTpQmZSNTSafneNa//A9QCWkwoBjePPv/Htx98/Huq0QANUz2d1tDqTHBgoozQ35NaO5COHbMaDQTtSQDMOPKDE5MXJszIskJ0D2MT7pkLFXneOdsSSQB07889fKRcKAdHopk8rzy06eVrBrdzOlNuSkQCYLxQ6n/T2W1vZ42LBdXRaffLru3PZWzfo08bdyqVL/77X5742pdMc4NaGqbCT/7kgw9ue8ELPMdRi6bRY7T34NjxC2Ur8lAIZnUUjq559reF2aMWTaMTgoEtAxuuGgxNtJcgASxxKAa3dNDLIxh1voXBmHdJ7mMh+tGiBF1cMntRH1gbDa+1bqZYVNTFnz0APA8JAABAU0gAAACaQgIAANAUEgAAgKaQAAAANIUE0Dae67/8LhSjkOQ1c8FYPpghHMMdDQlvTLijwhkTDt02DO6MCHeKyZlKbkgIT15H6Ds6gZDHUVQMUQ4Go1s5x2oiLkblPKmWUB8E44XAlilGDO54XCSIxlcA0VOrHiIyojYgrz+muwjcqT8454wPB/aCosDo4W75milcA7rUYB5A29z7Dx87vu9Hlh01WUYw06iM8cKx4NV6nIu1A+kNazKRV1pHaeM8gKkLE9FfL8wMd5xvO8s3m4Z/khQNNBvWZtetykR/l60QIpXODg1tDQ4rpmmOjVz817/5X4zFfH+yEPy1/+Gdvat6QybWCWP/D84XJ5zouQR02C9b3bOur4s3ewElHeypsrP/5AXVnokyWf9Ocflt9NioJQ3QRnZt7s6kTV8v6KF0KpUH3vkr5a9+jXWtV0vDuBNHb3rwwfU33xycrG4ydvj05HChSj+oRaEo5RbOGs981TBTask0ygtr15U2bx0NmSM2A20+Yh5AuqP32jf/HrP8G/ehLLRu6858d59qQ/tgItjiO/CDBz7/wferxgyOK67clr96ayediKlFc7SgCcC7MLH+9uGNr2E0xs3mcnH15q7L1yfZkfBJb6Zljpw6fceW3czoVosaEEbhzUee7F8/xD3/WTxt+cGnRsaLbuTkJ8MxrGvFkcuNZzwjZpprI5QCx4yBB9gNshLDbDIXDqRv3NmT4HvdG8z/Y0xUKmO/9Ov8y/cag/1qYaizBzoffCh7800irFoJPSPof9GPh2kaw2PVB/eNBx95T1jbss/t7vqsJ3JqUZjoBOB64sipUpI8+5bf+9MrXvgK1YD2wUSwxed5rnw1hoZaZVmg4Y5Omrk8t/UFnVRzL1kE/laFoJBlkzIsJgwr8LfPBxNeLeiHiPCCA/dc0RYCm62HR92QfYmnNhWKfhkblGLothHaPj1aMWr9bHDEKL/GJ7F2iZ0BDu2CAw0AoCkkAAAATSEBAABoCgkAAEBTSAAAAJpCAgAA0BQSAACAppAAAAA0hQQAAKApJAAAAE0hAUAAY0JWYYsMZsv1ZBUEf8gN1G5bNHObERGtVmJj1vrBIEL9P8wX+TDA0oNicAtt/yP3fuF//45qzCCLwW3N71rsYnDM4I9d+Lnhan+wzOdM1MmNQ71bN6/igd4KYaRslrKbP7dgllU5ffrs9pca/VGlx6SR0uDBPZmhIREoBkfKVY/zmKHHZOzMufETJ8etQAk0zzCvNI4MGie5zHkN0YEaN/ofMK4PKwYn1g9kbtjR13SpUZmMK5XRBMXgxNkDXQ8+lGtQDC4JOhTD45WH941agTpunjC35g7v7vpcdDE4evZ4Dt9//3NOyfEVg6NG2eF7fjjmefGH4q2//2c7X3CbakD7oBgcxHPTPdVMXzUbFZVMn5Xt6Mha+UB05Kx0C6M/oRGC/r7DNjtMFhO2SWs2GlFyGdkZX/d8QSsIOzNi5MeMnC9GjJxjpFovFacbSv/pVFjYzZ+XwDxBAoAAVUozJuQ7Dlm1MyzUhloi61PWBvfoiDCrS42DVrQMYQaCFmLEaoJ6aHzHubYQlhokAAAATSEBAABoCgkAAEBTSAAAAJpCAgCIUP+XS/Xvmo3C354drc8xEJ4rjGFjuBgVtRVrt81S/aT/C0RLXzMNSxcSAEBjzDSYFRuMmSkmQsKULzDPEx6PieB0iplYfz+7+Vb24p1RsWY7MxvOV+DCf48hIb+kmRueEwyZgbhXSwawomAi2EJb+hPBHhn75fPOKotFTQRzPbFjff7Kzd1N9zaKZbmnT49d8TKjL24i2Fi5d//99tAQjbJqyRxZJjt0avLpo5O25T9ormA3DUxs7Cx5cZeDCoM5Rko1ZmBMjFVST4x0mSzmKNFD9sIre7MZS76b8BGCl0q1txmRhGDZLLNt1ZzBNNm+I4XTFyuBuW6zmZY7fHxyz58zK6+WTHNdseOa9PU35WOmcdUmgh188LBbdnxPQmqVq/ze749iItgiwkQwgMRopKJzajtlWDHBLCtj8WBkLW4zPlnxpuKiWGk8LtL7i85Os6srJrq7WSokCdVVHe67x2BQH8rlqlHYIyae8sf4XsM5Lwd4WFmQAAAixXzCXw9/e0bImggmDeIxUb+zBjhPFI3fJdAJeGw36gyzxzCzgaC3YiHvLWC5QwIAANAUEgAAgKaQAAAANIUEAACgKSQAAABNIQEAAGgKCQAAQFNIAAAAmkICAADQFBIABFg2s2y6jQ/TCg/W8vOKC1E5Ic4eiInycVpT/UmAaTIrQRgGc7jhcLqdHSJi20kJEbblYAgm6MUoa8/NRzBPBO4xJAxarT4d2Bd0JGVYcUEsWh2WDRSDW2hLvRgcEw8+eeW50bxlRnXDdfkVW9dcvX3I8wI14wQ3egdFz1r5Q3MY41NT1SefkmNPNCHS11xtdnSEVkE4drZYcTwawVQ7FGNpdyrtFUVgNdpkf87tTCWoXtYAbbHsmueLqdj9oN+vXZWz5UFv+t4aoufDxbFyseRFd4MG7+HTRx/69Lus7Gq1aBo93Duu6tu9e3V01VJCT8KR46PC5b7DSXeNYnCLLlgMDglgoS35BMD2fOPxswcPW6m0WhTGqZ7Yde2v777mZi9YhtOriq0vFht2GbKAcLOoH2GFLYOE64aO/rTsgb3D40XXjDwadOZ74+rSjoGSx0NW4/LEvCW00dhSoHXzUld1Wq3Uj/q5EdOyjh879v/+8F2ZrjVq0TTXM7Zflr1mWwePyem0C8y0Q97/IQEsBagGCrGEYXUbqc1GakNUpK817LyvKObzwVp+XgkhHCdJhI7+dbbFkgQNTjT6eyIkWh+SaQu+bTaKGZ/YtD/ohNx3d8GQ2U7UP8kJhmHRcnqHYpuRIVdQew7LAR4tAABNIQEAAGgKCQAAQFNIAAAAmkICAADQFBLAQrPsNOciNBpfz7LcMHPWvLBmwpRXDrYWrmAur91GRRtme0mzr7qZEUkvybWILW+C1BqtkAfE17Fg1I5bo4kItS+VrK8SHbCMYB5A2zz05b87fWifaUVevW6aTuHc5KmngmO9x8W61enL1mabHo/aNA/A2POvh84+N2alok4OHKe465pX7L76upB5AIIbnatFR3/EBZpxhGFnjJ7VDQejZEbGKm7cVef0666018psL/kicivG2Fn5gw8dgUze6I7fEUr+Tz78aHFigs3+dmBankpnrn3JLal0qvkTBHpQC8NGeSp6eLZM88Sp05/+6P/O5LrVoml0djK4OrN5KBs9t4/6R91f1ZeevRMS3TPmASw6TASbR//w399zeO+jqtEADe69ndbQmmzwxcy50d9jr+lPN/0yXyoJgNA40fQ0YEJ/m+02hnaqZrPoXUQSosXr/eXYVjRO7QsZXmlHKBEObovNhfQG8Mt/+bHz+/ZamZxaVCNcJ7968C0f+P1MNuQ5kxSd3Z87bEwOyx8akwngzLlP/+3fZLJ5tWgaPW/7uuy1A+mYsxMhLItt3ZCrFdiYBQlgKcBEsHlk2Sn1UyR6+tMrmV7LobFC0EBj2q2FJceM1oLXJjfFRhuOOg136lOUYCRNxlY6neroSuU7Zobd0Wlns2qN5onaAfF1rEE0UD+oNLBHBL19iZ53DUsNEgAAgKaQAAAANIUEAACgKSQAAABNIQEAAGgKCQAAQFNIAAAAmkICAADQFBIAAICmkABWlNqMVJYk1B+saL5vNWwY7Zi8Ko9qONM0LfovhmUJIXiAqFUJVPfRAtWXaLVdUH8QpraSmhIcHnKdYEUkWLqQAFYQZnCPT42WpkaK0TE5UvTcFmr1LBNTIxcnLpyfuHAhKs6frxSLctxqAR32icJkMCYnpsZHRs+dOnX+1OnYyNqsf1V/b1/PrOjv6enuaHlIZaVSxde3kBifnJosUh5QfzQDdcD1RLHsFcs8MrxSpZWyerDQUAyubT7/x7cffPx7qtEAncz1dFpDqzPBsj/1YnBrB5ovBlcn5AswZhPcE9tesqVzoINOMNWiaTQStqEYXItkMbguY9121WwKnVDv/9ZXS8NnmRlVn5VXyxtvfdW6K3fxZneETvGnRkee+fodweJzdEpdmJh65sln6T2AWtQAnX3vvv7qTIYe/VmPCL0rsLP5K1//M3aanjNNPjPo/cXhh/dcfPZJFlmuit4NjRTGH3nqcSusoq2877j750LkMuYrb+5PpZivs/S8QjG4RYdicCsfsxizzLiovWNf6UzLMimP2XZE0JgY/blHEvT38pOegNrHP5ady9nZuMjkaFykIT6UupsWyA9v6n2KItdRfxAg9/HSRz0Nov4xmFwVlgkkAAAATSEBAABoCgkAAEBTSAAAAJpCAgAA0BQSADSpdsVHQ2ql5jFDfkPhjEtMGkVj3PO4W+WuExVOVe7KpUlhs0OSlxJFRm0ldZcBQginUnWqTnS41XpnZvdNLXETXwcUODi1EPR4UB/pJjLkLtP6oBPMA2ibJTIPIAnu8a0v3tLZn296HoDrlrdte8GOy3d5PHD5vDCyuQxF8ztCf5nOGX1Dqhkt2yG/QDhIiNNPP+kUp2K+G57zXF9/trtXBL7FnkbDiuM6Lu1g1LBIY6czOTGy91F57AI8YVSTHAjG1m6+3E6l/KsKYdqp9ddcS7fyyEZhRrVkuJVgb03LfPLBB0/te8JMpdWiMDT8j09NPnPk2Yh8Fo12NJsxX3FzX8rGPIClKDgPAAmgbbRKAFx4PR0bBrqGglepe6678fJNQxvXcdql5iX7jnxaZ8NVRiYfurI6pY3cjGlbp5564vgDd1mZnFo0jf76+PEzp4+donXUojDC4z2r+q/YtUO1Z6Aj0L964PIrtya4lp8J2hE77e8tDea1EhGqGYHeMA0fN8bOBNMhvUn55n3fe/DB+zKULKPQWwVKFk2O/oT2EglgKcNEMGiX2ucK8jMQOl+cHbZFJ8Vqreax2kdAcRF5di8HTs+j/6KiNgHYTGfp7DgYdjaX6upJd3ZHBK1Aq9XvMYiGfupCfNS7Wvu/WUEL55BH6aBZ/kNEUfs4K2WnbMuOjFQroz8sR0gAAACaQgIAANAUEgAAgKaQAAAANIUEAACgKSQAAABNIQEAAGgKCQAAQFNIAAAAmkICAD85izduJm+tzFj4WrXlcX/fTu24L8FFEC3jXHheTHAZcspvgCz9oWo71H9oHDG1IuoHOzLkQyIrX4SEvIm7B9ASEsCyVB9bgtGWF7ncFJdVgiJDDo+yTAGtGYja8iTa0V3BZR0lug1GMsw0rUzOSmf8kcmm8h3Znp5Md0ykO7poZf+fU2SyzE7L4jyyQkNkyBoMNEqH454bH67nurJ0XVi4dKhlcogjK0bQXoeFFfmF8pfQI1p7DvieLTISPyCwcFAMrm0WrBicx8WJs5Xg6EntdIptWJONfaXzyGJwX/qX/c8+fiGVjayAJkRnqqsn0yPPc2fzPL7hsnWDgwPR4zv9YTaX3XbF1iQDUxTLrp3HBO6LNju4XZZXC/5qtvroqRqz1fNcgoFTfhW/+nk22jvLSnaaJfNEYCOMccc5+N273biypqZpHj5x7PiZE7YVfODY5EShUinFHuot19z85v/8f9xqRbWn2an0E/d/866//lPVboCeC7bNtm/MWVZIMTjHFQePF2Of3gTF4OYJisGtEK7H6eUUDNdN8PKKQwnGceLCFVXHq5SrlUpIyP/KcVGqOFVH3WUrXEfWQHarIRE39NeZdHKbzYZGJpfL5fPZ2MjlfH94KaxMxrBSiaLB6Ez74ExOVAqj1cJYRDiF0YnRkfPnTl44dyYQp5KM/sTOZHOd3V39q32R6+rJdfaolSLQPQjD8WY9J2eGWg2WDCSAZUp9sjsraudZratvJz7kaqEaLQ9S99iS5zs0O2QHk5If2M+P2qdyCaMxWc7TktWtGwflMdOyZEVPX4lPGamkx7rx+Tm9F1I/JTPzoajfef0WlhQkAAAATSEBAABoCgkAAEBTSAAAAJpCAlhCav9cFvMvZXKd2r9vBter/WnMn88kNzLjn+mmI3Tbc0DbUBuOIdeMVN9KTMSQK9T3aNGiRbXvNa7vbKT6/i4B9d76zKl/8h/PYUEgASwZTE4FcD3hyYlUDYNWUOsE1qwvV1uLRC9Gz/Vcx3OrIcGTfQltbWZPbdJPIGjbVdetOk5U1FZodL0oLXccL0lEDRbco/00PGfRgjuC+lipJIlKuVwulXxRodtyuXbE4o+nR/u7BBKBF/o0lg8Uy/f0xUY612Gn02pbMM8wEaxtWpwIRupnearRgBy7uThyqkS3tdbzaOjt6bJvva43ySBgWmajr25/+MejZ85XLCt2Kw3vx5QsmSMao9+lzNTqjlWqPQMNFR2dua2b16t2Y3QYd1y9PZfPhacB+ZXoCY7FvKFHc6Iw+dz+w3Q41KIGKJseOnyKMl/wCSAEPz9+mnNXtRtiHncTJu9Gtt9469v/8C9UY7a999351Y/8N9WIVNvXkMPe1b/mV//0c/GDuxCpTNaU8/ugzTARbEmjQez5M6aIUO8AQlamHKC2FYfGitpZuj88OqemjSQaNqm/4SG37dA5fDUy5KSx0lSxHIjSZLFSqlBPXEcWN4gIz3Xp/hoSHu3nooZ8C+KVi24lJrxyqVwYK42OlANRGhutVulNQPzxpPduascXFb0D8D0t68ENlu3ozOQ6YiLfidF/wSABLC008EaHWon+k//zxxw0+ky59qvoaUmxYj+vvoROjWfOZno+qCMJthK30/UVFjFqN3J3YkLuam0mFwuEXCjRanFq+7zoLu28P+ht2tJIUXAJEgAAgKaQAAAANIUEAACgKSQAAABNIQEAAGgKCQAAQFNIAAAAmkICAADQFBIAAICmkACWFjkBNjJMeUv/H27mmtGxFEzPEfV1Te4e/VcrKBTDMutTZcND3U0LzMjtJwh5I2c2J7AUHpPg18Ffwr3w782HZQ3F4NqmxWJwNOoVy3x8womd0i+EmCh6wS3QklzWvHpbh9xWNCH6e1KZlBms+EB/+chT42cvVK34YnCtonE+Y2WDd0M7mEqn+np7VbsxYYgNQxszmYzc+dnoMF573RXZLB3q4F4mQoPy0aOnTp44Q8O4WjRH1IdiqXTqzEnKAWpRA5TvbnzjO3Pdfb5iCcxklVLx65/6k0p5Si1qygvf8PMbr7iWu1EV5Tjn3avWbr76RtWebfTcqRP7f1yr8dcQZbpKaequz/xfp1xSi2boHlj7vo9/2U5nVBsWXLAYHBJA27SeAMYn3ZPnKrHngvTr0BGetplJs8sGs+G/noHGxE3rsh05K6QbC5gACI3g6icfWTYmUd2YPrsvxezgVmj4ftsvvamrM8+bTQA07n//+088cveD6XxOLZojOoJV7ox6o5Tq1KIGTMv+zU99o2fVoGrP4FQrf/FrrysWxlS7KW/7gw/vuOmlqjGfnEr5w7/2utLEuGrPgASw6FANdKmjwT82ood3Omf0rR8WCzG4J1Hbm7BgpmXZSSJF0uFBW29y7J9GyTiVyfg2O5dI2+mUr8ONotHpuedU1U8t8FxH/TTP3Hb0FhYMEgAAgKaQAAAANIUEAACgKSQAAABNIQEAAGgKCaBtEl5owSikmZe81INu2qC2/SRR51soY2kQTFQSheEyw6vd+sKzmCFnipl0GxdMhAZtxPCKjJejwisxXu9GWAjH3+EGYdvhh962U8vr0ppGs8kW7EokSA7zANrm9HP7p8YussgpP6Ztn9r/wx987TOqPdum3S++4XW/0PRlf6ZlTY6c/85nPiR4zKRNIYyNg5nQeQDk4PHi+KRnxmWC7Tfe+uKf/gW36u+tnc786J6vPHn/N1W7Ga5jbTiXuznJZZyZ2jcIq8YMtGjn1r50yorehhA817s619UXnC9GR+DcWOlioRJ91Sxl0Wq5dPHYkdDk6QlRETzuWMo+brzyqlQ24+utMETKtl73otWZNBeUjxqz0+mHvvx3h374kGrP9nO/+/9d+aJXqsZ8olH+2L4feY5/PqOc3JfJbLrqBnq41CJYcJgItvie/cEDn//g+1Vjtpt+4mf/7bs/oBpNKVw8/+FffwP3oiZ8Eno1XjYYPhGMnDxXLpZ57FuBm1/3lp/8td9Vjdn23PHX933u46oxd8yolu0dhzpfrtqRansQthuGUXZpR8N/dYnn8Y2bL1s9OBj8vnL6S7s2qSIajXTlYvHQ/mcaHLHYA6mYRvjEN0oAH//Ib3TmUqrd2Dc+8aHH7/qiasy2YAkAljJMBFt8NDpPz8byB52NqpWaRe8efNsMDRqzarfhIU+eE4iYqduOujGCBsQkYckQodFhG50pFh1dKYPyYNoMiYxJG+GMzt8TRONu+DvcKNR+B9gpizuJPjxJOHca4BIkAAAATSEBAABoCgkAAEBTSAAAAJpCAgAA0BQSAACAppAAAAA0hQQAAKApJAAAAE0hASy0YMmBS6K/szsJIURsHQiF1c2aA1yPhCJ6m3gmcKOKb2UmXJ6M2lIY+bXCCTgur1Z5xWk+ylVvYsoJiUmnWHITdkN1OkwqZaufItFBUz8FRDzrQGeoBbTQTh146ntf/Ixl+0u7uE51+00vvfE1b1LtpkyOXbzrM/9XxI6/zJw69YRbHFXN2To3Xmdle2jMUO0w1NsdN7/shlf/jGrPtu+he5647047+uu/mVEuiSeeOq+aMzDagezqyTXXJ0lGE+MFz3FCE1dXb69lxZziVB3vxms3bd2yzvOaHCIpi9LRmBy/oNozmIyNFSo/3DdsmTG7Qi/CibHx0MSZTtu/+I7b8vlMdFkjZlqj+x+eOPUYM9Nq0TTPdW792V9ev+Nq1QZdoRgcKJ/7o/9w8PHwypHv+vDnB7fsUI35dGF06j/+zt9w7n8G0pKu7s7N27fTOxq1qBHGjh04MFUoBGtM0ri8bdeudDodXQ+uWPHe/JqtN127wXVbOkeWb6YCTNM8eXrs//3TE+lU/Fvtw/v3l0ul0O0k9Gu/9OpXvuwq1QAIQDE4mCYEjZmh4Trh9dzbzqs6jHNT+MMSHhNcUB6IJT/ZaDi+J9uC4B6946CT75bCdb1g1P7zEnRCfkqkOt2C1osJgm6QAAAANIUEAACgKSQAAABNIQEAAGgKCQAAQFNIAJpyG3/1vAhcl7nwhJAXg868zCY0aB2n6lYqTqUcEuWKV4qLYoU2M3/7y4QQpbL/ToNBXXXdwO6pSHptjx036QHAB/MANPX9b/zzuWMHTctS7UuEeMmbfrF3zZBqzqez58b+0+//PQ2Rqj2NhryBNX27b7ouycA8MTYik1ng8nlacP1VG7OZVHD7M3me2Lapf8NQD+UStah9GGPjhdIT+8+asRPBhPGd+58eGS8Fp4xR/8eGLya5TvSWF+28+sqQCQ2UKG+4dsua1T2qDbrCRDBYQholANfxLtu67uU/8TJ6MqpFjdVmToUMr7T4tmv78xk7OgHQn9LQPx+jfx11z7JY7H5wIf72C3tPnCva9qyzeNoxz/Oe27fPqVZbmSN2+3te96Kbt6sG6AoTwWA5kAOmnBtVH5qjo/YxSTg6F5aTsTy6bRyy5tB8jf6E0k+tG3FR64Z0acdqUV+qttWC2LcgoCckAAAATSEBAABoCgkAAEBTSAAAAJpCAgAA0BQSAACAppAAAAA0hQQAAKApJAAAAE0hAcCiMU1ZKy1UghoQz2MsLMLqQyxlas/95HK1BkC7IQFA+5Urztj4VHRMTpbHC6VUOh0MYtm22lYcz+OO4wXDdV21xrLADDtlpdO2PzLylvIZwHxAMThov69947F/+uKDmUxKtcPQiW06m1132RZ5uj6b4KKrJ7dj5wbVjnT40JmJybIZ2Ai9vfiNt+3u7sryJVDdOhad5e/ZO1woub6aPfQ+xnHdu75yz0RhyjSbP117//te/4IbL1cN0BWKwcFCqDoujWjlshMd1aprWhaNa360jCV9ZspicC53XVlPf2Z4rre8PjoxLRZyLCx5MNQaAO2G5xa0X/LCxaEfcMsPvpP/I0DtrugeQ9R+v2w02Os5HAqAOUICAADQFBIAAICmkAAAADSFBAAAoCkkAFg8ovbvvWHa8g+f7NKksOhQqy8yLgzO5ZcDzwpOt2qFWOrYhcGlRBAKTwtYJEJeqp/Pp3M5f9DCdOQcgiRo2CxVvGI5Ppylcb1oZ87q6bC787ODluTk6B12tZRfKp3O5nPZXCDyudHx4vDFibPnxiLizNnRkdFJtS3QAyaCQft98auP3vGVR1SjAc/jqwf7Xv36VzY4A096FefBA6cmCuXgl57Tn1919WWZTIrOf9WiMK4nrt7ctXWow1vs+WKh3aSjUKlW//sH//n4yUIqFXW6xj1vw9atPf39nN5HzGaa5pnjR8cujtAPalEYerdxw3Vbfuf2n1JtWHEwEQyWEDlmyw9hQtVXaUnt86UkschDf536PCoY6vcJ0Krq6M1Cv6FdlJ8mRYZcbTnMmoY2QgIAANAUEgAAgKaQAAAANIUEAACgKSQAAABNIQEAAGgKCQAAQFNIAAAAmkICAADQFBIAAICmkACg/YQsYxnH47wdNRhkrQOzVvHAr/7cXgm1DRIcTUkWfACYCxSDg/a7Z8+Bu/ccVI0GBBedXbnd12+noVotasqj3/vhuTMXLct/KmOa7BU/cUsun0tQDK5z2/rORS8GF4oOTrXqfvRvHxoeLVtW5IESRjqbse2QKqq0kdPHjo4OX4wuBkeu3735P7//jaoBKw6KwcFCSKUzHZ1dMdHVlc3l1R+0oDQ1OTY8Mj4yGoixJVLlrTVyF3L5Djpc/gPoi66u0NEfIAISAMwHGnsTUau3QH7WY9GpbVBLbyyWFHWw4qi1ARJDAgAA0BQSAACAppAAAAA0hQQAAKApJAAAAE0hAcB8YML/vbshAQnJYxU4eoFofEDrMy3qlwpFWxHz5iA5TASDJj362ME7vvJoOm2r9jS36m65Ykv/4BDnnlrUgMlYJptWjWbd/+09J46etW1LtaeZJnvDW16b78jLYa2xJT8RzHBcfs/3zxYrXvSEOcu0nt134OC+o3bK/4gIwftWr85mc7Hj+85tq9/55htVA1YcTASDthkbL548dfHwkXO+OPjc2alytaMjm8/HRDaXUduCRgSdozE6UPk8hf8AzoqOLDN4YWx8qlDwxcR4wbJsuVIuJtJpPCJ6QQKAJtH5u/opqPaJRBJqfYhUP1S12yi0JqM3PoEg0xuJV7tD0AUSAACAppAAAAA0hQQAAKApJAAAAE0hAQAAaAoJAABAU0gAAACaQgIAANAUEgAAgKaQAEBrgl4DtQmzVli09n31yw9bQd+jCUkgAYDWaMQbnXCOnyueCMSxs8WpkqtVDrgwXLj73ie+/Z29vvjW3T9+at9xtRKsIKgGCk2ikeIzn71PNWaolJ2XvPLGnbt2el5MNdC2aLEaKOFceLLmmp/jiRfs7LlsbX4RC4VSr1xPPPDExXKVx1QDtay9j+19/JGnM5mUWjSNc75p+/bO7u7oQ0Hvd6YmCkcPHKzXDvJ50Qu23/7u16kGLE+oBgrgR6kiZTE7ELSQxtxFG/sXR8Mkkw5UmYYVAAkAAEBTSAAAAJpCAgAA0BQSAACAppAAAAA0hQQAEE7Qy4P5p4bNOSxm22bTYdXDskz6Xxx5+WboRUtCXuI580siG4ZuM9+0h3kA0KQVMw+gEc7F+lXZvs4Ub3YLNJ46VWeyMNX46soYzGCux3+471Sl6kUPzjT6Hz9y8uTRs1bgUNAR6Fs1kMnlYucBVMrl0QvDoWngZS+58t2/+hrVgOUpOA8ACQCatOITAPG44GFzxBKikbRQKD791EnqjFo0RzQUc887uv9pSiTRp+fCEKmUTW8DVHs2TtlMiOhO0GGiuwidBUaQAFYATAQDmAOrwRyx5JGyWT5rNR25jJXL2plsOpNNRUc2m240+hMa1uVnRJGhPkQCneDxBgDQFBIAAICmkAAAADSFBAAAoCkkAAAATSEBAABoCgkAAEBTSAAAAJpCAgAA0BQSADRJGAY3WGgIZgpWv20yjGTBTLpt9LWNTKoVOFsIdEehIfvJWgxBu8joaMcEHXPfH16KKjfKrlH2YqLiGa5gTiBcYXjNV8SApQu1gKBJ3733R5/7+2+rxgxO2bnxtusvv2I7b6EWEBeG49GYFoexPfc/dvLERdv2n8rQ2PvqN9yWy7dUCygpIRgP2VnKUJMTpcMHz1Jn1KLGUpQq5CA7q7c0eHPunTp4yI2rBUQcwV0RctDoAGxcle7MWjGHgjHX5ZNTTuhQf+21W37uLS90qqrZCOW8ztVrTNNfmgmWAhSDg7Z5+u5v7PlM4AlFY7fHN1y2bt3gKs4TjOBhaKQrlirPPntUPj8j0Znxj1O3DLMOK+xdQJJht3V03m2XSp1PPmuE3p0whBefgWiXtw4MpazwL16XA3fcNui9xtmJkYuTY/S+Qy2aNnXC/cDHb9y2uc+L7An1oTA+cfCpA8GKQJTJxsYmDh8+aUUWCxKCZ7u63/pnn852dqlFsJSgGBy0Uf2TCX9QCpAfVwjPoLPR5sMzPNfgTnQIum18Vsu5WJgQHhdVT1TCoko7whMFp7cRQr73CQSrVSSNDsJknggLJ+LDoUDQdnxLKOTmaXinXY0KWklmfbpHWCaQAAAANIUEAACgKSQAAABNIQEAAGgKCQAAQFNIANAkZpozr4S5FIJuPY+7LveaDEHhum6l5JZjwiuXHC4vcqmGRcJrX2g1ed1SS8FEy9RhXWw8TO1xFfVrjWAlwTwA8Bs9ddwpleTg2JidTh99dM++u76i2jPQ0L9h+/bBDUM0cKhFc0T3XKm6J8+NqssbG6Pf7xvuHaukTBYygJ4Z51U3ej/kVatpZqZbmLgkDGaVy7kDx2LuKc5Q72q7hW4wxs4VLg6HzgM44v7Bp29KMg9garJ48sgJSu1q0TSTsQvDo0/vfdYKfPm+T7qj8+1//tfZrm7VhqUEE8Eg3pf+8PYLzx1QjQboFH/d0OoN69cGR3lerWx48csHr9hF5/JqUVNoPFI/RTpw37cnTx1jwSlUwrjz24VzxzwrFbUdOrld1zMw0NlLp7hq0fLUegKIYFnm0WOnv/WFu9K5jFrUABLAUoaJYBAv4chbEzKg0KLaBxqtjqe1z0Xi0f2E3pNaSPtCexMRtCYLe/sAM7Tj8YSlCAkAAEBTSAAAAJpCAgAA0BQSAACAppAAAAA0hQQAAKApJAAAAE0hAQAAaAoJAABAU0gAAACaQgKA5ay1+muawbECPxSDA78v/5ffPH/oWdVoYLoY3BrO/c8fz3U37Ny+7rINcdVAhWFnjNWbVGsWZjhlY/i4akVhB/c+OTEyagYKWAphfOPbhXPHuZVSS0JRJwd7Vw109MiyQk2hYbXiOWfGh2tVh2ahbeYz2TWd/Q3qFbVTRDG4SkG8/ddWr1+XCz5YMwnOu3q7hzauCx4KOrzHjp3+1h0oBre8oRgczD86K6fhuzwRE6UJo1KslRkLoIFUcP/6jaK1mqPtwLgQU5VSMCYrpYrrBPLCQmO2MTVRnBwrTMRFuVhSfwN6QAKAeSBrcJoJInJoTLQR+Y0uav3FQz1gzKRz8BBqlUVmUu/orUEk+TUAS6W/sECQAAAANIUEAACgKSQAAABNIQEAAGgKCQAAQFNIAOBXv3SldllL46hdMSKEvIzTF/KSd/lDnNpKtTuc/ptLQTf0fwk2UltNbSkYC2MB76p5tSM16+AEo37Ya0c0jCHoQfc/DWYH/bGJS4mWFUwEA7/JixfcaiU4rWkmK50+tOeevV/7Z9WewfP4xsvWDQ6uipl2JHgmn99y5Y7gpZK0pFQsHX36mSRDyQOPjJw56Vi2aj5PGKPD3K3GbCNiIhh14+Lk2GhxgsY2tSgcJUJeDZuOwIXoyXVs6Fsb3HhytJGTo+dc7sUcC8Zcz/XCJt9R166+bqq3uxrTC2FYKTvbkQuuRne97pobdr/xHdxx1KIw9STRtXqtaVpqESwlwYlgSADQpH33fPOBT39ENWbwPG/jxnWDawdiE0CuI3/FtTuDmYZG3uJUcf/eZ6KTkMSMb3938shTbiobsqbMCnEbiE4A5woXL0yMBufWBgXTGGlTAuDPXTjpeHEJoEEfCOWOy3eMdncVhYjZBvVTyBQSstrOl7/m37z3t1UDlifMBIa2oaGCRpxwsz4YaBD0n0kDTW0mV0jUVpq5fmjQjWnYaWal6OzVH7GjfwLyLpJQq88PeURq/0VTa4epzZmLZ9Kpu21bthUMUz5YsNIgAQAAaAoJAABAU0gAAACaQgIAANAUEgAAgKaQAAAANIUEAACgKSQAAABNIQEAAGgKCQCaxF1P/RRCzimtfclgdJi21Qj9yrAsFh22JeevqvtsFv19bU6xX22hWqcFCSfhhqt3rB1TmlvlVavqJ1hBUAsImnT+uQNHf/CQafvLsNHAPHH80OTJ56Lr3wgh0pn04GXraHhUi6bRglLRPbB/RLUjMGPfU9XR87zp4mPUja5sviOTC5broZF3olycqpTkENwU2mY2le7NdwU3npQsucovTo7zBFu45uXXbbluq+f4E7MQbGBVKZN2m+6F4N6qLdu33HyLasPyhGJwsBB++JV/euQfP6MaDTEamdyw6pI06JXKuf1PrE1y5pvuoHcS6ufm0OjcaICunX+3dPotCy1HFsWLx+gNSqI9fOef/OqLfvolqgEQgGJwsBCE56kPcqKYlm1lctkGkc50sWyCaHH0JzTE1z6wCtHi6E9kWbsWJRv9iVsNKUkNEAEJAABAU0gAAACaQgIAANAUEgAAgKaQAAAANIUEAO3Hw74hfeGZ8oslZ0w7axBLYp6V7K2/Y5dCrRHHc3EVEMwN5gFA+51/7tmzz+4z5ZeyN4Mx4brW6GhWtZsiBP/kn39qdGREPskbE0Lc9qrbbnvtbU4lZEbCguHc+xT1dnQ02NtMJvOu3/qNjs6O6C/Z55535S271l2+XrUBAjARDDRyzS0vOXr4KD2jVTsc+4MP/Pbv/cf3q9bi2fXCFx0/diLQW9bV3XXoxz/M5/NqAUCzMBEMdOF5XqdIdbJ0J8tERjrlLP6rwHGcToO6GuxtmpYXiyW1HkBbIQEAAGgKCQAAQFNIAAAAmkICAADQFBIAAICmkAAAADSFBAAAoCkkAAAATSEBAABoCgkAViz5bbwJIq5WxEJIpVKyv4G+1UOtBNBuqAUEK5Pnea945b89JqvrxHj/+9/7m7e/WzXarVAoPPfcYflCi0S9ffd7fuv8+QuqPUNXV+f93/3mwEC/agM0C8XgQBc0pP7Uz/zKiROnVbux97zr37/rN/6darTbvffe/453/KJqNMYY61+9xTTt4NuRzs78nV/92/7+XtUGaBaKwQEsKDaH7xqgoX/xP4wCrSABAABoCgkAAEBTSAAAAJpCAgAA0BQSAACAppAAYGWyLMucyyU4ABpCAoDl7fHHf3Tvvfffd58/aOEUvkoXIBImgsHy9spX/uT+/c+oxixsYPVm05IlFtSCBuZ1Ihilop//+YQTwTbXJoL5YSIYtAsmgsFKk07TEB8BU6sAGkICAADQFBIAAICmkAAAADSFBAAAoCkkAAAATSEBAABoCgkAAEBTSAAAAJpCAgAA0BQSAACAppAAYDF5rRE1alvhFqIgKPVBdWg2+hXnvL4OwBKEYnCwaE6fPveu935AtDZE7t/3o8mJMRZS+ZkNrNliWSHl1Xze/a5feNevt1QM7tkDz73/t/7IMv2nU8w0x8ZGDuz/IWMxZ1rU/4HVW8yw3nZ25r/+1b/p70MxOGhVsBgcEgAsmmPHT/3UT/+yajRrbORUpTwRNsKyVWtoSI2vBtp6Anjiif2/8Iu/qRqzMMcpjVw4mjgBhPQWCQDaBdVAYQmhk3YzcNa8LDX45hm5OCb7+MxtbYAWIQEAAGgKCQAAQFNIAAAAmkICAADQFBIALJq4fwEWCYJuarf+5fVYIKZZ/9def9TmKNANTxRqY8//+aUIXmAK0BZ4YkH7OY4zNVWMjkqlOlUsqj8Iw5gVH6YMU4YdjNpmaABtXrVa9XU7GLSzxWLZ37Fa1DuWSudjw07layv7t0BhGNbkVKlcrvjudz6C7kXtOegB8wCg/f7+s1/8+Cf+PpfLqnYYxpjneWNjBdWegc6Z0+l8d9861Y40NnLKqUyFXYjJEl5jGjEP4M//4tP/8oU7s9mMajfAzDQzu0SDZFN7HxAvbC4bvT4ZF5x548LwZGs+OVXnpS994Z988HdVG1YcTASDhfBXn/jsJz75D6oxdzIBZPK9/RvpR7WoITY2crJBAkgqIgH80R//xRe/9E3VaKDW247egQ30k1rkl7BvoX/OhOAjF45y7iTeTvNecstNH//oB1UDVhxMBIOFwORn4q1LcuJM6yQ7wW6KlfzD96heyE4miFARv2q/FTIvDxLD4w0AoCkkAAAATSEBAABoCgkAAEBTSAAAAJpCAgAA0BQSAACAppAAAAA0hQQAAKApJABYTLPKYT4fnuC+JY1Drun5F9ZC3ccy4ev888G551Vdt+rFBeeu/2+nYz6nS8MyhlpA0H6f+OQ//NUnPqsaDQnTTHV0rVKtWUQqne/r36BakUZHTjrVYmidnKmJ4SQldCJqAX3wQ3/5L3fcqRoNqFpA/etVu0mss2uVaVqqNYMwhFMtx4/gjJWKY5VSwQh8AT2jX02NVqul0HpzM7301hd89CP/UzVgxUEtIFgqaECj8S6b784FIpvrzlHke3P5nrjopTXl+sGN5Ltp+8vmxJcZtb0I2eV8vrend11P31B09PatpxQSfjzz3ZadlqkEYDYkAFhUdP4cSv6C13+MxGtrhog/ZV5iVL/Dzfo8p0HUPzcLsewOBSwYJAAAAE0hAQAAaAoJAABAU0gAAACaQgIAANAUEgAsLtaYmSzCySsrk3FdV/0U4DiO+ilORE8SqX2FPZm9a3MM+U2cansz0TLVyziValX9BHrARDBov2QTweSgmcl2ho3UwrRS2Vy3akUqlwrcC5ntRQPf7e97x+rV/Z7nqUVh6Lc7d27btnWTas+2b9/BY8dPRn9Trm1bR4+d/uSn71Dt5jAjl+ulJKCac0fDfKUy6TrlsONpvP2tr9t9zXbHaZjqCOdi7ZqBG264RrVhxQlOBEMCgPZLmACIaFywQfBEtRwaDZqWZX7rzs8ODq5R7fn0zLOH3vK2d6tGs+ShaO16/YiT/Y9+5I9f9tIXqgboCjOBYWmZ9QnG7DAtO0n4/upS0HO7Wk36AU6LqlXXd+9NhGn6d22uwUzLt81LEX3uD9pCAgAA0BQSAACAppAAAAA0hQQAAKApJAAAAE0hAQAAaAoJAABAU0gAAACaQgIAANAUEgC0H/cSVXGYV5zzBfsixIRVKxYRHQ31E8AMqAUE7feNb37ni1/6ViaTVu3FYJrmf/sv71+zZkC159ORI8f/1//5K1MW41yKHMd933vfed21u1QbdIVicAAAmkIxOAAAUJAAAAA0hQQAAKApJAAAAE0hAQAAaAoJAABAU0gAAACaCpkHAAAAOsA7AAAATSEBAABoCgkAAEBTSAAAAJpCAgAA0JJh/P9OP/is8MOeRgAAAABJRU5ErkJggg==\",\"altura_mm\":30,\"ancho_img_mm\":55,\"institucion_id\":null,\"banda_color\":\"#1a237e\",\"banda_alto_mm\":1.2,\"info_extra\":[],\"mostrar_tipo\":1,\"mostrar_resolucion\":1,\"mostrar_fecha\":1,\"mostrar_ubicacion\":1}','2026-05-05 14:31:57'),(179,'membrete_notas_tac','{\"usar\":1,\"imagen\":\"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAUFBQUFBQUGBgUICAcICAsKCQkKCxEMDQwNDBEaEBMQEBMQGhcbFhUWGxcpIBwcICkvJyUnLzkzMzlHREddXX0BBQUFBQUFBQYGBQgIBwgICwoJCQoLEQwNDA0MERoQExAQExAaFxsWFRYbFykgHBwgKS8nJScvOTMzOUdER11dff/CABEIAYoCvAMBIgACEQEDEQH/xAA1AAEAAgIDAQAAAAAAAAAAAAAAAgQBAwUGBwgBAQEAAwEBAQAAAAAAAAAAAAABAgMEBQYH/9oADAMBAAIQAxAAAAD6CQfhv202sbGvJPOtJsaxsQJNAbGsbGvJPOsbGsbGsbGsbGtJsQE86xsaxsaybEBNATzBE2tWxrRtaybGtGxryTQE0BsaxsaxszrWbGtGxrGxrGxryTzrSbGsbGsmxrLsaxszrWbGvMTQRNAUWp19u1qybGvJNAk86xszqzGxGeWGEs1BPNmtsGvMxrbBrbBBJEWY4pNbC7GsbGtGzOrJsaxsaxsQE0BNAmxrGxrzE0FTYlcQQyrDIwyMZZMMIyjjGzQYp51q2NY2NY2NeYmgNjUTa1q2NYoo46uyedaNjXkmgNjWNktJLKszlrNRZcUyXVPNlxTFxSF3FPMWcV2N3tGZZoMbNBGxrGxrGxAk86xsaxsa8mxrJsay7GslqVNswuSorLykLylnKXM0hdUkl1Swt2NTOK0q4xu6MGGU0GN2NeUmgJ51jY1k2NaNrWNjXgpovQ65IiSOTLCM5iiSIkiJIpJIiSIlmAmhmMsDOYokgNjWjZiJJIiaAmgNjXlJ4jVLVbhOxbcdmYZ0ZSzATQE0BNBE0Bsa0mxryTQE0BPOsbMQyk86xsaxsa0bGsbGsbGvJNAk0BPOsVs2Xt7K+d+bNDcNOdxNLcjS3jRiwNGLArLLFWjbS1FiON0sxwzkixs0CTQE0BJFEsxG6ejO3XYaM3HdnTmzbnSNzSTbjVDHLfDU15GGvOSKJIiSIkiiSOTLGIkiJGzLGDbLLHQsZSssistCqtEqrQrLWIrLOIrtyXSnjCxUnubr6hlL6jlLqmS4qZq3iqLWaiLanguwp4xys4rsMrCujbGDGzQSzQE0MxJESUOJ24dlcNyuF2osMpIklmAmgxTQVNESQzEkRLMBNBJNATQRNESREtmlZdzRZ4XlJZeUiXVRZbVcllXJYV0thXwWVSONt4qsLZVkVkHqdk0BNAk0RNBE0BNATQRNESzBE0CSRLNFEkSSREkSSiRJESRRJHJJESREkUSREkRJhGWCZzESREkUskSSRRLMBNDJJESRRJESRRLMBNATQJNFEkRJEVkHsdE0ETQySRRLMOuZ4dmeRejbtXLoZ5t8kUTQEkRLMETQE0MxJESRE0CTQSyzAkswE0MxJESRRJgSRJJFEswE1LbZYQY2aAmgJoCaKJIiaCSaAmgJoImgJoZSSKJZgWaKSSIkiKjD1+mSIkiMuG8Z6+T6Ax8r8z2cfK+S/U/gfp8HuvdfjL7A8n0ryGryvS3uD5PPG0g15zQGxBE0CTQE0MyyRJJESzATQRNATQySRRJFEswJNAVqPJTz18XzNXfLNFhnJETQSTQE0Bsa0bEBNBE0BNEkkRLMETQE0ETREkSSRFVB6/TNFEkRKna0ZYeM+J/VHB+94Hzx7H4zyPp+XxH0r81dw15+peF0uYynDb/dOwaOjzn2/q3L+N63b2vPmerNDMSREswE0ETQE0ESREmCSRJJFEkRJFEkRJHJlgSRRJESREswySREkUSRRJESREkRNBJNDJLOrJsaxsa8pNBE0BNAVWh62/fmuWwr5N3zZ7x5H6HkeO3PorzH1fF4LqnK8X18WDOerufavKo83Xe4rt1+zoTs3Wtujvf0p8X+t+X6/wBAtT5/6ja1jY15NjWjY1jY1jYgJoJJoDY15iaAmgJoCaKJIiSKJoEmgJoZJIokiJIolmAmgJoEmiiSKpIon0278m+p5PffceuWc8PQ3kfbuDu7eg5eqaBeJV3pLKuLGawWa8LPAOgem+x+38380UfRfNezgruT47dy4d/7pzdvjHcOB4DZp+sNfj/vfgfU/MPGfUnzn6fj/UStnwfp7CuWyrZiwriyrixmtksK5bGa2YsK/I6cK27mLPgc3DbOVcGridXOYzdcj2Pj/T38ahq9vqsK+asK4sZriwrqsNGTc0o3tCN7SXdnQN7RlNzSNvUed6Jv5POOpez1/Z8LzX3PxDqWzT6t0+lS3aO4dAx7mvFer8D3vwvot0tefP8ARmgXr2az0NVnNYWVdFjXrG/zrvfzZ2+ZwftvWfW+nh8M5Sl7yfKHfq2jq4Pob5z+jOveV9B5p7v4/wCrxZ4m65e+zmrmWyrZiwrlsq2SyriwriyrJbOyt27ztUeQi+N45ItUkiiSIkiMcDz7tz6cvcT9n22VZ0ZWc1sxYVxZVsxYV8lhXFjNYWVbK2VZFnhOT8C6uPpvE7/T/oPlPKc+6dF17KmrrtbZpDdz8lr19j1dHDer9q3+V7ndc1Xke7aVi9fV3dosK+Swr5N7Qiwr5Tf1DtHme/kqev8Am/oGWO7pHcmnosK7DdQ5iuuNjNbOOdhXFjNbJYV8m/NcWFfMb2gWFflNU7FysXwnNJFokkRJESREkVSRRnp3cKHp59SzWfZdVlXFhXyWFcWM1sxYV1WVbMWFcWVYtn53+gOC6eGHZ9OvT0fMHHS95935Xz2h3PyHHJv7vyWevje5+Mex83Z1z3birnm+3ZzVlz9VhXHAK2e7nsK4sqxbKtI35rix4v7B4D1eX7L2Khv5vQsK7HbZVslhoRYVxZVslhXFjNbMWFcWFfK2FfJY7v0P07wsNyD5jGaAmiiSIkiJIiaAniI6Nx/Yer/bbLCu7MrKuLCuLKuLCvlbCuLGa2YsK5bGawsq5PL/AFjrdjfyeY3O/wDMbefT5R674Yeiede6sNu6ddy91hXzLvaB19Xd3NYaBYVy2VdFhXyavGvQesdfkesK+eT17CuLGa2SwrosZrCyr5LCuLCvlbCuLGayLKsOb9K8y9K+Ys0Hi2aAmgJ4iJIokiJoCaA4fone/PPqpYV8+usK5bCvmLCuLGa2Swrixmuiwr4Oude5Pq3b5HqvRuhxz0cta4i9t5qHpdfitHZ6l4d7P5Vq6vXpde5nn77Cuw2WM11WFdHX81s93PYVxYVxZV0WM1snQuV6T6Z0+RzWa2eX17Cvk3tBbGa2SwrksK+VsK4sNCXfmuLKtksK6Oe9S8W9l+cz2IvEzkiJIiSIkiJIiSKJIjg/O+49G+q12FfPp472gWFcWVcWVYWVcWFctng+UMel9M7Dwff4PXpWdHR523dt9D1dXA+qdW7Dw+7Z6T23isc+I7r5N6lnq35rtHZZVhZzWHX813ZosK+VsK4sK+SxVl1jLT0z2LzP0XPjsZrZ0+lYVxYV8m9oFhXRZV1WFfJYV0tjNcWFcWM1xY9Y8g7X52fpyL5XqkiJIolmCJoCaAmgJocdnOhcDpfZ8m9obVhXyu9oFhXzFhXRYV1WM1xYV0aup9yjno6NX5rnNvFp18J3PDpsZrtPXYxoW+Sex+R+j9Hmcsr55vT3tAsK46kznv4o5lGDgOvZcff8+Z77p9F6TynVrO09jqXsO6KSbopIimIpJYpkillYJiKWSCYhmWSDYjXKRfUuU8n9h+c6qzl3Bu4dzA4dy44jPLF4lyyTiXLDifOew9C9zm1tmfV0a2wa87BqzsGtsyurOwa2zJqbRqztRqbcmnO0dO7ZwHM58u7OzOHVrbB02zyfQd3l+oZ88q47PTY+WV7r9QoeeM9XpSvxGXqcl1GlHLxgvIAC9l5roCdnpzzfkJ194z1TkZ080rZx32FdVlWkb2gu/NcWVcWFdFlWyWGgWFcWOW4FhffeU+dfRfA7vRVax5fTlhLlgZR6/nj2Hz7qvXfa47Ku9jksq2SyrFsq2Ysq4sK4sZrZLCvksK6WxmsLKtksK4jwvOdRy4+7tDDs35r8ex0+e7dXR8+GXMABz3AjaDUAAAAAC3e1dI3OvvLjrV9iwrlsZrZiwrixmuWwrixmtksK4sq4sK4sq2Yv9n6S1Z+p2/InNs9a4vzrFdh4etnq1WVdlLCuLKuLCvksK6LGa4sK6LKtlbCuLKsLKtSuPLurcc5e96fPNN0eh9W4U5vR3nBv7f1XUvGF0AAAAAAAAAAAAS5jhV3dul1G7l39icRby6riuudlXLYaBvzXFlXFhXFlWzFjNbMtjGgWVYWVbJYVxZVxYzWyWFdFlXFhXFjNbK2FfJvaElhQ4maewcJwsZ5+3UOMGIAAAAAAAAAAAAAAAAAADOC7bNFdnLb+CZ7+xZ67uy385nhtl28q46d2XlQzt5qKt5qZW0qi1msLKsW0q5LOaotKqLSqLWamEuqMJORcTomnndfX9GGjmuPqseUJoBAAAAAAAAAAAAAAAAAAAAAAAAAAAMyguW2Whc7Eqpbeaa5XlFbezQLfUBfxRF7FJJbxVTGxDUYZwY4AgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAH/xABAEAABAwICBgcECAUEAwAAAAABAAIDBBESUQUTITFAQRAiMlBSYXEgMIGRFBUjM0JiobEkQ2CS0TRTcoBwweH/2gAIAQEAAT8C/wCkdu4LKysrK3ct1dXV1dXV/aurq6urq/c11dX/AKSur/0K17Xdk3/pZzGvFnDYhSU7b2iAz7xsrKysrKysrKytw1lb3dlbvy3v7q6urq6urq6urq6vwllbgbKysr8FdXV1dX7+urq6v7d1dXV1dXV1dXV+BLGO5fFOxQdbHePnfkg97+y2zcz/AIW3uS6urq6urq6urq6ur9zmx/8AOFROadmPVF4525JmmID2mOaopo5heN4PdLnYfU7kPXu3SFBhvNENn4mqOV8Tg5jrFUdY2qZk8bx3M6RjN7lr4+eIeZaQEzrvc/l2W/8AvuqWYRDsPd5NF1NpWcGzYQz/AJb19ZVn+7+gUelp29tocPkqerhqh1Tt5tKr6b6PNs7DtoUEzoJWvbyTHiRjXjcRfoJA3my+kU/+/H/cEHNducD3CABy6GtDGhrRYDut8bJBZ7QR5qp0VvdB/aiC0kEbU17mODmmxCnlFbQl/wCOMi/Rop+Kmt4XWVZpLVkxw7Xc3ZJ8kkpu95J6A5zTdpIKp66tbvYZG+ihnEw7DmnJwt/RjnBoJcbBfT6S/wB8FVU0VazHE4Y8xzTmlpIIsQoZNWXZOaWn49EVUYaeVje08/p0QwSzm0bbqLRUbdsz7+mwLWaOp9xjHptX1nSeI/JMrqWTdMPjs/ozSNSZpSwHqM/foZI+M4mOIKmmFSMThaUc/F7FPTNI1s78EX6u9E/SQjbgpog1uZUk8s3bkJ9ikrpKc2PWjy/wmPbI0Oabg99VVbHS79r/AAo19bO8NYbX3BqpopY2/azF7j8h72eTVwyPyCptGYhjnJ2/hT6WghZd8YAUjtGHsskHp/8AU5sX4JP7hb2HPc/tG6a1zjZrSfRNoap38r5r6tq/APmn0dSzfCfht6dF1GF+pO527175qpxTwufz5eqe90ji5xuSqClFPHrH9sj5BSaTpo9ly7/ihpeDnG9RVtNNsbJtyOz3bgHixz/bo0jOZJyy/VZs+KtfchTVB3Qv+SfG+PY9tvZbJI3svI+Ki0jUR73Yx5qnqGVDMTfiFNSwz9pu3PmqmlfTO27W8ioDhmiP5hwliVgKwFYCsLuMnrGQbMLnO8lLpOpfu6g8kaioP89/9yjrqqP+aT67VSVzKnZ2X5LS0l5WR8gL/NUUYkqWX7I6x+Cra11Q4tabRj9VvVNosu60xt+XmmUdMzdC347Vu92TYEqmojUEyy7Gk39UyOKIdRoaqnSL3EtiNm58ygHPdmSpY9XIWbyP36IaxvZqIw9udtqdQU07ccLrfsp6aWnPXGzPl0aLdad4zb0SMbKwscLgrUOiq2RfnHy4JrCUGge2Y8kQRxD5GRi73ABO0rTDdiPoF9ZUcnbjPxbdGn0fU/dvDXeX+Cqihmp9vabmE1xaQ4GxCqJvpEmPnYXTJCxslt7hb4LeqaGCiAkncNYeWSGk6Um2IjzsgQRcbveHaCM1uWkajAzVje7f6dFBTYBrX9o7lF9rWtOcl1XUuqdrGjqH9OjR0jmzhl+q5Pa17S1wuCqqmNO/8p3FaMH27j+TpdE10scnNt+AFymst7renMtw1RO2njLz8ApppJ34nn2Ia6eLZixNyKm1MvXiGE82f46Y5NUcTe1yOStJKSbOcfmjDM3aYnD4LRU560J9W+9JsCVMZJpHPwnaqOkLnY5G9UcjzUrsEUjsmlaPF6keQKIDgQRsVVSGA4m7WfsqH/VR/HoqotdC4c94Wi27JXeg4IbTZNbhHvZGW2jhdJyYpgzk0fumtc4gNFyotFuO2R+HyCdR0MIvI4/EqQ6P/CyROwX6t/j7DXYeQ+O1Nrqlu6T9AqOr+ktN9jxvT6domjmYLOB63mDwFc7DTu87BaNHXkd5W6DY7CmUgiqGyM7O3Z0wx6ppH5ieCiZYX5+/e3CeErGudWPAG02sqWmbTt/PzKupZXTPc9x6ItHzybT1B5qaOni6oeXu/TosQGm2wqCSjd1ZYLfmBKfo2Jw+zcR+oVMySlq2Nf8Ai2evA6Sdsjb53WjhaJxzdw8TcTvTgJG4m8JqW/SNdzw26DuKttsqSkbCA521/wCy0jO9pbEDYEXPQyl/hZZXDbbqqkjbUU0sZ3h1wnscxxa4bQtHVGJuqO9u70T2B9r8jccDXOvNbIKlGGnj9L8PCLM9eBkGF54amg/ipSdzDs6NJffN/wCCpKO9pJRs5BSDFG8ZtK0a60j25hVlNrxib2x+qjhqoZGvER2K/AynWTPObk3qtAyHDDaRwVQOyeGMkMJdd4BJ2qOdkvYN/gnQsfIJHC5A2dNP9nWW/MRwcjsLHnIKnbimj9eHi2yN9eCqPu+CnqnRboXHz5JukfFH8lHKyUXaVWVRadWw+pUEIcDLKbMH6qStf2YhgahVTg/en4qmq9d1XbHfv0VP2dUT5gq/BVjrQ2zKoh9o45Dh4PvW8FP907gbp9dE3ddye+mn5YHZ8lG98El/mvvpjt3lTS6whrewNjQmUzf5soZ5c0KOnI2XPndOoiwh8Tto5FXWkB12OzCp3YoYz5cFWu2saqMWjJzPDwH7VnBVB+yPAyxGXZjs3yRoogO2R6p8LW9mVrujcmh5PVB+CMUg3xu+SopcL8HI9NcLxA5FULvsiMjwU7sUryoRhiYPLh2mzgfPgqs7GjgqwudIxgyT4WxAY3XdkFhLrkDYFYm2xCWVmzEQqWcyAtd2gpIGuIe3Y8dM4xRSDyVC60jhmOBe7Cxx8k0YnNGZ4mnfjib5bOBqH4pT5bOCwjWB/lZTxayoZkQqvqtjY3YFq/4QHmDdNwTxtLmgptPGx4c249ln2U48nW4Gqd1AM1TC8npxNJJhfhz4CWTVsJV+EnidK5ltyDAGYOVrKlOHHGeR9qqFpT5qN2ONp8vbxrGsZWMrGsaxrGsamdif6Kn2AlY1jWNY1jWMrGsaxlYysZWNY1jWMrGsaxrGsaxrGsaxrGVFVF7dwvzWuOQWuOQWuOS1xyWuOS1xyWuOS1xyWuOQWuOS1xyC1xyC1xyC1xyVRUmR3kFjWMrGsaxrGVjKxlYysZWNYysaxlYysZWMrWLGsZWNYynOwVAdmsaxrGsZWMqq24SqaTqlqxlYysZWsRqGjmF9LbkrBWCsFsT5mjsi6Mjjz6A4t3FNnbbaNvRG0BjVYKwVgrBWCsFYKwVgrBWCsFYKwVgrBWCsFYKwVgrBWCsFYKN2rdeyZqpG4mhYGeFYGeFYGeFYGeFYGeFYGeFYGeFYGeFYGeFYGeFYGeFYGeFVMjB1Gj1VgrDJWGSsMlYZKwVgrBWGSsFYKwyVgrBWCsMlYKwVgrDJWGSsMlYZKpb1AckyzmNNlYKwVgrDJTtBjdsUb9Wb2RqH+S1sniWN/iPtPkDE+Rz/AG21GYQlYefFRTOidcfEKKZkou0/D3c9X+GP58S8YmOHkqZ3VIy9meXALcz7l8ttg3rf7oOI3FCZ6FRm1CVh58O1xabg2KirhukHxTXNeLtN/bkqYo+dzkFLUvl8m5cXH1JnD2JJAweaJLjc+4fJyHANeWprg4cOHObuNk2tmbvsUNIZx/qvrCPwFfWDP9sp2kH/AIWAJ9RK/e/i8QzWsZ4gnuGtDgVjb4gsbR+IJ1QPwokuNzxQJaU14d3mZWDmjPkEZn5ouJ59xiXNXv3cXAbynTHkiSd57pEhWsCuM+6S8DmjKeS393XOaxlYwsQz7ixAc0ZMkXuPe2I5rGVjWNYldXV1dXV1dXV1dXV1dXV1dXV1dXV1dXWJY1jKxHPv+6uVdXWJXV1dXV1dXV1dXVwrrEsSxFXP/Sn/xAAtEAADAAAFAQcEAwEBAQAAAAAAAREhMUFRYXEQIECBkaGxMFDB0eHw8WBwgP/aAAgBAQABPyH7dS/9ZSl+rS/XvfpS/QpS/YKXu3tvib3YyEIiEIQiIiIiIiInYhPCUvcjIQhO8CEIRmPib3k53BBBB1FLyXkvJeSN+1soov1aX6GBVuVFL36UpUQSQN8fRpS+PpS/TvhKVlKysrOrsX6N+9VblfzCxXr9SlL/AMRjObDMkaKrw9xJJJJYfbPIjIyMoooooooooojIyPY8vBoItiIw27MDAwMCLYiI++Iuw0/rUUX3fknt63LyXwaCIw2MNjDb6WBERdpRBVv4CrueyvtahUXwMEd+r3K9yiiyy+3soor8Bcq3Zg/VDYxrYc6vVPVdTGfePoFgxePGH2LEr3K3KK+h/sr7OiI1Vs//AHCcLdQMZy2DI+Os06r7TMsKyJyI0saf21a73Rpyh3ZeqMYT/XL7NkEnos36Ilof5caH2NfIzev1r4yzt0ZDR5gP8B8Qmy97B5wJ3H8inz7Luhm2LYrdaodLUk8+xLUJu3DGhCyqOHfsNCIh4pprAhIUS+18FqSio3538MeASPFPMcraqaI2SeL7Xsbe87yPETIIwzF0bnXOT7FLchOMirkzX1R1jzP+v+MR1Rm24jLe0xsfqsz0MZ2YjTGp6Y8J2O7mZ2jHsr7uei6sX43t8gWHcLZfqqaXvxylZtXyL/wl7+KGpN0zfYrorVCaspimSfvucHB8AXFhkj8Dq8W3h6dxKe9TYJ33U/vSqYrJPzsXR2iRe51K+h36UpSlIVm9rroQ0GaM/NjQpdW2WOrfzmcc1tR7VdxxWtIuFsiqBslMndLkl8n+REdl/pkZdjnt1uKFKUpSlKUv29qcci7sMuNVtk+LHNv0h00d4X3KsB6MeJFda7tKUpSkw4Q51UopGwe5iZolfAp+UG6ZfZ932V2Q2XSf3MnrWDM0xW58eA14Rev0+cpSlKUpSlKUpSlKUoskhcJzI50NGg6ilKUpSlKUvgLybUuHmx0062kx9xpX6oeqI7Fi1fL6D7XywUv4qHhmsF82JNkkq3khOnl0T5bCOeXV7iSRJKLuUpSlKUSwySowJskWtfgm02v8s0n1/ZgISVf6ttjKeATgTadTjMJvNRoKOI5NO+ggcVkubsdRw+FlIyliWbhe9ZlKUpSlKUpSlKUpTFHgjJl3mk80KeaGYopSlKUpSlKUpeylKUpSlOf1NjOJz/sHg5+IZnDdAsOv62K0Gcmqmh6HUZXUhSb36qxJsklW8kI51YZvKtzzqTAJzE2VTWXdpSlKUoqe5JH5iiJJRLIhv+N/LsnqwMOy3G5E99HNxTjy7E8wDq6LMSizSZJ54/4jpJvdopR+ctF5lKUpSlKUpSlKURsSxF839JpJGh2NYopSlKUpSlKUpSlKUpSmLTpuMar3otF07nyYZi99+XX9e17ELee7qYiHm8WFkdu3Gq8Ev3IpSlKUpSlKUW4ySrGux2CmS0F95NwRm/RzgPYqd9+CzZlGmPmIvP4M/ocFES8K81EN20eRSlKUpSlKUpSlKUVqTMXzasv1OCFKUpSlKUpSlKUpSlKNuflBjVmSQrXqg/U/OwfJGTd5Ti9zSVXmft3GvUx8PgyHkbYBJKsiWq3ExsBLBYBlKUpSlKUpSlKUi94dNL6v8KIhoqeaY0ne2VaFKLX6+qeBSlKUpSlKUpSlKUxJm+s1VGOnpoUpSlKUpSlKUpSlKUuObLqkI+FZfxrgcJstQbeHC2EqxAo+o9Cnq+1EvY3jsNsCKk/AeZeNdKCeIqtZUUpSlKUpSlKUpSnV7eg/q5EUpSlKUpSlKUpSlKUpSmd5Yn4ChusilKUpSlKUpSlKUpSjcjZILncpjVuhM4LGxIS2m/3DKBC645dj1ipabJO01wg7Nog8dGMe3A/t0EcslmzRSlKUpSlKUpSlKdPa9cSc39wpSlKUpSlKUpSlKUpSlJz1xeBmNM0UpSlKUpSlKUpSlKUpRc7F+Z5FPZvlj+YH68s4nHsddn0Zgr+JsXE3FSTyu5SlKUpSlKUpSlKPRcH4EWxi9ClKUpSlKUpSlKUpSlKYBuxKJLbwPxJSlKUpSlKUpSlKUpSlH3eSa5TQpURa0l6swbBJp1KUaekdKUpSlKUpSlKUpSnLqyG6vTEpSlKUpSlKUpSlKUpSlP7bTwSYuGilKUpSlKUpSlKUowaka1Bj6W7fsxb1rwYUzn8R7sBOMYBOUzLZN9Qtpr2RTB+1FSTKUpSlKUpSlKUpSlbZL8l/6VlKUpSlKUpSlKUpSlKUo/u/HgvifJSlKUpSlKUpSlKNEm24hk0vQy9y3i04xdRL2PBo0dAe29kOX5gj5MI+tV/gX2yHkn6DkbbVwcipJw8nPoeT30wKUpSlKUpSlKUpSldoq/M/uZClKUpSlKUpSlKUpSlKUh1PnwUuRopSlKUpSlKUpSlJbtt5mPj66IWPXo+xN1HmoYwj4Y+wjqC3bDmO9nqUp/c+l/8AHspSlKUpSlKUpSlKbEWLyPVh5lKUpSlKUpSlKUpSlKUpw2jLfAx37voUpSlKUpSlKUpSlKdtYkuWWSYsPztiWm5z0FhGZxdTA82g1G4l3QoimprWblKebpeWJ/UaFKUpSlKUpSlKUpxz2PClKUpSlKUpSlKUpSlKUpTkGJ5eB4gFKUpSlKUpSlKUpRu1ScMQ5L6EqWa4Ykcz+ItmCx6jQ2LS4e5SlGP5qdMilKUpSlKUpSlKUjuXwRXspSlKUpSlKUpSlKUpSlKUpUZ4fPwCtX06lPEpSlKUpSlKUpSlKUwqepdiSJ1sVQHtnKL8lKUpSu2JnOeLr2UpSlK2K2OBHAVsVsWVsVsPd5DJWb+Cti9itkVsitjgK2K2RwHEjgL2RexexxF7F7F7F7F7IvZF7IvYvYSnULeQ7WZxjjnHOMcc4/Z3G7mZnHEJJLSL2OIvZF7IvY4kcRxHEcRexxF7I4jiOI4iti9jiRexxDNDz/BexexexxI4kYM8sB62jw8ziRxI4kWtjM/m+B75+RwHAcA0uZg1G+hnfkWHbww2m0G62xCTGY+ZwHAcJwnCcBwnCcBwHCcJwHCcJwHCcBwHAcBwnCcBwEVa3W5OQa+DiHEOIcQ4hxDiHEOIcQ4hxC4tdf4OHuhIcJwnD2LjOPs3CcJw9i4zgODtS4RwhcKxb5H1yWJxnGcfZoviWPoNaiOqRjOi+Q3fwQ3fuG28320oixz2GGLw277F86Mp9eBSlKUpSlKUpSlKUpSlKUpTSz6hmMa6l9K7isX9f1KUpSlKUpSlKUpSlKUpSlOYBbevkpSlENXK9voUXeL8Bts23j9LM1COqZ/AG2upSlKUpSlKUpSlKUpSlKJ76NUPSJ7f0RBTjv3U/OhfXlPyUpSlKUpSlKUpSlKUpSlKUo+yulKUq/Ih4Zi/oZ7er8Bl7w2KpFKUpSlKUpSlKUpSlKUo9r23ThnxPKF/r7AvQ9SDPuDpmfNlgvYpSlKUpSlKUpSlKUpSlKUpRpzVeZP9xjBZMTcvUHmvUFFEr30HhlfirhMUc7FKUpSlKUpSlKUpSlKUpSlKUpSlKUpSlKUpSlKUpSlLDcXQ/lRnZ0Myd+f2JNp1M0vWJMjKUpSlKUpSlKUpSlKUpSlKUpSlKUpSlKUpSlKUojsBjLOWZuP7Qm1imI54i1MBOyFKUpSlKUpSlKUpSlKUpSlKUpSlKUpSlKUpmYeyQbeJu/bkoLWQtZCcKUpSlKUpSlKUpSlKUpSlKUpSlKUo8wE6DUJ0+7R7B0EEd3YII7SCCOxBB1EbkEk9zyiR6Q2/f1b9lZ0nQSSSTuRuRuRuRuRuTucxPY6Ow5i//FH/xAArEAADAAAGAQQCAgIDAQAAAAAAAREQICFRYXExMEGBoZGxQNFQweHw8YD/2gAIAQEAAT8QpSl5KUpWUpSlKUpSlwuelKUpSlKysrKUpSlKUjBSlKUpSlKVlKUpSlKUpSvYpSlKUpSlKXCly0peClKUpSlKUrKUpSlKUpSlW5SlKUpSsrKyspSlKUpSopSlKUpclKUpSlK8gpSlZWVlKUpS4lKUprjSlLjcFKUpSlHYgqKilKUqwRgpSlKUpS40pSlKUpSlKXCl5KUpcSlKynQpXtgpUVFRUVFRUVFLjXkrKUpSlOhSlKJh3J3OYkkknC4stVJ2LGyKUpSlKUpSsrKUpSlLiUoq8Kyyyytyt0Vuit0Vuiyy8KJhSlKUuFe2FKiopSlKUpSlKiCopSlO0dTqTtjXIQJ3IECBOzASdB8GByYKVlZSlKUpSoqIwVlKUpRCa4TmRG52Kty8lLyXkuQS9zmwOIpJBSlKUpSkEEFwpSlKUpcKUpclKXClKV41leCsFKVFRUVFKVFwUpS5KXJSlKUpcHIVuchyHMUK3NXuVFRSlKVFIKUua4UqKilxuW4UuSlKUrKXClKUpSopSlKXG40onVxpyNEjVU3VeyRRsrKUpSspSlLgrBS4aFRUUpVhSlKUpSlLhSlKUpSlL6dwuSlwpSlKUuFLznryuFV5ppPhyHjk0keFO6DUP3QpMkSSSiSSwvBeC8FKUpSlKUpSrGlKUpSlKysrKUpWVlKUpSlLhGOE4jiyCcuWq6MT4sBHguFx+cLmpcEz84k4CBFsTYTYTYTYcA48Bt7PClKUpfUrKVlLhXmqKilKUpfRuFKUuFyRD2BoJF9GlKU5ccTbHQjYjk7DsI2K2GwWKZUVFwpS56Uok34Ez8sQcRNgmwQNNjQq2KioqKirY0JsRwI4iTtgcoiVFKUpSlyXGoa/caFbFbI4ENhSlKUpSlKXGlyXClKUpSlKUpSlKV5bhvHIiNylKXGlKXD5yVIafc7iNmTkrORhufHOA4CtitjgwucbPfJVsVbFWxSlKUpS8lLy6vc+ODQlSnRM15Peo9xou9pbT5qjj9m2iSSe5H9HS8FKUpSlLhSlL6FKXC40uGpWXdli69jqdTqdDoVtgNnuXLSlLlpSlKUpSlLkpfSal2eUJr5voUrKysrKUpSlKiopSlKUpTU1NcaUpclLnpSlKXLrhWV4UpSlKUpSlKXGlKUpSlZSlKirGlKUpS4Uua/wPnC5KylKUpSoqKiouNRSlKUpcay8FLwUpUVFRS8l9OvCvCsrKUpSlKUpS4XkuN4LwUpSlKUpS40pSlKUpSl9ClKXLTWgilLs+BF3VCUeC/6mtbkaZSlKUpSlKUpWUpSly1lZWVlZSsrKUpcKXHQQiu32LrwvLO6U/CvC9SlKUpSlKUpSlKUpcKUpSlKUpcKyjjqa0Iwkqb58e6GdR09zh7pj+lSL9fW8KUpWUuNKXJS4UpSlxpSlLkuNJyeVdVvVGxuqbVUFd0Evk1Kreg8R2k+MaUpSlLyUpSkblRSlKUpSlRUVFW/r2FqnT/lpRGxeI+wGXY4L+gVHRvvQiJPh5XGw0w67f9E+ANh2jSsJjwlw6/4H2TtTb/mOfLLT6pclKUpSlKUpSlKUpSly0pSlPKodcUr3YiUDZNNPZioqJPwklIsKXClKUpSlyUuFKUpSlKXGlRUUrLmrKOz+XgC1Card3w4ZWUkmka3TFdFaM00N4pF5dJw7cNUZqvwTXl9iNbbg+bnOc4WywUBT0e+BqDTbc1PCiojqtj4bUFKiopUJr1aXLcKXJWUpSlKXJSlKUpSlKUpcailKUpSlLhSlKUpRED6mQuWx67TfT/MNAJpdpTZ/N5ZNONMYh/jME+048GR0920Ry/Cw02Rr2+8E1pCrdHhtqznKWu80DW4byoCq1/CftkSNJp1ehS5qVlZSlKUpSlRUVFRUVFRUVFRUX+BrhSlxpSlKUpSClKtylKNvpmXjSNwYybRrQqDZKxfdey/eRWSW3qcYvKFX2xcRZ9gk/bGXbLE9JEsjL8aq6+YQ8QpFKUpS40pSlKUuSlKUpSlKX0aUrKysrKyspSlKUpSlKiibpWuq8N9YNEsZ7+XWS2JUrh3cv1AQNcPo1PsO8Wpoy94kEev2/tsfo745+GGu3OvSniE405RHUCU8I0gtEl7I5MmG+qLk3z3+nZDQtH8IW6O90SznWNNmmo0/DwtdsrYV/lEYIIyhG5G5Sl5KUpSlKUpSlKUpSlKUuFLjSlKUpS5KUpUUpGTQ+PBgs/uzYgJNFqsr/wAxVNuPQflEMQn3SJmKeLfdLmUUdjsdhMst7nAnxVgYivHsYFR1nhI2/hIQmwt5DiXVSY8NXizTfGIpCJVKzhIzXUwowpNvZNHNXn5F5aq5qJ8PZjT43viDt60ADtg7HbBMqxvzHbw57wbp6KI1O8g7YIIIIIIKircpSlKUpSlKUoqUZaux8MRyU4PzDU8d/wDGMbSe9dO/zqI9Npts6ubip+Trm/pEZ9SkkbreR14CRVoJ5ZpJCbbb0SSQ2344a7uhTZT3T+axQJCSSWiSRSlyOCMRzGrbpKsVSoOl1vAgiVqSVi3CULbj+RbBF6ql5ZJ7mr1t8ZJtLp6IQmEOpr2e6InIiX90zQg9tXDZ1HkEHrXg1ivbXKpgRJgJzuuUecPyZXpwArOFqb+4k6r3eZO0hrkpOjb2HUkdsSCMjjIYwV4ex2O2Q9hrXeyHND2KX3RqEPtX02J9vlf8kjQ7e4vuCPYW0aadTRIOO9oxwYM0g+xoFy4kPrtJI1bbcSXLKX0O1o9ivsJ7qbsrXqZVk1U01uVFRUXAkyKMCda50JCSyCSL2SUSQyDqdYJMHpf+dyz3EXxiYsDVNV4f/p4MExfbrGgh6EBC27GuPLcop7P8zEKBflGZ9epPCNzsdsCzcwjTfK9vSfEGmXf3swRudvRQKKK9ANqjrBo3+EPk2c9F7JkRrx8d1nDeqEVpG3J2YvK3xQqiiiad6Qnowkow1CY5bVG1CqtAvtGoWxT29VAAa/H+hKlSzzlw0QSBY5jVxsNdpI7Wg/8ASzWr7Fyn2rJp+zFVvTPdXjg2Z+Kv34NctpnFfvwVVf7Qbzh9vQIRvjohrEolWwFKUpSlKXBxlzVreq2ef2fTzCMVdWn04q2NSHEm23wkIp1KrT5ZxCymXs2WNoUQrFt/2RmbgLr8kZNYe2p/YRJLSvT9YkhEbHURnhCTtyMJRpe6tyh2Ox2wVnAkzjSfLpf/AJda8BDhdpBNNP2aYmYor8uxLpg7Cp0vH7f6EOx2wVnAjfIO2DsQ06P4WFL6aGIqa1Qwpb1c7Hb0OEEEZB2Ox2wMCLyPdpEaRV2fQghw9Em/hDCDKG6vYThDEJKtuJLfZCm2fe9PCEr/AKUp914aqYdvVqjXa9yl3iXyFLUX3ytLX7Ia35pSVR95P2O2GCMwK3wdjybyfwi/Zuk5fCs4MEZUrcrfE7YKyCI0uWL6VJ5L3vhiRnIrE7YKyhBJ8GV9ppg0V7q/KgjNN0Q1bbcSQoKdrjVe3LdjaaZnlbKuNMIgl2/KBn5cINpLg19wsqtBR/c2+wK5V97H7UUV67AB5vp82GkcbG5u5RrIKzwRidsgq/lr/WS8lz0pSlJUtT+JlZBWQ9vVAAUW9BPdb+hRd9ynk1Yi19/Tsjjse3BQnJ/KX+xaVEnTYk4wtpR1eGnDT9wTmhqrwzt6IL2O2YGoBRdbAsb0Q9JP4BjBgjIYEaHypfLcFL/CJLpKFKUvqySuXyhRWYMEZHGUEHjWWknhWwz9xnxyCJXgcjRpt1+cEDLUR3p1LF7EZHB1OvogGpvgu0jQGpK/Rdjthoor1MxdjtkKJHZH+F9alKUQ3br0QDtg7YKKyBAR8mPgcdGaY8y18BTX9p7tymM7K0l5VVgv/wC7W4PZC1JDJLSvpHVoNP3TQlbal0NuVgRpUn0zEKHU0mumdsFFeiCdjtgrBAnr+BYrPiXyUmYEb4KLwUUUVkEYkH5L9n8L7H6sn7HY7ZQ7ZgIQoTbbiSSHtFe8L4MeUXqxKbTvuLZo1KtE02nDe6atbfCQ0LD7tNK5Yi6V0vNcCozWjeV4CrQZVrWJIOeRUm0/arwyMGjPm9/2ao1w/eeArf0IEb4ktej+5oKdeX/jNBWcDt6QxS3u6/CehSlKUpSlKKU2f3fQBQRnA7EMx5Vq8tjwrry6H0hgybZL9zn2Nv3fg8MqN0xg0q1qOGOKYANHSbXZVfvFjflH4KXL1ZOPScx2Ox2IIyHVio/VpNA40j7avRAO2JBHpGD/AM6h0SImvDRSlKUpSlKUpSlKb5t+KTIO2CMz4yDtgVs4iPuxr6hqZGiUW9BIiK9tJw2/dl65350lS51PPtzjw0xUnQIlhApTpCdrAsPSytv2aX6NS9K/OaisTtlDsdjschTXciQ7ysE+mKEovQ4dsHY7ZB29GcQxdL5PQXLS4UWqnVpO15+8g7HbIO3otkQL7w000V20twJ65+TRoVDxEJkeJDW1ob3U01qk0aTRYZ+imTUaeo7HbAyaafhjV24m9h+qeQgjEhb1u+hsC/5vTE7HbErKEZgdsTsdsFCPG2lwvgpSlKUpSlKUpSmw/F3bwNhs629WV6wCDsdjtgaZ9KE0nw/7FjsKankajtfdNRsefqv0YmMFE3US39GueqPg0ZSiisR7I42AcU4xxBo9kcY4xtsiUdz1UldkpxjhY5nGOIcfDOJgHEwbhnCOAcI4RwjhZEZOEcMTEJNNNNbr3Q/Hoa/tm7v3f+28d3/uPN/d26sQqPd7nGODincbCOAcA4JxDjHBwzinFOKcU4Rx8I45xBDEkhcNVX9nGOMcbGKdyCpvOSHk9etsiqpoVpVyyt+G39KEnEtuv7PB8M4YgbRJJatlVHcVB29FdD6G2xkm1ceV8piQmjR+DGMPLbb5bHlTQfYcM4ZwTgnBOGcE4Jwzh4k8M4JwThnFOEcI4ZwzgnBOOcMUj0Tj7E5LMzyvdtnyvV3/AP8A/szOpf7cp9ltOCcY4BxDjHFOKcU4hwTgnAOKcU4pxDgnDOOcQ4mMQ3DJ2bCc1T8vDOCcE4JwCJEUvypSMmom6emxQiPH96eWddIPI/kDTUfeV1ds6L5GLSV6Los3iCZK3/XwyXFPbU+yWdvWAGRg7HY7ZgJTq8p4U8EBa0TMKUpT5yNEm2iSrYsrr1S/tc+TXXfWJgdjsQQRmbyWTuVF3etV1lA0mtKbNpX6OyOTyg+M2dbfpfRCyLe6v6h/YN/ZEWvtoErSd9AR2x6yCCCCMgbKCpgg4YavlBcZ/u1KUpSlPiyhrzsa88n57e+CCCCMg7HY7FFFFeoDP2Hai/NR2O2C2Osu8tedW/Qf+Gf0v4DJa2/4Lj7Wz2eCseiiivTAntkHOf030SklcT/KhAr3f+5H/fQt5vaCj27P6l9W/PiudGDt6FeMSMEEEZwKx6/zSDIF0ZK5rjRo8qPgLKoHblbQMht93/K0xn9PhmitI1xHY7ZQ7eqBh2yCiiv4gMATsdhqjbcRetttR5/zsU4qvYl9ulP5pn/gkKBrw0e0cQLE1NcYIwdsEZTr0QCDsQQQRlasHYrfIIIO2CMoTQQqKTsY0vaP/EN6k+BF4F+Qx4ceCCMpdswKKyhBHogHYoorKEYtrzbLVlpKXd6seVN7t/46PGE/AxqUR4JPkV++QV/BAACsSM4HbB4qQnaPl6F2y20f5VNrw4L3D5F7qTE/uEwTvdfkggkjJVJByHIjkRG5yHITgnMcmBBBOw/KaGrwqN2EjzbfGi+v8+k+45DjRYgcTEPLkWHDOFk6neRsyw+BDYGz8u//ABR//8QAIREBAAEEAwEBAQEBAAAAAAAAEhEBAgMEAAUTFBAwQFD/2gAIAQIBAQIAMRW2IiIiIiIiIj8iIiIgxBJJMQSYgxBrbFMXj4ePj4eHjXFEEkkmtppb5+Xl5eXl51siIjkREGIiKcfp6+vr6+rUGIgxEcil/r6+vr6+tcrrQkkkkAEAAAgAAAAW2ZLCYgmIgmIiIiIiPDx8PDw8PDw8K4K4K4wAAKUpyIivK0AIAAphpr/N83zfP8/z/NXWrhaSSma3TytpIFuG7EQACAAADbampmZSmSQCACACACSSSQSSSSSSSCCQAMeHNoAEgEgAAAgAeQAAIABAIBBOvo3dH1+x2nX0srhBJIJIJJApbfQEAAAAAEgEm2mpu58G/rYNXJ2O3jBAJAJJAJBJJJJJAAJJOhzHuY6cu16ZbcnY6RABJAAABJJJJJAHXddtUv0SCSa7eG+lb9nz2MettmCTBjNnz97d3Nnd6/d2XEkmCSTg18eTLqYsN121lJJJ08O3sZ82W7Uzb1beGIiIPYbufIQDp7mtmMEkkxqa9+Wzaph5dTY2YgmDGtZt8tvivCYiIjPkz5SSSOs2YJJME6uS6uXNgrdsbNuxliCATqW38JJMQTHd5DBIAOhkNbSSTEHNyuzr0x7JMGCTipBJMRERHd0JNbQAempEEEkYsNmqcldTl1kGIJiL6EkkkkR3eIkkknqcURBJNvMVZyX5a4ubFpJMRFlubhiIiIiIjs9YkAk48WHEYJJg23O/hOa0mINLPO227kGIMR+wd7UmZmZ6/Tj9iIiPyv5FttMFMHjFLf2DEREREQTfj2urrjJswanVkmCSSSbbQbaf0JiIgwScmvXrbOvtxEkxBJME0tNLf60rS6nDBMGDBiCSSSa0/wA6pfS9UryIiIiIiOVrW6tf9s0q2223P/c//8QANxEAAgECAwUECAYCAwAAAAAAAQIAAxEEElIQITAxUSAyQUITIkBhYnGBoSNTgpGxwTNQJGPR/9oACAECAQM/AOKe0eEPZWPIR48aNGjxx4Rh4cS/KOfLH0x+kfpH6R+kYeWEc149jcR9UeNG0w6YdMaPqjdeIV5LDpnUQdIumLpg0xvCOZc3PtpgvZuUoKPwyx+YtDDDDDD2hwTOsWLFiRIkWLOhh8JlNj26Q8spxIkSIPLEPk4LHkI0OqfFPinxT3w6oesYRtMOmfDPhgixYsWdFjRtUJ59j4Yr7lPraesKbjz09kcKxvlnwwdINMWLEiRYPBY0f2Gx/wBA1RwirvMxNAXqUWA+3sptc+y1sT3F3e8zFqMwyn6x2vg8Uvrju5vEdIMLVDJ/jf7HpCdwjrvNNh9OEINog2UxzRv3gZvd5fZXBXLe8xFLKmKRsh7rERaxpVU76sCre7xEbE0cg55hMNgqd8qi3eZpSOZaVFqvyG6PV9YYBqZ1C/3HbHAPs9GiXr1fDcvziVwQKDkfIWiqtl3DT02LUbNWa6jur4CYan6oqU1+oiP3WUxHQ1UWzjve8e2jEFqlX/GPvBXY0MJh1yL3mA5zE0hdqLW7RO6UsKi0kXOw/mVmXPUVUX7/AFgIBHjBSbLURgNXMShXS+VXBhwtdhTa3is9PSdanfC/vOkPboYdM1R7CAG1Gj+ozGsdxUfSYwH1sp+ko1Cq1UyHVzESooZGuDwhBHc39Czr7t0p0RZ8E1MarXmFxdPNTyhuo/uGnhBSG5stvqeZlPB0gqJdvADmZjWN6mZAfLyHatA9XM/Jf5ha1Gm3Pvf+RqFenbkF9ZZTrYd2G8ZTGo1FB7h5zPiH91oV3huAmDSw31D3V/syriKheo9z2a+Ee6tdPMvgZTxNJalNtx+3u4Xp6yqeXNpQwyhSygaYlXuUqhXVaIGzquQ/z8xse5ZEW/vM9Ir0K1Kx8re+GHadt6yX1TNXcx6YIB3GGMxJPAWjSeq3ILHxFV6jtvOwwww7Dhq6qW/DfcYNg7J2egd2+GNUfMxuTKeGpru+SyrVAqO9ge6o/uIASN4DZWlSmvpqNRrab3E9OUYixy2baOyM7N0WZnY9eEYVpU6Q87Xb6cH0+Fot45bN9OEZUqnOQ1gojCilJN3q+s0zUcQnw3jpTyFbjsDs5KLt17Rh2HaTiKQ/6+D/AMUg/mHgrls9H9UWnUzHegi9+p+lekw9UWy2PylqjL1WEMw6dgdnLRReENh9LRfqtv24AmXCKerE8AqbjnHsC1S5PlgMdBmCqRFdsy7r96ZaiGWqm3jsPauyiXZR04npsOSq7038BndUHMwUqSUx4LbYNg2DaVNxAEQDnm9aMrEA7tuZUbsLBpl4JY3gJuYIIvSCDTBBBpg0waYNMB8sTDvnFL1G+0o6JR/LlH8qUfypQ/LlHREH4zJY+WDTF0xdMXTF6QQQQaYNMXTAVDfSDTF0wNStDBEGwDsDYeGlRSrLcGOhL0vXXT4wqbFbbXqNZEuYEKvW3nTBxLqw2XNhAot7RSq99FMwp8n3Mwq7/RX+ZMRBZVsOIdgEEA5ca0HjAeyO0IO2NlvaCIRBpimKYNl+CIo8YPCE+3GMPGNDDDp2GGND/vf/xAAjEQEAAQQDAQACAwEAAAAAAAAREgECAwQABRMQFEAVIDBQ/9oACAEDAQECAIxiEYhGIAEQIxjGMYxAAjEjEAjEjEryUpSlJ5GMYxjGMYxK/FXhGMQjEAjErb5+Xl5efl5UshGMSMYxCNcfl5eXl5eXl50tIxjEIgAAAAAAVpSgABEjEACIRnKcpSlKc6X04ABWkIxhSylpwACtZznOc5znLy8vLz8vPz86YqY4UtAK1pUAAAAK2+Xl5efnCEKYvLzACMQA4BEPgB8AAAAACMQvrj2ADgAAAAHAAAIxAAAz7dO23tfrtuvKXgAAAARrbZbECIAAHAiF1u3oYM+hsZtnH1urXgAAAAAAAAAcAfnZW5dDLXlm1XBfj6vfAAAAAAAADh2O9rW49sFWmhsWVtxaXrp5NzQpWUpKt1921XYps2bVLlVX6bOfLgw7mbPZZp4AVrzs8/Xaepq4cfYanV2XUX6uTLWoBZfbeqqylvbOPBk0a7HLLtTTVlKXN7J11MmFsorKUmt1eAAY7lVV5va1lmDW2qY9PSv1ddZSV7XJiorKUpK3cD4AW3LKSyWWrbZobvM2gqqu3VVVVaUAADiqrLY2cvYUuw2dnTHerKUpS1qr8VVbOAABdxVVvt2rY6+HUx7VuhkVVc+XrbVVVVx3AAFeVrS5VWWXDXWwUeaNVQy7lvY7exgxgAAAYq+fn5+fn55bgjGMQAw0I5rq9jd2VexyZc+19x71nY2bK8VVaXY9inAuuy7CyVVVy1b8mzn+5c399fasvlKSqrTJTarsVvVVeLdku3ruxy7v8jl2P9cWazetzKqqqqslcmzm3a1/VtzW7lu9bt0z0vnJZSlKU65K7V2/fs/u0uplpnps/lU2vyvyq7NdiuV/7f8A/8QANREAAQMBBQUGBQQDAQAAAAAAAgABAxEEEiExUjAyQlFhEBMgQEFxImKRocEUUIGxBSMz4f/aAAgBAwEDPwDxun2LJvIP5BmQoUKZMmQoX2rak2pMhQpuabmq7eqFChTJuabmmQ8k3LaM/quq6p+fY6dMhVPPl67F9q6dEiRIkSdOuiZM+XjN0aJEiRIm9fC3gZky+VdF8qfkui6JuSFCmXVOiRIkSJc3QoeSpk3hcfTBM+3q1E3NfMnRIuSLSi5Ik6ZD+4sAuRZMoJnoEgu/lcfKw2fffH2VlJ6PeZvZCNLVZi+B9676PzX6mNxLfD7pmzQFgxC/kT9HZOzY5+VF2e9Sis8147KY32zBnZFF3sRbhC7EPXmhs018srrq0WySjXnruiKlZhKWYYvd8VHE7D+vGTo9P2a0TXLPC2eJeyksrs5WiNj01eqIjqeL6h9ewohuQDcd94uJ1bJfieKQvmo6kif4wJvdqIxkGCQqi+70fzr2du7j/wCj/ZPCLTWu0fGWQu+Ss0r3RmF38TNeJT22SSeQrgli1c6KzAVyEyMtWTfwnEnYvRPOF6CUSJuF8HVqsx0vkDtwobbZWKUBf0JPZZ4ji3HJv4dYNsBBqkS0ipXUrdUL4ENEztVtpHGNHtAxl1xUs71j/wAgMj6a0VrsUt2W848TP+EMlteZ8RvV92bJlJbpnOQ7o+rvkysAjSG6ZNmWbpvCz4OiihuBmeHsyuC9olHLER/KG12We9vvI7iSms1thF8H7xkFohImH/Y2SuWMOtXQm1Cav/mwuthmiJ6v4SB8ExtVtk9msxG2/kPurTbDdxYjfiJSQ788bPpripHHuze+PDXGns/YDswySkzdGqu6KK02ea+HENKYbC5ZZn+Wn1VyyRNzx+rqKVwIhxAqiXYICwjk2wZmqnJ6v47pbJ7UAAz8TXvZBBEwxtRmUttnLH3JWezk8MQVNt43/CkIgF8DMXIf49FDMf6e0QjXhKlHryei/SicbPUL1R2H+mONuIv6TBGA8hZtnXY4bOGBijExvuTvnjmhK1STSYte+Efy67u02OT5rv1UMs3fMRAfTY99bbPG3p4X8i+wNjd4rYNdNGojlgGNsJHKhUUn/Oz4ajyqrfZ3Er18OJq1V6zibcBMSYwjJvUa7HvbdNJ6NtK7HHYCY0fJRXzaOzizBmVXbFE2LCoZiaMjITfo1FJCBRHizbpdF3lnlH5Vfs0fy/DsO7hMuQqkZm/EX9bRmKj7CjVdVevYyZN4QlG76XmckRz2h3GgXaCo5gAyAb4/23bcltEPIq+CTWpNaGN6Md9+iKuLJpIwETrVSBCDM/Cpdal1qXWpNal1qTmpOak1KTUpNSk1KTWpDal/FTa1NrU2tS61NrUutHkxqTWpNal1qXWpdal1qTmpOak5qTmpOaMJpomLP4/qpNak1orNa2Ny3hQNk5Oi4WU75YIIhvESkmwZ6Bp8EoNR8fdRvvATfdQHkf4TbJxerIXwLB0z4t2iLVd6KuAbW5PAfOrfXsEBIiejMnnkr6Nu+A5SqWwKJ7pYghMWcXw2ZjkVFK2FVK/GnLEirswBqkdFCOT1XKL7o5WFnEWoVUdNxSzP8RYadtJE9RdA+BjRRnkflYo8yx0qQ8Bwb7pyerl5aUcjJSjnddC+YKJ/WiifI0L8SHmm1JtSbUm1JtSbUm1JtSHUgbMlC3EtAfVTSZn9PPE2RKTWpW4lIj0otKLkj5CpH0qV+JSPmad8/wB8/9k=\",\"altura_mm\":30,\"ancho_img_mm\":64,\"institucion_id\":1,\"banda_color\":\"#1a237e\",\"banda_alto_mm\":1.2,\"info_extra\":[{\"nombre\":\"\",\"descripcion\":\"asdfasdfadsf\"}],\"mostrar_tipo\":1,\"mostrar_resolucion\":1,\"mostrar_fecha\":1,\"mostrar_ubicacion\":1}','2026-05-06 23:28:10');
/*!40000 ALTER TABLE `configuracion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `constancia_plantillas`
--

DROP TABLE IF EXISTS `constancia_plantillas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `constancia_plantillas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ubicacion` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Guatemala',
  `saludo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Estimado(a) Director(a):',
  `cuerpo` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `despedida` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Atentamente,',
  `firma_nombre` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Secretaría',
  `firma_cargo` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mostrar_fecha` tinyint(1) NOT NULL DEFAULT '1',
  `mostrar_firma` tinyint(1) NOT NULL DEFAULT '1',
  `mostrar_telefono` tinyint(1) NOT NULL DEFAULT '1',
  `espacio_post_encabezado` tinyint NOT NULL DEFAULT '3',
  `espacio_post_fecha` tinyint NOT NULL DEFAULT '2',
  `espacio_post_saludo` tinyint NOT NULL DEFAULT '1',
  `espacio_post_cuerpo` tinyint NOT NULL DEFAULT '2',
  `espacio_post_despedida` tinyint NOT NULL DEFAULT '3',
  `activa` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `constancia_plantillas`
--

LOCK TABLES `constancia_plantillas` WRITE;
/*!40000 ALTER TABLE `constancia_plantillas` DISABLE KEYS */;
INSERT INTO `constancia_plantillas` VALUES (1,'Constancia de Inscripción','Guatemala','A quien corresponda:','Por medio de la presente hacemos constar que el alumno(a) {{nombre_completo}}, estudiante del establecimiento {{establecimiento}}, se encuentra inscrito(a) actualmente en el curso de Tecnología {{tac}}, en el horario de {{horario}} los días {{dias}} en el laboratorio {{laboratorio}}.\n\nLa presente constancia se extiende a solicitud del interesado para los usos que estime convenientes.','Atentamente,','Secretaría','',1,1,1,3,2,1,2,3,1,'2026-05-03 14:33:43','2026-05-03 14:33:43'),(2,'jb.kajvñh l qñ','Guatemala','Estimado(a) Director(a):','mf,ajsbca,sbca,sbca,dsbcas,jhbas,jhdchba,djhcbas,jdhva,jvas,jvbavbajbajbjasjjbd \nel alumno: {{nombre}} {{apellido}}','Atentamente,','Secretaría','',1,1,1,6,5,1,2,3,1,'2026-05-04 18:31:24','2026-05-04 18:31:24');
/*!40000 ALTER TABLE `constancia_plantillas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dip_diplomado_objetivos`
--

DROP TABLE IF EXISTS `dip_diplomado_objetivos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dip_diplomado_objetivos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `diplomado_id` int NOT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `orden` smallint NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_dip_obj` (`diplomado_id`,`orden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dip_diplomado_objetivos`
--

LOCK TABLES `dip_diplomado_objetivos` WRITE;
/*!40000 ALTER TABLE `dip_diplomado_objetivos` DISABLE KEYS */;
/*!40000 ALTER TABLE `dip_diplomado_objetivos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dip_diplomados`
--

DROP TABLE IF EXISTS `dip_diplomados`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dip_diplomados` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `objetivo_general` text COLLATE utf8mb4_unicode_ci,
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dip_diplomados`
--

LOCK TABLES `dip_diplomados` WRITE;
/*!40000 ALTER TABLE `dip_diplomados` DISABLE KEYS */;
INSERT INTO `dip_diplomados` VALUES (1,'Operador','',1,'2026-05-03 14:33:42'),(2,'Programador','',1,'2026-05-03 14:33:42'),(3,'Diseño Gráfico','',1,'2026-05-03 14:33:42');
/*!40000 ALTER TABLE `dip_diplomados` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dip_examenes`
--

DROP TABLE IF EXISTS `dip_examenes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dip_examenes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `diplomado_id` int NOT NULL,
  `nombre` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `orden` smallint NOT NULL DEFAULT '0',
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_dip_exam` (`diplomado_id`,`orden`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dip_examenes`
--

LOCK TABLES `dip_examenes` WRITE;
/*!40000 ALTER TABLE `dip_examenes` DISABLE KEYS */;
INSERT INTO `dip_examenes` VALUES (1,1,'Windows',0,1,'2026-05-03 14:33:42'),(2,1,'Word',1,1,'2026-05-03 14:33:42'),(3,1,'Publisher',2,1,'2026-05-03 14:33:42'),(4,1,'PowerPoint',3,1,'2026-05-03 14:33:42'),(5,1,'Parcial',4,1,'2026-05-03 14:33:42'),(6,1,'Excel',5,1,'2026-05-03 14:33:42'),(7,1,'Examen Final',6,1,'2026-05-03 14:33:42'),(8,2,'Scratch',0,1,'2026-05-03 14:33:42'),(9,2,'Python',1,1,'2026-05-03 14:33:42'),(10,2,'Parcial',2,1,'2026-05-03 14:33:42'),(11,2,'C#',3,1,'2026-05-03 14:33:42'),(12,2,'Examen Final',4,1,'2026-05-03 14:33:42'),(13,3,'Photoshop',0,1,'2026-05-03 14:33:42'),(14,3,'Illustrator',1,1,'2026-05-03 14:33:42'),(15,3,'Parcial',2,1,'2026-05-03 14:33:42'),(16,3,'Filmora',3,1,'2026-05-03 14:33:42'),(17,3,'Examen Final',4,1,'2026-05-03 14:33:42');
/*!40000 ALTER TABLE `dip_examenes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dip_programa_contenido`
--

DROP TABLE IF EXISTS `dip_programa_contenido`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dip_programa_contenido` (
  `id` int NOT NULL AUTO_INCREMENT,
  `programa_id` int NOT NULL,
  `semana_num` tinyint NOT NULL,
  `contenido` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_dip_prog_cont` (`programa_id`,`semana_num`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dip_programa_contenido`
--

LOCK TABLES `dip_programa_contenido` WRITE;
/*!40000 ALTER TABLE `dip_programa_contenido` DISABLE KEYS */;
/*!40000 ALTER TABLE `dip_programa_contenido` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dip_programa_objetivos`
--

DROP TABLE IF EXISTS `dip_programa_objetivos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dip_programa_objetivos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `programa_id` int NOT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `orden` smallint NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_prog_obj` (`programa_id`,`orden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dip_programa_objetivos`
--

LOCK TABLES `dip_programa_objetivos` WRITE;
/*!40000 ALTER TABLE `dip_programa_objetivos` DISABLE KEYS */;
/*!40000 ALTER TABLE `dip_programa_objetivos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dip_programas`
--

DROP TABLE IF EXISTS `dip_programas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dip_programas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `diplomado_id` int NOT NULL,
  `nombre` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `objetivo_general` text COLLATE utf8mb4_unicode_ci,
  `duracion_semanas` tinyint NOT NULL DEFAULT '1',
  `orden` smallint NOT NULL DEFAULT '0',
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_prog_dip` (`diplomado_id`,`orden`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dip_programas`
--

LOCK TABLES `dip_programas` WRITE;
/*!40000 ALTER TABLE `dip_programas` DISABLE KEYS */;
INSERT INTO `dip_programas` VALUES (1,1,'Windows','',1,0,1,'2026-05-03 14:33:42'),(2,1,'Word','',1,1,1,'2026-05-03 14:33:42'),(3,1,'Publisher','',1,2,1,'2026-05-03 14:33:42'),(4,1,'PowerPoint','',1,3,1,'2026-05-03 14:33:42'),(5,1,'Parcial','',1,4,1,'2026-05-03 14:33:42'),(6,1,'Excel','',1,5,1,'2026-05-03 14:33:42'),(7,1,'Examen Final','',1,6,1,'2026-05-03 14:33:42'),(8,2,'Scratch','',1,0,1,'2026-05-03 14:33:42'),(9,2,'Python','',1,1,1,'2026-05-03 14:33:42'),(10,2,'Parcial','',1,2,1,'2026-05-03 14:33:42'),(11,2,'C#','',1,3,1,'2026-05-03 14:33:42'),(12,2,'Examen Final','',1,4,1,'2026-05-03 14:33:42'),(13,3,'Photoshop','',1,0,1,'2026-05-03 14:33:42'),(14,3,'Illustrator','',1,1,1,'2026-05-03 14:33:42'),(15,3,'Parcial','',1,2,1,'2026-05-03 14:33:42'),(16,3,'Filmora','',1,3,1,'2026-05-03 14:33:42'),(17,3,'Examen Final','',1,4,1,'2026-05-03 14:33:42');
/*!40000 ALTER TABLE `dip_programas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `diplomado_notas`
--

DROP TABLE IF EXISTS `diplomado_notas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `diplomado_notas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `alumno_id` int NOT NULL,
  `anio` smallint NOT NULL,
  `materia` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nota` smallint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_dip_n` (`alumno_id`,`anio`,`materia`)
) ENGINE=InnoDB AUTO_INCREMENT=409 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `diplomado_notas`
--

LOCK TABLES `diplomado_notas` WRITE;
/*!40000 ALTER TABLE `diplomado_notas` DISABLE KEYS */;
INSERT INTO `diplomado_notas` VALUES (1,1,2026,'Scratch',90),(2,2,2026,'Scratch',96),(3,3,2026,'Scratch',72),(4,4,2026,'Scratch',93),(5,5,2026,'Scratch',94),(6,6,2026,'Scratch',91),(7,7,2026,'Scratch',68),(8,8,2026,'Scratch',68),(9,9,2026,'Scratch',86),(10,10,2026,'Scratch',70),(11,11,2026,'Scratch',91),(12,13,2026,'Scratch',86),(13,14,2026,'Scratch',95),(14,16,2026,'Scratch',71),(15,17,2026,'Scratch',85),(16,18,2026,'Scratch',84),(17,19,2026,'Scratch',86),(18,20,2026,'Scratch',80),(19,21,2026,'Scratch',97),(20,22,2026,'Scratch',66),(21,24,2026,'Scratch',70),(22,25,2026,'Scratch',50),(23,26,2026,'Scratch',67),(24,27,2026,'Scratch',65),(25,28,2026,'Scratch',75),(26,29,2026,'Scratch',74),(27,30,2026,'Scratch',89),(28,31,2026,'Scratch',81),(29,32,2026,'Scratch',92),(30,33,2026,'Scratch',89),(31,34,2026,'Scratch',69),(32,35,2026,'Scratch',81),(33,36,2026,'Scratch',91),(34,37,2026,'Scratch',95),(35,38,2026,'Scratch',77),(36,39,2026,'Scratch',73),(37,40,2026,'Scratch',70),(38,41,2026,'Scratch',67),(39,42,2026,'Scratch',64),(40,43,2026,'Scratch',71),(41,44,2026,'Scratch',72),(42,45,2026,'Scratch',72),(43,46,2026,'Scratch',71),(44,47,2026,'Scratch',75),(45,48,2026,'Scratch',69),(46,49,2026,'Scratch',66),(47,50,2026,'Scratch',62),(48,51,2026,'Scratch',65),(49,52,2026,'Scratch',68),(50,53,2026,'Scratch',66),(51,54,2026,'Scratch',67),(52,55,2026,'Scratch',82),(53,56,2026,'Scratch',69),(54,57,2026,'Scratch',70),(55,58,2026,'Scratch',68),(56,59,2026,'Scratch',66),(57,60,2026,'Windows',77),(58,61,2026,'Windows',76),(59,62,2026,'Windows',72),(60,63,2026,'Windows',70),(61,64,2026,'Windows',78),(62,65,2026,'Windows',78),(63,66,2026,'Windows',74),(64,67,2026,'Windows',82),(65,68,2026,'Windows',80),(66,69,2026,'Windows',77),(67,70,2026,'Windows',65),(68,71,2026,'Windows',67),(69,72,2026,'Windows',68),(70,1,2025,'Windows',85),(71,1,2025,'Word',92),(72,1,2025,'Publisher',68),(73,1,2025,'PowerPoint',68),(75,1,2025,'Excel',82),(76,2,2025,'Windows',69),(77,2,2025,'Word',81),(78,2,2025,'Publisher',74),(79,2,2025,'PowerPoint',74),(81,2,2025,'Excel',77),(82,3,2025,'Windows',70),(83,3,2025,'Word',63),(84,3,2025,'Publisher',76),(85,3,2025,'PowerPoint',76),(87,3,2025,'Excel',75),(88,4,2025,'Windows',76),(89,4,2025,'Word',81),(90,4,2025,'Publisher',84),(91,4,2025,'PowerPoint',84),(93,4,2025,'Excel',71),(94,5,2025,'Windows',73),(95,5,2025,'Word',67),(96,5,2025,'Publisher',72),(97,5,2025,'PowerPoint',72),(99,5,2025,'Excel',71),(100,6,2025,'Windows',70),(101,6,2025,'Word',76),(102,6,2025,'Publisher',75),(103,6,2025,'PowerPoint',75),(105,6,2025,'Excel',69),(106,7,2025,'Windows',66),(107,7,2025,'Word',67),(108,7,2025,'Publisher',70),(109,7,2025,'PowerPoint',70),(111,7,2025,'Excel',67),(112,8,2025,'Windows',73),(113,8,2025,'Word',70),(114,8,2025,'Publisher',72),(115,8,2025,'PowerPoint',72),(117,8,2025,'Excel',73),(118,9,2025,'Windows',70),(119,9,2025,'Word',71),(120,9,2025,'Publisher',73),(121,9,2025,'PowerPoint',73),(123,9,2025,'Excel',63),(124,10,2025,'Windows',79),(125,10,2025,'Word',79),(126,10,2025,'Publisher',77),(127,10,2025,'PowerPoint',77),(129,10,2025,'Excel',73),(130,11,2025,'Windows',77),(131,11,2025,'Word',65),(132,11,2025,'Publisher',75),(133,11,2025,'PowerPoint',75),(135,11,2025,'Excel',78),(137,13,2025,'Windows',76),(138,13,2025,'Word',66),(139,13,2025,'Publisher',68),(140,13,2025,'PowerPoint',68),(142,13,2025,'Excel',67),(143,14,2025,'Windows',72),(144,14,2025,'Word',94),(145,14,2025,'Publisher',89),(146,14,2025,'PowerPoint',89),(148,14,2025,'Excel',81),(150,16,2025,'Windows',80),(151,16,2025,'Word',67),(152,16,2025,'Publisher',75),(153,16,2025,'PowerPoint',75),(155,16,2025,'Excel',83),(156,17,2025,'Windows',74),(157,17,2025,'Word',75),(158,17,2025,'Publisher',77),(159,17,2025,'PowerPoint',77),(161,17,2025,'Excel',72),(162,18,2025,'Windows',80),(163,18,2025,'Word',64),(164,18,2025,'Publisher',68),(165,18,2025,'PowerPoint',68),(167,18,2025,'Excel',70),(168,19,2025,'Windows',68),(169,19,2025,'Word',60),(170,19,2025,'Publisher',70),(171,19,2025,'PowerPoint',70),(173,19,2025,'Excel',67),(174,20,2025,'Windows',86),(175,20,2025,'Word',74),(176,20,2025,'Publisher',80),(177,20,2025,'PowerPoint',80),(179,20,2025,'Excel',75),(180,21,2025,'Windows',82),(181,21,2025,'Word',88),(182,21,2025,'Publisher',92),(183,21,2025,'PowerPoint',92),(185,21,2025,'Excel',71),(186,22,2025,'Windows',77),(187,22,2025,'Word',79),(188,22,2025,'Publisher',70),(189,22,2025,'PowerPoint',70),(191,22,2025,'Excel',79),(192,23,2025,'Windows',60),(193,24,2025,'Windows',70),(194,24,2025,'Word',62),(195,24,2025,'Publisher',68),(196,24,2025,'PowerPoint',68),(198,24,2025,'Excel',72),(199,25,2025,'Windows',70),(200,25,2025,'Word',60),(201,25,2025,'Publisher',72),(202,25,2025,'PowerPoint',72),(204,26,2025,'Windows',68),(205,26,2025,'Word',66),(206,26,2025,'Publisher',68),(207,26,2025,'PowerPoint',68),(209,26,2025,'Excel',70),(210,27,2025,'Windows',60),(211,27,2025,'Word',69),(212,27,2025,'Publisher',70),(213,27,2025,'PowerPoint',70),(215,27,2025,'Excel',71),(216,28,2025,'Windows',62),(217,28,2025,'Word',60),(218,28,2025,'Publisher',62),(219,28,2025,'PowerPoint',62),(221,28,2025,'Excel',69),(222,29,2025,'Windows',68),(223,29,2025,'Word',68),(224,29,2025,'Publisher',70),(225,29,2025,'PowerPoint',70),(227,29,2025,'Excel',69),(228,30,2025,'Windows',79),(229,30,2025,'Word',65),(230,30,2025,'Publisher',60),(231,30,2025,'PowerPoint',60),(233,30,2025,'Excel',61),(234,31,2025,'Windows',69),(235,31,2025,'Word',73),(236,31,2025,'Publisher',66),(237,31,2025,'PowerPoint',66),(239,31,2025,'Excel',76),(240,32,2025,'Windows',80),(241,32,2025,'Word',86),(242,32,2025,'Publisher',77),(243,32,2025,'PowerPoint',77),(245,32,2025,'Excel',75),(246,33,2025,'Windows',84),(247,33,2025,'Word',85),(248,33,2025,'Publisher',80),(249,33,2025,'PowerPoint',80),(251,33,2025,'Excel',76),(252,34,2025,'Windows',69),(253,34,2025,'Word',68),(254,34,2025,'Publisher',68),(255,34,2025,'PowerPoint',68),(257,34,2025,'Excel',62),(258,35,2025,'Windows',65),(259,35,2025,'Word',60),(260,35,2025,'Publisher',66),(261,35,2025,'PowerPoint',66),(263,35,2025,'Excel',73),(264,36,2025,'Windows',67),(265,36,2025,'Word',63),(266,36,2025,'Publisher',65),(267,36,2025,'PowerPoint',65),(269,36,2025,'Excel',70),(270,37,2025,'Windows',90),(271,37,2025,'Word',96),(272,37,2025,'Publisher',90),(273,37,2025,'PowerPoint',90),(275,37,2025,'Excel',74),(276,38,2025,'Windows',65),(277,38,2025,'Word',62),(278,38,2025,'Publisher',67),(279,38,2025,'PowerPoint',67),(281,38,2025,'Excel',79),(282,39,2025,'Windows',69),(283,39,2025,'Word',64),(284,39,2025,'Publisher',65),(285,39,2025,'PowerPoint',65),(287,39,2025,'Excel',72),(288,40,2025,'Windows',67),(289,40,2025,'Word',69),(290,40,2025,'Publisher',71),(291,40,2025,'PowerPoint',71),(293,40,2025,'Excel',72),(294,41,2025,'Windows',67),(295,41,2025,'Word',60),(296,41,2025,'Publisher',70),(297,41,2025,'PowerPoint',70),(299,41,2025,'Excel',73),(300,42,2025,'Windows',62),(301,42,2025,'Word',60),(302,42,2025,'Publisher',63),(303,42,2025,'PowerPoint',63),(305,42,2025,'Excel',67),(306,43,2025,'Windows',63),(307,43,2025,'Word',60),(308,43,2025,'Publisher',65),(309,43,2025,'PowerPoint',65),(311,43,2025,'Excel',72),(312,44,2025,'Windows',60),(313,44,2025,'Word',60),(314,44,2025,'Publisher',61),(315,44,2025,'PowerPoint',61),(317,44,2025,'Excel',68),(318,45,2025,'Windows',62),(319,45,2025,'Word',61),(320,45,2025,'Publisher',63),(321,45,2025,'PowerPoint',63),(323,45,2025,'Excel',71),(324,46,2025,'Windows',64),(325,46,2025,'Word',64),(326,46,2025,'Publisher',67),(327,46,2025,'PowerPoint',67),(329,46,2025,'Excel',68),(330,47,2025,'Windows',65),(331,47,2025,'Word',67),(332,47,2025,'Publisher',70),(333,47,2025,'PowerPoint',70),(335,47,2025,'Excel',78),(336,48,2025,'Windows',69),(337,48,2025,'Word',60),(338,48,2025,'Publisher',72),(339,48,2025,'PowerPoint',72),(341,48,2025,'Excel',67),(342,49,2025,'Windows',68),(343,49,2025,'Word',60),(344,49,2025,'Publisher',60),(345,49,2025,'PowerPoint',60),(347,49,2025,'Excel',72),(348,50,2025,'Windows',64),(349,50,2025,'Word',60),(350,50,2025,'Publisher',68),(351,50,2025,'PowerPoint',68),(353,50,2025,'Excel',75),(354,51,2025,'Windows',62),(355,51,2025,'Word',60),(356,51,2025,'Publisher',62),(357,51,2025,'PowerPoint',62),(359,51,2025,'Excel',71),(360,52,2025,'Windows',63),(361,52,2025,'Word',60),(362,52,2025,'Publisher',60),(363,52,2025,'PowerPoint',60),(365,52,2025,'Excel',69),(366,53,2025,'Windows',66),(367,53,2025,'Word',60),(368,53,2025,'Publisher',64),(369,53,2025,'PowerPoint',64),(371,53,2025,'Excel',71),(372,54,2025,'Windows',67),(373,54,2025,'Word',60),(374,54,2025,'Publisher',70),(375,54,2025,'PowerPoint',70),(377,54,2025,'Excel',73),(378,55,2025,'Windows',68),(379,55,2025,'Word',71),(380,55,2025,'Publisher',72),(381,55,2025,'PowerPoint',72),(383,55,2025,'Excel',72),(384,56,2025,'Windows',69),(385,56,2025,'Word',61),(386,56,2025,'Publisher',64),(387,56,2025,'PowerPoint',64),(389,56,2025,'Excel',67),(390,57,2025,'Windows',64),(391,57,2025,'Word',73),(392,57,2025,'Publisher',65),(393,57,2025,'PowerPoint',65),(395,57,2025,'Excel',68),(396,58,2025,'Word',73),(397,59,2025,'Word',75);
/*!40000 ALTER TABLE `diplomado_notas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inscritos_tac`
--

DROP TABLE IF EXISTS `inscritos_tac`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inscritos_tac` (
  `id` int NOT NULL AUTO_INCREMENT,
  `alumno_id` int NOT NULL,
  `anio` smallint NOT NULL,
  `tac` tinyint NOT NULL,
  `estado` enum('inscrito','no_inscrito','pendiente') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'no_inscrito',
  `fecha_actualizacion` datetime DEFAULT NULL,
  `observaciones` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_inscritos_tac` (`alumno_id`,`anio`,`tac`),
  KEY `idx_inscritos_anio_tac` (`anio`,`tac`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inscritos_tac`
--

LOCK TABLES `inscritos_tac` WRITE;
/*!40000 ALTER TABLE `inscritos_tac` DISABLE KEYS */;
INSERT INTO `inscritos_tac` VALUES (1,71,2026,1,'inscrito','2026-05-04 12:15:56',''),(2,72,2026,1,'pendiente','2026-05-04 12:16:11','no se encuentra el alumno'),(4,18,2026,1,'inscrito','2026-05-04 12:16:27',''),(5,60,2026,1,'inscrito','2026-05-04 12:16:29',''),(6,66,2026,1,'inscrito','2026-05-04 12:16:31','');
/*!40000 ALTER TABLE `inscritos_tac` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `instituciones`
--

DROP TABLE IF EXISTS `instituciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `instituciones` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `resolucion` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `ubicacion` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `extras` longtext COLLATE utf8mb4_unicode_ci,
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `instituciones`
--

LOCK TABLES `instituciones` WRITE;
/*!40000 ALTER TABLE `instituciones` DISABLE KEYS */;
INSERT INTO `instituciones` VALUES (1,'M. Lozano','','resolucion ministerial 1551-2026-2026',NULL,'Genova Costa Cuca, San miguelito','[{\"nombre\":\"Tel.\",\"descripcion\":\" 7722-2141\"}]',1,'2026-05-06 23:26:43','2026-05-06 23:27:05');
/*!40000 ALTER TABLE `instituciones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mecanografia_notas`
--

DROP TABLE IF EXISTS `mecanografia_notas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mecanografia_notas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `alumno_id` int NOT NULL,
  `anio` smallint NOT NULL,
  `l1` smallint DEFAULT NULL,
  `l2` smallint DEFAULT NULL,
  `l3` smallint DEFAULT NULL,
  `l4` smallint DEFAULT NULL,
  `l5` smallint DEFAULT NULL,
  `l6` smallint DEFAULT NULL,
  `l7` smallint DEFAULT NULL,
  `l8` smallint DEFAULT NULL,
  `l9` smallint DEFAULT NULL,
  `l10` smallint DEFAULT NULL,
  `l11` smallint DEFAULT NULL,
  `l12` smallint DEFAULT NULL,
  `l13` smallint DEFAULT NULL,
  `l14` smallint DEFAULT NULL,
  `l15` smallint DEFAULT NULL,
  `l16` smallint DEFAULT NULL,
  `l17` smallint DEFAULT NULL,
  `l18` smallint DEFAULT NULL,
  `l19` smallint DEFAULT NULL,
  `l20` smallint DEFAULT NULL,
  `examen` smallint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_mec_n` (`alumno_id`,`anio`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mecanografia_notas`
--

LOCK TABLES `mecanografia_notas` WRITE;
/*!40000 ALTER TABLE `mecanografia_notas` DISABLE KEYS */;
INSERT INTO `mecanografia_notas` VALUES (1,1,2026,87,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `mecanografia_notas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mensualidades`
--

DROP TABLE IF EXISTS `mensualidades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mensualidades` (
  `id` int NOT NULL AUTO_INCREMENT,
  `alumno_id` int NOT NULL,
  `mes` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `anio` smallint NOT NULL,
  `monto` decimal(10,2) NOT NULL DEFAULT '0.00',
  `pagado` tinyint(1) NOT NULL DEFAULT '0',
  `anulado` tinyint(1) NOT NULL DEFAULT '0',
  `descuento_100` tinyint(1) NOT NULL DEFAULT '0',
  `no_recibo` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fecha_pago` date DEFAULT NULL,
  `monto_abonado` decimal(10,2) NOT NULL DEFAULT '0.00',
  `acreditado` tinyint(1) NOT NULL DEFAULT '0',
  `acreditado_msg` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_mens` (`alumno_id`,`mes`,`anio`)
) ENGINE=InnoDB AUTO_INCREMENT=72312 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mensualidades`
--

LOCK TABLES `mensualidades` WRITE;
/*!40000 ALTER TABLE `mensualidades` DISABLE KEYS */;
INSERT INTO `mensualidades` VALUES (1,1,'enero',2026,60.00,1,0,0,'594','2026-01-01',60.00,0,NULL),(2,1,'febrero',2026,60.00,1,0,0,'594','2026-02-01',60.00,0,NULL),(3,1,'marzo',2026,60.00,1,0,0,'594','2026-03-01',60.00,0,NULL),(4,1,'abril',2026,60.00,1,0,0,'609','2026-04-01',60.00,0,NULL),(5,1,'mayo',2026,60.00,1,0,0,'609','2026-05-01',60.00,0,NULL),(6,1,'junio',2026,60.00,1,0,0,'692','2026-06-01',60.00,0,NULL),(7,1,'julio',2026,60.00,1,0,0,'734','2026-05-04',60.00,0,NULL),(8,1,'agosto',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(9,1,'septiembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(10,1,'octubre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(11,1,'noviembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(12,1,'diciembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(13,2,'enero',2026,60.00,1,0,0,'586','2026-01-01',60.00,0,NULL),(14,2,'febrero',2026,60.00,1,0,0,'654','2026-02-01',60.00,0,NULL),(15,2,'marzo',2026,60.00,1,0,0,'711','2026-03-01',60.00,0,NULL),(16,2,'abril',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(17,2,'mayo',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(18,2,'junio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(19,2,'julio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(20,2,'agosto',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(21,2,'septiembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(22,2,'octubre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(23,2,'noviembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(24,2,'diciembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(25,3,'enero',2026,60.00,1,0,0,'624','2026-01-01',60.00,0,NULL),(26,3,'febrero',2026,60.00,1,0,0,'660','2026-02-01',60.00,0,NULL),(27,3,'marzo',2026,60.00,1,0,0,'736','2026-05-04',60.00,0,NULL),(28,3,'abril',2026,60.00,1,0,0,'736','2026-05-04',60.00,0,NULL),(29,3,'mayo',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(30,3,'junio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(31,3,'julio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(32,3,'agosto',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(33,3,'septiembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(34,3,'octubre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(35,3,'noviembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(36,3,'diciembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(37,4,'enero',2026,60.00,1,0,0,'680','2026-01-01',60.00,0,NULL),(38,4,'febrero',2026,60.00,1,0,0,'680','2026-02-01',60.00,0,NULL),(39,4,'marzo',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(40,4,'abril',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(41,4,'mayo',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(42,4,'junio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(43,4,'julio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(44,4,'agosto',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(45,4,'septiembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(46,4,'octubre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(47,4,'noviembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(48,4,'diciembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(49,5,'enero',2026,60.00,1,0,0,'625','2026-01-01',60.00,0,NULL),(50,5,'febrero',2026,60.00,1,0,0,'625','2026-02-01',60.00,0,NULL),(51,5,'marzo',2026,60.00,1,0,0,'712','2026-03-01',60.00,0,NULL),(52,5,'abril',2026,60.00,1,0,0,'712','2026-04-01',60.00,0,NULL),(53,5,'mayo',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(54,5,'junio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(55,5,'julio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(56,5,'agosto',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(57,5,'septiembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(58,5,'octubre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(59,5,'noviembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(60,5,'diciembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(61,6,'enero',2026,60.00,1,0,0,'621','2026-01-01',60.00,0,NULL),(62,6,'febrero',2026,60.00,1,0,0,'681','2026-02-01',60.00,0,NULL),(63,6,'marzo',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(64,6,'abril',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(65,6,'mayo',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(66,6,'junio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(67,6,'julio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(68,6,'agosto',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(69,6,'septiembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(70,6,'octubre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(71,6,'noviembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(72,6,'diciembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(73,7,'enero',2026,60.00,1,0,0,'600','2026-01-01',60.00,0,NULL),(74,7,'febrero',2026,60.00,1,0,0,'633','2026-02-01',60.00,0,NULL),(75,7,'marzo',2026,60.00,1,0,0,'633','2026-03-01',60.00,0,NULL),(76,7,'abril',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(77,7,'mayo',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(78,7,'junio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(79,7,'julio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(80,7,'agosto',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(81,7,'septiembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(82,7,'octubre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(83,7,'noviembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(84,7,'diciembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(85,8,'enero',2026,60.00,1,0,0,'593','2026-01-01',60.00,0,NULL),(86,8,'febrero',2026,60.00,1,0,0,'627','2026-02-01',60.00,0,NULL),(87,8,'marzo',2026,60.00,1,0,0,'704','2026-03-01',60.00,0,NULL),(88,8,'abril',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(89,8,'mayo',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(90,8,'junio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(91,8,'julio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(92,8,'agosto',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(93,8,'septiembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(94,8,'octubre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(95,8,'noviembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(96,8,'diciembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(97,9,'enero',2026,60.00,1,0,0,'610','2026-01-01',60.00,0,NULL),(98,9,'febrero',2026,60.00,1,0,0,'693','2026-02-01',60.00,0,NULL),(99,9,'marzo',2026,60.00,1,0,0,'735','2026-05-04',60.00,0,NULL),(100,9,'abril',2026,60.00,1,0,0,'735','2026-05-04',60.00,0,NULL),(101,9,'mayo',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(102,9,'junio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(103,9,'julio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(104,9,'agosto',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(105,9,'septiembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(106,9,'octubre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(107,9,'noviembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(108,9,'diciembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(109,10,'enero',2026,60.00,1,0,0,'619','2026-01-01',60.00,0,NULL),(110,10,'febrero',2026,60.00,1,0,0,'716','2026-02-01',60.00,0,NULL),(111,10,'marzo',2026,60.00,1,0,0,'716','2026-03-01',60.00,0,NULL),(112,10,'abril',2026,60.00,1,0,0,'716','2026-04-01',60.00,0,NULL),(113,10,'mayo',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(114,10,'junio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(115,10,'julio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(116,10,'agosto',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(117,10,'septiembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(118,10,'octubre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(119,10,'noviembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(120,10,'diciembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(121,11,'enero',2026,60.00,1,0,0,'595','2026-01-01',60.00,0,NULL),(122,11,'febrero',2026,60.00,1,0,0,'634','2026-02-01',60.00,0,NULL),(123,11,'marzo',2026,60.00,1,0,0,'691','2026-03-01',60.00,0,NULL),(124,11,'abril',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(125,11,'mayo',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(126,11,'junio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(127,11,'julio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(128,11,'agosto',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(129,11,'septiembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(130,11,'octubre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(131,11,'noviembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(132,11,'diciembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(133,12,'enero',2026,60.00,1,0,0,'589','2026-01-01',60.00,0,NULL),(134,12,'febrero',2026,60.00,1,0,0,'655','2026-02-01',60.00,0,NULL),(135,12,'marzo',2026,60.00,1,0,0,'697','2026-03-01',60.00,0,NULL),(136,12,'abril',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(137,12,'mayo',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(138,12,'junio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(139,12,'julio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(140,12,'agosto',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(141,12,'septiembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(142,12,'octubre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(143,12,'noviembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(144,12,'diciembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(145,13,'enero',2026,60.00,1,0,0,'690','2026-01-01',60.00,0,NULL),(146,13,'febrero',2026,60.00,1,0,0,'690','2026-02-01',60.00,0,NULL),(147,13,'marzo',2026,60.00,1,0,0,'690','2026-03-01',60.00,0,NULL),(148,13,'abril',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(149,13,'mayo',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(150,13,'junio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(151,13,'julio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(152,13,'agosto',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(153,13,'septiembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(154,13,'octubre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(155,13,'noviembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(156,13,'diciembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(157,14,'enero',2026,60.00,1,0,0,'580','2026-01-01',60.00,0,NULL),(158,14,'febrero',2026,60.00,1,0,0,'580','2026-02-01',60.00,0,NULL),(159,14,'marzo',2026,60.00,1,0,0,'737','2026-05-04',60.00,0,NULL),(160,14,'abril',2026,60.00,1,0,0,'737','2026-05-04',60.00,0,NULL),(161,14,'mayo',2026,60.00,1,0,0,'737','2026-05-04',60.00,0,NULL),(162,14,'junio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(163,14,'julio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(164,14,'agosto',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(165,14,'septiembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(166,14,'octubre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(167,14,'noviembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(168,14,'diciembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(169,15,'enero',2026,60.00,1,0,0,'648','2026-01-01',60.00,0,NULL),(170,15,'febrero',2026,60.00,1,0,0,'648','2026-02-01',60.00,0,NULL),(171,15,'marzo',2026,60.00,1,0,0,'648','2026-03-01',60.00,0,NULL),(172,15,'abril',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(173,15,'mayo',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(174,15,'junio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(175,15,'julio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(176,15,'agosto',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(177,15,'septiembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(178,15,'octubre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(179,15,'noviembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(180,15,'diciembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(181,16,'enero',2026,60.00,1,0,0,'551','2026-01-01',60.00,0,NULL),(182,16,'febrero',2026,60.00,1,0,0,'606','2026-02-01',60.00,0,NULL),(183,16,'marzo',2026,60.00,1,0,0,'675','2026-03-01',60.00,0,NULL),(184,16,'abril',2026,60.00,1,0,0,'718','2026-04-01',60.00,0,NULL),(185,16,'mayo',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(186,16,'junio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(187,16,'julio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(188,16,'agosto',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(189,16,'septiembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(190,16,'octubre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(191,16,'noviembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(192,16,'diciembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(193,17,'enero',2026,60.00,1,0,0,'563','2026-01-01',60.00,0,NULL),(194,17,'febrero',2026,60.00,1,0,0,'622','2026-02-01',60.00,0,NULL),(195,17,'marzo',2026,60.00,1,0,0,'646','2026-03-01',60.00,0,NULL),(196,17,'abril',2026,60.00,1,0,0,'739','2026-05-05',60.00,0,NULL),(197,17,'mayo',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(198,17,'junio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(199,17,'julio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(200,17,'agosto',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(201,17,'septiembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(202,17,'octubre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(203,17,'noviembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(204,17,'diciembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(205,18,'enero',2026,60.00,1,0,0,'596','2026-01-01',60.00,0,NULL),(206,18,'febrero',2026,60.00,1,0,0,'694','2026-02-01',60.00,0,NULL),(207,18,'marzo',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(208,18,'abril',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(209,18,'mayo',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(210,18,'junio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(211,18,'julio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(212,18,'agosto',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(213,18,'septiembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(214,18,'octubre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(215,18,'noviembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(216,18,'diciembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(217,19,'enero',2026,60.00,1,0,0,'666','2026-01-01',60.00,0,NULL),(218,19,'febrero',2026,60.00,1,0,0,'666','2026-02-01',60.00,0,NULL),(219,19,'marzo',2026,60.00,1,0,0,'666','2026-03-01',60.00,0,NULL),(220,19,'abril',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(221,19,'mayo',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(222,19,'junio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(223,19,'julio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(224,19,'agosto',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(225,19,'septiembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(226,19,'octubre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(227,19,'noviembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(228,19,'diciembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(229,20,'enero',2026,60.00,1,0,0,'566','2026-01-01',60.00,0,NULL),(230,20,'febrero',2026,60.00,1,0,0,'672','2026-02-01',60.00,0,NULL),(231,20,'marzo',2026,60.00,1,0,0,'672','2026-03-01',60.00,0,NULL),(232,20,'abril',2026,60.00,1,0,0,'672','2026-04-01',60.00,0,NULL),(233,20,'mayo',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(234,20,'junio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(235,20,'julio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(236,20,'agosto',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(237,20,'septiembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(238,20,'octubre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(239,20,'noviembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(240,20,'diciembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(241,21,'enero',2026,60.00,1,0,0,'598','2026-01-01',60.00,0,NULL),(242,21,'febrero',2026,60.00,1,0,0,'598','2026-02-01',60.00,0,NULL),(243,21,'marzo',2026,60.00,1,0,0,'639','2026-03-01',60.00,0,NULL),(244,21,'abril',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(245,21,'mayo',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(246,21,'junio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(247,21,'julio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(248,21,'agosto',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(249,21,'septiembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(250,21,'octubre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(251,21,'noviembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(252,21,'diciembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(253,22,'enero',2026,60.00,1,0,0,'554','2026-01-01',60.00,0,NULL),(254,22,'febrero',2026,60.00,1,0,0,'677','2026-02-01',60.00,0,NULL),(255,22,'marzo',2026,60.00,1,0,0,'703','2026-03-01',60.00,0,NULL),(256,22,'abril',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(257,22,'mayo',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(258,22,'junio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(259,22,'julio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(260,22,'agosto',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(261,22,'septiembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(262,22,'octubre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(263,22,'noviembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(264,22,'diciembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(265,23,'enero',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(266,23,'febrero',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(267,23,'marzo',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(268,23,'abril',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(269,23,'mayo',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(270,23,'junio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(271,23,'julio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(272,23,'agosto',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(273,23,'septiembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(274,23,'octubre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(275,23,'noviembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(276,23,'diciembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(277,24,'enero',2026,60.00,1,0,0,'656','2026-01-01',60.00,0,NULL),(278,24,'febrero',2026,60.00,1,0,0,'656','2026-02-01',60.00,0,NULL),(279,24,'marzo',2026,60.00,1,0,0,'656','2026-03-01',60.00,0,NULL),(280,24,'abril',2026,60.00,1,0,0,'657','2026-04-01',60.00,0,NULL),(281,24,'mayo',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(282,24,'junio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(283,24,'julio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(284,24,'agosto',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(285,24,'septiembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(286,24,'octubre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(287,24,'noviembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(288,24,'diciembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(289,25,'enero',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(290,25,'febrero',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(291,25,'marzo',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(292,25,'abril',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(293,25,'mayo',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(294,25,'junio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(295,25,'julio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(296,25,'agosto',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(297,25,'septiembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(298,25,'octubre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(299,25,'noviembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(300,25,'diciembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(301,26,'enero',2026,60.00,1,0,0,'577','2026-01-01',60.00,0,NULL),(302,26,'febrero',2026,60.00,1,0,0,'667','2026-02-01',60.00,0,NULL),(303,26,'marzo',2026,60.00,1,0,0,'667','2026-03-01',60.00,0,NULL),(304,26,'abril',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(305,26,'mayo',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(306,26,'junio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(307,26,'julio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(308,26,'agosto',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(309,26,'septiembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(310,26,'octubre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(311,26,'noviembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(312,26,'diciembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(313,27,'enero',2026,60.00,1,0,0,'584','2026-01-01',60.00,0,NULL),(314,27,'febrero',2026,60.00,1,0,0,'620','2026-02-01',60.00,0,NULL),(315,27,'marzo',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(316,27,'abril',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(317,27,'mayo',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(318,27,'junio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(319,27,'julio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(320,27,'agosto',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(321,27,'septiembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(322,27,'octubre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(323,27,'noviembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(324,27,'diciembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(325,28,'enero',2026,60.00,1,0,0,'590','2026-01-01',60.00,0,NULL),(326,28,'febrero',2026,60.00,1,0,0,'658','2026-02-01',60.00,0,NULL),(327,28,'marzo',2026,60.00,1,0,0,'717','2026-03-01',60.00,0,NULL),(328,28,'abril',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(329,28,'mayo',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(330,28,'junio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(331,28,'julio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(332,28,'agosto',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(333,28,'septiembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(334,28,'octubre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(335,28,'noviembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(336,28,'diciembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(337,29,'enero',2026,60.00,1,0,0,'583','2026-01-01',60.00,0,NULL),(338,29,'febrero',2026,60.00,1,0,0,'668','2026-02-01',60.00,0,NULL),(339,29,'marzo',2026,60.00,1,0,0,'687','2026-03-01',60.00,0,NULL),(340,29,'abril',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(341,29,'mayo',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(342,29,'junio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(343,29,'julio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(344,29,'agosto',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(345,29,'septiembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(346,29,'octubre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(347,29,'noviembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(348,29,'diciembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(349,30,'enero',2026,60.00,1,0,0,'568','2026-01-01',60.00,0,NULL),(350,30,'febrero',2026,60.00,1,0,0,'568','2026-02-01',60.00,0,NULL),(351,30,'marzo',2026,60.00,1,0,0,'568','2026-03-01',60.00,0,NULL),(352,30,'abril',2026,60.00,1,0,0,'568','2026-04-01',60.00,0,NULL),(353,30,'mayo',2026,60.00,1,0,0,'568','2026-05-01',60.00,0,NULL),(354,30,'junio',2026,60.00,1,0,0,'568','2026-06-01',60.00,0,NULL),(355,30,'julio',2026,60.00,1,0,0,'568','2026-07-01',60.00,0,NULL),(356,30,'agosto',2026,60.00,1,0,0,'568','2026-08-01',60.00,0,NULL),(357,30,'septiembre',2026,60.00,1,0,0,'568-571','2026-09-01',60.00,0,NULL),(358,30,'octubre',2026,60.00,1,0,0,'571','2026-10-01',60.00,0,NULL),(359,30,'noviembre',2026,60.00,1,0,0,'571','2026-11-01',60.00,0,NULL),(360,30,'diciembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(361,31,'enero',2026,60.00,1,0,0,'638','2026-01-01',60.00,0,NULL),(362,31,'febrero',2026,60.00,1,0,0,'638','2026-02-01',60.00,0,NULL),(363,31,'marzo',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(364,31,'abril',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(365,31,'mayo',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(366,31,'junio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(367,31,'julio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(368,31,'agosto',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(369,31,'septiembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(370,31,'octubre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(371,31,'noviembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(372,31,'diciembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(373,32,'enero',2026,60.00,1,0,0,'567','2026-01-01',60.00,0,NULL),(374,32,'febrero',2026,60.00,1,0,0,'637','2026-02-01',60.00,0,NULL),(375,32,'marzo',2026,60.00,1,0,0,'682','2026-03-01',60.00,0,NULL),(376,32,'abril',2026,60.00,1,0,0,'726','2026-04-01',60.00,0,NULL),(377,32,'mayo',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(378,32,'junio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(379,32,'julio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(380,32,'agosto',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(381,32,'septiembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(382,32,'octubre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(383,32,'noviembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(384,32,'diciembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(385,33,'enero',2026,60.00,1,0,0,'569','2026-01-01',60.00,0,NULL),(386,33,'febrero',2026,60.00,1,0,0,'569','2026-02-01',60.00,0,NULL),(387,33,'marzo',2026,60.00,1,0,0,'665','2026-03-01',60.00,0,NULL),(388,33,'abril',2026,60.00,1,0,0,'665','2026-04-01',60.00,0,NULL),(389,33,'mayo',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(390,33,'junio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(391,33,'julio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(392,33,'agosto',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(393,33,'septiembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(394,33,'octubre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(395,33,'noviembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(396,33,'diciembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(397,34,'enero',2026,60.00,1,0,0,'611','2026-01-01',60.00,0,NULL),(398,34,'febrero',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(399,34,'marzo',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(400,34,'abril',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(401,34,'mayo',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(402,34,'junio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(403,34,'julio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(404,34,'agosto',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(405,34,'septiembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(406,34,'octubre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(407,34,'noviembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(408,34,'diciembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(409,35,'enero',2026,60.00,1,0,0,'597','2026-01-01',60.00,0,NULL),(410,35,'febrero',2026,60.00,1,0,0,'651','2026-02-01',60.00,0,NULL),(411,35,'marzo',2026,60.00,1,0,0,'651','2026-03-01',60.00,0,NULL),(412,35,'abril',2026,60.00,1,0,0,'651','2026-04-01',60.00,0,NULL),(413,35,'mayo',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(414,35,'junio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(415,35,'julio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(416,35,'agosto',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(417,35,'septiembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(418,35,'octubre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(419,35,'noviembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(420,35,'diciembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(421,36,'enero',2026,60.00,1,0,0,'612','2026-01-01',60.00,0,NULL),(422,36,'febrero',2026,60.00,1,0,0,'612','2026-02-01',60.00,0,NULL),(423,36,'marzo',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(424,36,'abril',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(425,36,'mayo',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(426,36,'junio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(427,36,'julio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(428,36,'agosto',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(429,36,'septiembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(430,36,'octubre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(431,36,'noviembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(432,36,'diciembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(433,37,'enero',2026,60.00,1,0,0,'570','2026-01-01',60.00,0,NULL),(434,37,'febrero',2026,60.00,1,0,0,'626','2026-02-01',60.00,0,NULL),(435,37,'marzo',2026,60.00,1,0,0,'683','2026-03-01',60.00,0,NULL),(436,37,'abril',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(437,37,'mayo',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(438,37,'junio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(439,37,'julio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(440,37,'agosto',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(441,37,'septiembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(442,37,'octubre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(443,37,'noviembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(444,37,'diciembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(445,38,'enero',2026,60.00,1,0,0,'653','2026-01-01',60.00,0,NULL),(446,38,'febrero',2026,60.00,1,0,0,'653','2026-02-01',60.00,0,NULL),(447,38,'marzo',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(448,38,'abril',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(449,38,'mayo',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(450,38,'junio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(451,38,'julio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(452,38,'agosto',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(453,38,'septiembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(454,38,'octubre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(455,38,'noviembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(456,38,'diciembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(457,39,'enero',2026,60.00,1,0,0,'560','2026-01-01',60.00,0,NULL),(458,39,'febrero',2026,60.00,1,0,0,'630','2026-02-01',60.00,0,NULL),(459,39,'marzo',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(460,39,'abril',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(461,39,'mayo',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(462,39,'junio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(463,39,'julio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(464,39,'agosto',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(465,39,'septiembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(466,39,'octubre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(467,39,'noviembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(468,39,'diciembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(469,40,'enero',2026,60.00,1,0,0,'556','2026-01-01',60.00,0,NULL),(470,40,'febrero',2026,60.00,1,0,0,'608','2026-02-01',60.00,0,NULL),(471,40,'marzo',2026,60.00,1,0,0,'647','2026-03-01',60.00,0,NULL),(472,40,'abril',2026,60.00,1,0,0,'707','2026-04-01',60.00,0,NULL),(473,40,'mayo',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(474,40,'junio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(475,40,'julio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(476,40,'agosto',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(477,40,'septiembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(478,40,'octubre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(479,40,'noviembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(480,40,'diciembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(481,41,'enero',2026,60.00,1,0,0,'614','2026-01-01',60.00,0,NULL),(482,41,'febrero',2026,60.00,1,0,0,'659','2026-02-01',60.00,0,NULL),(483,41,'marzo',2026,60.00,1,0,0,'659','2026-03-01',60.00,0,NULL),(484,41,'abril',2026,60.00,1,0,0,'729','2026-04-01',60.00,0,NULL),(485,41,'mayo',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(486,41,'junio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(487,41,'julio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(488,41,'agosto',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(489,41,'septiembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(490,41,'octubre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(491,41,'noviembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(492,41,'diciembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(493,42,'enero',2026,60.00,1,0,0,'579','2026-01-01',60.00,0,NULL),(494,42,'febrero',2026,60.00,1,0,0,'631','2026-02-01',60.00,0,NULL),(495,42,'marzo',2026,60.00,1,0,0,'708','2026-03-01',60.00,0,NULL),(496,42,'abril',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(497,42,'mayo',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(498,42,'junio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(499,42,'julio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(500,42,'agosto',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(501,42,'septiembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(502,42,'octubre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(503,42,'noviembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(504,42,'diciembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(505,43,'enero',2026,60.00,1,0,0,'663','2026-01-01',60.00,0,NULL),(506,43,'febrero',2026,60.00,1,0,0,'663','2026-02-01',60.00,0,NULL),(507,43,'marzo',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(508,43,'abril',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(509,43,'mayo',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(510,43,'junio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(511,43,'julio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(512,43,'agosto',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(513,43,'septiembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(514,43,'octubre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(515,43,'noviembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(516,43,'diciembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(517,44,'enero',2026,60.00,1,0,0,'578','2026-01-01',60.00,0,NULL),(518,44,'febrero',2026,60.00,1,0,0,'670','2026-02-01',60.00,0,NULL),(519,44,'marzo',2026,60.00,1,0,0,'710','2026-03-01',60.00,0,NULL),(520,44,'abril',2026,60.00,1,0,0,'728','2026-04-01',60.00,0,NULL),(521,44,'mayo',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(522,44,'junio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(523,44,'julio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(524,44,'agosto',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(525,44,'septiembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(526,44,'octubre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(527,44,'noviembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(528,44,'diciembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(529,45,'enero',2026,60.00,1,0,0,'557','2026-01-01',60.00,0,NULL),(530,45,'febrero',2026,60.00,1,0,0,'557','2026-02-01',60.00,0,NULL),(531,45,'marzo',2026,60.00,1,0,0,'557','2026-03-01',60.00,0,NULL),(532,45,'abril',2026,60.00,1,0,0,'558-709','2026-04-01',60.00,0,NULL),(533,45,'mayo',2026,60.00,1,0,0,'709','2026-05-01',60.00,0,NULL),(534,45,'junio',2026,60.00,1,0,0,'709','2026-06-01',60.00,0,NULL),(535,45,'julio',2026,60.00,1,0,0,'709','2026-07-01',60.00,0,NULL),(536,45,'agosto',2026,60.00,1,0,0,'709','2026-08-01',60.00,0,NULL),(537,45,'septiembre',2026,60.00,1,0,0,'709','2026-09-01',60.00,0,NULL),(538,45,'octubre',2026,60.00,1,0,0,'709','2026-10-01',60.00,0,NULL),(539,45,'noviembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(540,45,'diciembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(541,46,'enero',2026,60.00,1,0,0,'591','2026-01-01',60.00,0,NULL),(542,46,'febrero',2026,60.00,1,0,0,'669','2026-02-01',60.00,0,NULL),(543,46,'marzo',2026,60.00,1,0,0,'706','2026-03-01',60.00,0,NULL),(544,46,'abril',2026,60.00,1,0,0,'732','2026-04-01',60.00,0,NULL),(545,46,'mayo',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(546,46,'junio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(547,46,'julio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(548,46,'agosto',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(549,46,'septiembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(550,46,'octubre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(551,46,'noviembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(552,46,'diciembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(553,47,'enero',2026,60.00,1,0,0,'555','2026-01-01',60.00,0,NULL),(554,47,'febrero',2026,60.00,1,0,0,'555','2026-02-01',60.00,0,NULL),(555,47,'marzo',2026,60.00,1,0,0,'650','2026-03-01',60.00,0,NULL),(556,47,'abril',2026,60.00,1,0,0,'720','2026-04-01',60.00,0,NULL),(557,47,'mayo',2026,60.00,1,0,0,'720','2026-05-01',60.00,0,NULL),(558,47,'junio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(559,47,'julio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(560,47,'agosto',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(561,47,'septiembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(562,47,'octubre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(563,47,'noviembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(564,47,'diciembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(565,48,'enero',2026,60.00,1,0,0,'662','2026-01-01',60.00,0,NULL),(566,48,'febrero',2026,60.00,1,0,0,'662','2026-02-01',60.00,0,NULL),(567,48,'marzo',2026,60.00,1,0,0,'662','2026-03-01',60.00,0,NULL),(568,48,'abril',2026,60.00,1,0,0,'713','2026-04-01',60.00,0,NULL),(569,48,'mayo',2026,60.00,1,0,0,'714','2026-05-01',60.00,0,NULL),(570,48,'junio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(571,48,'julio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(572,48,'agosto',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(573,48,'septiembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(574,48,'octubre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(575,48,'noviembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(576,48,'diciembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(577,49,'enero',2026,60.00,1,0,0,'605','2026-01-01',60.00,0,NULL),(578,49,'febrero',2026,60.00,1,0,0,'605','2026-02-01',60.00,0,NULL),(579,49,'marzo',2026,60.00,1,0,0,'705','2026-03-01',60.00,0,NULL),(580,49,'abril',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(581,49,'mayo',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(582,49,'junio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(583,49,'julio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(584,49,'agosto',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(585,49,'septiembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(586,49,'octubre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(587,49,'noviembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(588,49,'diciembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(589,50,'enero',2026,60.00,1,0,0,'561','2026-01-01',60.00,0,NULL),(590,50,'febrero',2026,60.00,1,0,0,'561','2026-02-01',60.00,0,NULL),(591,50,'marzo',2026,60.00,1,0,0,'731','2026-03-01',60.00,0,NULL),(592,50,'abril',2026,60.00,1,0,0,'731','2026-04-01',60.00,0,NULL),(593,50,'mayo',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(594,50,'junio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(595,50,'julio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(596,50,'agosto',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(597,50,'septiembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(598,50,'octubre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(599,50,'noviembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(600,50,'diciembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(601,51,'enero',2026,60.00,1,0,0,'559','2026-01-01',60.00,0,NULL),(602,51,'febrero',2026,60.00,1,0,0,'559','2026-02-01',60.00,0,NULL),(603,51,'marzo',2026,60.00,1,0,0,'730','2026-03-01',60.00,0,NULL),(604,51,'abril',2026,60.00,1,0,0,'730','2026-04-01',60.00,0,NULL),(605,51,'mayo',2026,60.00,1,0,0,'730','2026-05-01',60.00,0,NULL),(606,51,'junio',2026,60.00,1,0,0,'730','2026-06-01',60.00,0,NULL),(607,51,'julio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(608,51,'agosto',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(609,51,'septiembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(610,51,'octubre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(611,51,'noviembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(612,51,'diciembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(613,52,'enero',2026,60.00,1,0,0,'632','2026-01-01',60.00,0,NULL),(614,52,'febrero',2026,60.00,1,0,0,'719','2026-02-01',60.00,0,NULL),(615,52,'marzo',2026,60.00,1,0,0,'719','2026-03-01',60.00,0,NULL),(616,52,'abril',2026,60.00,1,0,0,'727','2026-04-01',60.00,0,NULL),(617,52,'mayo',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(618,52,'junio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(619,52,'julio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(620,52,'agosto',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(621,52,'septiembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(622,52,'octubre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(623,52,'noviembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(624,52,'diciembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(625,53,'enero',2026,60.00,1,0,0,'592','2026-01-01',60.00,0,NULL),(626,53,'febrero',2026,60.00,1,0,0,'678','2026-02-01',60.00,0,NULL),(627,53,'marzo',2026,60.00,1,0,0,'740','2026-05-06',60.00,0,NULL),(628,53,'abril',2026,60.00,1,0,0,'740','2026-05-06',60.00,0,NULL),(629,53,'mayo',2026,60.00,1,0,0,'740','2026-05-06',60.00,0,NULL),(630,53,'junio',2026,60.00,1,0,0,'740','2026-05-06',60.00,0,NULL),(631,53,'julio',2026,60.00,1,0,0,NULL,NULL,0.00,1,'Gratis'),(632,53,'agosto',2026,60.00,1,0,0,'744','2026-05-06',60.00,0,NULL),(633,53,'septiembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(634,53,'octubre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(635,53,'noviembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(636,53,'diciembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(637,54,'enero',2026,60.00,1,0,0,'585','2026-01-01',60.00,0,NULL),(638,54,'febrero',2026,60.00,1,0,0,'585','2026-02-01',60.00,0,NULL),(639,54,'marzo',2026,60.00,1,0,0,'679','2026-03-01',60.00,0,NULL),(640,54,'abril',2026,60.00,1,0,0,'679','2026-04-01',60.00,0,NULL),(641,54,'mayo',2026,60.00,1,0,0,'679','2026-05-01',60.00,0,NULL),(642,54,'junio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(643,54,'julio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(644,54,'agosto',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(645,54,'septiembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(646,54,'octubre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(647,54,'noviembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(648,54,'diciembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(649,55,'enero',2026,60.00,1,0,0,'671','2026-01-01',60.00,0,NULL),(650,55,'febrero',2026,60.00,1,0,0,'671','2026-02-01',60.00,0,NULL),(651,55,'marzo',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(652,55,'abril',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(653,55,'mayo',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(654,55,'junio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(655,55,'julio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(656,55,'agosto',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(657,55,'septiembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(658,55,'octubre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(659,55,'noviembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(660,55,'diciembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(661,56,'enero',2026,60.00,1,0,0,'552','2026-01-01',60.00,0,NULL),(662,56,'febrero',2026,60.00,1,0,0,'661','2026-02-01',60.00,0,NULL),(663,56,'marzo',2026,60.00,1,0,0,'661','2026-03-01',60.00,0,NULL),(664,56,'abril',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(665,56,'mayo',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(666,56,'junio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(667,56,'julio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(668,56,'agosto',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(669,56,'septiembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(670,56,'octubre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(671,56,'noviembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(672,56,'diciembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(673,57,'enero',2026,60.00,1,0,0,'553','2026-01-01',60.00,0,NULL),(674,57,'febrero',2026,60.00,1,0,0,'676','2026-02-01',60.00,0,NULL),(675,57,'marzo',2026,60.00,1,0,0,'702','2026-03-01',60.00,0,NULL),(676,57,'abril',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(677,57,'mayo',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(678,57,'junio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(679,57,'julio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(680,57,'agosto',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(681,57,'septiembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(682,57,'octubre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(683,57,'noviembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(684,57,'diciembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(685,58,'enero',2026,60.00,1,0,0,'572','2026-01-01',60.00,0,NULL),(686,58,'febrero',2026,60.00,1,0,0,'628','2026-02-01',60.00,0,NULL),(687,58,'marzo',2026,60.00,1,0,0,'688','2026-03-01',60.00,0,NULL),(688,58,'abril',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(689,58,'mayo',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(690,58,'junio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(691,58,'julio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(692,58,'agosto',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(693,58,'septiembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(694,58,'octubre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(695,58,'noviembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(696,58,'diciembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(697,59,'enero',2026,60.00,1,0,0,'573','2026-01-01',60.00,0,NULL),(698,59,'febrero',2026,60.00,1,0,0,'629','2026-02-01',60.00,0,NULL),(699,59,'marzo',2026,60.00,1,0,0,'689','2026-03-01',60.00,0,NULL),(700,59,'abril',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(701,59,'mayo',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(702,59,'junio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(703,59,'julio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(704,59,'agosto',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(705,59,'septiembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(706,59,'octubre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(707,59,'noviembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(708,59,'diciembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(709,60,'enero',2026,60.00,1,0,0,'588','2026-01-01',60.00,0,NULL),(710,60,'febrero',2026,60.00,1,0,0,'643','2026-02-01',60.00,0,NULL),(711,60,'marzo',2026,60.00,1,0,0,'695','2026-03-01',60.00,0,NULL),(712,60,'abril',2026,60.00,1,0,0,'695','2026-04-01',60.00,0,NULL),(713,60,'mayo',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(714,60,'junio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(715,60,'julio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(716,60,'agosto',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(717,60,'septiembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(718,60,'octubre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(719,60,'noviembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(720,60,'diciembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(721,61,'enero',2026,60.00,1,0,0,'733','2026-05-03',60.00,0,NULL),(722,61,'febrero',2026,60.00,1,0,0,'733','2026-05-03',60.00,0,NULL),(723,61,'marzo',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(724,61,'abril',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(725,61,'mayo',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(726,61,'junio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(727,61,'julio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(728,61,'agosto',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(729,61,'septiembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(730,61,'octubre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(731,61,'noviembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(732,61,'diciembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(733,62,'enero',2026,60.00,1,0,0,'616','2026-01-01',60.00,0,NULL),(734,62,'febrero',2026,60.00,1,0,0,'685','2026-02-01',60.00,0,NULL),(735,62,'marzo',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(736,62,'abril',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(737,62,'mayo',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(738,62,'junio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(739,62,'julio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(740,62,'agosto',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(741,62,'septiembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(742,62,'octubre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(743,62,'noviembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(744,62,'diciembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(745,63,'enero',2026,60.00,1,0,0,'642','2026-01-01',60.00,0,NULL),(746,63,'febrero',2026,60.00,1,0,0,'642','2026-02-01',60.00,0,NULL),(747,63,'marzo',2026,60.00,1,0,0,'642','2026-03-01',60.00,0,NULL),(748,63,'abril',2026,60.00,1,0,0,'642','2026-04-01',60.00,0,NULL),(749,63,'mayo',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(750,63,'junio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(751,63,'julio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(752,63,'agosto',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(753,63,'septiembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(754,63,'octubre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(755,63,'noviembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(756,63,'diciembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(757,64,'enero',2026,60.00,1,0,0,'575','2026-01-01',60.00,0,NULL),(758,64,'febrero',2026,60.00,1,0,0,'575','2026-02-01',60.00,0,NULL),(759,64,'marzo',2026,60.00,1,0,0,'576','2026-03-01',60.00,0,NULL),(760,64,'abril',2026,60.00,1,0,0,'696','2026-04-01',60.00,0,NULL),(761,64,'mayo',2026,60.00,1,0,0,'696','2026-05-01',60.00,0,NULL),(762,64,'junio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(763,64,'julio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(764,64,'agosto',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(765,64,'septiembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(766,64,'octubre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(767,64,'noviembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(768,64,'diciembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(769,65,'enero',2026,60.00,1,0,0,'587','2026-01-01',60.00,0,NULL),(770,65,'febrero',2026,60.00,1,0,0,'635','2026-02-01',60.00,0,NULL),(771,65,'marzo',2026,60.00,1,0,0,'686','2026-03-01',60.00,0,NULL),(772,65,'abril',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(773,65,'mayo',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(774,65,'junio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(775,65,'julio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(776,65,'agosto',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(777,65,'septiembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(778,65,'octubre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(779,65,'noviembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(780,65,'diciembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(781,66,'enero',2026,60.00,1,0,0,'617','2026-01-01',60.00,0,NULL),(782,66,'febrero',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(783,66,'marzo',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(784,66,'abril',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(785,66,'mayo',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(786,66,'junio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(787,66,'julio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(788,66,'agosto',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(789,66,'septiembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(790,66,'octubre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(791,66,'noviembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(792,66,'diciembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(793,67,'enero',2026,60.00,1,0,0,'615','2026-01-01',60.00,0,NULL),(794,67,'febrero',2026,60.00,1,0,0,'615','2026-02-01',60.00,0,NULL),(795,67,'marzo',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(796,67,'abril',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(797,67,'mayo',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(798,67,'junio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(799,67,'julio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(800,67,'agosto',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(801,67,'septiembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(802,67,'octubre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(803,67,'noviembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(804,67,'diciembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(805,68,'enero',2026,60.00,1,0,0,'664','2026-01-01',60.00,0,NULL),(806,68,'febrero',2026,60.00,1,0,0,'664','2026-02-01',60.00,0,NULL),(807,68,'marzo',2026,60.00,1,0,0,'664','2026-03-01',60.00,0,NULL),(808,68,'abril',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(809,68,'mayo',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(810,68,'junio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(811,68,'julio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(812,68,'agosto',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(813,68,'septiembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(814,68,'octubre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(815,68,'noviembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(816,68,'diciembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(817,69,'enero',2026,60.00,1,0,0,'618','2026-01-01',60.00,0,NULL),(818,69,'febrero',2026,60.00,1,0,0,'618','2026-02-01',60.00,0,NULL),(819,69,'marzo',2026,60.00,1,0,0,'698','2026-03-01',60.00,0,NULL),(820,69,'abril',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(821,69,'mayo',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(822,69,'junio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(823,69,'julio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(824,69,'agosto',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(825,69,'septiembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(826,69,'octubre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(827,69,'noviembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(828,69,'diciembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(829,70,'enero',2026,60.00,1,0,0,'603','2026-01-01',60.00,0,NULL),(830,70,'febrero',2026,60.00,1,0,0,'644','2026-02-01',60.00,0,NULL),(831,70,'marzo',2026,60.00,1,0,0,'673','2026-03-01',60.00,0,NULL),(832,70,'abril',2026,60.00,1,0,0,'700','2026-04-01',60.00,0,NULL),(833,70,'mayo',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(834,70,'junio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(835,70,'julio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(836,70,'agosto',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(837,70,'septiembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(838,70,'octubre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(839,70,'noviembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(840,70,'diciembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(841,71,'enero',2026,60.00,1,0,0,'604','2026-01-01',60.00,0,NULL),(842,71,'febrero',2026,60.00,1,0,0,'645','2026-02-01',60.00,0,NULL),(843,71,'marzo',2026,60.00,1,0,0,'674','2026-03-01',60.00,0,NULL),(844,71,'abril',2026,60.00,1,0,0,'701','2026-04-01',60.00,0,NULL),(845,71,'mayo',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(846,71,'junio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(847,71,'julio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(848,71,'agosto',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(849,71,'septiembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(850,71,'octubre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(851,71,'noviembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(852,71,'diciembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(853,72,'enero',2026,60.00,1,0,0,'613','2026-01-01',60.00,0,NULL),(854,72,'febrero',2026,60.00,1,0,0,'641','2026-02-01',60.00,0,NULL),(855,72,'marzo',2026,60.00,1,0,0,'715','2026-03-01',60.00,0,NULL),(856,72,'abril',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(857,72,'mayo',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(858,72,'junio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(859,72,'julio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(860,72,'agosto',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(861,72,'septiembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(862,72,'octubre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(863,72,'noviembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(864,72,'diciembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(865,73,'enero',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(866,73,'febrero',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(867,73,'marzo',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(868,73,'abril',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(869,73,'mayo',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(870,73,'junio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(871,73,'julio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(872,73,'agosto',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(873,73,'septiembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(874,73,'octubre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(875,73,'noviembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(876,73,'diciembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(877,74,'enero',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(878,74,'febrero',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(879,74,'marzo',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(880,74,'abril',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(881,74,'mayo',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(882,74,'junio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(883,74,'julio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(884,74,'agosto',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(885,74,'septiembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(886,74,'octubre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(887,74,'noviembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(888,74,'diciembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(26231,1,'febrero',2025,60.00,1,0,0,'105','2025-02-01',60.00,0,NULL),(26232,1,'marzo',2025,60.00,1,0,0,'136','2025-03-01',60.00,0,NULL),(26233,1,'abril',2025,60.00,1,0,0,'217','2025-04-01',60.00,0,NULL),(26234,1,'mayo',2025,60.00,1,0,0,'217','2025-05-01',60.00,0,NULL),(26235,1,'junio',2025,60.00,1,0,0,'261','2025-06-01',60.00,0,NULL),(26236,1,'julio',2025,60.00,1,0,0,'310','2025-07-01',60.00,0,NULL),(26237,1,'agosto',2025,60.00,1,0,0,'356','2025-08-01',60.00,0,NULL),(26238,1,'septiembre',2025,60.00,1,0,0,'399','2025-09-01',60.00,0,NULL),(26239,1,'octubre',2025,60.00,1,0,0,'474','2025-10-01',60.00,0,NULL),(26240,1,'noviembre',2025,60.00,1,0,0,'498','2025-11-01',60.00,0,NULL),(26241,2,'febrero',2025,60.00,1,0,0,'118','2025-02-01',60.00,0,NULL),(26242,2,'marzo',2025,60.00,1,0,0,'118','2025-03-01',60.00,0,NULL),(26243,2,'abril',2025,60.00,1,0,0,'169','2025-04-01',60.00,0,NULL),(26244,2,'mayo',2025,60.00,1,0,0,'238','2025-05-01',60.00,0,NULL),(26245,2,'junio',2025,60.00,1,0,0,'276','2025-06-01',60.00,0,NULL),(26246,2,'julio',2025,60.00,1,0,0,'334','2025-07-01',60.00,0,NULL),(26247,2,'agosto',2025,60.00,1,0,0,'486','2025-08-01',60.00,0,NULL),(26248,2,'septiembre',2025,60.00,1,0,0,'486','2025-09-01',60.00,0,NULL),(26249,2,'octubre',2025,60.00,1,0,0,'486','2025-10-01',60.00,0,NULL),(26250,2,'noviembre',2025,60.00,1,0,0,'525','2025-11-01',60.00,0,NULL),(26251,3,'febrero',2025,60.00,1,0,0,'98','2025-02-01',60.00,0,NULL),(26252,3,'marzo',2025,60.00,1,0,0,'137','2025-03-01',60.00,0,NULL),(26253,3,'abril',2025,60.00,1,0,0,'260','2025-04-01',60.00,0,NULL),(26254,3,'mayo',2025,60.00,1,0,0,'260','2025-05-01',60.00,0,NULL),(26255,3,'junio',2025,60.00,1,0,0,'307','2025-06-01',60.00,0,NULL),(26256,3,'julio',2025,60.00,1,0,0,'331','2025-07-01',60.00,0,NULL),(26257,3,'agosto',2025,60.00,1,0,0,'361','2025-08-01',60.00,0,NULL),(26258,3,'septiembre',2025,60.00,1,0,0,'402','2025-09-01',60.00,0,NULL),(26259,3,'octubre',2025,60.00,1,0,0,'488','2025-10-01',60.00,0,NULL),(26260,3,'noviembre',2025,60.00,1,0,0,'522','2025-11-01',60.00,0,NULL),(26261,35,'febrero',2025,60.00,1,0,0,'76','2025-02-01',60.00,0,NULL),(26262,35,'marzo',2025,60.00,1,0,0,'193','2025-03-01',60.00,0,NULL),(26263,35,'abril',2025,60.00,1,0,0,'193','2025-04-01',60.00,0,NULL),(26264,35,'mayo',2025,60.00,1,0,0,'290','2025-05-01',60.00,0,NULL),(26265,35,'junio',2025,60.00,1,0,0,'290','2025-06-01',60.00,0,NULL),(26266,35,'julio',2025,60.00,1,0,0,'296','2025-07-01',60.00,0,NULL),(26267,35,'agosto',2025,60.00,1,0,0,'297','2025-08-01',60.00,0,NULL),(26268,35,'septiembre',2025,60.00,1,0,0,'362','2025-09-01',60.00,0,NULL),(26269,35,'octubre',2025,60.00,1,0,0,'362','2025-10-01',60.00,0,NULL),(26270,35,'noviembre',2025,60.00,1,0,0,'413','2025-11-01',60.00,0,NULL),(26271,36,'febrero',2025,60.00,1,0,0,'112','2025-02-01',60.00,0,NULL),(26272,36,'marzo',2025,60.00,1,0,0,'196','2025-03-01',60.00,0,NULL),(26273,36,'abril',2025,60.00,1,0,0,'196','2025-04-01',60.00,0,NULL),(26274,36,'mayo',2025,60.00,1,0,0,'314','2025-05-01',60.00,0,NULL),(26275,36,'junio',2025,60.00,1,0,0,'314','2025-06-01',60.00,0,NULL),(26276,36,'julio',2025,60.00,1,0,0,'314','2025-07-01',60.00,0,NULL),(26277,36,'agosto',2025,60.00,1,0,0,'314','2025-08-01',60.00,0,NULL),(26278,36,'septiembre',2025,60.00,1,0,0,'478','2025-09-01',60.00,0,NULL),(26279,36,'octubre',2025,60.00,1,0,0,'478','2025-10-01',60.00,0,NULL),(26280,36,'noviembre',2025,60.00,1,0,0,'537','2025-11-01',60.00,0,NULL),(26281,37,'febrero',2025,60.00,1,0,0,'65','2025-02-01',60.00,0,NULL),(26282,37,'marzo',2025,60.00,1,0,0,'125','2025-03-01',60.00,0,NULL),(26283,37,'abril',2025,60.00,1,0,0,'190','2025-04-01',60.00,0,NULL),(26284,37,'mayo',2025,60.00,1,0,0,'234','2025-05-01',60.00,0,NULL),(26285,37,'junio',2025,60.00,1,0,0,'272','2025-06-01',60.00,0,NULL),(26286,37,'julio',2025,60.00,1,0,0,'315','2025-07-01',60.00,0,NULL),(26287,37,'agosto',2025,60.00,1,0,0,'369','2025-08-01',60.00,0,NULL),(26288,37,'septiembre',2025,60.00,1,0,0,'455','2025-09-01',60.00,0,NULL),(26289,37,'octubre',2025,60.00,1,0,0,'455','2025-10-01',60.00,0,NULL),(26290,37,'noviembre',2025,60.00,1,0,0,'540','2025-11-01',60.00,0,NULL),(26291,38,'febrero',2025,60.00,1,0,0,'77','2025-02-01',60.00,0,NULL),(26292,38,'marzo',2025,60.00,1,0,0,'143-195','2025-03-01',60.00,0,NULL),(26293,38,'abril',2025,60.00,1,0,0,'195','2025-04-01',60.00,0,NULL),(26294,38,'mayo',2025,60.00,1,0,0,'316','2025-05-01',60.00,0,NULL),(26295,38,'junio',2025,60.00,1,0,0,'316','2025-06-01',60.00,0,NULL),(26296,38,'julio',2025,60.00,1,0,0,'342','2025-07-01',60.00,0,NULL),(26297,38,'agosto',2025,60.00,1,0,0,'368','2025-08-01',60.00,0,NULL),(26298,38,'septiembre',2025,60.00,1,0,0,'414','2025-09-01',60.00,0,NULL),(26299,38,'octubre',2025,60.00,1,0,0,'441','2025-10-01',60.00,0,NULL),(26300,38,'noviembre',2025,60.00,1,0,0,'441','2025-11-01',60.00,0,NULL),(26301,39,'febrero',2025,60.00,1,0,0,'114','2025-02-01',60.00,0,NULL),(26302,39,'marzo',2025,60.00,1,0,0,'200','2025-03-01',60.00,0,NULL),(26303,39,'abril',2025,60.00,1,0,0,'200','2025-04-01',60.00,0,NULL),(26304,39,'mayo',2025,60.00,1,0,0,'200','2025-05-01',60.00,0,NULL),(26305,39,'junio',2025,60.00,1,0,0,'256','2025-06-01',60.00,0,NULL),(26306,39,'julio',2025,60.00,1,0,0,'371','2025-07-01',60.00,0,NULL),(26307,39,'agosto',2025,60.00,1,0,0,'371','2025-08-01',60.00,0,NULL),(26308,39,'septiembre',2025,60.00,1,0,0,'419','2025-09-01',60.00,0,NULL),(26309,39,'octubre',2025,60.00,1,0,0,'440','2025-10-01',60.00,0,NULL),(26310,39,'noviembre',2025,60.00,1,0,0,'440','2025-11-01',60.00,0,NULL),(26311,40,'febrero',2025,60.00,1,0,0,'91','2025-02-01',60.00,0,NULL),(26312,40,'marzo',2025,60.00,1,0,0,'129','2025-03-01',60.00,0,NULL),(26313,40,'abril',2025,60.00,1,0,0,'129','2025-04-01',60.00,0,NULL),(26314,40,'mayo',2025,60.00,1,0,0,'205','2025-05-01',60.00,0,NULL),(26315,40,'junio',2025,60.00,1,0,0,'247','2025-06-01',60.00,0,NULL),(26316,40,'julio',2025,60.00,1,0,0,'299','2025-07-01',60.00,0,NULL),(26317,40,'agosto',2025,60.00,1,0,0,'350','2025-08-01',60.00,0,NULL),(26318,40,'septiembre',2025,60.00,1,0,0,'396','2025-09-01',60.00,0,NULL),(26319,40,'octubre',2025,60.00,1,0,0,'458','2025-10-01',60.00,0,NULL),(26320,40,'noviembre',2025,60.00,1,0,0,'507','2025-11-01',60.00,0,NULL),(26321,41,'febrero',2025,60.00,1,0,0,'153','2025-02-01',60.00,0,NULL),(26322,41,'marzo',2025,60.00,1,0,0,'207','2025-03-01',60.00,0,NULL),(26323,41,'abril',2025,60.00,1,0,0,'250','2025-04-01',60.00,0,NULL),(26324,41,'mayo',2025,60.00,1,0,0,'250','2025-05-01',60.00,0,NULL),(26325,41,'junio',2025,60.00,1,0,0,'301','2025-06-01',60.00,0,NULL),(26326,41,'julio',2025,60.00,1,0,0,'322','2025-07-01',60.00,0,NULL),(26327,41,'agosto',2025,60.00,1,0,0,'348','2025-08-01',60.00,0,NULL),(26328,41,'septiembre',2025,60.00,1,0,0,'395','2025-09-01',60.00,0,NULL),(26329,41,'octubre',2025,60.00,1,0,0,'434','2025-10-01',60.00,0,NULL),(26330,41,'noviembre',2025,60.00,1,0,0,'434','2025-11-01',60.00,0,NULL),(26331,42,'febrero',2025,60.00,1,0,0,'82','2025-02-01',60.00,0,NULL),(26332,42,'marzo',2025,60.00,1,0,0,'157','2025-03-01',60.00,0,NULL),(26333,42,'abril',2025,60.00,1,0,0,'198','2025-04-01',60.00,0,NULL),(26334,42,'mayo',2025,60.00,1,0,0,'244','2025-05-01',60.00,0,NULL),(26335,42,'junio',2025,60.00,1,0,0,'324','2025-06-01',60.00,0,NULL),(26336,42,'julio',2025,60.00,1,0,0,'347','2025-07-01',60.00,0,NULL),(26337,42,'agosto',2025,60.00,1,0,0,'376','2025-08-01',60.00,0,NULL),(26338,42,'septiembre',2025,60.00,1,0,0,'421','2025-09-01',60.00,0,NULL),(26339,42,'octubre',2025,60.00,1,0,0,'461','2025-10-01',60.00,0,NULL),(26340,42,'noviembre',2025,60.00,1,0,0,'513','2025-11-01',60.00,0,NULL),(26341,43,'febrero',2025,60.00,1,0,0,'117','2025-02-01',60.00,0,NULL),(26342,43,'marzo',2025,60.00,1,0,0,'199','2025-03-01',60.00,0,NULL),(26343,43,'abril',2025,60.00,1,0,0,'199','2025-04-01',60.00,0,NULL),(26344,43,'mayo',2025,60.00,1,0,0,'254','2025-05-01',60.00,0,NULL),(26345,43,'junio',2025,60.00,1,0,0,'353','2025-06-01',60.00,0,NULL),(26346,43,'julio',2025,60.00,1,0,0,'375','2025-07-01',60.00,0,NULL),(26347,43,'agosto',2025,60.00,1,0,0,'394','2025-08-01',60.00,0,NULL),(26348,43,'septiembre',2025,60.00,1,0,0,'415','2025-09-01',60.00,0,NULL),(26349,43,'octubre',2025,60.00,1,0,0,'435','2025-10-01',60.00,0,NULL),(26350,43,'noviembre',2025,60.00,1,0,0,'515','2025-11-01',60.00,0,NULL),(26351,44,'febrero',2025,60.00,1,0,0,'89','2025-02-01',60.00,0,NULL),(26352,44,'marzo',2025,60.00,1,0,0,'154','2025-03-01',60.00,0,NULL),(26353,44,'abril',2025,60.00,1,0,0,'209','2025-04-01',60.00,0,NULL),(26354,44,'mayo',2025,60.00,1,0,0,'251','2025-05-01',60.00,0,NULL),(26355,44,'junio',2025,60.00,1,0,0,'321','2025-06-01',60.00,0,NULL),(26356,44,'julio',2025,60.00,1,0,0,'374','2025-07-01',60.00,0,NULL),(26357,44,'agosto',2025,60.00,1,0,0,'427','2025-08-01',60.00,0,NULL),(26358,44,'septiembre',2025,60.00,1,0,0,'462','2025-09-01',60.00,0,NULL),(26359,44,'octubre',2025,60.00,1,0,0,'511','2025-10-01',60.00,0,NULL),(26360,44,'noviembre',2025,60.00,1,0,0,'511','2025-11-01',60.00,0,NULL),(26361,45,'febrero',2025,60.00,1,0,0,'83','2025-02-01',60.00,0,NULL),(26362,45,'marzo',2025,60.00,1,0,0,'127','2025-03-01',60.00,0,NULL),(26363,45,'abril',2025,60.00,1,0,0,'208','2025-04-01',60.00,0,NULL),(26364,45,'mayo',2025,60.00,1,0,0,'275','2025-05-01',60.00,0,NULL),(26365,45,'junio',2025,60.00,1,0,0,'323','2025-06-01',60.00,0,NULL),(26366,45,'julio',2025,60.00,1,0,0,'344','2025-07-01',60.00,0,NULL),(26367,45,'agosto',2025,60.00,1,0,0,'416','2025-08-01',60.00,0,NULL),(26368,45,'septiembre',2025,60.00,1,0,0,'438','2025-09-01',60.00,0,NULL),(26369,45,'octubre',2025,60.00,1,0,0,'438','2025-10-01',60.00,0,NULL),(26370,45,'noviembre',2025,60.00,1,0,0,'438','2025-11-01',60.00,0,NULL),(26371,46,'febrero',2025,60.00,1,0,0,'92','2025-02-01',60.00,0,NULL),(26372,46,'marzo',2025,60.00,1,0,0,'162','2025-03-01',60.00,0,NULL),(26373,46,'abril',2025,60.00,1,0,0,'201','2025-04-01',60.00,0,NULL),(26374,46,'mayo',2025,60.00,1,0,0,'248','2025-05-01',60.00,0,NULL),(26375,46,'junio',2025,60.00,1,0,0,'302','2025-06-01',60.00,0,NULL),(26376,46,'julio',2025,60.00,1,0,0,'352','2025-07-01',60.00,0,NULL),(26377,46,'agosto',2025,60.00,1,0,0,'393','2025-08-01',60.00,0,NULL),(26378,46,'septiembre',2025,60.00,1,0,0,'459','2025-09-01',60.00,0,NULL),(26379,46,'octubre',2025,60.00,1,0,0,'514','2025-10-01',60.00,0,NULL),(26380,46,'noviembre',2025,60.00,1,0,0,'514','2025-11-01',60.00,0,NULL),(26381,47,'febrero',2025,60.00,1,0,0,'95','2025-02-01',60.00,0,NULL),(26382,47,'marzo',2025,60.00,1,0,0,'160','2025-03-01',60.00,0,NULL),(26383,47,'abril',2025,60.00,1,0,0,'197','2025-04-01',60.00,0,NULL),(26384,47,'mayo',2025,60.00,1,0,0,'225','2025-05-01',60.00,0,NULL),(26385,47,'junio',2025,60.00,1,0,0,'304','2025-06-01',60.00,0,NULL),(26386,47,'julio',2025,60.00,1,0,0,'327','2025-07-01',60.00,0,NULL),(26387,47,'agosto',2025,60.00,1,0,0,'372','2025-08-01',60.00,0,NULL),(26388,47,'septiembre',2025,60.00,1,0,0,'392','2025-09-01',60.00,0,NULL),(26389,47,'octubre',2025,60.00,1,0,0,'428','2025-10-01',60.00,0,NULL),(26390,47,'noviembre',2025,60.00,1,0,0,'493','2025-11-01',60.00,0,NULL),(26391,48,'febrero',2025,60.00,1,0,0,'115','2025-02-01',60.00,0,NULL),(26392,48,'marzo',2025,60.00,1,0,0,'161','2025-03-01',60.00,0,NULL),(26393,48,'abril',2025,60.00,1,0,0,'202','2025-04-01',60.00,0,NULL),(26394,48,'mayo',2025,60.00,1,0,0,'223','2025-05-01',60.00,0,NULL),(26395,48,'junio',2025,60.00,1,0,0,'257','2025-06-01',60.00,0,NULL),(26396,48,'julio',2025,60.00,1,0,0,'303','2025-07-01',60.00,0,NULL),(26397,48,'agosto',2025,60.00,1,0,0,'370','2025-08-01',60.00,0,NULL),(26398,48,'septiembre',2025,60.00,1,0,0,'417','2025-09-01',60.00,0,NULL),(26399,48,'octubre',2025,60.00,1,0,0,'429','2025-10-01',60.00,0,NULL),(26400,48,'noviembre',2025,60.00,1,0,0,'429','2025-11-01',60.00,0,NULL),(26401,49,'febrero',2025,60.00,1,0,0,'90','2025-02-01',60.00,0,NULL),(26402,49,'marzo',2025,60.00,1,0,0,'152','2025-03-01',60.00,0,NULL),(26403,49,'abril',2025,60.00,1,0,0,'206','2025-04-01',60.00,0,NULL),(26404,49,'mayo',2025,60.00,1,0,0,'206','2025-05-01',60.00,0,NULL),(26405,49,'junio',2025,60.00,1,0,0,'274','2025-06-01',60.00,0,NULL),(26406,49,'julio',2025,60.00,1,0,0,'354','2025-07-01',60.00,0,NULL),(26407,49,'agosto',2025,60.00,1,0,0,'430','2025-08-01',60.00,0,NULL),(26408,49,'septiembre',2025,60.00,1,0,0,'430','2025-09-01',60.00,0,NULL),(26409,49,'octubre',2025,60.00,1,0,0,'490','2025-10-01',60.00,0,NULL),(26410,49,'noviembre',2025,60.00,1,0,0,'512','2025-11-01',60.00,0,NULL),(26411,50,'febrero',2025,60.00,1,0,0,'87','2025-02-01',60.00,0,NULL),(26412,50,'marzo',2025,60.00,1,0,0,'116','2025-03-01',60.00,0,NULL),(26413,50,'abril',2025,60.00,1,0,0,'204','2025-04-01',60.00,0,NULL),(26414,50,'mayo',2025,60.00,1,0,0,'222','2025-05-01',60.00,0,NULL),(26415,50,'junio',2025,60.00,1,0,0,'300','2025-06-01',60.00,0,NULL),(26416,50,'julio',2025,60.00,1,0,0,'325','2025-07-01',60.00,0,NULL),(26417,50,'agosto',2025,60.00,1,0,0,'349','2025-08-01',60.00,0,NULL),(26418,50,'septiembre',2025,60.00,1,0,0,'373','2025-09-01',60.00,0,NULL),(26419,50,'octubre',2025,60.00,1,0,0,'504','2025-10-01',60.00,0,NULL),(26420,50,'noviembre',2025,60.00,1,0,0,'504','2025-11-01',60.00,0,NULL),(26421,51,'febrero',2025,60.00,1,0,0,'81','2025-02-01',60.00,0,NULL),(26422,51,'marzo',2025,60.00,1,0,0,'126','2025-03-01',60.00,0,NULL),(26423,51,'abril',2025,60.00,1,0,0,'203','2025-04-01',60.00,0,NULL),(26424,51,'mayo',2025,60.00,1,0,0,'203','2025-05-01',60.00,0,NULL),(26425,51,'junio',2025,60.00,1,0,0,'273','2025-06-01',60.00,0,NULL),(26426,51,'julio',2025,60.00,1,0,0,'346','2025-07-01',60.00,0,NULL),(26427,51,'agosto',2025,60.00,1,0,0,'397','2025-08-01',60.00,0,NULL),(26428,51,'septiembre',2025,60.00,1,0,0,'431','2025-09-01',60.00,0,NULL),(26429,51,'octubre',2025,60.00,1,0,0,'505','2025-10-01',60.00,0,NULL),(26430,51,'noviembre',2025,60.00,1,0,0,'505','2025-11-01',60.00,0,NULL),(26431,52,'febrero',2025,60.00,1,0,0,'109','2025-02-01',60.00,0,NULL),(26432,52,'marzo',2025,60.00,1,0,0,'140','2025-03-01',60.00,0,NULL),(26433,52,'abril',2025,60.00,1,0,0,'286','2025-04-01',60.00,0,NULL),(26434,52,'mayo',2025,60.00,1,0,0,'286','2025-05-01',60.00,0,NULL),(26435,52,'junio',2025,60.00,1,0,0,'286','2025-06-01',60.00,0,NULL),(26436,52,'julio',2025,60.00,1,0,0,'338','2025-07-01',60.00,0,NULL),(26437,52,'agosto',2025,60.00,1,0,0,'495','2025-08-01',60.00,0,NULL),(26438,52,'septiembre',2025,60.00,1,0,0,'495','2025-09-01',60.00,0,NULL),(26439,52,'octubre',2025,60.00,1,0,0,'495','2025-10-01',60.00,0,NULL),(26440,52,'noviembre',2025,60.00,1,0,0,'495','2025-11-01',60.00,0,NULL),(26441,53,'febrero',2025,60.00,1,0,0,'88','2025-02-01',60.00,0,NULL),(26442,53,'marzo',2025,60.00,1,0,0,'246','2025-03-01',60.00,0,NULL),(26443,53,'abril',2025,60.00,1,0,0,'246','2025-04-01',60.00,0,NULL),(26444,53,'mayo',2025,60.00,1,0,0,'246','2025-05-01',60.00,0,NULL),(26445,53,'junio',2025,60.00,1,0,0,'351','2025-06-01',60.00,0,NULL),(26446,53,'julio',2025,60.00,1,0,0,'351','2025-07-01',60.00,0,NULL),(26447,53,'agosto',2025,60.00,1,0,0,'420','2025-08-01',60.00,0,NULL),(26448,53,'septiembre',2025,60.00,1,0,0,'420','2025-09-01',60.00,0,NULL),(26449,53,'octubre',2025,60.00,1,0,0,'491','2025-10-01',60.00,0,NULL),(26450,53,'noviembre',2025,60.00,1,0,0,'506','2025-11-01',60.00,0,NULL),(26451,54,'febrero',2025,60.00,1,0,0,'85','2025-02-01',60.00,0,NULL),(26452,54,'marzo',2025,60.00,1,0,0,'158','2025-03-01',60.00,0,NULL),(26453,54,'abril',2025,60.00,1,0,0,'221','2025-04-01',60.00,0,NULL),(26454,54,'mayo',2025,60.00,1,0,0,'221','2025-05-01',60.00,0,NULL),(26455,54,'junio',2025,60.00,1,0,0,'298','2025-06-01',60.00,0,NULL),(26456,54,'julio',2025,60.00,1,0,0,'298','2025-07-01',60.00,0,NULL),(26457,54,'agosto',2025,60.00,1,0,0,'418','2025-08-01',60.00,0,NULL),(26458,54,'septiembre',2025,60.00,1,0,0,'418','2025-09-01',60.00,0,NULL),(26459,54,'octubre',2025,60.00,1,0,0,'494','2025-10-01',60.00,0,NULL),(26460,54,'noviembre',2025,60.00,1,0,0,'494','2025-11-01',60.00,0,NULL),(26461,55,'febrero',2025,60.00,1,0,0,'84','2025-02-01',60.00,0,NULL),(26462,55,'marzo',2025,60.00,1,0,0,'156','2025-03-01',60.00,0,NULL),(26463,55,'abril',2025,60.00,1,0,0,'211','2025-04-01',60.00,0,NULL),(26464,55,'mayo',2025,60.00,1,0,0,'258','2025-05-01',60.00,0,NULL),(26465,55,'junio',2025,60.00,1,0,0,'345','2025-06-01',60.00,0,NULL),(26466,55,'julio',2025,60.00,1,0,0,'460','2025-07-01',60.00,0,NULL),(26467,55,'agosto',2025,60.00,1,0,0,'492','2025-08-01',60.00,0,NULL),(26468,55,'septiembre',2025,60.00,1,0,0,'492','2025-09-01',60.00,0,NULL),(26469,55,'octubre',2025,60.00,1,0,0,'492','2025-10-01',60.00,0,NULL),(26470,55,'noviembre',2025,60.00,1,0,0,'492','2025-11-01',60.00,0,NULL),(26471,56,'febrero',2025,60.00,1,0,0,'61','2025-02-01',60.00,0,NULL),(26472,56,'marzo',2025,60.00,1,0,0,'61','2025-03-01',60.00,0,NULL),(26473,56,'abril',2025,60.00,1,0,0,'61','2025-04-01',60.00,0,NULL),(26474,56,'mayo',2025,60.00,1,0,0,'186','2025-05-01',60.00,0,NULL),(26475,56,'junio',2025,60.00,1,0,0,'319','2025-06-01',60.00,0,NULL),(26476,56,'julio',2025,60.00,1,0,0,'319','2025-07-01',60.00,0,NULL),(26477,56,'agosto',2025,60.00,1,0,0,'367','2025-08-01',60.00,0,NULL),(26478,56,'septiembre',2025,60.00,1,0,0,'412','2025-09-01',60.00,0,NULL),(26479,56,'octubre',2025,60.00,1,0,0,'457','2025-10-01',60.00,0,NULL),(26480,56,'noviembre',2025,60.00,1,0,0,'508','2025-11-01',60.00,0,NULL),(26481,57,'febrero',2025,60.00,1,0,0,'123','2025-02-01',60.00,0,NULL),(26482,57,'marzo',2025,60.00,1,0,0,'182','2025-03-01',60.00,0,NULL),(26483,57,'abril',2025,60.00,1,0,0,'264','2025-04-01',60.00,0,NULL),(26484,57,'mayo',2025,60.00,1,0,0,'289','2025-05-01',60.00,0,NULL),(26485,57,'junio',2025,60.00,1,0,0,'337','2025-06-01',60.00,0,NULL),(26486,57,'julio',2025,60.00,1,0,0,'381','2025-07-01',60.00,0,NULL),(26487,57,'agosto',2025,60.00,1,0,0,'425','2025-08-01',60.00,0,NULL),(26488,57,'septiembre',2025,60.00,1,0,0,'466','2025-09-01',60.00,0,NULL),(26489,57,'octubre',2025,60.00,1,0,0,'530','2025-10-01',60.00,0,NULL),(26490,57,'noviembre',2025,60.00,1,0,0,'530','2025-11-01',60.00,0,NULL),(26491,58,'abril',2025,60.00,1,0,0,'231','2025-04-01',60.00,0,NULL),(26492,58,'mayo',2025,60.00,1,0,0,'267','2025-05-01',60.00,0,NULL),(26493,58,'junio',2025,60.00,1,0,0,'292','2025-06-01',60.00,0,NULL),(26494,58,'julio',2025,60.00,1,0,0,'339','2025-07-01',60.00,0,NULL),(26495,58,'agosto',2025,60.00,1,0,0,'383','2025-08-01',60.00,0,NULL),(26496,58,'septiembre',2025,60.00,1,0,0,'406','2025-09-01',60.00,0,NULL),(26497,58,'octubre',2025,60.00,1,0,0,'496','2025-10-01',60.00,0,NULL),(26498,58,'noviembre',2025,60.00,1,0,0,'534','2025-11-01',60.00,0,NULL),(26499,59,'abril',2025,60.00,1,0,0,'232','2025-04-01',60.00,0,NULL),(26500,59,'mayo',2025,60.00,1,0,0,'268','2025-05-01',60.00,0,NULL),(26501,59,'junio',2025,60.00,1,0,0,'293','2025-06-01',60.00,0,NULL),(26502,59,'julio',2025,60.00,1,0,0,'340','2025-07-01',60.00,0,NULL),(26503,59,'agosto',2025,60.00,1,0,0,'384','2025-08-01',60.00,0,NULL),(26504,59,'septiembre',2025,60.00,1,0,0,'405','2025-09-01',60.00,0,NULL),(26505,59,'octubre',2025,60.00,1,0,0,'497','2025-10-01',60.00,0,NULL),(26506,59,'noviembre',2025,60.00,1,0,0,'535','2025-11-01',60.00,0,NULL),(26537,4,'febrero',2025,60.00,1,0,0,'166','2025-02-01',60.00,0,NULL),(26538,4,'marzo',2025,60.00,1,0,0,'166','2025-03-01',60.00,0,NULL),(26539,4,'abril',2025,60.00,1,0,0,'166','2025-04-01',60.00,0,NULL),(26540,4,'mayo',2025,60.00,1,0,0,'403','2025-05-01',60.00,0,NULL),(26541,4,'junio',2025,60.00,1,0,0,'403','2025-06-01',60.00,0,NULL),(26542,4,'julio',2025,60.00,1,0,0,'480','2025-07-01',60.00,0,NULL),(26543,4,'agosto',2025,60.00,1,0,0,'480','2025-08-01',60.00,0,NULL),(26544,4,'septiembre',2025,60.00,1,0,0,'480','2025-09-01',60.00,0,NULL),(26545,4,'octubre',2025,60.00,1,0,0,'480','2025-10-01',60.00,0,NULL),(26546,4,'noviembre',2025,60.00,1,0,0,'520','2025-11-01',60.00,0,NULL),(26547,5,'febrero',2025,60.00,1,0,0,'106','2025-02-01',60.00,0,NULL),(26548,5,'marzo',2025,60.00,1,0,0,'130','2025-03-01',60.00,0,NULL),(26549,5,'abril',2025,60.00,1,0,0,'240','2025-04-01',60.00,0,NULL),(26550,5,'mayo',2025,60.00,1,0,0,'240','2025-05-01',60.00,0,NULL),(26551,5,'junio',2025,60.00,1,0,0,'333','2025-06-01',60.00,0,NULL),(26552,5,'julio',2025,60.00,1,0,0,'333','2025-07-01',60.00,0,NULL),(26553,5,'agosto',2025,60.00,1,0,0,'482','2025-08-01',60.00,0,NULL),(26554,5,'septiembre',2025,60.00,1,0,0,'482','2025-09-01',60.00,0,NULL),(26555,5,'octubre',2025,60.00,1,0,0,'482','2025-10-01',60.00,0,NULL),(26556,5,'noviembre',2025,60.00,1,0,0,'499','2025-11-01',60.00,0,NULL),(26557,6,'febrero',2025,60.00,1,0,0,'99','2025-02-01',60.00,0,NULL),(26558,6,'marzo',2025,60.00,1,0,0,'138','2025-03-01',60.00,0,NULL),(26559,6,'abril',2025,60.00,1,0,0,'214','2025-04-01',60.00,0,NULL),(26560,6,'mayo',2025,60.00,1,0,0,'259','2025-05-01',60.00,0,NULL),(26561,6,'junio',2025,60.00,1,0,0,'329','2025-06-01',60.00,0,NULL),(26562,6,'julio',2025,60.00,1,0,0,'404','2025-07-01',60.00,0,NULL),(26563,6,'agosto',2025,60.00,1,0,0,'447','2025-08-01',60.00,0,NULL),(26564,6,'septiembre',2025,60.00,1,0,0,'481','2025-09-01',60.00,0,NULL),(26565,6,'octubre',2025,60.00,1,0,0,'481','2025-10-01',60.00,0,NULL),(26566,6,'noviembre',2025,60.00,1,0,0,'521','2025-11-01',60.00,0,NULL),(26567,7,'febrero',2025,60.00,1,0,0,'101','2025-02-01',60.00,0,NULL),(26568,7,'marzo',2025,60.00,1,0,0,'163','2025-03-01',60.00,0,NULL),(26569,7,'abril',2025,60.00,1,0,0,'215','2025-04-01',60.00,0,NULL),(26570,7,'mayo',2025,60.00,1,0,0,'243','2025-05-01',60.00,0,NULL),(26571,7,'junio',2025,60.00,1,0,0,'330','2025-06-01',60.00,0,NULL),(26572,7,'julio',2025,60.00,1,0,0,'330','2025-07-01',60.00,0,NULL),(26573,7,'agosto',2025,60.00,1,0,0,'360','2025-08-01',60.00,0,NULL),(26574,7,'septiembre',2025,60.00,1,0,0,'401','2025-09-01',60.00,0,NULL),(26575,7,'octubre',2025,60.00,1,0,0,'483','2025-10-01',60.00,0,NULL),(26576,7,'noviembre',2025,60.00,1,0,0,'523','2025-11-01',60.00,0,NULL),(26577,8,'febrero',2025,60.00,1,0,0,'56','2025-02-01',60.00,0,NULL),(26578,8,'marzo',2025,60.00,1,0,0,'56','2025-03-01',60.00,0,NULL),(26579,8,'abril',2025,60.00,1,0,0,'56','2025-04-01',60.00,0,NULL),(26580,8,'mayo',2025,60.00,1,0,0,'212','2025-05-01',60.00,0,NULL),(26581,8,'junio',2025,60.00,1,0,0,'212','2025-06-01',60.00,0,NULL),(26582,8,'julio',2025,60.00,1,0,0,'212','2025-07-01',60.00,0,NULL),(26583,8,'agosto',2025,60.00,1,0,0,'212','2025-08-01',60.00,0,NULL),(26584,8,'septiembre',2025,60.00,1,0,0,'470','2025-09-01',60.00,0,NULL),(26585,8,'octubre',2025,60.00,1,0,0,'470','2025-10-01',60.00,0,NULL),(26586,8,'noviembre',2025,60.00,1,0,0,'471','2025-11-01',60.00,0,NULL),(26587,9,'febrero',2025,60.00,1,0,0,'103','2025-02-01',60.00,0,NULL),(26588,9,'marzo',2025,60.00,1,0,0,'134','2025-03-01',60.00,0,NULL),(26589,9,'abril',2025,60.00,1,0,0,'168','2025-04-01',60.00,0,NULL),(26590,9,'mayo',2025,60.00,1,0,0,'245','2025-05-01',60.00,0,NULL),(26591,9,'junio',2025,60.00,1,0,0,'281','2025-06-01',60.00,0,NULL),(26592,9,'julio',2025,60.00,1,0,0,'358','2025-07-01',60.00,0,NULL),(26593,9,'agosto',2025,60.00,1,0,0,'398','2025-08-01',60.00,0,NULL),(26594,9,'septiembre',2025,60.00,1,0,0,'445','2025-09-01',60.00,0,NULL),(26595,9,'octubre',2025,60.00,1,0,0,'445','2025-10-01',60.00,0,NULL),(26596,9,'noviembre',2025,60.00,1,0,0,'445','2025-11-01',60.00,0,NULL),(26597,10,'febrero',2025,60.00,1,0,0,'54','2025-02-01',60.00,0,NULL),(26598,10,'marzo',2025,60.00,1,0,0,'54','2025-03-01',60.00,0,NULL),(26599,10,'abril',2025,60.00,1,0,0,'54','2025-04-01',60.00,0,NULL),(26600,10,'mayo',2025,60.00,1,0,0,'242','2025-05-01',60.00,0,NULL),(26601,10,'junio',2025,60.00,1,0,0,'305','2025-06-01',60.00,0,NULL),(26602,10,'julio',2025,60.00,1,0,0,'359','2025-07-01',60.00,0,NULL),(26603,10,'agosto',2025,60.00,1,0,0,'390','2025-08-01',60.00,0,NULL),(26604,10,'septiembre',2025,60.00,1,0,0,'472','2025-09-01',60.00,0,NULL),(26605,10,'octubre',2025,60.00,1,0,0,'472','2025-10-01',60.00,0,NULL),(26606,10,'noviembre',2025,60.00,1,0,0,'518','2025-11-01',60.00,0,NULL),(26607,11,'febrero',2025,60.00,1,0,0,'102','2025-02-01',60.00,0,NULL),(26608,11,'marzo',2025,60.00,1,0,0,'133','2025-03-01',60.00,0,NULL),(26609,11,'abril',2025,60.00,1,0,0,'173','2025-04-01',60.00,0,NULL),(26610,11,'mayo',2025,60.00,1,0,0,'241','2025-05-01',60.00,0,NULL),(26611,11,'junio',2025,60.00,1,0,0,'308','2025-06-01',60.00,0,NULL),(26612,11,'julio',2025,60.00,1,0,0,'363','2025-07-01',60.00,0,NULL),(26613,11,'agosto',2025,60.00,1,0,0,'422','2025-08-01',60.00,0,NULL),(26614,11,'septiembre',2025,60.00,1,0,0,'452','2025-09-01',60.00,0,NULL),(26615,11,'octubre',2025,60.00,1,0,0,'473','2025-10-01',60.00,0,NULL),(26616,11,'noviembre',2025,60.00,1,0,0,'517','2025-11-01',60.00,0,NULL),(26617,13,'febrero',2025,60.00,1,0,0,'119','2025-02-01',60.00,0,NULL),(26618,13,'marzo',2025,60.00,1,0,0,'252','2025-03-01',60.00,0,NULL),(26619,13,'abril',2025,60.00,1,0,0,'283','2025-04-01',60.00,0,NULL),(26620,13,'mayo',2025,60.00,1,0,0,'283','2025-05-01',60.00,0,NULL),(26621,13,'junio',2025,60.00,1,0,0,'443','2025-06-01',60.00,0,NULL),(26622,13,'julio',2025,60.00,1,0,0,'443','2025-07-01',60.00,0,NULL),(26623,13,'agosto',2025,60.00,1,0,0,'443','2025-08-01',60.00,0,NULL),(26624,13,'septiembre',2025,60.00,1,0,0,'443','2025-09-01',60.00,0,NULL),(26625,13,'octubre',2025,60.00,1,0,0,'479','2025-10-01',60.00,0,NULL),(26626,13,'noviembre',2025,60.00,1,0,0,'524','2025-11-01',60.00,0,NULL),(26627,14,'marzo',2025,60.00,1,0,0,'141','2025-03-01',60.00,0,NULL),(26628,14,'abril',2025,60.00,1,0,0,'141','2025-04-01',60.00,0,NULL),(26629,14,'mayo',2025,60.00,1,0,0,'227','2025-05-01',60.00,0,NULL),(26630,14,'junio',2025,60.00,1,0,0,'227','2025-06-01',60.00,0,NULL),(26631,14,'julio',2025,60.00,1,0,0,'227','2025-07-01',60.00,0,NULL),(26632,14,'agosto',2025,60.00,1,0,0,'227','2025-08-01',60.00,0,NULL),(26633,14,'septiembre',2025,60.00,1,0,0,'468','2025-09-01',60.00,0,NULL),(26634,14,'octubre',2025,60.00,1,0,0,'468','2025-10-01',60.00,0,NULL),(26635,14,'noviembre',2025,60.00,1,0,0,'531','2025-11-01',60.00,0,NULL),(26636,16,'febrero',2025,60.00,1,0,0,'96','2025-02-01',60.00,0,NULL),(26637,16,'marzo',2025,60.00,1,0,0,'167','2025-03-01',60.00,0,NULL),(26638,16,'abril',2025,60.00,1,0,0,'167','2025-04-01',60.00,0,NULL),(26639,16,'mayo',2025,60.00,1,0,0,'279','2025-05-01',60.00,0,NULL),(26640,16,'junio',2025,60.00,1,0,0,'309','2025-06-01',60.00,0,NULL),(26641,16,'julio',2025,60.00,1,0,0,'389','2025-07-01',60.00,0,NULL),(26642,16,'agosto',2025,60.00,1,0,0,'446','2025-08-01',60.00,0,NULL),(26643,16,'septiembre',2025,60.00,1,0,0,'446','2025-09-01',60.00,0,NULL),(26644,16,'octubre',2025,60.00,1,0,0,'519','2025-10-01',60.00,0,NULL),(26645,16,'noviembre',2025,60.00,1,0,0,'519','2025-11-01',60.00,0,NULL),(26646,17,'febrero',2025,60.00,1,0,0,'100','2025-02-01',60.00,0,NULL),(26647,17,'marzo',2025,60.00,1,0,0,'131','2025-03-01',60.00,0,NULL),(26648,17,'abril',2025,60.00,1,0,0,'213','2025-04-01',60.00,0,NULL),(26649,17,'mayo',2025,60.00,1,0,0,'249','2025-05-01',60.00,0,NULL),(26650,17,'junio',2025,60.00,1,0,0,'282','2025-06-01',60.00,0,NULL),(26651,17,'julio',2025,60.00,1,0,0,'306','2025-07-01',60.00,0,NULL),(26652,17,'agosto',2025,60.00,1,0,0,'328','2025-08-01',60.00,0,NULL),(26653,17,'septiembre',2025,60.00,1,0,0,'448','2025-09-01',60.00,0,NULL),(26654,17,'octubre',2025,60.00,1,0,0,'467','2025-10-01',60.00,0,NULL),(26655,17,'noviembre',2025,60.00,1,0,0,'516','2025-11-01',60.00,0,NULL),(26656,18,'febrero',2025,60.00,1,0,0,'107','2025-02-01',60.00,0,NULL),(26657,18,'marzo',2025,60.00,1,0,0,'132','2025-03-01',60.00,0,NULL),(26658,18,'abril',2025,60.00,1,0,0,'171','2025-04-01',60.00,0,NULL),(26659,18,'mayo',2025,60.00,1,0,0,'262','2025-05-01',60.00,0,NULL),(26660,18,'junio',2025,60.00,1,0,0,'280','2025-06-01',60.00,0,NULL),(26661,18,'julio',2025,60.00,1,0,0,'332','2025-07-01',60.00,0,NULL),(26662,18,'agosto',2025,60.00,1,0,0,'386','2025-08-01',60.00,0,NULL),(26663,18,'septiembre',2025,60.00,1,0,0,'450','2025-09-01',60.00,0,NULL),(26664,18,'octubre',2025,60.00,1,0,0,'469','2025-10-01',60.00,0,NULL),(26665,18,'noviembre',2025,60.00,1,0,0,'527','2025-11-01',60.00,0,NULL),(26666,19,'febrero',2025,60.00,1,0,0,'66','2025-02-01',60.00,0,NULL),(26667,19,'marzo',2025,60.00,1,0,0,'66','2025-03-01',60.00,0,NULL),(26668,19,'abril',2025,60.00,1,0,0,'66','2025-04-01',60.00,0,NULL),(26669,19,'mayo',2025,60.00,1,0,0,'253','2025-05-01',60.00,0,NULL),(26670,19,'junio',2025,60.00,1,0,0,'253','2025-06-01',60.00,0,NULL),(26671,19,'julio',2025,60.00,1,0,0,'385','2025-07-01',60.00,0,NULL),(26672,19,'agosto',2025,60.00,1,0,0,'385','2025-08-01',60.00,0,NULL),(26673,19,'septiembre',2025,60.00,1,0,0,'385','2025-09-01',60.00,0,NULL),(26674,19,'octubre',2025,60.00,1,0,0,'385','2025-10-01',60.00,0,NULL),(26675,19,'noviembre',2025,60.00,1,0,0,'528','2025-11-01',60.00,0,NULL),(26676,20,'febrero',2025,60.00,1,0,0,'104','2025-02-01',60.00,0,NULL),(26677,20,'marzo',2025,60.00,1,0,0,'174','2025-03-01',60.00,0,NULL),(26678,20,'abril',2025,60.00,1,0,0,'216','2025-04-01',60.00,0,NULL),(26679,20,'mayo',2025,60.00,1,0,0,'278','2025-05-01',60.00,0,NULL),(26680,20,'junio',2025,60.00,1,0,0,'357','2025-06-01',60.00,0,NULL),(26681,20,'julio',2025,60.00,1,0,0,'357','2025-07-01',60.00,0,NULL),(26682,20,'agosto',2025,60.00,1,0,0,'387','2025-08-01',60.00,0,NULL),(26683,20,'septiembre',2025,60.00,1,0,0,'451','2025-09-01',60.00,0,NULL),(26684,20,'octubre',2025,60.00,1,0,0,'475','2025-10-01',60.00,0,NULL),(26685,20,'noviembre',2025,60.00,1,0,0,'485','2025-11-01',60.00,0,NULL),(26686,21,'marzo',2025,60.00,1,0,0,'142','2025-03-01',60.00,0,NULL),(26687,21,'abril',2025,60.00,1,0,0,'180','2025-04-01',60.00,0,NULL),(26688,21,'mayo',2025,60.00,1,0,0,'228','2025-05-01',60.00,0,NULL),(26689,21,'junio',2025,60.00,1,0,0,'228','2025-06-01',60.00,0,NULL),(26690,21,'julio',2025,60.00,1,0,0,'311','2025-07-01',60.00,0,NULL),(26691,21,'agosto',2025,60.00,1,0,0,'380','2025-08-01',60.00,0,NULL),(26692,21,'septiembre',2025,60.00,1,0,0,'380','2025-09-01',60.00,0,NULL),(26693,21,'octubre',2025,60.00,1,0,0,'464','2025-10-01',60.00,0,NULL),(26694,21,'noviembre',2025,60.00,1,0,0,'464','2025-11-01',60.00,0,NULL),(26695,22,'febrero',2025,60.00,1,0,0,'122','2025-02-01',60.00,0,NULL),(26696,22,'marzo',2025,60.00,1,0,0,'181','2025-03-01',60.00,0,NULL),(26697,22,'abril',2025,60.00,1,0,0,'263','2025-04-01',60.00,0,NULL),(26698,22,'mayo',2025,60.00,1,0,0,'288','2025-05-01',60.00,0,NULL),(26699,22,'junio',2025,60.00,1,0,0,'336','2025-06-01',60.00,0,NULL),(26700,22,'julio',2025,60.00,1,0,0,'382','2025-07-01',60.00,0,NULL),(26701,22,'agosto',2025,60.00,1,0,0,'423','2025-08-01',60.00,0,NULL),(26702,22,'septiembre',2025,60.00,1,0,0,'465','2025-09-01',60.00,0,NULL),(26703,22,'octubre',2025,60.00,1,0,0,'529','2025-10-01',60.00,0,NULL),(26704,22,'noviembre',2025,60.00,1,0,0,'529','2025-11-01',60.00,0,NULL),(26705,24,'febrero',2025,60.00,1,0,0,'70','2025-02-01',60.00,0,NULL),(26706,24,'marzo',2025,60.00,1,0,0,'146','2025-03-01',60.00,0,NULL),(26707,24,'abril',2025,60.00,1,0,0,'219','2025-04-01',60.00,0,NULL),(26708,24,'mayo',2025,60.00,1,0,0,'236','2025-05-01',60.00,0,NULL),(26709,24,'junio',2025,60.00,1,0,0,'270','2025-06-01',60.00,0,NULL),(26710,24,'julio',2025,60.00,1,0,0,'295','2025-07-01',60.00,0,NULL),(26711,24,'agosto',2025,60.00,1,0,0,'313','2025-08-01',60.00,0,NULL),(26712,24,'septiembre',2025,60.00,1,0,0,'442','2025-09-01',60.00,0,NULL),(26713,24,'octubre',2025,60.00,1,0,0,'442','2025-10-01',60.00,0,NULL),(26714,24,'noviembre',2025,60.00,1,0,0,'442','2025-11-01',60.00,0,NULL),(26715,25,'febrero',2025,60.00,1,0,0,'79','2025-02-01',60.00,0,NULL),(26716,25,'marzo',2025,60.00,1,0,0,'113','2025-03-01',60.00,0,NULL),(26717,25,'abril',2025,60.00,1,0,0,'189','2025-04-01',60.00,0,NULL),(26718,25,'mayo',2025,60.00,1,0,0,'189','2025-05-01',60.00,0,NULL),(26719,25,'junio',2025,60.00,1,0,0,'291','2025-06-01',60.00,0,NULL),(26720,25,'julio',2025,60.00,1,0,0,'341','2025-07-01',60.00,0,NULL),(26721,25,'agosto',2025,60.00,1,0,0,'365','2025-08-01',60.00,0,NULL),(26722,25,'septiembre',2025,60.00,1,0,0,'436','2025-09-01',60.00,0,NULL),(26723,25,'octubre',2025,60.00,1,0,0,'436','2025-10-01',60.00,0,NULL),(26724,26,'febrero',2025,60.00,1,0,0,'73','2025-02-01',60.00,0,NULL),(26725,26,'marzo',2025,60.00,1,0,0,'148','2025-03-01',60.00,0,NULL),(26726,26,'abril',2025,60.00,1,0,0,'187','2025-04-01',60.00,0,NULL),(26727,26,'mayo',2025,60.00,1,0,0,'239','2025-05-01',60.00,0,NULL),(26728,26,'junio',2025,60.00,1,0,0,'317','2025-06-01',60.00,0,NULL),(26729,26,'julio',2025,60.00,1,0,0,'366','2025-07-01',60.00,0,NULL),(26730,26,'agosto',2025,60.00,1,0,0,'407','2025-08-01',60.00,0,NULL),(26731,26,'septiembre',2025,60.00,1,0,0,'456','2025-09-01',60.00,0,NULL),(26732,26,'octubre',2025,60.00,1,0,0,'536','2025-10-01',60.00,0,NULL),(26733,26,'noviembre',2025,60.00,1,0,0,'536','2025-11-01',60.00,0,NULL),(26734,27,'febrero',2025,60.00,1,0,0,'69','2025-02-01',60.00,0,NULL),(26735,27,'marzo',2025,60.00,1,0,0,'145','2025-03-01',60.00,0,NULL),(26736,27,'abril',2025,60.00,1,0,0,'184','2025-04-01',60.00,0,NULL),(26737,27,'mayo',2025,60.00,1,0,0,'237','2025-05-01',60.00,0,NULL),(26738,27,'junio',2025,60.00,1,0,0,'294','2025-06-01',60.00,0,NULL),(26739,27,'julio',2025,60.00,1,0,0,'343','2025-07-01',60.00,0,NULL),(26740,27,'agosto',2025,60.00,1,0,0,'408','2025-08-01',60.00,0,NULL),(26741,27,'septiembre',2025,60.00,1,0,0,'453','2025-09-01',60.00,0,NULL),(26742,27,'octubre',2025,60.00,1,0,0,'538','2025-10-01',60.00,0,NULL),(26743,27,'noviembre',2025,60.00,1,0,0,'538','2025-11-01',60.00,0,NULL),(26744,28,'febrero',2025,60.00,1,0,0,'71','2025-02-01',60.00,0,NULL),(26745,28,'marzo',2025,60.00,1,0,0,'147','2025-03-01',60.00,0,NULL),(26746,28,'abril',2025,60.00,1,0,0,'194','2025-04-01',60.00,0,NULL),(26747,28,'mayo',2025,60.00,1,0,0,'271','2025-05-01',60.00,0,NULL),(26748,28,'junio',2025,60.00,1,0,0,'318','2025-06-01',60.00,0,NULL),(26749,28,'julio',2025,60.00,1,0,0,'364','2025-07-01',60.00,0,NULL),(26750,28,'agosto',2025,60.00,1,0,0,'409','2025-08-01',60.00,0,NULL),(26751,28,'septiembre',2025,60.00,1,0,0,'437','2025-09-01',60.00,0,NULL),(26752,28,'octubre',2025,60.00,1,0,0,'510','2025-10-01',60.00,0,NULL),(26753,28,'noviembre',2025,60.00,1,0,0,'510','2025-11-01',60.00,0,NULL),(26754,29,'febrero',2025,60.00,1,0,0,'80','2025-02-01',60.00,0,NULL),(26755,29,'marzo',2025,60.00,1,0,0,'149','2025-03-01',60.00,0,NULL),(26756,29,'abril',2025,60.00,1,0,0,'188','2025-04-01',60.00,0,NULL),(26757,29,'mayo',2025,60.00,1,0,0,'296','2025-05-01',60.00,0,NULL),(26758,29,'junio',2025,60.00,1,0,0,'296','2025-06-01',60.00,0,NULL),(26759,29,'julio',2025,60.00,1,0,0,'391','2025-07-01',60.00,0,NULL),(26760,29,'agosto',2025,60.00,1,0,0,'391','2025-08-01',60.00,0,NULL),(26761,29,'septiembre',2025,60.00,1,0,0,'411','2025-09-01',60.00,0,NULL),(26762,29,'octubre',2025,60.00,1,0,0,'439','2025-10-01',60.00,0,NULL),(26763,29,'noviembre',2025,60.00,1,0,0,'439','2025-11-01',60.00,0,NULL),(26764,30,'febrero',2025,60.00,1,0,0,'108','2025-02-01',60.00,0,NULL),(26765,30,'marzo',2025,60.00,1,0,0,'139','2025-03-01',60.00,0,NULL),(26766,30,'abril',2025,60.00,1,0,0,'170','2025-04-01',60.00,0,NULL),(26767,30,'mayo',2025,60.00,1,0,0,'335','2025-05-01',60.00,0,NULL),(26768,30,'junio',2025,60.00,1,0,0,'335','2025-06-01',60.00,0,NULL),(26769,30,'julio',2025,60.00,1,0,0,'335','2025-07-01',60.00,0,NULL),(26770,30,'agosto',2025,60.00,1,0,0,'335','2025-08-01',60.00,0,NULL),(26771,30,'septiembre',2025,60.00,1,0,0,'335','2025-09-01',60.00,0,NULL),(26772,30,'octubre',2025,60.00,1,0,0,'335','2025-10-01',60.00,0,NULL),(26773,30,'noviembre',2025,60.00,1,0,0,'335','2025-11-01',60.00,0,NULL),(26774,31,'febrero',2025,60.00,1,0,0,'121','2025-02-01',60.00,0,NULL),(26775,31,'marzo',2025,60.00,1,0,0,'25','2025-03-01',60.00,0,NULL),(26776,31,'abril',2025,60.00,1,0,0,'226','2025-04-01',60.00,0,NULL),(26777,31,'mayo',2025,60.00,1,0,0,'226','2025-05-01',60.00,0,NULL),(26778,31,'junio',2025,60.00,1,0,0,'284','2025-06-01',60.00,0,NULL),(26779,31,'julio',2025,60.00,1,0,0,'484','2025-07-01',60.00,0,NULL),(26780,31,'agosto',2025,60.00,1,0,0,'484','2025-08-01',60.00,0,NULL),(26781,31,'septiembre',2025,60.00,1,0,0,'484','2025-09-01',60.00,0,NULL),(26782,31,'octubre',2025,60.00,1,0,0,'484','2025-10-01',60.00,0,NULL),(26783,31,'noviembre',2025,60.00,1,0,0,'533','2025-11-01',60.00,0,NULL),(26784,32,'febrero',2025,60.00,1,0,0,'229','2025-02-01',60.00,0,NULL),(26785,32,'marzo',2025,60.00,1,0,0,'229','2025-03-01',60.00,0,NULL),(26786,32,'abril',2025,60.00,1,0,0,'229','2025-04-01',60.00,0,NULL),(26787,32,'mayo',2025,60.00,1,0,0,'229','2025-05-01',60.00,0,NULL),(26788,32,'junio',2025,60.00,1,0,0,'378','2025-06-01',60.00,0,NULL),(26789,32,'julio',2025,60.00,1,0,0,'378','2025-07-01',60.00,0,NULL),(26790,32,'agosto',2025,60.00,1,0,0,'388','2025-08-01',60.00,0,NULL),(26791,32,'septiembre',2025,60.00,1,0,0,'501','2025-09-01',60.00,0,NULL),(26792,32,'octubre',2025,60.00,1,0,0,'501','2025-10-01',60.00,0,NULL),(26793,32,'noviembre',2025,60.00,1,0,0,'501','2025-11-01',60.00,0,NULL),(26794,33,'marzo',2025,60.00,1,0,0,'218','2025-03-01',60.00,0,NULL),(26795,33,'abril',2025,60.00,1,0,0,'265','2025-04-01',60.00,0,NULL),(26796,33,'mayo',2025,60.00,1,0,0,'265','2025-05-01',60.00,0,NULL),(26797,33,'junio',2025,60.00,1,0,0,'433','2025-06-01',60.00,0,NULL),(26798,33,'julio',2025,60.00,1,0,0,'444','2025-07-01',60.00,0,NULL),(26799,33,'agosto',2025,60.00,1,0,0,'444','2025-08-01',60.00,0,NULL),(26800,33,'septiembre',2025,60.00,1,0,0,'444','2025-09-01',60.00,0,NULL),(26801,33,'octubre',2025,60.00,1,0,0,'476','2025-10-01',60.00,0,NULL),(26802,33,'noviembre',2025,60.00,1,0,0,'532','2025-11-01',60.00,0,NULL),(26803,34,'febrero',2025,60.00,1,0,0,'120','2025-02-01',60.00,0,NULL),(26804,34,'marzo',2025,60.00,1,0,0,'178','2025-03-01',60.00,0,NULL),(26805,34,'abril',2025,60.00,1,0,0,'230','2025-04-01',60.00,0,NULL),(26806,34,'mayo',2025,60.00,1,0,0,'230','2025-05-01',60.00,0,NULL),(26807,34,'junio',2025,60.00,1,0,0,'266','2025-06-01',60.00,0,NULL),(26808,34,'julio',2025,60.00,1,0,0,'285','2025-07-01',60.00,0,NULL),(26809,34,'agosto',2025,60.00,1,0,0,'379','2025-08-01',60.00,0,NULL),(26810,34,'septiembre',2025,60.00,1,0,0,'424','2025-09-01',60.00,0,NULL),(26811,34,'octubre',2025,60.00,1,0,0,'503','2025-10-01',60.00,0,NULL),(26812,34,'noviembre',2025,60.00,1,0,0,'503','2025-11-01',60.00,0,NULL),(32691,75,'enero',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(32692,75,'febrero',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(32693,75,'marzo',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(32694,75,'abril',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(32695,75,'mayo',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(32696,75,'junio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(32697,75,'julio',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(32698,75,'agosto',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(32699,75,'septiembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(32700,75,'octubre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(32701,75,'noviembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL),(32702,75,'diciembre',2026,60.00,0,0,0,NULL,NULL,0.00,0,NULL);
/*!40000 ALTER TABLE `mensualidades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mis_tablas`
--

DROP TABLE IF EXISTS `mis_tablas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mis_tablas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci,
  `encabezado` text COLLATE utf8mb4_unicode_ci,
  `columnas` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `filas` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mis_tablas`
--

LOCK TABLES `mis_tablas` WRITE;
/*!40000 ALTER TABLE `mis_tablas` DISABLE KEYS */;
INSERT INTO `mis_tablas` VALUES (3,'l','','','[{\"key\":\"codigo_estudiante\",\"label\":\"Código\",\"tipo\":\"texto\"},{\"key\":\"nombre\",\"label\":\"Nombre\",\"tipo\":\"texto\"},{\"key\":\"apellido\",\"label\":\"Apellido\",\"tipo\":\"texto\"},{\"key\":\"clave\",\"label\":\"Clave\",\"tipo\":\"texto\"},{\"key\":\"l\",\"label\":\"l\",\"tipo\":\"texto\"},{\"key\":\"jh\",\"label\":\"jh\",\"tipo\":\"texto\"},{\"key\":\"mhg\",\"label\":\"mhg\",\"tipo\":\"texto\"}]','[{\"codigo_estudiante\":\"I830IFB\",\"nombre\":\"Vasquez Perez\",\"apellido\":\"Adriana Marisol\",\"clave\":\"54\",\"l\":\"\",\"jh\":\"\",\"mhg\":\"\"},{\"codigo_estudiante\":\"L404PJB\",\"nombre\":\"Soto Melchor\",\"apellido\":\"Alexi Esai\",\"clave\":\"71\",\"l\":\"\",\"jh\":\"\",\"mhg\":\"\"},{\"codigo_estudiante\":\"J442HPE\",\"nombre\":\"Juarez Lucas\",\"apellido\":\"Alison Alondra\",\"clave\":\"11\",\"l\":\"\",\"jh\":\"\",\"mhg\":\"\"},{\"codigo_estudiante\":\"I241QHQ\",\"nombre\":\"Mendoza Castillo\",\"apellido\":\"Andrea Elizabeth\",\"clave\":\"72\",\"l\":\"\",\"jh\":\"\",\"mhg\":\"\"},{\"codigo_estudiante\":\"I531LUW\",\"nombre\":\"Lopez Lopez\",\"apellido\":\"Angel Abraham\",\"clave\":\"46\",\"l\":\"\",\"jh\":\"\",\"mhg\":\"\"},{\"codigo_estudiante\":\"J943NLK\",\"nombre\":\"Cigarroa Barrios\",\"apellido\":\"Angel David\",\"clave\":\"20\",\"l\":\"\",\"jh\":\"\",\"mhg\":\"\"},{\"codigo_estudiante\":\"K200EPK\",\"nombre\":\"De Paz Fuentes\",\"apellido\":\"Angel Ferreyn\",\"clave\":\"18\",\"l\":\"\",\"jh\":\"\",\"mhg\":\"\"},{\"codigo_estudiante\":\"I638BYE\",\"nombre\":\"Jimenez Perez\",\"apellido\":\"Antonio Isai\",\"clave\":\"21\",\"l\":\"\",\"jh\":\"\",\"mhg\":\"\"},{\"codigo_estudiante\":\"L103ZDB\",\"nombre\":\"Lopez Lucas\",\"apellido\":\"Blanca Azucena\",\"clave\":\"60\",\"l\":\"\",\"jh\":\"\",\"mhg\":\"\"},{\"codigo_estudiante\":\"L503GBC\",\"nombre\":\"Cabrera Lopez\",\"apellido\":\"Brayan Yobani\",\"clave\":\"27\",\"l\":\"\",\"jh\":\"\",\"mhg\":\"\"},{\"codigo_estudiante\":\"J147NAK\",\"nombre\":\"Jimenez Gomez\",\"apellido\":\"Byron Jeremias\",\"clave\":\"56\",\"l\":\"\",\"jh\":\"\",\"mhg\":\"\"},{\"codigo_estudiante\":\"\",\"nombre\":\"Rony Alexander\",\"apellido\":\"Castillo Lopez\",\"clave\":\"75\",\"l\":\"\",\"jh\":\"\",\"mhg\":\"\"},{\"codigo_estudiante\":\"K100YAN\",\"nombre\":\"De Leon Gomez\",\"apellido\":\"Cecilia\",\"clave\":\"2\",\"l\":\"\",\"jh\":\"\",\"mhg\":\"\"},{\"codigo_estudiante\":\"K400KIR\",\"nombre\":\"Ramirez Lopez\",\"apellido\":\"Crisbel Maricruz\",\"clave\":\"66\",\"l\":\"\",\"jh\":\"\",\"mhg\":\"\"},{\"codigo_estudiante\":\"J144ZQJ\",\"nombre\":\"Suchite Cabrera\",\"apellido\":\"Cristian Wilfredo\",\"clave\":\"13\",\"l\":\"\",\"jh\":\"\",\"mhg\":\"\"},{\"codigo_estudiante\":\"J142HJR\",\"nombre\":\"Ramirez Perez\",\"apellido\":\"Delsy Liliana\",\"clave\":\"43\",\"l\":\"\",\"jh\":\"\",\"mhg\":\"\"},{\"codigo_estudiante\":\"J843JGK\",\"nombre\":\"Molina Perez\",\"apellido\":\"Diana Aurora\",\"clave\":\"35\",\"l\":\"\",\"jh\":\"\",\"mhg\":\"\"},{\"codigo_estudiante\":\"K500CZC\",\"nombre\":\"Estrada del Toro\",\"apellido\":\"Diego Alejandro\",\"clave\":\"5\",\"l\":\"\",\"jh\":\"\",\"mhg\":\"\"},{\"codigo_estudiante\":\"J943THM\",\"nombre\":\"Cabrera Giron\",\"apellido\":\"Doris Aimar\",\"clave\":\"14\",\"l\":\"\",\"jh\":\"\",\"mhg\":\"\"},{\"codigo_estudiante\":\"K001WCH\",\"nombre\":\"Lopez Garcia\",\"apellido\":\"Eduardo Alberto\",\"clave\":\"50\",\"l\":\"\",\"jh\":\"\",\"mhg\":\"\"},{\"codigo_estudiante\":\"G758GIP\",\"nombre\":\"Shlaj Lucas\",\"apellido\":\"Eduardo Apolinario\",\"clave\":\"10\",\"l\":\"\",\"jh\":\"\",\"mhg\":\"\"},{\"codigo_estudiante\":\"L404GBP\",\"nombre\":\"Melchor Garcia\",\"apellido\":\"Elias Daniel\",\"clave\":\"70\",\"l\":\"\",\"jh\":\"\",\"mhg\":\"\"},{\"codigo_estudiante\":\"K501KNZ\",\"nombre\":\"Velasquez Cabrera\",\"apellido\":\"Elisa Lisbeth\",\"clave\":\"12\",\"l\":\"\",\"jh\":\"\",\"mhg\":\"\"},{\"codigo_estudiante\":\"K500DQZ\",\"nombre\":\"Orozco Rojas\",\"apellido\":\"Elmer Nehemias\",\"clave\":\"15\",\"l\":\"\",\"jh\":\"\",\"mhg\":\"\"},{\"codigo_estudiante\":\"J844EFP\",\"nombre\":\"Cabrera Alonzo\",\"apellido\":\"Emelin Azucena\",\"clave\":\"45\",\"l\":\"\",\"jh\":\"\",\"mhg\":\"\"},{\"codigo_estudiante\":\"J185CSM\",\"nombre\":\"Castillo Coy\",\"apellido\":\"Emilia Elizabeth\",\"clave\":\"58\",\"l\":\"\",\"jh\":\"\",\"mhg\":\"\"},{\"codigo_estudiante\":\"F779BAL\",\"nombre\":\"Lopez Hernandez\",\"apellido\":\"Esperanza Isabel\",\"clave\":\"74\",\"l\":\"\",\"jh\":\"\",\"mhg\":\"\"},{\"codigo_estudiante\":\"H790XMD\",\"nombre\":\"Cuyuch Ordoñez\",\"apellido\":\"Estefani Yoana\",\"clave\":\"25\",\"l\":\"\",\"jh\":\"\",\"mhg\":\"\"},{\"codigo_estudiante\":\"F474XPB\",\"nombre\":\"Castillo Coy\",\"apellido\":\"Evelyn Marleny\",\"clave\":\"59\",\"l\":\"\",\"jh\":\"\",\"mhg\":\"\"},{\"codigo_estudiante\":\"I440CQR\",\"nombre\":\"Rojop Garcia\",\"apellido\":\"Fatima Nalleli\",\"clave\":\"23\",\"l\":\"\",\"jh\":\"\",\"mhg\":\"\"},{\"codigo_estudiante\":\"J762CVT\",\"nombre\":\"Alonzo Lopez\",\"apellido\":\"Francis Noe Misael\",\"clave\":\"52\",\"l\":\"\",\"jh\":\"\",\"mhg\":\"\"},{\"codigo_estudiante\":\"J042SBS\",\"nombre\":\"Lara Lopez\",\"apellido\":\"Gerson Elias\",\"clave\":\"24\",\"l\":\"\",\"jh\":\"\",\"mhg\":\"\"},{\"codigo_estudiante\":\"K100TBN\",\"nombre\":\"Molina\",\"apellido\":\"Guillermo Lucas\",\"clave\":\"19\",\"l\":\"\",\"jh\":\"\",\"mhg\":\"\"},{\"codigo_estudiante\":\"J045MGS\",\"nombre\":\"Hernandez Cabrera\",\"apellido\":\"Hazel Daniela\",\"clave\":\"1\",\"l\":\"\",\"jh\":\"\",\"mhg\":\"\"},{\"codigo_estudiante\":\"J842VQL\",\"nombre\":\"Garcia Lopez\",\"apellido\":\"Hernan Alexander\",\"clave\":\"68\",\"l\":\"\",\"jh\":\"\",\"mhg\":\"\"},{\"codigo_estudiante\":\"I932LQD\",\"nombre\":\"Perez Perez\",\"apellido\":\"Ines\",\"clave\":\"47\",\"l\":\"\",\"jh\":\"\",\"mhg\":\"\"},{\"codigo_estudiante\":\"L404XUS\",\"nombre\":\"Garcia Romero\",\"apellido\":\"Ivana Jassmin\",\"clave\":\"17\",\"l\":\"\",\"jh\":\"\",\"mhg\":\"\"},{\"codigo_estudiante\":\"I133ZUF\",\"nombre\":\"Castillo Ovalle\",\"apellido\":\"Jade Maria\",\"clave\":\"16\",\"l\":\"\",\"jh\":\"\",\"mhg\":\"\"},{\"codigo_estudiante\":\"I530GWL\",\"nombre\":\"Felipe Gomez\",\"apellido\":\"Jaqueline Mauricia\",\"clave\":\"61\",\"l\":\"\",\"jh\":\"\",\"mhg\":\"\"},{\"codigo_estudiante\":\"I932JWQ\",\"nombre\":\"Giron Mendez\",\"apellido\":\"Jean Carlos\",\"clave\":\"48\",\"l\":\"\",\"jh\":\"\",\"mhg\":\"\"},{\"codigo_estudiante\":\"G850PKW\",\"nombre\":\"Cruz Vicente\",\"apellido\":\"Jimena Dayana\",\"clave\":\"55\",\"l\":\"\",\"jh\":\"\",\"mhg\":\"\"},{\"codigo_estudiante\":\"J043LES\",\"nombre\":\"Gonzalez Maldonado\",\"apellido\":\"Jorge Daniel\",\"clave\":\"39\",\"l\":\"\",\"jh\":\"\",\"mhg\":\"\"},{\"codigo_estudiante\":\"J743JPZ\",\"nombre\":\"Garcia Perez\",\"apellido\":\"Jorge Danilo\",\"clave\":\"7\",\"l\":\"\",\"jh\":\"\",\"mhg\":\"\"},{\"codigo_estudiante\":\"L103IZA\",\"nombre\":\"Gomez Dueñas\",\"apellido\":\"Jose Emanuel\",\"clave\":\"69\",\"l\":\"\",\"jh\":\"\",\"mhg\":\"\"},{\"codigo_estudiante\":\"I430ISI\",\"nombre\":\"Chavalan Jasinto\",\"apellido\":\"Jose Enrique\",\"clave\":\"38\",\"l\":\"\",\"jh\":\"\",\"mhg\":\"\"},{\"codigo_estudiante\":\"I130LTV\",\"nombre\":\"Rojop Dominguez\",\"apellido\":\"Juan Miguel\",\"clave\":\"53\",\"l\":\"\",\"jh\":\"\",\"mhg\":\"\"},{\"codigo_estudiante\":\"K500JNB\",\"nombre\":\"Vasquez Paxtor\",\"apellido\":\"Juan Miguel\",\"clave\":\"30\",\"l\":\"\",\"jh\":\"\",\"mhg\":\"\"},{\"codigo_estudiante\":\"J944BFG\",\"nombre\":\"Galindo Chavez\",\"apellido\":\"Julia Amparo\",\"clave\":\"63\",\"l\":\"\",\"jh\":\"\",\"mhg\":\"\"},{\"codigo_estudiante\":\"K801FYT\",\"nombre\":\"Velasquez Meza\",\"apellido\":\"Katerin Elizani\",\"clave\":\"29\",\"l\":\"\",\"jh\":\"\",\"mhg\":\"\"},{\"codigo_estudiante\":\"K002IAJ\",\"nombre\":\"Sales Garcia\",\"apellido\":\"Kervin Ventura\",\"clave\":\"28\",\"l\":\"\",\"jh\":\"\",\"mhg\":\"\"},{\"codigo_estudiante\":\"J944VVG\",\"nombre\":\"Berduo Lopez\",\"apellido\":\"Kevin Enrique\",\"clave\":\"73\",\"l\":\"\",\"jh\":\"\",\"mhg\":\"\"},{\"codigo_estudiante\":\"K402GML\",\"nombre\":\"Bonilla Garcia\",\"apellido\":\"Lea Raquel\",\"clave\":\"67\",\"l\":\"\",\"jh\":\"\",\"mhg\":\"\"},{\"codigo_estudiante\":\"J643IPD\",\"nombre\":\"Molina Vasquez\",\"apellido\":\"Lesly Yasmin\",\"clave\":\"49\",\"l\":\"\",\"jh\":\"\",\"mhg\":\"\"},{\"codigo_estudiante\":\"J644UUZ\",\"nombre\":\"Perez Orozco\",\"apellido\":\"Lilian Delfina\",\"clave\":\"37\",\"l\":\"\",\"jh\":\"\",\"mhg\":\"\"},{\"codigo_estudiante\":\"I130LIL\",\"nombre\":\"Garcia Mendez\",\"apellido\":\"Marelin Yoseni\",\"clave\":\"42\",\"l\":\"\",\"jh\":\"\",\"mhg\":\"\"},{\"codigo_estudiante\":\"J744DMN\",\"nombre\":\"Gomez\",\"apellido\":\"Maria Ines\",\"clave\":\"34\",\"l\":\"\",\"jh\":\"\",\"mhg\":\"\"},{\"codigo_estudiante\":\"K300GFT\",\"nombre\":\"Juarez\",\"apellido\":\"Maria Lucas\",\"clave\":\"65\",\"l\":\"\",\"jh\":\"\",\"mhg\":\"\"},{\"codigo_estudiante\":\"J943CQJ\",\"nombre\":\"Garcia Porrez\",\"apellido\":\"Marilin Selyna\",\"clave\":\"41\",\"l\":\"\",\"jh\":\"\",\"mhg\":\"\"},{\"codigo_estudiante\":\"J844KPA\",\"nombre\":\"de Leon Molina\",\"apellido\":\"Marvin Estuardo\",\"clave\":\"36\",\"l\":\"\",\"jh\":\"\",\"mhg\":\"\"},{\"codigo_estudiante\":\"I730VAV\",\"nombre\":\"Juarez de Leon\",\"apellido\":\"Miguel de Jesus\",\"clave\":\"3\",\"l\":\"\",\"jh\":\"\",\"mhg\":\"\"},{\"codigo_estudiante\":\"I739FRH\",\"nombre\":\"Perez Perez\",\"apellido\":\"Milton Aron\",\"clave\":\"9\",\"l\":\"\",\"jh\":\"\",\"mhg\":\"\"},{\"codigo_estudiante\":\"J144HDI\",\"nombre\":\"Garcia Perez\",\"apellido\":\"Nancy Marisol\",\"clave\":\"51\",\"l\":\"\",\"jh\":\"\",\"mhg\":\"\"},{\"codigo_estudiante\":\"K300WMG\",\"nombre\":\"Lara Tiu\",\"apellido\":\"Natalia Lucita\",\"clave\":\"4\",\"l\":\"\",\"jh\":\"\",\"mhg\":\"\"},{\"codigo_estudiante\":\"J642MRJ\",\"nombre\":\"Vicente Diaz\",\"apellido\":\"Nataly Celeste\",\"clave\":\"33\",\"l\":\"\",\"jh\":\"\",\"mhg\":\"\"},{\"codigo_estudiante\":\"K801UKZ\",\"nombre\":\"Vicente Perez\",\"apellido\":\"Neftali Odiel\",\"clave\":\"32\",\"l\":\"\",\"jh\":\"\",\"mhg\":\"\"},{\"codigo_estudiante\":\"J642LEB\",\"nombre\":\"Lopez Ramirez\",\"apellido\":\"Nestor Antonio\",\"clave\":\"26\",\"l\":\"\",\"jh\":\"\",\"mhg\":\"\"},{\"codigo_estudiante\":\"J244VTS\",\"nombre\":\"Pablo de Leon\",\"apellido\":\"Ricardo Alberto\",\"clave\":\"31\",\"l\":\"\",\"jh\":\"\",\"mhg\":\"\"},{\"codigo_estudiante\":\"J943TDN\",\"nombre\":\"Contreras Lopez\",\"apellido\":\"Rosa Leticia\",\"clave\":\"57\",\"l\":\"\",\"jh\":\"\",\"mhg\":\"\"},{\"codigo_estudiante\":\"J242ADF\",\"nombre\":\"Contreras Lopez\",\"apellido\":\"Sergio Alexander\",\"clave\":\"22\",\"l\":\"\",\"jh\":\"\",\"mhg\":\"\"},{\"codigo_estudiante\":\"J046RPG\",\"nombre\":\"Cuyuch Domiguez\",\"apellido\":\"Sergio Ottoniel\",\"clave\":\"6\",\"l\":\"\",\"jh\":\"\",\"mhg\":\"\"},{\"codigo_estudiante\":\"I232ZGQ\",\"nombre\":\"Mendez Vasquez\",\"apellido\":\"Sheily Maritza\",\"clave\":\"44\",\"l\":\"\",\"jh\":\"\",\"mhg\":\"\"},{\"codigo_estudiante\":\"K402QXP\",\"nombre\":\"Molina\",\"apellido\":\"Sofia Joanna\",\"clave\":\"64\",\"l\":\"\",\"jh\":\"\",\"mhg\":\"\"},{\"codigo_estudiante\":\"J744KPV\",\"nombre\":\"Guzman Gomez\",\"apellido\":\"Walfred Antonio\",\"clave\":\"40\",\"l\":\"\",\"jh\":\"\",\"mhg\":\"\"},{\"codigo_estudiante\":\"J043MBJ\",\"nombre\":\"Chavez Lorenzo\",\"apellido\":\"Yeimi Josefina\",\"clave\":\"8\",\"l\":\"\",\"jh\":\"\",\"mhg\":\"\"},{\"codigo_estudiante\":\"K402PXP\",\"nombre\":\"Macario Vicente\",\"apellido\":\"Yeimi Roxana\",\"clave\":\"62\",\"l\":\"\",\"jh\":\"\",\"mhg\":\"\"},{\"codigo_estudiante\":\"\",\"nombre\":\"\",\"apellido\":\"\",\"clave\":\"\",\"l\":\"\",\"jh\":\"\",\"mhg\":\"\"}]','2026-05-07 02:30:17','2026-05-07 02:30:54');
/*!40000 ALTER TABLE `mis_tablas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notas_tac_anual`
--

DROP TABLE IF EXISTS `notas_tac_anual`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notas_tac_anual` (
  `id` int NOT NULL AUTO_INCREMENT,
  `alumno_id` int NOT NULL,
  `anio` smallint NOT NULL,
  `nota1` smallint DEFAULT NULL,
  `nota2` smallint DEFAULT NULL,
  `nota3` smallint DEFAULT NULL,
  `nota4` smallint DEFAULT NULL,
  `tac` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_tac_a` (`alumno_id`,`anio`,`tac`)
) ENGINE=InnoDB AUTO_INCREMENT=161 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notas_tac_anual`
--

LOCK TABLES `notas_tac_anual` WRITE;
/*!40000 ALTER TABLE `notas_tac_anual` DISABLE KEYS */;
INSERT INTO `notas_tac_anual` VALUES (1,1,2025,89,94,95,90,'1'),(2,2,2025,85,83,86,86,'1'),(3,3,2025,75,70,72,75,'1'),(4,4,2025,81,83,85,87,'1'),(5,5,2025,78,70,75,77,'1'),(6,6,2025,75,80,79,74,'1'),(7,7,2025,72,70,72,78,'1'),(8,8,2025,78,75,74,77,'1'),(9,9,2025,75,74,77,82,'1'),(10,10,2025,84,81,83,84,'1'),(11,11,2025,82,73,78,83,'1'),(12,13,2025,81,75,80,84,'1'),(13,14,2025,77,95,93,91,'1'),(14,16,2025,85,73,80,82,'1'),(15,17,2025,79,80,82,83,'1'),(16,18,2025,85,70,74,75,'1'),(17,19,2025,74,70,72,76,'1'),(18,20,2025,89,78,80,81,'1'),(19,21,2025,87,90,91,92,'1'),(20,22,2025,83,84,80,85,'1'),(21,23,2025,70,NULL,NULL,NULL,'1'),(22,24,2025,80,81,80,83,'1'),(23,25,2025,80,78,75,79,'1'),(24,26,2025,78,80,81,85,'1'),(25,27,2025,NULL,NULL,NULL,NULL,'1'),(26,28,2025,72,73,74,77,'1'),(27,29,2025,78,79,77,82,'1'),(28,30,2025,84,72,74,78,'1'),(29,31,2025,76,77,80,87,'1'),(30,32,2025,78,77,79,78,'1'),(31,33,2025,80,87,89,92,'1'),(32,34,2025,NULL,NULL,NULL,NULL,'1'),(33,35,2025,77,70,76,81,'1'),(34,36,2025,76,71,77,84,'1'),(35,37,2025,78,97,95,90,'1'),(36,38,2025,79,70,77,82,'1'),(37,39,2025,70,72,70,72,'1'),(38,40,2025,76,78,77,81,'1'),(39,41,2025,79,77,75,77,'1'),(40,42,2025,75,76,75,78,'1'),(41,43,2025,80,81,79,80,'1'),(42,44,2025,81,82,83,82,'1'),(43,45,2025,70,72,75,79,'1'),(44,46,2025,69,71,73,75,'1'),(45,47,2025,75,78,77,78,'1'),(46,48,2025,80,81,80,83,'1'),(47,49,2025,73,78,77,76,'1'),(48,50,2025,75,77,77,79,'1'),(49,51,2025,79,80,81,84,'1'),(50,52,2025,80,70,71,75,'1'),(51,53,2025,74,77,75,78,'1'),(52,54,2025,70,72,70,72,'1'),(53,55,2025,76,80,78,78,'1'),(54,56,2025,80,78,79,83,'1'),(55,57,2025,78,79,77,82,'1'),(56,58,2025,65,65,73,77,'1'),(57,59,2025,68,68,75,73,'2'),(58,59,2025,70,NULL,NULL,NULL,'3'),(59,1,2026,90,NULL,NULL,NULL,'2'),(60,2,2026,96,NULL,NULL,NULL,'2'),(61,3,2026,78,NULL,NULL,NULL,'2'),(62,4,2026,93,NULL,NULL,NULL,'2'),(63,5,2026,94,NULL,NULL,NULL,'2'),(64,6,2026,91,NULL,NULL,NULL,'2'),(65,7,2026,75,NULL,NULL,NULL,'2'),(66,8,2026,75,NULL,NULL,NULL,'2'),(67,9,2026,NULL,NULL,NULL,NULL,'2'),(68,10,2026,75,NULL,NULL,NULL,'2'),(69,11,2026,91,NULL,NULL,NULL,'2'),(70,12,2026,85,NULL,NULL,NULL,'2'),(71,13,2026,88,NULL,NULL,NULL,'2'),(72,14,2026,95,NULL,NULL,NULL,'2'),(73,15,2026,75,NULL,NULL,NULL,'2'),(74,16,2026,78,NULL,NULL,NULL,'2'),(75,17,2026,87,NULL,NULL,NULL,'2'),(76,18,2026,NULL,NULL,NULL,NULL,'2'),(77,19,2026,88,NULL,NULL,NULL,'2'),(78,20,2026,82,NULL,NULL,NULL,'2'),(79,21,2026,97,NULL,NULL,NULL,'2'),(80,22,2026,72,NULL,NULL,NULL,'2'),(81,23,2026,NULL,NULL,NULL,NULL,'2'),(82,24,2026,78,NULL,NULL,NULL,'2'),(83,25,2026,NULL,NULL,NULL,NULL,'2'),(84,26,2026,73,NULL,NULL,NULL,'2'),(85,27,2026,NULL,NULL,NULL,NULL,'2'),(86,28,2026,80,NULL,NULL,NULL,'2'),(87,29,2026,79,NULL,NULL,NULL,'2'),(88,30,2026,90,NULL,NULL,NULL,'2'),(89,31,2026,NULL,NULL,NULL,NULL,'2'),(90,32,2026,92,NULL,NULL,NULL,'2'),(91,33,2026,90,NULL,NULL,NULL,'2'),(92,34,2026,NULL,NULL,NULL,NULL,'2'),(93,35,2026,83,NULL,NULL,NULL,'2'),(94,36,2026,91,NULL,NULL,NULL,'2'),(95,37,2026,95,NULL,NULL,NULL,'2'),(96,38,2026,80,NULL,NULL,NULL,'2'),(97,39,2026,78,NULL,NULL,NULL,'2'),(98,40,2026,74,NULL,NULL,NULL,'2'),(99,41,2026,72,NULL,NULL,NULL,'2'),(100,42,2026,70,NULL,NULL,NULL,'2'),(101,43,2026,73,NULL,NULL,NULL,'2'),(102,44,2026,77,NULL,NULL,NULL,'2'),(103,45,2026,77,NULL,NULL,NULL,'2'),(104,46,2026,76,NULL,NULL,NULL,'2'),(105,47,2026,79,NULL,NULL,NULL,'2'),(106,48,2026,74,NULL,NULL,NULL,'2'),(107,49,2026,71,NULL,NULL,NULL,'2'),(108,50,2026,69,NULL,NULL,NULL,'2'),(109,51,2026,70,NULL,NULL,NULL,'2'),(110,52,2026,74,NULL,NULL,NULL,'2'),(111,53,2026,71,NULL,NULL,NULL,'2'),(112,54,2026,73,NULL,NULL,NULL,'2'),(113,55,2026,86,NULL,NULL,NULL,'2'),(114,56,2026,74,NULL,NULL,NULL,'2'),(115,57,2026,77,NULL,NULL,NULL,'2'),(116,58,2026,73,NULL,NULL,NULL,'2'),(117,59,2026,70,NULL,NULL,NULL,'3'),(118,60,2026,80,NULL,NULL,NULL,'1'),(119,61,2026,80,NULL,NULL,NULL,'2'),(120,62,2026,78,NULL,NULL,NULL,'1'),(121,63,2026,75,NULL,NULL,NULL,'1'),(122,64,2026,82,NULL,NULL,NULL,'1'),(123,65,2026,82,NULL,NULL,NULL,'1'),(124,66,2026,79,NULL,NULL,NULL,'1'),(125,67,2026,87,NULL,NULL,NULL,'1'),(126,68,2026,85,NULL,NULL,NULL,'1'),(127,69,2026,81,NULL,NULL,NULL,'1'),(128,70,2026,70,NULL,NULL,NULL,'1'),(129,71,2026,72,NULL,NULL,NULL,'1'),(130,72,2026,73,NULL,NULL,NULL,'1'),(131,73,2026,NULL,NULL,NULL,NULL,'1'),(132,74,2026,NULL,NULL,NULL,NULL,'1'),(144,34,2026,75,NULL,NULL,NULL,'1'),(145,9,2026,75,NULL,NULL,NULL,'1'),(146,18,2026,85,NULL,NULL,NULL,'1'),(147,31,2026,76,NULL,NULL,NULL,'1'),(156,23,2026,NULL,NULL,NULL,NULL,'1');
/*!40000 ALTER TABLE `notas_tac_anual` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `papeleria`
--

DROP TABLE IF EXISTS `papeleria`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `papeleria` (
  `id` int NOT NULL AUTO_INCREMENT,
  `no_recibo` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `alumno_id` int DEFAULT NULL,
  `descripcion` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `total` decimal(10,2) DEFAULT NULL,
  `observaciones` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `alumno_texto` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `anulado` tinyint(1) NOT NULL DEFAULT '0',
  `anulado_at` timestamp NULL DEFAULT NULL,
  `no_deposito` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `papeleria`
--

LOCK TABLES `papeleria` WRITE;
/*!40000 ALTER TABLE `papeleria` DISABLE KEYS */;
INSERT INTO `papeleria` VALUES (1,'1',37,'Certificado TAC 2025','2025-09-25',25.00,NULL,'2026-05-03 21:00:46',NULL,0,NULL,NULL),(2,'2',35,'Certificado TAC 2025','2025-09-25',25.00,NULL,'2026-05-03 21:00:46',NULL,0,NULL,NULL),(3,'3',28,'Certificado TAC 2025','2025-09-25',25.00,NULL,'2026-05-03 21:00:46',NULL,0,NULL,NULL),(4,'4',45,'Certificado TAC 2025','2025-09-25',25.00,NULL,'2026-05-03 21:00:46',NULL,0,NULL,NULL),(5,'5',29,'Certificado TAC 2025','2025-09-25',25.00,NULL,'2026-05-03 21:00:46',NULL,0,NULL,NULL),(6,'6',38,'Certificado TAC 2025','2025-09-25',25.00,NULL,'2026-05-03 21:00:46',NULL,0,NULL,NULL),(7,'7',24,'Certificado TAC 2025','2025-09-25',25.00,NULL,'2026-05-03 21:00:46',NULL,0,NULL,NULL),(8,'8',50,'Certificado TAC 2025','2025-09-25',25.00,NULL,'2026-05-03 21:00:46',NULL,0,NULL,NULL),(9,'9',9,'Certificado TAC 2025','2025-09-26',25.00,NULL,'2026-05-03 21:00:46',NULL,0,NULL,NULL),(10,'10',11,'Certificado TAC 2025','2025-09-26',25.00,NULL,'2026-05-03 21:00:46',NULL,0,NULL,NULL),(11,'11',20,'Certificado TAC 2025','2025-09-27',25.00,NULL,'2026-05-03 21:00:46',NULL,0,NULL,NULL),(12,'12',16,'Certificado TAC 2025','2025-09-27',25.00,NULL,'2026-05-03 21:00:46',NULL,0,NULL,NULL),(13,'13',56,'Certificado TAC 2025','2025-10-04',25.00,NULL,'2026-05-03 21:00:46',NULL,0,NULL,NULL),(14,'14',39,'Certificado TAC 2025','2025-10-04',25.00,NULL,'2026-05-03 21:00:46',NULL,0,NULL,NULL),(15,'15',54,'Certificado TAC 2025','2025-10-04',25.00,NULL,'2026-05-03 21:00:46',NULL,0,NULL,NULL),(16,'16',42,'Certificado TAC 2025','2025-10-04',25.00,NULL,'2026-05-03 21:00:46',NULL,0,NULL,NULL),(17,'17',44,'Certificado TAC 2025','2025-10-04',25.00,NULL,'2026-05-03 21:00:46',NULL,0,NULL,NULL),(18,'18',17,'Certificado TAC 2025','2025-10-09',25.00,NULL,'2026-05-03 21:00:46',NULL,0,NULL,NULL),(19,'19',14,'Certificado TAC 2025','2025-10-09',25.00,NULL,'2026-05-03 21:00:46',NULL,0,NULL,NULL),(20,'20',18,'Certificado TAC 2025','2025-10-09',25.00,NULL,'2026-05-03 21:00:46',NULL,0,NULL,NULL),(21,'21',8,'Certificado TAC 2025','2025-10-09',25.00,NULL,'2026-05-03 21:00:46',NULL,0,NULL,NULL),(22,'22',21,'Certificado TAC 2025','2025-10-09',25.00,NULL,'2026-05-03 21:00:46',NULL,0,NULL,NULL),(23,'23',10,'Certificado TAC 2025','2025-10-09',25.00,NULL,'2026-05-03 21:00:46',NULL,0,NULL,NULL),(24,'24',30,'Certificado TAC 2025','2025-10-09',25.00,NULL,'2026-05-03 21:00:46',NULL,0,NULL,NULL),(25,'25',1,'Certificado TAC 2025','2025-10-09',25.00,NULL,'2026-05-03 21:00:46',NULL,0,NULL,NULL),(26,'26',33,'Certificado TAC 2025','2025-10-09',25.00,NULL,'2026-05-03 21:00:46',NULL,0,NULL,NULL),(27,'27',36,'Certificado TAC 2025','2025-10-09',25.00,NULL,'2026-05-03 21:00:46',NULL,0,NULL,NULL),(28,'28',13,'Certificado TAC 2025','2025-10-09',25.00,NULL,'2026-05-03 21:00:46',NULL,0,NULL,NULL),(29,'29',4,'Certificado TAC 2025','2025-10-09',25.00,NULL,'2026-05-03 21:00:46',NULL,0,NULL,NULL),(30,'32',5,'Certificado TAC 2025','2025-10-09',25.00,NULL,'2026-05-03 21:00:46',NULL,0,NULL,NULL),(31,'33',7,'Certificado TAC 2025','2025-10-09',25.00,NULL,'2026-05-03 21:00:46',NULL,0,NULL,NULL),(32,'34',31,'Certificado TAC 2025','2025-10-11',25.00,NULL,'2026-05-03 21:00:46',NULL,0,NULL,NULL),(33,'36',3,'Certificado TAC 2025','2025-10-13',25.00,NULL,'2026-05-03 21:00:46',NULL,0,NULL,NULL),(34,'37',2,'Certificado TAC 2025','2025-10-13',25.00,NULL,'2026-05-03 21:00:46',NULL,0,NULL,NULL),(35,'38',51,'Certificado TAC 2025','2025-10-18',25.00,NULL,'2026-05-03 21:00:46',NULL,0,NULL,NULL),(36,'39',49,'Certificado TAC 2025','2025-10-18',25.00,NULL,'2026-05-03 21:00:46',NULL,0,NULL,NULL),(37,'40',47,'Certificado TAC 2025','2025-10-18',25.00,NULL,'2026-05-03 21:00:46',NULL,0,NULL,NULL),(38,'41',48,'Certificado TAC 2025','2025-10-18',25.00,NULL,'2026-05-03 21:00:46',NULL,0,NULL,NULL),(39,'42',46,'Certificado TAC 2025','2025-10-18',25.00,NULL,'2026-05-03 21:00:46',NULL,0,NULL,NULL),(40,'43',52,'Certificado TAC 2025','2025-10-19',25.00,NULL,'2026-05-03 21:00:46',NULL,0,NULL,NULL),(41,'44',32,'Certificado TAC 2025','2025-10-19',25.00,NULL,'2026-05-03 21:00:46',NULL,0,NULL,NULL),(42,'46',53,'Certificado TAC 2025','2025-11-07',25.00,NULL,'2026-05-03 21:00:46',NULL,0,NULL,NULL),(43,'47',40,'Certificado TAC 2025','2025-11-07',25.00,NULL,'2026-05-03 21:00:46',NULL,0,NULL,NULL),(44,'49',55,'Certificado TAC 2025','2025-11-07',25.00,NULL,'2026-05-03 21:00:46',NULL,0,NULL,NULL),(45,'50',43,'Certificado TAC 2025','2025-11-07',25.00,NULL,'2026-05-03 21:00:46',NULL,0,NULL,NULL),(46,'52',58,'Certificado TAC 2025','2025-11-09',25.00,NULL,'2026-05-03 21:00:46',NULL,0,NULL,NULL),(47,'54',22,'Certificado TAC 2025','2025-11-09',25.00,NULL,'2026-05-03 21:00:46',NULL,0,NULL,NULL),(48,'55',57,'Certificado TAC 2025','2025-11-09',25.00,NULL,'2026-05-03 21:00:46',NULL,0,NULL,NULL),(49,'56',26,'Certificado TAC 2025','2025-11-15',25.00,NULL,'2026-05-03 21:00:46',NULL,0,NULL,NULL);
/*!40000 ALTER TABLE `papeleria` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_resets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `usuario_id` int NOT NULL,
  `token` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expira_at` datetime NOT NULL,
  `usado` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `token` (`token`),
  KEY `idx_pwres_user` (`usuario_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recibos`
--

DROP TABLE IF EXISTS `recibos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `recibos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `no_recibo` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `alumno_id` int DEFAULT NULL,
  `meses` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `total` decimal(10,2) DEFAULT NULL,
  `observaciones` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `descuento` decimal(10,2) NOT NULL DEFAULT '0.00',
  `alumno_texto` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `anulado` tinyint(1) NOT NULL DEFAULT '0',
  `anulado_at` timestamp NULL DEFAULT NULL,
  `no_deposito` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3703 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recibos`
--

LOCK TABLES `recibos` WRITE;
/*!40000 ALTER TABLE `recibos` DISABLE KEYS */;
INSERT INTO `recibos` VALUES (1441,'1',NULL,'Noviembre 24','2024-10-28',75.00,NULL,'2026-05-04 01:13:23',0.00,'Shlaj Lucas Eduardo Apolinario',0,NULL,NULL),(1442,'2',NULL,'Noviembre 24','2024-10-28',75.00,NULL,'2026-05-04 01:13:23',0.00,'Chavez Lorenzo Yeimi Josefina',0,NULL,NULL),(1443,'3',NULL,'Noviembre 24','2024-10-28',75.00,NULL,'2026-05-04 01:13:23',0.00,'De Leon Gomez Cecilia',0,NULL,NULL),(1444,'4',NULL,'Noviembre 24','2024-10-29',75.00,NULL,'2026-05-04 01:13:23',0.00,'Castillo Ovalle Jade Maria',0,NULL,NULL),(1445,'5',NULL,'Noviembre 24','2024-10-29',75.00,NULL,'2026-05-04 01:13:23',0.00,'Vasquez Lopez Marcy Magali',0,NULL,NULL),(1446,'6',NULL,'Noviembre 24','2024-10-29',75.00,NULL,'2026-05-04 01:13:23',0.00,'Molina Lucas Guillermo',0,NULL,NULL),(1447,'7',NULL,'Noviembre 24','2024-10-29',75.00,NULL,'2026-05-04 01:13:23',0.00,'Gomez Lopez Sara Concepcion',0,NULL,NULL),(1448,'8',NULL,'Noviembre 24','2024-11-03',75.00,NULL,'2026-05-04 01:13:23',0.00,'Jimenez Guzman Ana Cecilia',0,NULL,NULL),(1449,'9',NULL,'Noviembre 24','2024-11-03',75.00,NULL,'2026-05-04 01:13:23',0.00,'Cuyuch Ordoñez Estefani Yoana',0,NULL,NULL),(1450,'10',NULL,'Noviembre 24','2024-11-03',75.00,NULL,'2026-05-04 01:13:23',0.00,'Ochoa Cabrera Gerli Yurandi',0,NULL,NULL),(1451,'11',NULL,'Noviembre 24','2024-11-03',75.00,NULL,'2026-05-04 01:13:23',0.00,'Cabrera Lopez Brayan Yobani',0,NULL,NULL),(1452,'12',NULL,'Noviembre 24','2024-11-03',75.00,NULL,'2026-05-04 01:13:23',0.00,'Cabrera Hernandez Mileidi Estrellita',0,NULL,NULL),(1453,'13',NULL,'Noviembre 24','2024-11-03',75.00,NULL,'2026-05-04 01:13:23',0.00,'Lopez Ramirez Nestor Antonio',0,NULL,NULL),(1454,'14',NULL,'Noviembre 24','2024-11-03',75.00,NULL,'2026-05-04 01:13:23',0.00,'Lara Lopez Gerson Elias',0,NULL,NULL),(1455,'15',NULL,'Noviembre 24','2024-11-03',75.00,NULL,'2026-05-04 01:13:23',0.00,'Aguilar Lopez Imelda Carolina',0,NULL,NULL),(1456,'16',NULL,'Noviembre 24','2024-11-03',75.00,NULL,'2026-05-04 01:13:23',0.00,'Cuxon Lopez Olga Mishel',0,NULL,NULL),(1457,'17',NULL,'Noviembre 24','2024-11-04',75.00,NULL,'2026-05-04 01:13:23',0.00,'Juarez Lucas Alison Alondra',0,NULL,NULL),(1458,'18',NULL,'Noviembre 24','2024-11-05',75.00,NULL,'2026-05-04 01:13:23',0.00,'Aguilar Molina Helen Maritza',0,NULL,NULL),(1459,'19',NULL,'Noviembre 24','2024-11-05',75.00,NULL,'2026-05-04 01:13:23',0.00,'Vasquez Perez Wilson Daniel',0,NULL,NULL),(1460,'20',NULL,'Noviembre 24','2024-11-06',75.00,NULL,'2026-05-04 01:13:23',0.00,'Jimenez Perez Antonio Isai',0,NULL,NULL),(1461,'21',NULL,'Noviembre 24','2024-11-06',75.00,NULL,'2026-05-04 01:13:23',0.00,'Rojop Garcia Fatima Nalleli',0,NULL,NULL),(1462,'22',NULL,'Noviembre 24','2024-11-12',75.00,NULL,'2026-05-04 01:13:23',0.00,'Lara Tiu Natalia Lucita',0,NULL,NULL),(1463,'23',NULL,'Noviembre 24','2024-11-12',75.00,NULL,'2026-05-04 01:13:23',0.00,'De Paz Fuentes Angel Ferreyn',0,NULL,NULL),(1464,'24',NULL,'Noviembre 24','2024-11-13',75.00,NULL,'2026-05-04 01:13:23',0.00,'Hernandez Orozco Luis Rogelio',0,NULL,NULL),(1465,'25',NULL,'Noviembre 24','2024-11-14',75.00,NULL,'2026-05-04 01:13:23',0.00,'Guzman Perez Maria Amalia',0,NULL,NULL),(1466,'26',NULL,'Noviembre 24','2024-11-17',75.00,NULL,'2026-05-04 01:13:23',0.00,'Velasquez Meza Katerin Elizani',0,NULL,NULL),(1467,'27',NULL,'Noviembre 24','2024-11-17',75.00,NULL,'2026-05-04 01:13:23',0.00,'Sales Garcia Kervin Ventura',0,NULL,NULL),(1468,'28',NULL,'Noviembre 24','2024-11-17',75.00,NULL,'2026-05-04 01:13:23',0.00,'Garcia Lopez Natali Alexandra',0,NULL,NULL),(1469,'29',NULL,'Noviembre 24','2024-11-17',75.00,NULL,'2026-05-04 01:13:23',0.00,'Garcia Lopez Anyely Samanta',0,NULL,NULL),(1470,'30',NULL,'Noviembre 24','2024-11-18',75.00,NULL,'2026-05-04 01:13:23',0.00,'Hernandez Cabrera Hazel Daniela',0,NULL,NULL),(1471,'31',NULL,'Noviembre 24','2024-11-19',75.00,NULL,'2026-05-04 01:13:23',0.00,'Orozco Juarez Alexis Benjamin',0,NULL,NULL),(1472,'32',NULL,'Noviembre 24','2024-11-22',37.50,NULL,'2026-05-04 01:13:23',0.00,'Molina Perez Diana Aurora',0,NULL,NULL),(1473,'33',NULL,'Noviembre 24','2024-11-22',37.50,NULL,'2026-05-04 01:13:23',0.00,'Perez Orozco Lilian Delfina',0,NULL,NULL),(1474,'34',NULL,'Noviembre 24','2024-11-22',37.50,NULL,'2026-05-04 01:13:23',0.00,'de Leon Molina Marvin Estuardo',0,NULL,NULL),(1475,'35',NULL,'Noviembre 24','2024-11-22',37.50,NULL,'2026-05-04 01:13:23',0.00,'Diaz Vasquez Mishel Nohemi',0,NULL,NULL),(1476,'36',NULL,'Noviembre 24','2024-11-22',37.50,NULL,'2026-05-04 01:13:23',0.00,'Poz Cabrera Victoria Elizabeth',0,NULL,NULL),(1477,'37',NULL,'Noviembre 24','2024-11-22',37.50,NULL,'2026-05-04 01:13:23',0.00,'Mazariegos de Leon Jennifer Estefani',0,NULL,NULL),(1478,'38',NULL,'Noviembre 24','2024-11-24',37.50,NULL,'2026-05-04 01:13:23',0.00,'Rojop Dominguez Juan Miguel',0,NULL,NULL),(1479,'39',NULL,'Noviembre 24','2024-11-24',37.50,NULL,'2026-05-04 01:13:23',0.00,'Molina Vasquez Lesly Yasmin',0,NULL,NULL),(1480,'40',NULL,'Noviembre 24','2024-11-24',37.50,NULL,'2026-05-04 01:13:23',0.00,'Mendez Vasquez Sheily Maritza',0,NULL,NULL),(1481,'41',NULL,'Noviembre 24','2024-11-24',37.50,NULL,'2026-05-04 01:13:23',0.00,'Garcia Perez Nancy Marisol',0,NULL,NULL),(1482,'42',NULL,'Noviembre 24','2024-11-24',37.50,NULL,'2026-05-04 01:13:23',0.00,'Garcia Perez Eduardo Alberto',0,NULL,NULL),(1483,'43',NULL,'Noviembre 24','2024-11-24',37.50,NULL,'2026-05-04 01:13:23',0.00,'Giron Mendez Jean Carlos',0,NULL,NULL),(1484,'44',NULL,'Noviembre 24','2024-11-24',37.50,NULL,'2026-05-04 01:13:23',0.00,'Perez Perez Ines',0,NULL,NULL),(1485,'45',NULL,'Noviembre 24','2024-11-24',37.50,NULL,'2026-05-04 01:13:23',0.00,'Alonzo Lopez Francis Noe Misael',0,NULL,NULL),(1486,'46',NULL,'Noviembre 24','2024-11-25',75.00,NULL,'2026-05-04 01:13:23',0.00,'Cuyuch Domiguez Sergio Ottoniel',0,NULL,NULL),(1487,'47',NULL,'Noviembre 24','2024-11-28',75.00,NULL,'2026-05-04 01:13:23',0.00,'Perez Molina Leiby Judith',0,NULL,NULL),(1488,'48',NULL,'Noviembre 24','2024-11-29',37.50,NULL,'2026-05-04 01:13:23',0.00,'Garcia Mendez Marelin Yoseni',0,NULL,NULL),(1489,'49',NULL,'Noviembre 24','2024-11-29',37.50,NULL,'2026-05-04 01:13:23',0.00,'Guzman Gomez Walfred Antonio',0,NULL,NULL),(1490,'50',NULL,'Noviembre 24','2024-11-29',37.50,NULL,'2026-05-04 01:13:23',0.00,'Chavalan Jasinto Jose Enrique',0,NULL,NULL),(1491,'51',NULL,'Noviembre 24','2024-12-01',37.50,NULL,'2026-05-04 01:13:23',0.00,'Vasquez Perez Adriana Marisol',0,NULL,NULL),(1492,'52',NULL,'Noviembre 24','2024-12-01',37.50,NULL,'2026-05-04 01:13:23',0.00,'Cabrera Alonzo Emelin Azucena',0,NULL,NULL),(1493,'53',NULL,'Noviembre 24','2024-12-01',37.50,NULL,'2026-05-04 01:13:23',0.00,'Lopez Lopez Angel Abraham',0,NULL,NULL),(1494,'54',NULL,'Noviembre 24','2024-12-02',75.00,NULL,'2026-05-04 01:13:23',0.00,'Shlaj Lucas Eduardo Apolinario',0,NULL,NULL),(1495,'55',NULL,'Noviembre 24','2024-12-02',75.00,NULL,'2026-05-04 01:13:23',0.00,'Juarez de Leon Miguel de Jesus',0,NULL,NULL),(1496,'56',NULL,'Noviembre 24','2024-12-02',75.00,NULL,'2026-05-04 01:13:23',0.00,'Chavez Lorenzo Yeimi Josefina',0,NULL,NULL),(1497,'57',NULL,'Noviembre 24','2024-12-02',75.00,NULL,'2026-05-04 01:13:23',0.00,'Velasquez Cabrera Elisa Lisbeth',0,NULL,NULL),(1498,'58',NULL,'Noviembre 24','2024-12-02',75.00,NULL,'2026-05-04 01:13:23',0.00,'Juares Escalante Rebeca Josefina',0,NULL,NULL),(1499,'59',NULL,'Noviembre 24','2024-12-03',75.00,NULL,'2026-05-04 01:13:23',0.00,'Cabrera Giron Doris Aimar',0,NULL,NULL),(1500,'60',NULL,'Inscripcion','2024-12-11',0.00,NULL,'2026-05-04 01:13:23',0.00,'Jimenez Gomez Byron Jeremias',0,NULL,NULL),(1501,'61',NULL,'Noviembre 24','2024-12-11',75.00,NULL,'2026-05-04 01:13:23',0.00,'Jimenez Gomez Byron Jeremias',0,NULL,NULL),(1502,'62',NULL,'Noviembre 24','2024-12-11',75.00,NULL,'2026-05-04 01:13:23',0.00,'Contreras Lopez Sergio Alexander',0,NULL,NULL),(1503,'63',NULL,'Noviembre 24','2024-12-11',75.00,NULL,'2026-05-04 01:13:23',0.00,'Perez Beteta Kevin Ulises',0,NULL,NULL),(1504,'64',NULL,'Noviembre 24','2025-01-18',75.00,NULL,'2026-05-04 01:13:23',0.00,'Perez Perez Milton Aron',0,NULL,NULL),(1505,'65',NULL,'Febrero','2025-02-08',25.00,NULL,'2026-05-04 01:13:23',0.00,'Perez Orozco Lilian Delfina',0,NULL,NULL),(1506,'66',NULL,'febrero-marzo-abril','2025-02-15',75.00,NULL,'2026-05-04 01:13:23',0.00,'Molina Lucas Guillermo',0,NULL,NULL),(1507,'67',NULL,'febrero','2025-02-22',25.00,NULL,'2026-05-04 01:13:23',0.00,'Jimenez Guzman Ana Cecilia',0,NULL,NULL),(1508,'68',NULL,'febrero','2025-02-22',25.00,NULL,'2026-05-04 01:13:23',0.00,'Ochoa Cabrera Gerli Yurandi',0,NULL,NULL),(1509,'69',NULL,'febrero','2025-02-22',25.00,NULL,'2026-05-04 01:13:23',0.00,'Cabrera Lopez Brayan Yobani',0,NULL,NULL),(1510,'70',NULL,'febrero','2025-02-22',25.00,NULL,'2026-05-04 01:13:23',0.00,'Lara Lopez Gerson Elias',0,NULL,NULL),(1511,'71',NULL,'febrero','2025-02-22',25.00,NULL,'2026-05-04 01:13:23',0.00,'Sales Garcia Kervin Ventura',0,NULL,NULL),(1512,'72',NULL,'noviembre 24 febrero 2025','2025-02-22',100.00,NULL,'2026-05-04 01:13:24',0.00,'Baltazar Vasqauez Sebastian Anibal',0,NULL,NULL),(1513,'73',NULL,'febrero','2025-02-22',25.00,NULL,'2026-05-04 01:13:24',0.00,'Lopez Ramirez Nestor Antonio',0,NULL,NULL),(1514,'74',NULL,'febrero','2025-02-22',25.00,NULL,'2026-05-04 01:13:24',0.00,'Mazariegos de Leon Jennifer Estefani',0,NULL,NULL),(1515,'75',NULL,'febrero','2025-02-22',25.00,NULL,'2026-05-04 01:13:24',0.00,'Diaz Vasquez Mishel Nohemi',0,NULL,NULL),(1516,'76',NULL,'febrero','2025-02-22',25.00,NULL,'2026-05-04 01:13:24',0.00,'Molina Perez Diana Aurora',0,NULL,NULL),(1517,'77',NULL,'febrero','2025-02-22',25.00,NULL,'2026-05-04 01:13:24',0.00,'Chavalan Jasinto Jose Enrique',0,NULL,NULL),(1518,'78',NULL,'febrero','2025-02-22',25.00,NULL,'2026-05-04 01:13:24',0.00,'Cabrera Hernandez Mileidi Estrellita',0,NULL,NULL),(1519,'79',NULL,'febrero','2025-02-22',25.00,NULL,'2026-05-04 01:13:24',0.00,'Cuyuch Ordoñez Estefani Yoana',0,NULL,NULL),(1520,'80',NULL,'febrero','2025-02-22',25.00,NULL,'2026-05-04 01:13:24',0.00,'Velasquez Meza Katerin Elizani',0,NULL,NULL),(1521,'81',NULL,'febrero','2025-02-22',25.00,NULL,'2026-05-04 01:13:24',0.00,'Garcia Perez Nancy Marisol',0,NULL,NULL),(1522,'82',NULL,'febrero','2025-02-22',25.00,NULL,'2026-05-04 01:13:24',0.00,'Garcia Mendez Marelin Yoseni',0,NULL,NULL),(1523,'83',NULL,'febrero','2025-02-22',25.00,NULL,'2026-05-04 01:13:24',0.00,'Cabrera Alonzo Emelin Azucena',0,NULL,NULL),(1524,'84',NULL,'febrero','2025-02-22',25.00,NULL,'2026-05-04 01:13:24',0.00,'Cruz Vicente Jimena Dayana',0,NULL,NULL),(1525,'85',NULL,'febrero','2025-02-22',25.00,NULL,'2026-05-04 01:13:24',0.00,'Vasquez Perez Adriana Marisol',0,NULL,NULL),(1526,'86',NULL,'febrero','2025-02-22',25.00,NULL,'2026-05-04 01:13:24',0.00,'Chaves Lucas Rosa Belen',0,NULL,NULL),(1527,'87',NULL,'febrero','2025-02-22',25.00,NULL,'2026-05-04 01:13:24',0.00,'Lopez Garcia Eduardo Alberto',0,NULL,NULL),(1528,'88',NULL,'febrero','2025-02-22',25.00,NULL,'2026-05-04 01:13:24',0.00,'Rojop Dominguez Juan Miguel',0,NULL,NULL),(1529,'89',NULL,'febrero','2025-02-22',25.00,NULL,'2026-05-04 01:13:24',0.00,'Mendez Vasquez Sheily Maritza',0,NULL,NULL),(1530,'90',NULL,'febrero','2025-02-22',25.00,NULL,'2026-05-04 01:13:24',0.00,'Molina Vasquez Lesly Yasmin',0,NULL,NULL),(1531,'91',NULL,'febrero','2025-02-22',25.00,NULL,'2026-05-04 01:13:24',0.00,'Guzman Gomez Walfred Antonio',0,NULL,NULL),(1532,'92',NULL,'febrero','2025-02-22',25.00,NULL,'2026-05-04 01:13:24',0.00,'Lopez Lopez Angel Abraham',0,NULL,NULL),(1533,'93',NULL,'noviembre','2025-02-22',37.50,NULL,'2026-05-04 01:13:24',0.00,'Sales Perez Brandi Yovani',0,NULL,NULL),(1534,'94',NULL,'febrero','2025-02-22',25.00,NULL,'2026-05-04 01:13:24',0.00,'Sales Perez Brandi Yovani',0,NULL,NULL),(1535,'95',NULL,'febrero','2025-02-22',25.00,NULL,'2026-05-04 01:13:24',0.00,'Perez Perez Ines',0,NULL,NULL),(1536,'96',NULL,'febrero','2025-03-01',25.00,NULL,'2026-05-04 01:13:24',0.00,'Castillo Ovalle Jade Maria',0,NULL,NULL),(1537,'97',NULL,'febrero','2025-03-01',25.00,NULL,'2026-05-04 01:13:24',0.00,'Vasquez Perez Wilson Daniel',0,NULL,NULL),(1538,'98',NULL,'febrero','2025-03-01',25.00,NULL,'2026-05-04 01:13:24',0.00,'Juarez de Leon Miguel de Jesus',0,NULL,NULL),(1539,'99',NULL,'febrero','2025-03-01',25.00,NULL,'2026-05-04 01:13:24',0.00,'Cuyuch Domiguez Sergio Ottoniel',0,NULL,NULL),(1540,'100',NULL,'noviembre 24 y febrero','2025-03-01',100.00,NULL,'2026-05-04 01:13:24',0.00,'Garcia Romero Ivana Jassmin',0,NULL,NULL),(1541,'101',NULL,'noviembre 24 y febrero','2025-03-01',100.00,NULL,'2026-05-04 01:13:24',0.00,'Garcia Perez Jorge Danilo',0,NULL,NULL),(1542,'102',NULL,'febrero','2025-03-01',25.00,NULL,'2026-05-04 01:13:24',0.00,'Juarez Lucas Alison Alondra',0,NULL,NULL),(1543,'103',NULL,'febrero','2025-03-01',25.00,NULL,'2026-05-04 01:13:24',0.00,'Perez Perez Milton Aron',0,NULL,NULL),(1544,'104',NULL,'noviembre 24 y febrero','2025-03-01',100.00,NULL,'2026-05-04 01:13:24',0.00,'Cigarroa Barrios Angel David',0,NULL,NULL),(1545,'105',NULL,'febrero','2025-03-01',25.00,NULL,'2026-05-04 01:13:24',0.00,'Hernandez Cabrera Hazel Daniela',0,NULL,NULL),(1546,'106',NULL,'noviembre 24 y febrero','2025-03-01',100.00,NULL,'2026-05-04 01:13:24',0.00,'Estrada del Toro Diego Alejandro',0,NULL,NULL),(1547,'107',NULL,'febrero','2025-03-01',25.00,NULL,'2026-05-04 01:13:24',0.00,'De Paz Fuentes Angel Ferreyn',0,NULL,NULL),(1548,'108',NULL,'noviembre 24 y febrero','2025-03-01',100.00,NULL,'2026-05-04 01:13:24',0.00,'Vasquez Paxtor Juan Miguel',0,NULL,NULL),(1549,'109',NULL,'febrero','2025-03-01',25.00,NULL,'2026-05-04 01:13:24',0.00,'Alonzo Lopez Francis Noe Misael',0,NULL,NULL),(1550,'110',NULL,'febrero','2025-03-01',25.00,NULL,'2026-05-04 01:13:24',0.00,'Rojop Garcia Fatima Nalleli',0,NULL,NULL),(1551,'111',NULL,'noviembre','2025-03-01',75.00,NULL,'2026-05-04 01:13:24',0.00,'Gomez Maria Ines',0,NULL,NULL),(1552,'112',NULL,'febrero','2025-03-08',25.00,NULL,'2026-05-04 01:13:24',0.00,'de Leon Molina Marvin Estuardo',0,NULL,NULL),(1553,'113',NULL,'marzo','2025-03-08',25.00,NULL,'2026-05-04 01:13:24',0.00,'Cuyuch Ordoñez Estefani Yoana',0,NULL,NULL),(1554,'114',NULL,'noviembre 2024 febrero 2025','2025-03-08',62.50,NULL,'2026-05-04 01:13:24',0.00,'Gonzalez Maldonado Jorge Daniel',0,NULL,NULL),(1555,'115',NULL,'febrero','2025-03-08',25.00,NULL,'2026-05-04 01:13:24',0.00,'Giron Mendez Jean Carlos',0,NULL,NULL),(1556,'116',NULL,'MARZO','2025-03-08',25.00,NULL,'2026-05-04 01:13:24',0.00,'Lopez Garcia Eduardo Alberto',0,NULL,NULL),(1557,'117',NULL,'febrero','2025-03-08',25.00,NULL,'2026-05-04 01:13:24',0.00,'Ramirez Perez Delsy Liliana',0,NULL,NULL),(1558,'118',NULL,'febrero-marzo','2025-03-15',50.00,NULL,'2026-05-04 01:13:24',0.00,'De Leon Gomez Cecilia',0,NULL,NULL),(1559,'119',NULL,'noviembre 2024 febrero 2025','2025-03-15',100.00,NULL,'2026-05-04 01:13:24',0.00,'Suchite Cabrera Cristian Wilfredo',0,NULL,NULL),(1560,'120',NULL,'febrero','2025-03-15',25.00,NULL,'2026-05-04 01:13:24',0.00,'Gomez Maria Ines',0,NULL,NULL),(1561,'121',NULL,'noviembre 2024 febrero 2025','2025-03-15',100.00,NULL,'2026-05-04 01:13:24',0.00,'Pablo de Leon Ricardo Alberto',0,NULL,NULL),(1562,'122',NULL,'febrero','2025-03-15',25.00,NULL,'2026-05-04 01:13:24',0.00,'Contreras Lopez Sergio Alexander',0,NULL,NULL),(1563,'123',NULL,'febrero','2025-03-15',25.00,NULL,'2026-05-04 01:13:24',0.00,'Contreras Lopez Rosa Leticia',0,NULL,NULL),(1564,'124',NULL,'noviembre 2024 febrero 2025','2025-03-15',100.00,NULL,'2026-05-04 01:13:24',0.00,'Vasquez Sales Saida',0,NULL,NULL),(1565,'125',NULL,'marzo','2025-03-22',25.00,NULL,'2026-05-04 01:13:24',0.00,'Perez Orozco Lilian Delfina',0,NULL,NULL),(1566,'126',NULL,'marzo','2025-03-22',25.00,NULL,'2026-05-04 01:13:24',0.00,'Garcia Perez Nancy Marisol',0,NULL,NULL),(1567,'127',NULL,'marzo','2025-03-22',25.00,NULL,'2026-05-04 01:13:24',0.00,'Cabrera Alonzo Emelin Azucena',0,NULL,NULL),(1568,'128',NULL,'noviembre 2024','2025-03-22',37.50,NULL,'2026-05-04 01:13:24',0.00,'Garcia Porrez Marilin Selyna',0,NULL,NULL),(1569,'129',NULL,'marzo-abril','2025-03-22',50.00,NULL,'2026-05-04 01:13:24',0.00,'Guzman Gomez Walfred Antonio',0,NULL,NULL),(1570,'130',NULL,'marzo','2025-03-29',25.00,NULL,'2026-05-04 01:13:24',0.00,'Estrada del Toro Diego Alejandro',0,NULL,NULL),(1571,'131',NULL,'marzo','2025-03-29',25.00,NULL,'2026-05-04 01:13:24',0.00,'Garcia Romero Ivana Jassmin',0,NULL,NULL),(1572,'132',NULL,'marzo','2025-03-29',25.00,NULL,'2026-05-04 01:13:24',0.00,'De Paz Fuentes Angel Ferreyn',0,NULL,NULL),(1573,'133',NULL,'marzo','2025-03-29',25.00,NULL,'2026-05-04 01:13:24',0.00,'Juarez Lucas Alison Alondra',0,NULL,NULL),(1574,'134',NULL,'marzo','2025-03-29',25.00,NULL,'2026-05-04 01:13:24',0.00,'Perez Perez Milton Aron',0,NULL,NULL),(1575,'135',NULL,'marzo','2025-03-29',25.00,NULL,'2026-05-04 01:13:24',0.00,'Vasquez Perez Wilson Daniel',0,NULL,NULL),(1576,'136',NULL,'marzo','2025-03-29',25.00,NULL,'2026-05-04 01:13:24',0.00,'Hernandez Cabrera Hazel Daniela',0,NULL,NULL),(1577,'137',NULL,'marzo','2025-03-29',25.00,NULL,'2026-05-04 01:13:24',0.00,'Juarez de Leon Miguel de Jesus',0,NULL,NULL),(1578,'138',NULL,'marzo','2025-03-29',25.00,NULL,'2026-05-04 01:13:24',0.00,'Cuyuch Domiguez Sergio Ottoniel',0,NULL,NULL),(1579,'139',NULL,'marzo','2025-03-29',25.00,NULL,'2026-05-04 01:13:24',0.00,'Vasquez Paxtor Juan Miguel',0,NULL,NULL),(1580,'140',NULL,'marzo','2025-03-29',25.00,NULL,'2026-05-04 01:13:24',0.00,'Alonzo Lopez Francis Noe Misael',0,NULL,NULL),(1581,'141',NULL,'marzo-abril','2025-03-30',50.00,NULL,'2026-05-04 01:13:24',0.00,'Cabrera Giron Doris Aimar',0,NULL,NULL),(1582,'142',NULL,'marzo','2025-03-30',25.00,NULL,'2026-05-04 01:13:24',0.00,'Jimenez Perez Antonio Isai',0,NULL,NULL),(1583,'143',NULL,'abono marzo','2025-04-05',15.00,NULL,'2026-05-04 01:13:24',0.00,'Chavalan Jasinto Jose Enrique',0,NULL,NULL),(1584,'144',NULL,'marzo','2025-04-05',25.00,NULL,'2026-05-04 01:13:24',0.00,'Ochoa Cabrera Gerli Yurandi',0,NULL,NULL),(1585,'145',NULL,'marzo','2025-04-05',25.00,NULL,'2026-05-04 01:13:24',0.00,'Cabrera Lopez Brayan Yobani',0,NULL,NULL),(1586,'146',NULL,'marzo','2025-04-05',25.00,NULL,'2026-05-04 01:13:24',0.00,'Lara Lopez Gerson Elias',0,NULL,NULL),(1587,'147',NULL,'marzo','2025-04-05',25.00,NULL,'2026-05-04 01:13:24',0.00,'Sales Garcia Kervin Ventura',0,NULL,NULL),(1588,'148',NULL,'marzo','2025-04-05',25.00,NULL,'2026-05-04 01:13:24',0.00,'Lopez Ramirez Nestor Antonio',0,NULL,NULL),(1589,'149',NULL,'marzo','2025-04-05',25.00,NULL,'2026-05-04 01:13:24',0.00,'Velasquez Meza Katerin Elizani',0,NULL,NULL),(1590,'150',NULL,'marzo','2025-04-05',25.00,NULL,'2026-05-04 01:13:24',0.00,'Mazariegos de Leon Jennifer Estefani',0,NULL,NULL),(1591,'151',NULL,'marzo','2025-04-05',25.00,NULL,'2026-05-04 01:13:24',0.00,'Jimenez Guzman Ana Cecilia',0,NULL,NULL),(1592,'152',NULL,'marzo','2025-04-05',25.00,NULL,'2026-05-04 01:13:24',0.00,'Molina Vasquez Lesly Yasmin',0,NULL,NULL),(1593,'153',NULL,'febrero','2025-04-05',25.00,NULL,'2026-05-04 01:13:24',0.00,'Garcia Porrez Marilin Selyna',0,NULL,NULL),(1594,'154',NULL,'marzo','2025-04-05',25.00,NULL,'2026-05-04 01:13:24',0.00,'Mendez Vasquez Sheily Maritza',0,NULL,NULL),(1595,'155',NULL,'marzo','2025-04-05',25.00,NULL,'2026-05-04 01:13:24',0.00,'Chaves Lucas Rosa Belen',0,NULL,NULL),(1596,'156',NULL,'marzo','2025-04-05',25.00,NULL,'2026-05-04 01:13:24',0.00,'Cruz Vicente Jimena Dayana',0,NULL,NULL),(1597,'157',NULL,'marzo','2025-04-05',25.00,NULL,'2026-05-04 01:13:24',0.00,'Garcia Mendez Marelin Yoseni',0,NULL,NULL),(1598,'158',NULL,'marzo','2025-04-05',25.00,NULL,'2026-05-04 01:13:24',0.00,'Vasquez Perez Adriana Marisol',0,NULL,NULL),(1599,'159',NULL,'marzo','2025-04-05',25.00,NULL,'2026-05-04 01:13:24',0.00,'Sales Perez Brandi Yovani',0,NULL,NULL),(1600,'160',NULL,'marzo','2025-04-05',25.00,NULL,'2026-05-04 01:13:24',0.00,'Perez Perez Ines',0,NULL,NULL),(1601,'161',NULL,'marzo','2025-04-05',25.00,NULL,'2026-05-04 01:13:24',0.00,'Giron Mendez Jean Carlos',0,NULL,NULL),(1602,'162',NULL,'marzo','2025-04-05',25.00,NULL,'2026-05-04 01:13:24',0.00,'Lopez Lopez Angel Abraham',0,NULL,NULL),(1603,'163',NULL,'marzo','2025-04-12',25.00,NULL,'2026-05-04 01:13:24',0.00,'Garcia Perez Jorge Danilo',0,NULL,NULL),(1604,'164',NULL,'anulado','2025-04-13',0.00,NULL,'2026-05-04 01:13:24',0.00,'anulado',0,NULL,NULL),(1605,'165',NULL,'noviembre','2025-04-13',75.00,NULL,'2026-05-04 01:13:24',0.00,'Vicente Diaz Nataly Celeste',0,NULL,NULL),(1606,'166',NULL,'febrero-marzo-abril','2025-04-26',75.00,NULL,'2026-05-04 01:13:24',0.00,'Lara Tiu Natalia Lucita',0,NULL,NULL),(1607,'167',NULL,'marzo-abril','2025-04-26',50.00,NULL,'2026-05-04 01:13:24',0.00,'Castillo Ovalle Jade Maria',0,NULL,NULL),(1608,'168',NULL,'abril','2025-04-26',25.00,NULL,'2026-05-04 01:13:24',0.00,'Perez Perez Milton Aron',0,NULL,NULL),(1609,'169',NULL,'abril','2025-04-26',25.00,NULL,'2026-05-04 01:13:24',0.00,'De Leon Gomez Cecilia',0,NULL,NULL),(1610,'170',NULL,'abril','2025-04-26',25.00,NULL,'2026-05-04 01:13:24',0.00,'Vasquez Paxtor Juan Miguel',0,NULL,NULL),(1611,'171',NULL,'abril','2025-04-26',25.00,NULL,'2026-05-04 01:13:24',0.00,'De Paz Fuentes Angel Ferreyn',0,NULL,NULL),(1612,'172',NULL,'abril','2025-04-26',25.00,NULL,'2026-05-04 01:13:24',0.00,'Vasquez Perez Wilson Daniel',0,NULL,NULL),(1613,'173',NULL,'abril','2025-04-26',25.00,NULL,'2026-05-04 01:13:24',0.00,'Juarez Lucas Alison Alondra',0,NULL,NULL),(1614,'174',NULL,'marzo','2025-04-26',25.00,NULL,'2026-05-04 01:13:24',0.00,'Cigarroa Barrios Angel David',0,NULL,NULL),(1615,'175',NULL,'inscripcion','2025-04-26',0.00,NULL,'2026-05-04 01:13:24',0.00,'por inscripciones de Castillo Coy Emilia Elizabeth',0,NULL,NULL),(1616,'176',NULL,'inscripcion','2025-04-26',0.00,NULL,'2026-05-04 01:13:24',0.00,'por inscripciones de Castillo Coy Evelyn Marleny',0,NULL,NULL),(1617,'177',NULL,'marzo','2025-04-27',25.00,NULL,'2026-05-04 01:13:24',0.00,'Pablo de Leon Ricardo Alberto',0,NULL,NULL),(1618,'178',NULL,'marzo','2025-04-27',25.00,NULL,'2026-05-04 01:13:24',0.00,'Gomez Maria Ines',0,NULL,NULL),(1619,'179',NULL,'noviembre 2024','2025-04-27',75.00,NULL,'2026-05-04 01:13:24',0.00,'Vicente Perez Neftali Odiel',0,NULL,NULL),(1620,'180',NULL,'abril','2025-04-27',25.00,NULL,'2026-05-04 01:13:24',0.00,'Jimenez Perez Antonio Isai',0,NULL,NULL),(1621,'181',NULL,'marzo','2025-04-27',25.00,NULL,'2026-05-04 01:13:24',0.00,'Contreras Lopez Sergio Alexander',0,NULL,NULL),(1622,'182',NULL,'marzo','2025-04-27',25.00,NULL,'2026-05-04 01:13:24',0.00,'Contreras Lopez Rosa Leticia',0,NULL,NULL),(1623,'183',NULL,'abril','2025-05-03',25.00,NULL,'2026-05-04 01:13:24',0.00,'Ochoa Cabrera Gerli Yurandi',0,NULL,NULL),(1624,'184',NULL,'abril','2025-05-03',25.00,NULL,'2026-05-04 01:13:24',0.00,'Cabrera Lopez Brayan Yobani',0,NULL,NULL),(1625,'185',NULL,'marzo','2025-05-03',25.00,NULL,'2026-05-04 01:13:24',0.00,'Cabrera Hernandez Mileidi Estrellita',0,NULL,NULL),(1626,'186',NULL,'mayo','2025-05-03',25.00,NULL,'2026-05-04 01:13:24',0.00,'Jimenez Gomez Byron Jeremias',0,NULL,NULL),(1627,'187',NULL,'abril','2025-05-03',25.00,NULL,'2026-05-04 01:13:24',0.00,'Lopez Ramirez Nestor Antonio',0,NULL,NULL),(1628,'188',NULL,'abril','2025-05-03',25.00,NULL,'2026-05-04 01:13:24',0.00,'Velasquez Meza Katerin Elizani',0,NULL,NULL),(1629,'189',NULL,'abril-mayo','2025-05-03',50.00,NULL,'2026-05-04 01:13:24',0.00,'Cuyuch Ordoñez Estefani Yoana',0,NULL,NULL),(1630,'190',NULL,'abril','2025-05-03',25.00,NULL,'2026-05-04 01:13:24',0.00,'Perez Orozco Lilian Delfina',0,NULL,NULL),(1631,'191',NULL,'abril','2025-05-03',25.00,NULL,'2026-05-04 01:13:24',0.00,'Mazariegos de Leon Jennifer Estefani',0,NULL,NULL),(1632,'192',NULL,'marzo','2025-05-03',25.00,NULL,'2026-05-04 01:13:24',0.00,'Diaz Vasquez Mishel Nohemi',0,NULL,NULL),(1633,'193',NULL,'marzo-abril','2025-05-03',50.00,NULL,'2026-05-04 01:13:24',0.00,'Molina Perez Diana Aurora',0,NULL,NULL),(1634,'194',NULL,'abril','2025-05-03',25.00,NULL,'2026-05-04 01:13:24',0.00,'Sales Garcia Kervin Ventura',0,NULL,NULL),(1635,'195',NULL,'resto de marzo-abril','2025-05-03',35.00,NULL,'2026-05-04 01:13:24',0.00,'Chavalan Jasinto Jose Enrique',0,NULL,NULL),(1636,'196',NULL,'marzo-abril','2025-05-03',50.00,NULL,'2026-05-04 01:13:24',0.00,'de Leon Molina Marvin Estuardo',0,NULL,NULL),(1637,'197',NULL,'abril','2025-05-03',25.00,NULL,'2026-05-04 01:13:24',0.00,'Perez Perez Ines',0,NULL,NULL),(1638,'198',NULL,'abril','2025-05-03',25.00,NULL,'2026-05-04 01:13:24',0.00,'Garcia Mendez Marelin Yoseni',0,NULL,NULL),(1639,'199',NULL,'marzo-abril','2025-05-03',50.00,NULL,'2026-05-04 01:13:24',0.00,'Ramirez Perez Delsy Liliana',0,NULL,NULL),(1640,'200',NULL,'marzo-abril-mayo','2025-05-03',75.00,NULL,'2026-05-04 01:13:24',0.00,'Gonzalez Maldonado Jorge Daniel',0,NULL,NULL),(1641,'201',NULL,'abril','2025-05-03',25.00,NULL,'2026-05-04 01:13:24',0.00,'Lopez Lopez Angel Abraham',0,NULL,NULL),(1642,'202',NULL,'abril','2025-05-03',25.00,NULL,'2026-05-04 01:13:24',0.00,'Giron Mendez Jean Carlos',0,NULL,NULL),(1643,'203',NULL,'abril-mayo','2025-05-03',50.00,NULL,'2026-05-04 01:13:24',0.00,'Garcia Perez Nancy Marisol',0,NULL,NULL),(1644,'204',NULL,'abril','2025-05-03',25.00,NULL,'2026-05-04 01:13:24',0.00,'Lopez Garcia Eduardo Alberto',0,NULL,NULL),(1645,'205',NULL,'mayo','2025-05-03',25.00,NULL,'2026-05-04 01:13:24',0.00,'Guzman Gomez Walfred Antonio',0,NULL,NULL),(1646,'206',NULL,'abril-mayo','2025-05-03',50.00,NULL,'2026-05-04 01:13:24',0.00,'Molina Vasquez Lesly Yasmin',0,NULL,NULL),(1647,'207',NULL,'marzo','2025-05-03',25.00,NULL,'2026-05-04 01:13:24',0.00,'Garcia Porrez Marilin Selyna',0,NULL,NULL),(1648,'208',NULL,'abril','2025-05-03',25.00,NULL,'2026-05-04 01:13:24',0.00,'Cabrera Alonzo Emelin Azucena',0,NULL,NULL),(1649,'209',NULL,'abril','2025-05-03',25.00,NULL,'2026-05-04 01:13:24',0.00,'Mendez Vasquez Sheily Maritza',0,NULL,NULL),(1650,'210',NULL,'abril','2025-05-03',25.00,NULL,'2026-05-04 01:13:24',0.00,'Chaves Lucas Rosa Belen',0,NULL,NULL),(1651,'211',NULL,'abril','2025-05-03',25.00,NULL,'2026-05-04 01:13:24',0.00,'Cruz Vicente Jimena Dayana',0,NULL,NULL),(1652,'212',NULL,'mayo-junio-julio-agosto','2025-05-10',100.00,NULL,'2026-05-04 01:13:24',0.00,'Chavez Lorenzo Yeimi Josefina',0,NULL,NULL),(1653,'213',NULL,'abril','2025-05-10',25.00,NULL,'2026-05-04 01:13:24',0.00,'Garcia Romero Ivana Jassmin',0,NULL,NULL),(1654,'214',NULL,'abril','2025-05-10',25.00,NULL,'2026-05-04 01:13:24',0.00,'Cuyuch Domiguez Sergio Ottoniel',0,NULL,NULL),(1655,'215',NULL,'abril','2025-05-10',25.00,NULL,'2026-05-04 01:13:24',0.00,'Garcia Perez Jorge Danilo',0,NULL,NULL),(1656,'216',NULL,'abril','2025-05-10',25.00,NULL,'2026-05-04 01:13:24',0.00,'Cigarroa Barrios Angel David',0,NULL,NULL),(1657,'217',NULL,'abril-mayo','2025-05-10',50.00,NULL,'2026-05-04 01:13:24',0.00,'Hernandez Cabrera Hazel Daniela',0,NULL,NULL),(1658,'218',NULL,'marzo','2025-05-11',25.00,NULL,'2026-05-04 01:13:24',0.00,'Vicente Diaz Nataly Celeste',0,NULL,NULL),(1659,'219',NULL,'abril','2025-05-17',25.00,NULL,'2026-05-04 01:13:24',0.00,'Lara Lopez Gerson Elias',0,NULL,NULL),(1660,'220',NULL,'marzo-abril','2025-05-17',50.00,NULL,'2026-05-04 01:13:24',0.00,'Baltazar Vasqauez Sebastian Anibal',0,NULL,NULL),(1661,'221',NULL,'abril-mayo','2025-05-17',50.00,NULL,'2026-05-04 01:13:24',0.00,'Vasquez Perez Adriana Marisol',0,NULL,NULL),(1662,'222',NULL,'mayo','2025-05-17',25.00,NULL,'2026-05-04 01:13:24',0.00,'Lopez Garcia Eduardo Alberto',0,NULL,NULL),(1663,'223',NULL,'mayo','2025-05-17',25.00,NULL,'2026-05-04 01:13:24',0.00,'Giron Mendez Jean Carlos',0,NULL,NULL),(1664,'224',NULL,'abril-mayo','2025-05-17',50.00,NULL,'2026-05-04 01:13:24',0.00,'Sales Perez Brandi Yovani',0,NULL,NULL),(1665,'225',NULL,'mayo','2025-05-17',25.00,NULL,'2026-05-04 01:13:24',0.00,'Perez Perez Ines',0,NULL,NULL),(1666,'226',NULL,'abril-mayo','2025-05-25',50.00,NULL,'2026-05-04 01:13:24',0.00,'Pablo de Leon Ricardo Alberto',0,NULL,NULL),(1667,'227',NULL,'mayo-junio-julio-agosto','2025-05-25',100.00,NULL,'2026-05-04 01:13:24',0.00,'Cabrera Giron Doris Aimar',0,NULL,NULL),(1668,'228',NULL,'mayo-junio','2025-05-25',50.00,NULL,'2026-05-04 01:13:24',0.00,'Jimenez Perez Antonio Isai',0,NULL,NULL),(1669,'229',NULL,'febrero-marzo-abril-mayo','2025-05-25',100.00,NULL,'2026-05-04 01:13:24',0.00,'Vicente Perez Neftali Odiel',0,NULL,NULL),(1670,'230',NULL,'abril-mayo','2025-05-25',50.00,NULL,'2026-05-04 01:13:24',0.00,'Gomez Maria Ines',0,NULL,NULL),(1671,'231',NULL,'abril','2025-05-25',25.00,NULL,'2026-05-04 01:13:24',0.00,'Castillo Coy Emilia Elizabeth',0,NULL,NULL),(1672,'232',NULL,'abril','2025-05-25',25.00,NULL,'2026-05-04 01:13:24',0.00,'Castillo Coy Evelyn Marleny',0,NULL,NULL),(1673,'233',NULL,'mayo','2025-05-31',25.00,NULL,'2026-05-04 01:13:24',0.00,'Jimenez Guzman Ana Cecilia',0,NULL,NULL),(1674,'234',NULL,'mayo','2025-05-31',25.00,NULL,'2026-05-04 01:13:24',0.00,'Perez Orozco Lilian Delfina',0,NULL,NULL),(1675,'235',NULL,'abril','2025-05-31',25.00,NULL,'2026-05-04 01:13:24',0.00,'Diaz Vasquez Mishel Nohemi',0,NULL,NULL),(1676,'236',NULL,'mayo','2025-05-31',25.00,NULL,'2026-05-04 01:13:24',0.00,'Lara Lopez Gerson Elias',0,NULL,NULL),(1677,'237',NULL,'mayo','2025-05-31',25.00,NULL,'2026-05-04 01:13:24',0.00,'Cabrera Lopez Brayan Yobani',0,NULL,NULL),(1678,'238',NULL,'mayo','2025-05-31',25.00,NULL,'2026-05-04 01:13:24',0.00,'De Leon Gomez Cecilia',0,NULL,NULL),(1679,'239',NULL,'mayo','2025-05-31',25.00,NULL,'2026-05-04 01:13:24',0.00,'Lopez Ramirez Nestor Antonio',0,NULL,NULL),(1680,'240',NULL,'abril-mayo','2025-05-31',50.00,NULL,'2026-05-04 01:13:24',0.00,'Estrada del Toro Diego Alejandro',0,NULL,NULL),(1681,'241',NULL,'mayo','2025-05-31',25.00,NULL,'2026-05-04 01:13:24',0.00,'Juarez Lucas Alison Alondra',0,NULL,NULL),(1682,'242',NULL,'mayo','2025-05-31',25.00,NULL,'2026-05-04 01:13:24',0.00,'Shlaj Lucas Eduardo Apolinario',0,NULL,NULL),(1683,'243',NULL,'mayo','2025-05-31',25.00,NULL,'2026-05-04 01:13:24',0.00,'Garcia Perez Jorge Danilo',0,NULL,NULL),(1684,'244',NULL,'mayo','2025-05-31',25.00,NULL,'2026-05-04 01:13:24',0.00,'Garcia Mendez Marelin Yoseni',0,NULL,NULL),(1685,'245',NULL,'mayo','2025-05-31',25.00,NULL,'2026-05-04 01:13:24',0.00,'Perez Perez Milton Aron',0,NULL,NULL),(1686,'246',NULL,'marzo-abril-mayo','2025-05-31',75.00,NULL,'2026-05-04 01:13:24',0.00,'Rojop Dominguez Juan Miguel',0,NULL,NULL),(1687,'247',NULL,'junio','2025-05-31',25.00,NULL,'2026-05-04 01:13:24',0.00,'Guzman Gomez Walfred Antonio',0,NULL,NULL),(1688,'248',NULL,'mayo','2025-05-31',25.00,NULL,'2026-05-04 01:13:24',0.00,'Lopez Lopez Angel Abraham',0,NULL,NULL),(1689,'249',NULL,'mayo','2025-05-31',25.00,NULL,'2026-05-04 01:13:24',0.00,'Garcia Romero Ivana Jassmin',0,NULL,NULL),(1690,'250',NULL,'abril-mayo','2025-05-31',50.00,NULL,'2026-05-04 01:13:24',0.00,'Garcia Porrez Marilin Selyna',0,NULL,NULL),(1691,'251',NULL,'mayo','2025-05-31',25.00,NULL,'2026-05-04 01:13:24',0.00,'Mendez Vasquez Sheily Maritza',0,NULL,NULL),(1692,'252',NULL,'marzo','2025-05-31',25.00,NULL,'2026-05-04 01:13:24',0.00,'Suchite Cabrera Cristian Wilfredo',0,NULL,NULL),(1693,'253',NULL,'mayo-junio','2025-05-31',50.00,NULL,'2026-05-04 01:13:24',0.00,'Molina Lucas Guillermo',0,NULL,NULL),(1694,'254',NULL,'mayo','2025-05-31',25.00,NULL,'2026-05-04 01:13:24',0.00,'Ramirez Perez Delsy Liliana',0,NULL,NULL),(1695,'255',NULL,'mayo','2025-05-31',25.00,NULL,'2026-05-04 01:13:24',0.00,'Vasquez Perez Wilson Daniel',0,NULL,NULL),(1696,'256',NULL,'junio','2025-05-31',25.00,NULL,'2026-05-04 01:13:24',0.00,'Gonzalez Maldonado Jorge Daniel',0,NULL,NULL),(1697,'257',NULL,'junio','2025-05-31',25.00,NULL,'2026-05-04 01:13:24',0.00,'Giron Mendez Jean Carlos',0,NULL,NULL),(1698,'258',NULL,'mayo','2025-05-31',25.00,NULL,'2026-05-04 01:13:24',0.00,'Cruz Vicente Jimena Dayana',0,NULL,NULL),(1699,'259',NULL,'mayo','2025-06-07',25.00,NULL,'2026-05-04 01:13:24',0.00,'Cuyuch Domiguez Sergio Ottoniel',0,NULL,NULL),(1700,'260',NULL,'abril-mayo','2025-06-07',50.00,NULL,'2026-05-04 01:13:24',0.00,'Juarez de Leon Miguel de Jesus',0,NULL,NULL),(1701,'261',NULL,'junio','2025-06-07',25.00,NULL,'2026-05-04 01:13:24',0.00,'Hernandez Cabrera Hazel Daniela',0,NULL,NULL),(1702,'262',NULL,'mayo','2025-06-07',25.00,NULL,'2026-05-04 01:13:24',0.00,'De Paz Fuentes Angel Ferreyn',0,NULL,NULL),(1703,'263',NULL,'abril','2025-06-08',25.00,NULL,'2026-05-04 01:13:24',0.00,'Contreras Lopez Sergio Alexander',0,NULL,NULL),(1704,'264',NULL,'abril','2025-06-08',25.00,NULL,'2026-05-04 01:13:24',0.00,'Contreras Lopez Rosa Leticia',0,NULL,NULL),(1705,'265',NULL,'abril-mayo','2025-06-08',50.00,NULL,'2026-05-04 01:13:24',0.00,'Vicente Diaz Nataly Celeste',0,NULL,NULL),(1706,'266',NULL,'junio','2025-06-08',25.00,NULL,'2026-05-04 01:13:24',0.00,'Gomez Maria Ines',0,NULL,NULL),(1707,'267',NULL,'mayo','2025-06-08',25.00,NULL,'2026-05-04 01:13:24',0.00,'Castillo Coy Emilia Elizabeth',0,NULL,NULL),(1708,'268',NULL,'mayo','2025-06-08',25.00,NULL,'2026-05-04 01:13:24',0.00,'Castillo Coy Evelyn Marleny',0,NULL,NULL),(1709,'269',NULL,'abril-mayo','2025-06-08',50.00,NULL,'2026-05-04 01:13:24',0.00,'Cabrera Hernandez Mileidi Estrellita',0,NULL,NULL),(1710,'270',NULL,'junio','2025-06-14',25.00,NULL,'2026-05-04 01:13:24',0.00,'Lara Lopez Gerson Elias',0,NULL,NULL),(1711,'271',NULL,'mayo','2025-06-14',25.00,NULL,'2026-05-04 01:13:24',0.00,'Sales Garcia Kervin Ventura',0,NULL,NULL),(1712,'272',NULL,'junio','2025-06-14',25.00,NULL,'2026-05-04 01:13:25',0.00,'Perez Orozco Lilian Delfina',0,NULL,NULL),(1713,'273',NULL,'junio','2025-06-14',25.00,NULL,'2026-05-04 01:13:25',0.00,'Garcia Perez Nancy Marisol',0,NULL,NULL),(1714,'274',NULL,'junio','2025-06-14',25.00,NULL,'2026-05-04 01:13:25',0.00,'Molina Vasquez Lesly Yasmin',0,NULL,NULL),(1715,'275',NULL,'mayo','2025-06-14',25.00,NULL,'2026-05-04 01:13:25',0.00,'Cabrera Alonzo Emelin Azucena',0,NULL,NULL),(1716,'276',NULL,'junio','2025-06-21',25.00,NULL,'2026-05-04 01:13:25',0.00,'De Leon Gomez Cecilia',0,NULL,NULL),(1717,'277',NULL,'junio','2025-06-21',25.00,NULL,'2026-05-04 01:13:25',0.00,'Vasquez Perez Wilson Daniel',0,NULL,NULL),(1718,'278',NULL,'mayo','2025-06-21',25.00,NULL,'2026-05-04 01:13:25',0.00,'Cigarroa Barrios Angel David',0,NULL,NULL),(1719,'279',NULL,'mayo','2025-06-21',25.00,NULL,'2026-05-04 01:13:25',0.00,'Castillo Ovalle Jade Maria',0,NULL,NULL),(1720,'280',NULL,'junio','2025-06-21',25.00,NULL,'2026-05-04 01:13:25',0.00,'De Paz Fuentes Angel Ferreyn',0,NULL,NULL),(1721,'281',NULL,'junio','2025-06-21',25.00,NULL,'2026-05-04 01:13:25',0.00,'Perez Perez Milton Aron',0,NULL,NULL),(1722,'282',NULL,'junio','2025-06-21',25.00,NULL,'2026-05-04 01:13:25',0.00,'Garcia Romero Ivana Jassmin',0,NULL,NULL),(1723,'283',NULL,'abril-mayo','2025-06-21',50.00,NULL,'2026-05-04 01:13:25',0.00,'Suchite Cabrera Cristian Wilfredo',0,NULL,NULL),(1724,'284',NULL,'junio','2025-06-22',25.00,NULL,'2026-05-04 01:13:25',0.00,'Pablo de Leon Ricardo Alberto',0,NULL,NULL),(1725,'285',NULL,'julio','2025-06-22',25.00,NULL,'2026-05-04 01:13:25',0.00,'Gomez Maria Ines',0,NULL,NULL),(1726,'286',NULL,'abril-mayo-junio','2025-06-22',75.00,NULL,'2026-05-04 01:13:25',0.00,'Alonzo Lopez Francis Noe Misael',0,NULL,NULL),(1727,'287',NULL,'junio','2025-06-22',25.00,NULL,'2026-05-04 01:13:25',0.00,'Cabrera Hernandez Mileidi Estrellita',0,NULL,NULL),(1728,'288',NULL,'mayo','2025-06-22',25.00,NULL,'2026-05-04 01:13:25',0.00,'Contreras Lopez Sergio Alexander',0,NULL,NULL),(1729,'289',NULL,'mayo','2025-06-22',25.00,NULL,'2026-05-04 01:13:25',0.00,'Contreras Lopez Rosa Leticia',0,NULL,NULL),(1730,'290',NULL,'mayo-junio','2025-06-22',50.00,NULL,'2026-05-04 01:13:25',0.00,'Molina Perez Diana Aurora',0,NULL,NULL),(1731,'291',NULL,'junio','2025-06-22',25.00,NULL,'2026-05-04 01:13:25',0.00,'Cuyuch Ordoñez Estefani Yoana',0,NULL,NULL),(1732,'292',NULL,'junio','2025-06-22',25.00,NULL,'2026-05-04 01:13:25',0.00,'Castillo Coy Emilia Elizabeth',0,NULL,NULL),(1733,'293',NULL,'junio','2025-06-22',25.00,NULL,'2026-05-04 01:13:25',0.00,'Castillo Coy Evelyn Marleny',0,NULL,NULL),(1734,'294',NULL,'junio','2025-06-28',25.00,NULL,'2026-05-04 01:13:25',0.00,'Cabrera Lopez Brayan Yobani',0,NULL,NULL),(1735,'295',NULL,'julio','2025-06-28',25.00,NULL,'2026-05-04 01:13:25',0.00,'Lara Lopez Gerson Elias',0,NULL,NULL),(1736,'296',NULL,'mayo-junio','2025-06-28',50.00,NULL,'2026-05-04 01:13:25',0.00,'Velasquez Meza Katerin Elizani',0,NULL,NULL),(1737,'297',NULL,'agosto','2025-06-28',25.00,NULL,'2026-05-04 01:13:25',0.00,'Molina Perez Diana Aurora',0,NULL,NULL),(1738,'298',NULL,'junio-julio','2025-06-28',50.00,NULL,'2026-05-04 01:13:25',0.00,'Vasquez Perez Adriana Marisol',0,NULL,NULL),(1739,'299',NULL,'julio','2025-06-28',25.00,NULL,'2026-05-04 01:13:25',0.00,'Guzman Gomez Walfred Antonio',0,NULL,NULL),(1740,'300',NULL,'junio','2025-06-28',25.00,NULL,'2026-05-04 01:13:25',0.00,'Lopez Garcia Eduardo Alberto',0,NULL,NULL),(1741,'301',NULL,'junio','2025-06-28',25.00,NULL,'2026-05-04 01:13:25',0.00,'Garcia Porrez Marilin Selyna',0,NULL,NULL),(1742,'302',NULL,'junio','2025-06-28',25.00,NULL,'2026-05-04 01:13:25',0.00,'Lopez Lopez Angel Abraham',0,NULL,NULL),(1743,'303',NULL,'julio','2025-06-28',25.00,NULL,'2026-05-04 01:13:25',0.00,'Giron Mendez Jean Carlos',0,NULL,NULL),(1744,'304',NULL,'junio','2025-06-28',25.00,NULL,'2026-05-04 01:13:25',0.00,'Perez Perez Ines',0,NULL,NULL),(1745,'305',NULL,'junio','2025-07-05',25.00,NULL,'2026-05-04 01:13:25',0.00,'Shlaj Lucas Eduardo Apolinario',0,NULL,NULL),(1746,'306',NULL,'julio','2025-07-05',25.00,NULL,'2026-05-04 01:13:25',0.00,'Garcia Romero Ivana Jassmin',0,NULL,NULL),(1747,'307',NULL,'junio','2025-07-05',25.00,NULL,'2026-05-04 01:13:25',0.00,'Juarez de Leon Miguel de Jesus',0,NULL,NULL),(1748,'308',NULL,'junio','2025-07-05',25.00,NULL,'2026-05-04 01:13:25',0.00,'Juarez Lucas Alison Alondra',0,NULL,NULL),(1749,'309',NULL,'junio','2025-07-05',25.00,NULL,'2026-05-04 01:13:25',0.00,'Castillo Ovalle Jade Maria',0,NULL,NULL),(1750,'310',NULL,'julio','2025-07-05',25.00,NULL,'2026-05-04 01:13:25',0.00,'Hernandez Cabrera Hazel Daniela',0,NULL,NULL),(1751,'311',NULL,'julio','2025-07-06',25.00,NULL,'2026-05-04 01:13:25',0.00,'Jimenez Perez Antonio Isai',0,NULL,NULL),(1752,'312',NULL,'mayo','2025-07-12',25.00,NULL,'2026-05-04 01:13:25',0.00,'Ochoa Cabrera Gerli Yurandi',0,NULL,NULL),(1753,'313',NULL,'agosto','2025-07-12',25.00,NULL,'2026-05-04 01:13:25',0.00,'Lara Lopez Gerson Elias',0,NULL,NULL),(1754,'314',NULL,'mayo-junio-julio-agosto','2025-07-12',100.00,NULL,'2026-05-04 01:13:25',0.00,'de Leon Molina Marvin Estuardo',0,NULL,NULL),(1755,'315',NULL,'julio','2025-07-12',25.00,NULL,'2026-05-04 01:13:25',0.00,'Perez Orozco Lilian Delfina',0,NULL,NULL),(1756,'316',NULL,'mayo-junio','2025-07-12',50.00,NULL,'2026-05-04 01:13:25',0.00,'Chavalan Jasinto Jose Enrique',0,NULL,NULL),(1757,'317',NULL,'junio','2025-07-12',25.00,NULL,'2026-05-04 01:13:25',0.00,'Lopez Ramirez Nestor Antonio',0,NULL,NULL),(1758,'318',NULL,'junio','2025-07-12',25.00,NULL,'2026-05-04 01:13:25',0.00,'Sales Garcia Kervin Ventura',0,NULL,NULL),(1759,'319',NULL,'junio-julio','2025-07-12',50.00,NULL,'2026-05-04 01:13:25',0.00,'Jimenez Gomez Byron Jeremias',0,NULL,NULL),(1760,'320',NULL,'mayo-junio','2025-07-12',50.00,NULL,'2026-05-04 01:13:25',0.00,'Baltazar Vasqauez Sebastian Anibal',0,NULL,NULL),(1761,'321',NULL,'junio','2025-07-12',25.00,NULL,'2026-05-04 01:13:25',0.00,'Mendez Vasquez Sheily Maritza',0,NULL,NULL),(1762,'322',NULL,'julio','2025-07-12',25.00,NULL,'2026-05-04 01:13:25',0.00,'Garcia Porrez Marilin Selyna',0,NULL,NULL),(1763,'323',NULL,'junio','2025-07-12',25.00,NULL,'2026-05-04 01:13:25',0.00,'Cabrera Alonzo Emelin Azucena',0,NULL,NULL),(1764,'324',NULL,'junio','2025-07-12',25.00,NULL,'2026-05-04 01:13:25',0.00,'Garcia Mendez Marelin Yoseni',0,NULL,NULL),(1765,'325',NULL,'julio','2025-07-12',25.00,NULL,'2026-05-04 01:13:25',0.00,'Lopez Garcia Eduardo Alberto',0,NULL,NULL),(1766,'326',NULL,'junio-julio','2025-07-12',50.00,NULL,'2026-05-04 01:13:25',0.00,'Sales Perez Brandi Yovani',0,NULL,NULL),(1767,'327',NULL,'julio','2025-07-12',25.00,NULL,'2026-05-04 01:13:25',0.00,'Perez Perez Ines',0,NULL,NULL),(1768,'328',NULL,'agosto','2025-07-19',25.00,NULL,'2026-05-04 01:13:25',0.00,'Garcia Romero Ivana Jassmin',0,NULL,NULL),(1769,'329',NULL,'junio','2025-07-19',25.00,NULL,'2026-05-04 01:13:25',0.00,'Cuyuch Domiguez Sergio Ottoniel',0,NULL,NULL),(1770,'330',NULL,'junio-julio','2025-07-19',50.00,NULL,'2026-05-04 01:13:25',0.00,'Garcia Perez Jorge Danilo',0,NULL,NULL),(1771,'331',NULL,'julio','2025-07-19',25.00,NULL,'2026-05-04 01:13:25',0.00,'Juarez de Leon Miguel de Jesus',0,NULL,NULL),(1772,'332',NULL,'julio','2025-07-19',25.00,NULL,'2026-05-04 01:13:25',0.00,'De Paz Fuentes Angel Ferreyn',0,NULL,NULL),(1773,'333',NULL,'junio-julio','2025-07-19',50.00,NULL,'2026-05-04 01:13:25',0.00,'Estrada del Toro Diego Alejandro',0,NULL,NULL),(1774,'334',NULL,'julio','2025-07-19',25.00,NULL,'2026-05-04 01:13:25',0.00,'De Leon Gomez Cecilia',0,NULL,NULL),(1775,'335',NULL,'mayo-junio-julio-agosto-septiembre-octubre-noviembre','2025-07-19',175.00,NULL,'2026-05-04 01:13:25',0.00,'Vasquez Paxtor Juan Miguel',0,NULL,NULL),(1776,'336',NULL,'junio','2025-07-20',25.00,NULL,'2026-05-04 01:13:25',0.00,'Contreras Lopez Sergio Alexander',0,NULL,NULL),(1777,'337',NULL,'junio','2025-07-20',25.00,NULL,'2026-05-04 01:13:25',0.00,'Contreras Lopez Rosa Leticia',0,NULL,NULL),(1778,'338',NULL,'julio','2025-07-20',25.00,NULL,'2026-05-04 01:13:25',0.00,'Alonzo Lopez Francis Noe Misael',0,NULL,NULL),(1779,'339',NULL,'julio','2025-07-20',25.00,NULL,'2026-05-04 01:13:25',0.00,'Castillo Coy Emilia Elizabeth',0,NULL,NULL),(1780,'340',NULL,'julio','2025-07-20',25.00,NULL,'2026-05-04 01:13:25',0.00,'Castillo Coy Evelyn Marleny',0,NULL,NULL),(1781,'341',NULL,'julio','2025-07-20',25.00,NULL,'2026-05-04 01:13:25',0.00,'Cuyuch Ordoñez Estefani Yoana',0,NULL,NULL),(1782,'342',NULL,'julio','2025-07-26',25.00,NULL,'2026-05-04 01:13:25',0.00,'Chavalan Jasinto Jose Enrique',0,NULL,NULL),(1783,'343',NULL,'julio','2025-07-26',25.00,NULL,'2026-05-04 01:13:25',0.00,'Cabrera Lopez Brayan Yobani',0,NULL,NULL),(1784,'344',NULL,'julio','2025-07-26',25.00,NULL,'2026-05-04 01:13:25',0.00,'Cabrera Alonzo Emelin Azucena',0,NULL,NULL),(1785,'345',NULL,'junio','2025-07-26',25.00,NULL,'2026-05-04 01:13:25',0.00,'Cruz Vicente Jimena Dayana',0,NULL,NULL),(1786,'346',NULL,'julio','2025-07-26',25.00,NULL,'2026-05-04 01:13:25',0.00,'Garcia Perez Nancy Marisol',0,NULL,NULL),(1787,'347',NULL,'julio','2025-07-26',25.00,NULL,'2026-05-04 01:13:25',0.00,'Garcia Mendez Marelin Yoseni',0,NULL,NULL),(1788,'348',NULL,'agosto','2025-07-26',25.00,NULL,'2026-05-04 01:13:25',0.00,'Garcia Porrez Marilin Selyna',0,NULL,NULL),(1789,'349',NULL,'agosto','2025-07-26',25.00,NULL,'2026-05-04 01:13:25',0.00,'Lopez Garcia Eduardo Alberto',0,NULL,NULL),(1790,'350',NULL,'agosto','2025-07-26',25.00,NULL,'2026-05-04 01:13:25',0.00,'Guzman Gomez Walfred Antonio',0,NULL,NULL),(1791,'351',NULL,'junio-julio','2025-07-26',50.00,NULL,'2026-05-04 01:13:25',0.00,'Rojop Dominguez Juan Miguel',0,NULL,NULL),(1792,'352',NULL,'julio','2025-07-26',25.00,NULL,'2026-05-04 01:13:25',0.00,'Lopez Lopez Angel Abraham',0,NULL,NULL),(1793,'353',NULL,'junio','2025-07-26',25.00,NULL,'2026-05-04 01:13:25',0.00,'Ramirez Perez Delsy Liliana',0,NULL,NULL),(1794,'354',NULL,'julio','2025-07-26',25.00,NULL,'2026-05-04 01:13:25',0.00,'Molina Vasquez Lesly Yasmin',0,NULL,NULL),(1795,'355',NULL,'julio','2025-08-02',25.00,NULL,'2026-05-04 01:13:25',0.00,'Vasquez Perez Wilson Daniel',0,NULL,NULL),(1796,'356',NULL,'agosto','2025-08-02',25.00,NULL,'2026-05-04 01:13:25',0.00,'Hernandez Cabrera Hazel Daniela',0,NULL,NULL),(1797,'357',NULL,'junio-julio','2025-08-02',50.00,NULL,'2026-05-04 01:13:25',0.00,'Cigarroa Barrios Angel David',0,NULL,NULL),(1798,'358',NULL,'julio','2025-08-02',25.00,NULL,'2026-05-04 01:13:25',0.00,'Perez Perez Milton Aron',0,NULL,NULL),(1799,'359',NULL,'julio','2025-08-02',25.00,NULL,'2026-05-04 01:13:25',0.00,'Shlaj Lucas Eduardo Apolinario',0,NULL,NULL),(1800,'360',NULL,'agosto','2025-08-02',25.00,NULL,'2026-05-04 01:13:25',0.00,'Garcia Perez Jorge Danilo',0,NULL,NULL),(1801,'361',NULL,'agosto','2025-08-02',25.00,NULL,'2026-05-04 01:13:25',0.00,'Juarez de Leon Miguel de Jesus',0,NULL,NULL),(1802,'362',NULL,'septiembre-octubre','2025-08-02',50.00,NULL,'2026-05-04 01:13:25',0.00,'Molina Perez Diana Aurora',0,NULL,NULL),(1803,'363',NULL,'julio','2025-08-02',25.00,NULL,'2026-05-04 01:13:25',0.00,'Juarez Lucas Alison Alondra',0,NULL,NULL),(1804,'364',NULL,'julio','2025-08-09',25.00,NULL,'2026-05-04 01:13:25',0.00,'Sales Garcia Kervin Ventura',0,NULL,NULL),(1805,'365',NULL,'agosto','2025-08-09',25.00,NULL,'2026-05-04 01:13:25',0.00,'Cuyuch Ordoñez Estefani Yoana',0,NULL,NULL),(1806,'366',NULL,'julio','2025-08-09',25.00,NULL,'2026-05-04 01:13:25',0.00,'Lopez Ramirez Nestor Antonio',0,NULL,NULL),(1807,'367',NULL,'agosto','2025-08-09',25.00,NULL,'2026-05-04 01:13:25',0.00,'Jimenez Gomez Byron Jeremias',0,NULL,NULL),(1808,'368',NULL,'agosto','2025-08-09',25.00,NULL,'2026-05-04 01:13:25',0.00,'Chavalan Jasinto Jose Enrique',0,NULL,NULL),(1809,'369',NULL,'agosto','2025-08-09',25.00,NULL,'2026-05-04 01:13:25',0.00,'Perez Orozco Lilian Delfina',0,NULL,NULL),(1810,'370',NULL,'agosto','2025-08-09',25.00,NULL,'2026-05-04 01:13:25',0.00,'Giron Mendez Jean Carlos',0,NULL,NULL),(1811,'371',NULL,'julio-agosto','2025-08-09',50.00,NULL,'2026-05-04 01:13:25',0.00,'Gonzalez Maldonado Jorge Daniel',0,NULL,NULL),(1812,'372',NULL,'agosto','2025-08-09',25.00,NULL,'2026-05-04 01:13:25',0.00,'Perez Perez Ines',0,NULL,NULL),(1813,'373',NULL,'septiembre','2025-08-09',25.00,NULL,'2026-05-04 01:13:25',0.00,'Lopez Garcia Eduardo Alberto',0,NULL,NULL),(1814,'374',NULL,'julio','2025-08-10',25.00,NULL,'2026-05-04 01:13:25',0.00,'Mendez Vasquez Sheily Maritza',0,NULL,NULL),(1815,'375',NULL,'julio','2025-08-10',25.00,NULL,'2026-05-04 01:13:25',0.00,'Ramirez Perez Delsy Liliana',0,NULL,NULL),(1816,'376',NULL,'agosto','2025-08-10',25.00,NULL,'2026-05-04 01:13:25',0.00,'Garcia Mendez Marelin Yoseni',0,NULL,NULL),(1817,'377',NULL,'julio','2025-08-10',25.00,NULL,'2026-05-04 01:13:25',0.00,'Cabrera Hernandez Mileidi Estrellita',0,NULL,NULL),(1818,'378',NULL,'junio-julio','2025-08-10',50.00,NULL,'2026-05-04 01:13:25',0.00,'Vicente Perez Neftali Odiel',0,NULL,NULL),(1819,'379',NULL,'agosto','2025-08-10',25.00,NULL,'2026-05-04 01:13:25',0.00,'Gomez Maria Ines',0,NULL,NULL),(1820,'380',NULL,'agosto-septiembre','2025-08-10',50.00,NULL,'2026-05-04 01:13:25',0.00,'Jimenez Perez Antonio Isai',0,NULL,NULL),(1821,'381',NULL,'julio','2025-08-10',25.00,NULL,'2026-05-04 01:13:25',0.00,'Contreras Lopez Rosa Leticia',0,NULL,NULL),(1822,'382',NULL,'julio','2025-08-10',25.00,NULL,'2026-05-04 01:13:25',0.00,'Contreras Lopez Sergio Alexander',0,NULL,NULL),(1823,'383',NULL,'agosto','2025-08-10',25.00,NULL,'2026-05-04 01:13:25',0.00,'Castillo Coy Emilia Elizabeth',0,NULL,NULL),(1824,'384',NULL,'agosto','2025-08-10',25.00,NULL,'2026-05-04 01:13:25',0.00,'Castillo Coy Evelyn Marleny',0,NULL,NULL),(1825,'385',NULL,'julio-agosto-septiembre-octubre','2025-08-16',100.00,NULL,'2026-05-04 01:13:25',0.00,'Molina Lucas Guillermo',0,NULL,NULL),(1826,'386',NULL,'agosto','2025-08-16',25.00,NULL,'2026-05-04 01:13:25',0.00,'De Paz Fuentes Angel Ferreyn',0,NULL,NULL),(1827,'387',NULL,'agosto','2025-08-16',25.00,NULL,'2026-05-04 01:13:25',0.00,'Cigarroa Barrios Angel David',0,NULL,NULL),(1828,'388',NULL,'agosto','2025-08-17',25.00,NULL,'2026-05-04 01:13:25',0.00,'Vicente Perez Neftali Odiel',0,NULL,NULL),(1829,'389',NULL,'julio','2025-08-17',25.00,NULL,'2026-05-04 01:13:25',0.00,'Castillo Ovalle Jade Maria',0,NULL,NULL),(1830,'390',NULL,'agosto','2025-08-17',25.00,NULL,'2026-05-04 01:13:25',0.00,'Shlaj Lucas Eduardo Apolinario',0,NULL,NULL),(1831,'391',NULL,'julio-agosto','2025-08-23',50.00,NULL,'2026-05-04 01:13:25',0.00,'Velasquez Meza Katerin Elizani',0,NULL,NULL),(1832,'392',NULL,'septiembre','2025-08-23',25.00,NULL,'2026-05-04 01:13:25',0.00,'Perez Perez Ines',0,NULL,NULL),(1833,'393',NULL,'agosto','2025-08-23',25.00,NULL,'2026-05-04 01:13:25',0.00,'Lopez Lopez Angel Abraham',0,NULL,NULL),(1834,'394',NULL,'agosto','2025-08-23',25.00,NULL,'2026-05-04 01:13:25',0.00,'Ramirez Perez Delsy Liliana',0,NULL,NULL),(1835,'395',NULL,'septeimbre','2025-08-23',25.00,NULL,'2026-05-04 01:13:25',0.00,'Garcia Porrez Marilin Selyna',0,NULL,NULL),(1836,'396',NULL,'septiembre','2025-08-23',25.00,NULL,'2026-05-04 01:13:25',0.00,'Guzman Gomez Walfred Antonio',0,NULL,NULL),(1837,'397',NULL,'agosto','2025-08-23',25.00,NULL,'2026-05-04 01:13:25',0.00,'Garcia Perez Nancy Marisol',0,NULL,NULL),(1838,'398',NULL,'agosto','2025-08-30',25.00,NULL,'2026-05-04 01:13:25',0.00,'Perez Perez Milton Aron',0,NULL,NULL),(1839,'399',NULL,'septiembre','2025-08-30',25.00,NULL,'2026-05-04 01:13:25',0.00,'Hernandez Cabrera Hazel Daniela',0,NULL,NULL),(1840,'400',NULL,'agosto','2025-08-30',25.00,NULL,'2026-05-04 01:13:25',0.00,'Vasquez Perez Wilson Daniel',0,NULL,NULL),(1841,'401',NULL,'septiembre','2025-08-30',25.00,NULL,'2026-05-04 01:13:25',0.00,'Garcia Perez Jorge Danilo',0,NULL,NULL),(1842,'402',NULL,'septiembre','2025-08-30',25.00,NULL,'2026-05-04 01:13:25',0.00,'Juarez de Leon Miguel de Jesus',0,NULL,NULL),(1843,'403',NULL,'mayo-junio','2025-08-30',50.00,NULL,'2026-05-04 01:13:25',0.00,'Lara Tiu Natalia Lucita',0,NULL,NULL),(1844,'404',NULL,'julio','2025-08-30',25.00,NULL,'2026-05-04 01:13:25',0.00,'Cuyuch Domiguez Sergio Ottoniel',0,NULL,NULL),(1845,'405',NULL,'septiembre','2025-08-31',25.00,NULL,'2026-05-04 01:13:25',0.00,'Castillo Coy Evelyn Marleny',0,NULL,NULL),(1846,'406',NULL,'septiembre','2025-08-31',25.00,NULL,'2026-05-04 01:13:25',0.00,'Castillo Coy Emilia Elizabeth',0,NULL,NULL),(1847,'407',NULL,'agosto','2025-09-06',25.00,NULL,'2026-05-04 01:13:25',0.00,'Lopez Ramirez Nestor Antonio',0,NULL,NULL),(1848,'408',NULL,'agosto','2025-09-06',25.00,NULL,'2026-05-04 01:13:25',0.00,'Cabrera Lopez Brayan Yobani',0,NULL,NULL),(1849,'409',NULL,'agosto','2025-09-06',25.00,NULL,'2026-05-04 01:13:25',0.00,'Sales Garcia Kervin Ventura',0,NULL,NULL),(1850,'410',NULL,'junio','2025-09-06',25.00,NULL,'2026-05-04 01:13:25',0.00,'Ochoa Cabrera Gerli Yurandi',0,NULL,NULL),(1851,'411',NULL,'septiembre','2025-09-06',25.00,NULL,'2026-05-04 01:13:25',0.00,'Velasquez Meza Katerin Elizani',0,NULL,NULL),(1852,'412',NULL,'septiembre','2025-09-06',25.00,NULL,'2026-05-04 01:13:25',0.00,'Jimenez Gomez Byron Jeremias',0,NULL,NULL),(1853,'413',NULL,'noviembre','2025-09-06',25.00,NULL,'2026-05-04 01:13:25',0.00,'Molina Perez Diana Aurora',0,NULL,NULL),(1854,'414',NULL,'septiembre','2025-09-06',25.00,NULL,'2026-05-04 01:13:25',0.00,'Chavalan Jasinto Jose Enrique',0,NULL,NULL),(1855,'415',NULL,'septiembre','2025-09-06',25.00,NULL,'2026-05-04 01:13:25',0.00,'Ramirez Perez Delsy Liliana',0,NULL,NULL),(1856,'416',NULL,'agosto','2025-09-06',25.00,NULL,'2026-05-04 01:13:25',0.00,'Cabrera Alonzo Emelin Azucena',0,NULL,NULL),(1857,'417',NULL,'septiembre','2025-09-06',25.00,NULL,'2026-05-04 01:13:25',0.00,'Giron Mendez Jean Carlos',0,NULL,NULL),(1858,'418',NULL,'agosto-septiembre','2025-09-06',50.00,NULL,'2026-05-04 01:13:25',0.00,'Vasquez Perez Adriana Marisol',0,NULL,NULL),(1859,'419',NULL,'septiembre','2025-09-06',25.00,NULL,'2026-05-04 01:13:25',0.00,'Gonzalez Maldonado Jorge Daniel',0,NULL,NULL),(1860,'420',NULL,'agosto-septiembre','2025-09-06',50.00,NULL,'2026-05-04 01:13:25',0.00,'Rojop Dominguez Juan Miguel',0,NULL,NULL),(1861,'421',NULL,'septiembre','2025-09-06',25.00,NULL,'2026-05-04 01:13:25',0.00,'Garcia Mendez Marelin Yoseni',0,NULL,NULL),(1862,'422',NULL,'agosto','2025-09-07',25.00,NULL,'2026-05-04 01:13:25',0.00,'Juarez Lucas Alison Alondra',0,NULL,NULL),(1863,'423',NULL,'agosto','2025-09-07',25.00,NULL,'2026-05-04 01:13:25',0.00,'Contreras Lopez Sergio Alexander',0,NULL,NULL),(1864,'424',NULL,'septiembre','2025-09-07',25.00,NULL,'2026-05-04 01:13:25',0.00,'Gomez Maria Ines',0,NULL,NULL),(1865,'425',NULL,'agosto','2025-09-07',25.00,NULL,'2026-05-04 01:13:25',0.00,'Contreras Lopez Rosa Leticia',0,NULL,NULL),(1866,'426',NULL,'agosto-septiembre','2025-09-07',50.00,NULL,'2026-05-04 01:13:25',0.00,'Cabrera Hernandez Mileidi Estrellita',0,NULL,NULL),(1867,'427',NULL,'agosto','2025-09-20',25.00,NULL,'2026-05-04 01:13:25',0.00,'Mendez Vasquez Sheily Maritza',0,NULL,NULL),(1868,'428',NULL,'octubre','2025-09-20',25.00,NULL,'2026-05-04 01:13:25',0.00,'Perez Perez Ines',0,NULL,NULL),(1869,'429',NULL,'octubre - noviembre','2025-09-20',50.00,NULL,'2026-05-04 01:13:25',0.00,'Giron Mendez Jean Carlos',0,NULL,NULL),(1870,'430',NULL,'agosto-septiembre','2025-09-20',50.00,NULL,'2026-05-04 01:13:25',0.00,'Molina Vasquez Lesly Yasmin',0,NULL,NULL),(1871,'431',NULL,'Septiembre','2025-09-20',25.00,NULL,'2026-05-04 01:13:25',0.00,'Garcia Perez Nancy Marisol',0,NULL,NULL),(1872,'432',NULL,'agosto-septiembre','2025-09-20',50.00,NULL,'2026-05-04 01:13:25',0.00,'Sales Perez Brandi Yovani',0,NULL,NULL),(1873,'433',NULL,'junio','2025-09-20',25.00,NULL,'2026-05-04 01:13:25',0.00,'Vicente Diaz Nataly Celeste',0,NULL,NULL),(1874,'434',NULL,'octubre- noviembre','2025-09-25',50.00,NULL,'2026-05-04 01:13:25',0.00,'Garcia Porrez Marilin Selyna',0,NULL,NULL),(1875,'435',NULL,'octubre','2025-09-25',25.00,NULL,'2026-05-04 01:13:25',0.00,'Ramirez Perez Delsy Liliana',0,NULL,NULL),(1876,'436',NULL,'septiembre - octubre','2025-09-25',50.00,NULL,'2026-05-04 01:13:25',0.00,'Cuyuch Ordoñez Estefani Yoana',0,NULL,NULL),(1877,'437',NULL,'septiembre','2025-09-25',25.00,NULL,'2026-05-04 01:13:25',0.00,'Sales Garcia Kervin Ventura',0,NULL,NULL),(1878,'438',NULL,'septiembre- octubre - noviembre','2025-09-25',75.00,NULL,'2026-05-04 01:13:25',0.00,'Cabrera Alonzo Emelin Azucena',0,NULL,NULL),(1879,'439',NULL,'octubre - noviembre','2025-09-25',50.00,NULL,'2026-05-04 01:13:25',0.00,'Velasquez Meza Katerin Elizani',0,NULL,NULL),(1880,'440',NULL,'octubre- noviembre','2025-09-25',50.00,NULL,'2026-05-04 01:13:25',0.00,'Gonzalez Maldonado Jorge Daniel',0,NULL,NULL),(1881,'441',NULL,'octubre - noviembre','2025-09-25',50.00,NULL,'2026-05-04 01:13:25',0.00,'Chavalan Jasinto Jose Enrique',0,NULL,NULL),(1882,'442',NULL,'septiembre - octubre -noviembre','2025-09-25',75.00,NULL,'2026-05-04 01:13:25',0.00,'Lara Lopez Gerson Elias',0,NULL,NULL),(1883,'443',NULL,'junio -julio- agosto -septiembre','2025-09-26',100.00,NULL,'2026-05-04 01:13:25',0.00,'Suchite Cabrera Cristian Wilfredo',0,NULL,NULL),(1884,'444',NULL,'julio -agosto -septiembre','2025-09-26',75.00,NULL,'2026-05-04 01:13:25',0.00,'Vicente Diaz Nataly Celeste',0,NULL,NULL),(1885,'445',NULL,'septiembre - octubre -noviembre','2025-09-26',75.00,NULL,'2026-05-04 01:13:25',0.00,'Perez Perez Milton Aron',0,NULL,NULL),(1886,'446',NULL,'agosto -septiembre','2025-09-26',50.00,NULL,'2026-05-04 01:13:25',0.00,'Castillo Ovalle Jade Maria',0,NULL,NULL),(1887,'447',NULL,'agosto','2025-09-27',25.00,NULL,'2026-05-04 01:13:25',0.00,'Cuyuch Domiguez Sergio Ottoniel',0,NULL,NULL),(1888,'448',NULL,'septiembre','2025-09-27',25.00,NULL,'2026-05-04 01:13:25',0.00,'Garcia Romero Ivana Jassmin',0,NULL,NULL),(1889,'449',NULL,'septiembre','2025-09-27',25.00,NULL,'2026-05-04 01:13:25',0.00,'Vasquez Perez Wilson Daniel',0,NULL,NULL),(1890,'450',NULL,'septiembre','2025-09-27',25.00,NULL,'2026-05-04 01:13:25',0.00,'De Paz Fuentes Angel Ferreyn',0,NULL,NULL),(1891,'451',NULL,'septiembre','2025-09-27',25.00,NULL,'2026-05-04 01:13:25',0.00,'Cigarroa Barrios Angel David',0,NULL,NULL),(1892,'452',NULL,'septiembre','2025-09-27',25.00,NULL,'2026-05-04 01:13:25',0.00,'Juarez Lucas Alison Alondra',0,NULL,NULL),(1893,'453',NULL,'septiembre','2025-10-04',25.00,NULL,'2026-05-04 01:13:25',0.00,'Cabrera Lopez Brayan Yobani',0,NULL,NULL),(1894,'454',NULL,'julio- agosto -septiembre','2025-10-04',75.00,NULL,'2026-05-04 01:13:25',0.00,'Ochoa Cabrera Gerli Yurandi',0,NULL,NULL),(1895,'455',NULL,'septiembre - octubre','2025-10-04',50.00,NULL,'2026-05-04 01:13:25',0.00,'Perez Orozco Lilian Delfina',0,NULL,NULL),(1896,'456',NULL,'septiembre','2025-10-04',25.00,NULL,'2026-05-04 01:13:25',0.00,'Lopez Ramirez Nestor Antonio',0,NULL,NULL),(1897,'457',NULL,'octubre','2025-10-04',25.00,NULL,'2026-05-04 01:13:25',0.00,'Jimenez Gomez Byron Jeremias',0,NULL,NULL),(1898,'458',NULL,'octubre','2025-10-04',25.00,NULL,'2026-05-04 01:13:25',0.00,'Guzman Gomez Walfred Antonio',0,NULL,NULL),(1899,'459',NULL,'septiembre','2025-10-04',25.00,NULL,'2026-05-04 01:13:25',0.00,'Lopez Lopez Angel Abraham',0,NULL,NULL),(1900,'460',NULL,'julio','2025-10-04',25.00,NULL,'2026-05-04 01:13:25',0.00,'Cruz Vicente Jimena Dayana',0,NULL,NULL),(1901,'461',NULL,'octubre','2025-10-04',25.00,NULL,'2026-05-04 01:13:25',0.00,'Garcia Mendez Marelin Yoseni',0,NULL,NULL),(1902,'462',NULL,'septiembre','2025-10-04',25.00,NULL,'2026-05-04 01:13:25',0.00,'Mendez Vasquez Sheily Maritza',0,NULL,NULL),(1903,'463',NULL,'anulado','2025-10-04',0.00,NULL,'2026-05-04 01:13:25',0.00,'anulado',0,NULL,NULL),(1904,'464',NULL,'octubre - noviembre','2025-10-05',50.00,NULL,'2026-05-04 01:13:25',0.00,'Jimenez Perez Antonio Isai',0,NULL,NULL),(1905,'465',NULL,'septiembre','2025-10-05',25.00,NULL,'2026-05-04 01:13:25',0.00,'Contreras Lopez Sergio Alexander',0,NULL,NULL),(1906,'466',NULL,'septiembre','2025-10-05',25.00,NULL,'2026-05-04 01:13:25',0.00,'Contreras Lopez Rosa Leticia',0,NULL,NULL),(1907,'467',NULL,'octubre','2025-10-09',25.00,NULL,'2026-05-04 01:13:25',0.00,'Garcia Romero Ivana Jassmin',0,NULL,NULL),(1908,'468',NULL,'septiembre octubre','2025-10-09',50.00,NULL,'2026-05-04 01:13:25',0.00,'Cabrera Giron Doris Aimar',0,NULL,NULL),(1909,'469',NULL,'octubre','2025-10-09',25.00,NULL,'2026-05-04 01:13:25',0.00,'De Paz Fuentes Angel Ferreyn',0,NULL,NULL),(1910,'470',NULL,'septiembre - octubre','2025-10-09',50.00,NULL,'2026-05-04 01:13:25',0.00,'Chavez Lorenzo Yeimi Josefina',0,NULL,NULL),(1911,'471',NULL,'noviembre','2025-10-09',25.00,NULL,'2026-05-04 01:13:25',0.00,'Chavez Lorenzo Yeimi Josefina',0,NULL,NULL),(1912,'472',NULL,'septiembre octubre','2025-10-09',50.00,NULL,'2026-05-04 01:13:25',0.00,'Shlaj Lucas Eduardo Apolinario',0,NULL,NULL),(1913,'473',NULL,'octubre','2025-10-09',25.00,NULL,'2026-05-04 01:13:25',0.00,'Juarez Lucas Alison Alondra',0,NULL,NULL),(1914,'474',NULL,'octubre','2025-10-09',25.00,NULL,'2026-05-04 01:13:25',0.00,'Hernandez Cabrera Hazel Daniela',0,NULL,NULL),(1915,'475',NULL,'octubre','2025-10-09',25.00,NULL,'2026-05-04 01:13:26',0.00,'Cigarroa Barrios Angel David',0,NULL,NULL),(1916,'476',NULL,'octubre','2025-10-09',25.00,NULL,'2026-05-04 01:13:26',0.00,'Vicente Diaz Nataly Celeste',0,NULL,NULL),(1917,'477',NULL,'anulado','2025-10-09',0.00,NULL,'2026-05-04 01:13:26',0.00,'anulado',0,NULL,NULL),(1918,'478',NULL,'septiembre - octubre','2025-10-09',50.00,NULL,'2026-05-04 01:13:26',0.00,'de Leon Molina Marvin Estuardo',0,NULL,NULL),(1919,'479',NULL,'octubre','2025-10-09',25.00,NULL,'2026-05-04 01:13:26',0.00,'Suchite Cabrera Cristian Wilfredo',0,NULL,NULL),(1920,'480',NULL,'julio- agosto -septiembre - octubre','2025-10-09',100.00,NULL,'2026-05-04 01:13:26',0.00,'Lara Tiu Natalia Lucita',0,NULL,NULL),(1921,'481',NULL,'Septiembre - octubre','2025-10-09',50.00,NULL,'2026-05-04 01:13:26',0.00,'Cuyuch Domiguez Sergio Ottoniel',0,NULL,NULL),(1922,'482',NULL,'agosto-septiembre - octubre','2025-10-09',75.00,NULL,'2026-05-04 01:13:26',0.00,'Estrada del Toro Diego Alejandro',0,NULL,NULL),(1923,'483',NULL,'octubre','2025-10-09',25.00,NULL,'2026-05-04 01:13:26',0.00,'Garcia Perez Jorge Danilo',0,NULL,NULL),(1924,'484',NULL,'julio-agosto-septiembre-octubre','2025-10-11',100.00,NULL,'2026-05-04 01:13:26',0.00,'Pablo de Leon Ricardo Alberto',0,NULL,NULL),(1925,'485',NULL,'noviembre','2025-10-11',25.00,NULL,'2026-05-04 01:13:26',0.00,'Cigarroa Barrios Angel David',0,NULL,NULL),(1926,'486',NULL,'agosto-septiembre-octubre','2025-10-11',75.00,NULL,'2026-05-04 01:13:26',0.00,'De Leon Gomez Cecilia',0,NULL,NULL),(1927,'487',NULL,'octubre','2025-10-11',25.00,NULL,'2026-05-04 01:13:26',0.00,'Vasquez Perez Wilson Daniel',0,NULL,NULL),(1928,'488',NULL,'octubre','2025-10-11',25.00,NULL,'2026-05-04 01:13:26',0.00,'Juarez de Leon Miguel de Jesus',0,NULL,NULL),(1929,'489',NULL,'octubre','2025-10-18',25.00,NULL,'2026-05-04 01:13:26',0.00,'Ochoa Cabrera Gerli Yurandi',0,NULL,NULL),(1930,'490',NULL,'octubre','2025-10-18',25.00,NULL,'2026-05-04 01:13:26',0.00,'Molina Vasquez Lesly Yasmin',0,NULL,NULL),(1931,'491',NULL,'octubre','2025-10-18',25.00,NULL,'2026-05-04 01:13:26',0.00,'Rojop Dominguez Juan Miguel',0,NULL,NULL),(1932,'492',NULL,'agosto- Septiembre- octubre - noviembre','2025-10-18',100.00,NULL,'2026-05-04 01:13:26',0.00,'Cruz Vicente Jimena Dayana',0,NULL,NULL),(1933,'493',NULL,'noviembre','2025-10-18',25.00,NULL,'2026-05-04 01:13:26',0.00,'Perez Perez Ines',0,NULL,NULL),(1934,'494',NULL,'octubre - noviembre','2025-10-18',50.00,NULL,'2026-05-04 01:13:26',0.00,'Vasquez Perez adriana Marisol',0,NULL,NULL),(1935,'495',NULL,'agosto -septiembre -octubre - noviembre','2025-10-19',100.00,NULL,'2026-05-04 01:13:26',0.00,'Alonzo Lopez Francis Noe Misael',0,NULL,NULL),(1936,'496',NULL,'octubre','2025-10-19',25.00,NULL,'2026-05-04 01:13:26',0.00,'Castillo Coy Emilia Elizabeth',0,NULL,NULL),(1937,'497',NULL,'octubre','2025-10-19',25.00,NULL,'2026-05-04 01:13:26',0.00,'Castillo Coy Evelyn Marleny',0,NULL,NULL),(1938,'498',NULL,'noviembre','2025-10-25',25.00,NULL,'2026-05-04 01:13:26',0.00,'Hernandez Cabrera Hazel Daniela',0,NULL,NULL),(1939,'499',NULL,'noviembre','2025-10-25',25.00,NULL,'2026-05-04 01:13:26',0.00,'Estrada del Toro Diego Alejandro',0,NULL,NULL),(1940,'500',NULL,'anulado','2025-10-25',0.00,NULL,'2026-05-04 01:13:26',0.00,'anulado',0,NULL,NULL),(1941,'501',NULL,'septiembre - octubre -noviembre','2025-10-26',75.00,NULL,'2026-05-04 01:13:26',0.00,'Vicente Perez Neftali Odiel',0,NULL,NULL),(1942,'502',NULL,'octubre - noviembre','2025-10-26',50.00,NULL,'2026-05-04 01:13:26',0.00,'Cabrera Hernandez Mileidi Estrellita',0,NULL,NULL),(1943,'503',NULL,'octubre - noviembre','2025-10-26',50.00,NULL,'2026-05-04 01:13:26',0.00,'Gomez Maria Ines',0,NULL,NULL),(1944,'504',NULL,'octubre- noviembre','2025-11-07',50.00,NULL,'2026-05-04 01:13:26',0.00,'Lopez Garcia Eduardo Alberto',0,NULL,NULL),(1945,'505',NULL,'octubre-noviembre','2025-11-07',50.00,NULL,'2026-05-04 01:13:26',0.00,'Garcia Perez Nancy Marisol',0,NULL,NULL),(1946,'506',NULL,'noviembre','2025-11-07',25.00,NULL,'2026-05-04 01:13:26',0.00,'Rojop Dominguez Juan Miguel',0,NULL,NULL),(1947,'507',NULL,'noviembre','2025-11-07',25.00,NULL,'2026-05-04 01:13:26',0.00,'Guzman Gomez Walfred Antonio',0,NULL,NULL),(1948,'508',NULL,'noviembre','2025-11-07',25.00,NULL,'2026-05-04 01:13:26',0.00,'Jimenez Gomez Byron Jeremias',0,NULL,NULL),(1949,'509',NULL,'octubre-noviembre','2025-11-07',50.00,NULL,'2026-05-04 01:13:26',0.00,'Sales Perez Brandi Yovani',0,NULL,NULL),(1950,'510',NULL,'octubre-noviembre','2025-11-07',50.00,NULL,'2026-05-04 01:13:26',0.00,'Sales Garcia Kervin Ventura',0,NULL,NULL),(1951,'511',NULL,'octubre-noviembre','2025-11-07',50.00,NULL,'2026-05-04 01:13:26',0.00,'Mendez Vasquez Sheily Maritza',0,NULL,NULL),(1952,'512',NULL,'noviembre','2025-11-07',25.00,NULL,'2026-05-04 01:13:26',0.00,'Molina Vasquez Lesly Yasmin',0,NULL,NULL),(1953,'513',NULL,'noviembre','2025-11-07',25.00,NULL,'2026-05-04 01:13:26',0.00,'Garcia Mendez Marelin Yoseni',0,NULL,NULL),(1954,'514',NULL,'octubre-noviembre','2025-11-07',50.00,NULL,'2026-05-04 01:13:26',0.00,'Lopez Lopez Angel Abraham',0,NULL,NULL),(1955,'515',NULL,'noviembre','2025-11-07',25.00,NULL,'2026-05-04 01:13:26',0.00,'Ramirez Perez Delsy Liliana',0,NULL,NULL),(1956,'516',NULL,'noviembre','2025-11-08',25.00,NULL,'2026-05-04 01:13:26',0.00,'Garcia Romero Ivana Jassmin',0,NULL,NULL),(1957,'517',NULL,'noviembre','2025-11-08',25.00,NULL,'2026-05-04 01:13:26',0.00,'Juarez Lucas Alison Alondra',0,NULL,NULL),(1958,'518',NULL,'noviembre','2025-11-08',25.00,NULL,'2026-05-04 01:13:26',0.00,'Shlaj Lucas Eduardo Apolinario',0,NULL,NULL),(1959,'519',NULL,'octubre-noviembre','2025-11-08',50.00,NULL,'2026-05-04 01:13:26',0.00,'Castillo Ovalle Jade Maria',0,NULL,NULL),(1960,'520',NULL,'noviembre','2025-11-08',25.00,NULL,'2026-05-04 01:13:26',0.00,'Lara Tiu Natalia Lucita',0,NULL,NULL),(1961,'521',NULL,'noviembre','2025-11-08',25.00,NULL,'2026-05-04 01:13:26',0.00,'Cuyuch Domiguez Sergio Ottoniel',0,NULL,NULL),(1962,'522',NULL,'noviembre','2025-11-08',25.00,NULL,'2026-05-04 01:13:26',0.00,'Juarez de Leon Miguel de Jesus',0,NULL,NULL),(1963,'523',NULL,'noviembre','2025-11-08',25.00,NULL,'2026-05-04 01:13:26',0.00,'Garcia Perez Jorge Danilo',0,NULL,NULL),(1964,'524',NULL,'noviembre','2025-11-08',25.00,NULL,'2026-05-04 01:13:26',0.00,'Suchite Cabrera Cristian Wilfredo',0,NULL,NULL),(1965,'525',NULL,'noviembre','2025-11-08',25.00,NULL,'2026-05-04 01:13:26',0.00,'De Leon Gomez Cecilia',0,NULL,NULL),(1966,'526',NULL,'noviembre','2025-11-08',25.00,NULL,'2026-05-04 01:13:26',0.00,'Vasquez Perez Wilson Daniel',0,NULL,NULL),(1967,'527',NULL,'noviembre','2025-11-08',25.00,NULL,'2026-05-04 01:13:26',0.00,'De Paz Fuentes Angel Ferreyn',0,NULL,NULL),(1968,'528',NULL,'noviembre','2025-11-08',25.00,NULL,'2026-05-04 01:13:26',0.00,'Molina Lucas Guillermo',0,NULL,NULL),(1969,'529',NULL,'octubre-noviembre','2025-11-09',50.00,NULL,'2026-05-04 01:13:26',0.00,'Contreras Lopez Sergio Alexander',0,NULL,NULL),(1970,'530',NULL,'octubre-noviembre','2025-11-09',50.00,NULL,'2026-05-04 01:13:26',0.00,'Contreras Lopez Rosa Leticia',0,NULL,NULL),(1971,'531',NULL,'noviembre','2025-11-09',25.00,NULL,'2026-05-04 01:13:26',0.00,'Cabrera Giron Doris Aimar',0,NULL,NULL),(1972,'532',NULL,'noviembre','2025-11-09',25.00,NULL,'2026-05-04 01:13:26',0.00,'Vicente Diaz Nataly Celeste',0,NULL,NULL),(1973,'533',NULL,'noviembre','2025-11-09',25.00,NULL,'2026-05-04 01:13:26',0.00,'Pablo de Leon Ricardo Alberto',0,NULL,NULL),(1974,'534',NULL,'noviembre','2025-11-09',25.00,NULL,'2026-05-04 01:13:26',0.00,'Castillo Coy Emilia Elizabeth',0,NULL,NULL),(1975,'535',NULL,'noviembre','2025-11-09',25.00,NULL,'2026-05-04 01:13:26',0.00,'Castillo Coy Evelyn Marleny',0,NULL,NULL),(1976,'536',NULL,'octubre-noviembre','2025-11-15',50.00,NULL,'2026-05-04 01:13:26',0.00,'Lopez Ramirez Nestor Antonio',0,NULL,NULL),(1977,'537',NULL,'noviembre','2025-11-15',25.00,NULL,'2026-05-04 01:13:26',0.00,'de Leon Molina Marvin Estuardo',0,NULL,NULL),(1978,'538',NULL,'octubre-noviembre','2025-11-15',50.00,NULL,'2026-05-04 01:13:26',0.00,'Cabrera Lopez Brayan Yobani',0,NULL,NULL),(1979,'539',NULL,'noviembre','2025-11-15',25.00,NULL,'2026-05-04 01:13:26',0.00,'Ochoa Cabrera Gerli Yurandi',0,NULL,NULL),(1980,'540',NULL,'noviembre','2025-11-15',25.00,NULL,'2026-05-04 01:13:26',0.00,'Perez Orozco Lilian Delfina',0,NULL,NULL),(1981,'541',NULL,'anulado','2025-11-15',0.00,NULL,'2026-05-04 01:13:26',0.00,'anulado',0,NULL,NULL),(1982,'542',NULL,'inscripcion 2026','2026-01-03',100.00,NULL,'2026-05-04 01:13:26',0.00,'Lopez Lucas Blanca Azucena',0,NULL,NULL),(1983,'543',NULL,'inscripcion 2026','2026-01-03',125.00,NULL,'2026-05-04 01:13:26',0.00,'Felipe Gomez Jaquelin Mauricia',0,NULL,NULL),(1984,'544',NULL,'inscripcion 2026','2026-01-04',125.00,NULL,'2026-05-04 01:13:26',0.00,'Macario Vicente Yeimi Roxana',0,NULL,NULL),(1985,'545',NULL,'inscripcion 2026','2026-01-05',100.00,NULL,'2026-05-04 01:13:26',0.00,'Galindo Chavez Julia Amparo',0,NULL,NULL),(1986,'546',NULL,'inscripcion 2026','2026-01-06',30.00,NULL,'2026-05-04 01:13:26',0.00,'Velasquez Cabrera Eliza Lisbeth',0,NULL,NULL),(1987,'547',NULL,'anulado','2026-01-06',0.00,NULL,'2026-05-04 01:13:26',0.00,'anulado',0,NULL,NULL),(1988,'548',NULL,'anulado','2026-01-06',0.00,NULL,'2026-05-04 01:13:26',0.00,'anulado',0,NULL,NULL),(1989,'549',NULL,'anulado','2026-01-06',0.00,NULL,'2026-05-04 01:13:26',0.00,'anulado',0,NULL,NULL),(1990,'550',NULL,'anulado','2026-01-06',0.00,NULL,'2026-05-04 01:13:26',0.00,'anulado',0,NULL,NULL),(1991,'551',NULL,'enero','2026-01-08',60.00,NULL,'2026-05-04 01:13:26',0.00,'Castillo Ovalle Jade Maria',0,NULL,NULL),(1992,'552',NULL,'enero','2026-01-08',60.00,NULL,'2026-05-04 01:13:26',0.00,'Jimenez Gomez Byron Jeremias',0,NULL,NULL),(1993,'553',NULL,'enero','2026-01-08',60.00,NULL,'2026-05-04 01:13:26',0.00,'Contreras Lopez Rosa Leticia',0,NULL,NULL),(1994,'554',NULL,'enero','2026-01-08',60.00,NULL,'2026-05-04 01:13:26',0.00,'Contreras Lopez Sergio Alexander',0,NULL,NULL),(1995,'555',NULL,'enero-febrero','2026-01-08',120.00,NULL,'2026-05-04 01:13:26',0.00,'Perez Perez Ines',0,NULL,NULL),(1996,'556',NULL,'enero','2026-01-08',60.00,NULL,'2026-05-04 01:13:26',0.00,'Guzman Gomez Walfred Antonio',0,NULL,NULL),(1997,'557',NULL,'enero-febrero-marzo','2026-01-08',180.00,NULL,'2026-05-04 01:13:26',0.00,'Cabrera Alonzo Emelin Azucena',0,NULL,NULL),(1998,'558',NULL,'abono 20 al mes de abril','2026-01-08',20.00,NULL,'2026-05-04 01:13:26',0.00,'Cabrera Alonzo Emelin Azucena',0,NULL,NULL),(1999,'559',NULL,'enero-febrero','2026-01-08',120.00,NULL,'2026-05-04 01:13:26',0.00,'Garcia Perez Nancy Marisol',0,NULL,NULL),(2000,'560',NULL,'enero','2026-01-08',60.00,NULL,'2026-05-04 01:13:26',0.00,'Gonzalez Maldonado Jorge Daniel',0,NULL,NULL),(2001,'561',NULL,'enero-febrero','2026-01-08',120.00,NULL,'2026-05-04 01:13:26',0.00,'Lopez Garcia Eduardo Alberto',0,NULL,NULL),(2002,'562',NULL,'inscripcion 2026','2026-01-08',100.00,NULL,'2026-05-04 01:13:26',0.00,'Molina Sofia Yohana',0,NULL,NULL),(2003,'563',NULL,'enero','2026-01-09',60.00,NULL,'2026-05-04 01:13:26',0.00,'Garcia Romero Ivana Jassmin',0,NULL,NULL),(2004,'564',NULL,'inscripcion 2026','2026-01-09',100.00,NULL,'2026-05-04 01:13:26',0.00,'Juarez Lucas Maria',0,NULL,NULL),(2005,'565',NULL,'inscripcion 2026','2026-01-09',100.00,NULL,'2026-05-04 01:13:26',0.00,'Ramirez Lopez Crisbel Maricruz',0,NULL,NULL),(2006,'566',NULL,'enero','2026-01-09',60.00,NULL,'2026-05-04 01:13:26',0.00,'Cigarroa Barrios Angel David',0,NULL,NULL),(2007,'567',NULL,'enero','2026-01-09',60.00,NULL,'2026-05-04 01:13:26',0.00,'Vicente Perez Neftali Odiel',0,NULL,NULL),(2008,'568',NULL,'enero-febrero-marzo-abril-mayo-junio-julio-agosto y abono 20 a septiembre','2026-01-09',500.00,NULL,'2026-05-04 01:13:26',0.00,'Vasquez Paxtor Juan Miguel',0,NULL,NULL),(2009,'569',NULL,'enero-febrero','2026-01-09',120.00,NULL,'2026-05-04 01:13:26',0.00,'Vicente Diaz Nataly Celeste',0,NULL,NULL),(2010,'570',NULL,'enero','2026-01-09',60.00,NULL,'2026-05-04 01:13:26',0.00,'Perez Orozco Lilian Delfina',0,NULL,NULL),(2011,'571',NULL,'completo septiembre - octubre-noviembre','2026-01-09',160.00,NULL,'2026-05-04 01:13:26',0.00,'Vasquez Paxtor Juan Miguel',0,NULL,NULL),(2012,'572',NULL,'enero','2026-01-10',60.00,NULL,'2026-05-04 01:13:26',0.00,'Castillo Coy Emilia Elizabeth',0,NULL,NULL),(2013,'573',NULL,'enero','2026-01-10',60.00,NULL,'2026-05-04 01:13:26',0.00,'Castillo Coy Evelyn Marleny',0,NULL,NULL),(2014,'574',NULL,'inscripcion 2026','2026-01-13',30.00,NULL,'2026-05-04 01:13:26',0.00,'Orozco Rojas Elmer Nehemias',0,NULL,NULL),(2015,'575',NULL,'enero-febrero','2026-01-16',120.00,NULL,'2026-05-04 01:13:26',0.00,'Molina Sofia Yohana',0,NULL,NULL),(2016,'576',NULL,'marzo','2026-01-16',60.00,NULL,'2026-05-04 01:13:26',0.00,'Molina Sofia Yohana',0,NULL,NULL),(2017,'577',NULL,'enero','2026-01-17',60.00,NULL,'2026-05-04 01:13:26',0.00,'Lopez Ramirez Nestor Antonio',0,NULL,NULL),(2018,'578',NULL,'enero','2026-01-17',60.00,NULL,'2026-05-04 01:13:26',0.00,'Mendez Vasquez Sheily Maritza',0,NULL,NULL),(2019,'579',NULL,'enero','2026-01-17',60.00,NULL,'2026-05-04 01:13:26',0.00,'Garcia Mendez Marelin Yoseni',0,NULL,NULL),(2020,'580',NULL,'enero-febrero','2026-01-18',120.00,NULL,'2026-05-04 01:13:26',0.00,'Cabrera Giron Doris Aimar',0,NULL,NULL),(2021,'581',NULL,'inscripcion 2026','2026-01-20',125.00,NULL,'2026-05-04 01:13:26',0.00,'Bonilla Garcia Lea Raquel',0,NULL,NULL),(2022,'582',NULL,'inscripcion 2026','2026-01-22',125.00,NULL,'2026-05-04 01:13:26',0.00,'Garcia Lopez Hernan Alexander',0,NULL,NULL),(2023,'583',NULL,'enero','2026-01-24',60.00,NULL,'2026-05-04 01:13:26',0.00,'Velasquez Meza Katerin Elizani',0,NULL,NULL),(2024,'584',NULL,'enero','2026-01-24',60.00,NULL,'2026-05-04 01:13:26',0.00,'Cabrera Lopez Brayan Yobani',0,NULL,NULL),(2025,'585',NULL,'enero-febrero','2026-01-24',120.00,NULL,'2026-05-04 01:13:26',0.00,'Vasquez Perez adriana Marisol',0,NULL,NULL),(2026,'586',NULL,'enero','2026-01-25',60.00,NULL,'2026-05-04 01:13:26',0.00,'De Leon Gomez Cecilia',0,NULL,NULL),(2027,'587',NULL,'enero','2026-01-30',60.00,NULL,'2026-05-04 01:13:26',0.00,'Juarez Lucas Maria',0,NULL,NULL),(2028,'588',NULL,'enero','2026-01-30',60.00,NULL,'2026-05-04 01:13:26',0.00,'Lopez Lucas Blanca Azucena',0,NULL,NULL),(2029,'589',NULL,'enero','2026-01-30',60.00,NULL,'2026-05-04 01:13:26',0.00,'Velasquez Cabrera Elisa Lisbeth',0,NULL,NULL),(2030,'590',NULL,'enero','2026-01-31',60.00,NULL,'2026-05-04 01:13:26',0.00,'Sales Garcia Kervin Ventura',0,NULL,NULL),(2031,'591',NULL,'enero','2026-01-31',60.00,NULL,'2026-05-04 01:13:26',0.00,'Lopez Lopez Angel Abraham',0,NULL,NULL),(2032,'592',NULL,'enero','2026-01-31',60.00,NULL,'2026-05-04 01:13:26',0.00,'Rojop Dominguez Juan Miguel',0,NULL,NULL),(2033,'593',NULL,'enero','2026-02-01',60.00,NULL,'2026-05-04 01:13:26',0.00,'Chavez Lorenzo Yeimi Josefina',0,NULL,NULL),(2034,'594',NULL,'enero-febrero-marzo','2026-02-01',180.00,NULL,'2026-05-04 01:13:26',0.00,'Hernandez Cabrera Hazel Daniela',0,NULL,NULL),(2035,'595',NULL,'enero','2026-02-01',60.00,NULL,'2026-05-04 01:13:26',0.00,'Juarez Lucas Alison Alondra',0,NULL,NULL),(2036,'596',NULL,'enero','2026-02-01',60.00,NULL,'2026-05-04 01:13:26',0.00,'De Paz Fuentes Angel Ferreyn',0,NULL,NULL),(2037,'597',NULL,'enero','2026-02-01',60.00,NULL,'2026-05-04 01:13:26',0.00,'Molina Perez Diana Aurora',0,NULL,NULL),(2038,'598',NULL,'enero-febrero','2026-02-01',120.00,NULL,'2026-05-04 01:13:26',0.00,'Jimenez Perez Antonio Isai',0,NULL,NULL),(2039,'599',NULL,'inscripcion 2026','2026-02-04',125.00,NULL,'2026-05-04 01:13:26',0.00,'Gomez Dueñas Jose Emanuel',0,NULL,NULL),(2040,'600',NULL,'enero','2026-02-13',60.00,NULL,'2026-05-04 01:13:26',0.00,'Garcia Perez Jorge Danilo',0,NULL,NULL),(2041,'601',NULL,'inscripcion 2026','2026-02-14',100.00,NULL,'2026-05-04 01:13:26',0.00,'Melchor Garcia Elias Daniel',0,NULL,NULL),(2042,'602',NULL,'inscripcion 2026','2026-02-14',100.00,NULL,'2026-05-04 01:13:26',0.00,'Soto Melchor Alexi Esai',0,NULL,NULL),(2043,'603',NULL,'enero','2026-02-14',60.00,NULL,'2026-05-04 01:13:26',0.00,'Melchor Garcia Elias Daniel',0,NULL,NULL),(2044,'604',NULL,'enero','2026-02-14',60.00,NULL,'2026-05-04 01:13:26',0.00,'Soto Melchor Alexi Esai',0,NULL,NULL),(2045,'605',NULL,'enero-febrero','2026-02-14',120.00,NULL,'2026-05-04 01:13:26',0.00,'Molina Vasquez Lesly Yasmin',0,NULL,NULL),(2046,'606',NULL,'febrero','2026-02-14',60.00,NULL,'2026-05-04 01:13:26',0.00,'Castillo Ovalle Jade Maria',0,NULL,NULL),(2047,'607',NULL,'inscripcion 2026','2026-02-14',125.00,NULL,'2026-05-04 01:13:26',0.00,'Mendoza Castillo Andrea Elizabeth',0,NULL,NULL),(2048,'608',NULL,'febrero','2026-02-14',60.00,NULL,'2026-05-04 01:13:26',0.00,'Guzman Gomez Walfred Antonio',0,NULL,NULL),(2049,'609',NULL,'abril-mayo','2026-02-15',120.00,NULL,'2026-05-04 01:13:26',0.00,'Hernandez Cabrera Hazel Daniela',0,NULL,NULL),(2050,'610',NULL,'enero','2026-02-15',60.00,NULL,'2026-05-04 01:13:26',0.00,'Perez Perez Milton Aron',0,NULL,NULL),(2051,'611',NULL,'enero','2026-02-15',60.00,NULL,'2026-05-04 01:13:26',0.00,'Gomez Maria Ines',0,NULL,NULL),(2052,'612',NULL,'enero-febrero','2026-02-15',120.00,NULL,'2026-05-04 01:13:26',0.00,'de Leon Molina Marvin Estuardo',0,NULL,NULL),(2053,'613',NULL,'enero','2026-02-17',60.00,NULL,'2026-05-04 01:13:26',0.00,'Mendoza Castillo Andrea Elizabeth',0,NULL,NULL),(2054,'614',NULL,'enero','2026-02-17',60.00,NULL,'2026-05-04 01:13:26',0.00,'Garcia Porrez Marilin Selyna',0,NULL,NULL),(2055,'615',NULL,'enero-febrero','2026-02-20',120.00,NULL,'2026-05-04 01:13:26',0.00,'Bonilla Garcia Lea Raquel',0,NULL,NULL),(2056,'616',NULL,'enero','2026-02-20',60.00,NULL,'2026-05-04 01:13:26',0.00,'Macario Vicente Yeimi Roxana',0,NULL,NULL),(2057,'617',NULL,'enero','2026-02-20',60.00,NULL,'2026-05-04 01:13:26',0.00,'Ramirez Lopez Crisbel Maricruz',0,NULL,NULL),(2058,'618',NULL,'enero-febrero','2026-02-20',120.00,NULL,'2026-05-04 01:13:26',0.00,'Gomez Dueñas Jose Emanuel',0,NULL,NULL),(2059,'619',NULL,'enero','2026-02-21',60.00,NULL,'2026-05-04 01:13:26',0.00,'Shlaj Lucas Eduardo Apolinario',0,NULL,NULL),(2060,'620',NULL,'febrero','2026-02-21',60.00,NULL,'2026-05-04 01:13:26',0.00,'Cabrera Lopez Brayan Yobani',0,NULL,NULL),(2061,'621',NULL,'enero','2026-02-22',60.00,NULL,'2026-05-04 01:13:26',0.00,'Cuyuch Domiguez Sergio Ottoniel',0,NULL,NULL),(2062,'622',NULL,'febrero','2026-02-22',60.00,NULL,'2026-05-04 01:13:26',0.00,'Garcia Romero Ivana Jassmin',0,NULL,NULL),(2063,'623',NULL,'anulado','2026-02-22',0.00,NULL,'2026-05-04 01:13:26',0.00,'anulado',0,NULL,NULL),(2064,'624',NULL,'enero','2026-02-22',60.00,NULL,'2026-05-04 01:13:26',0.00,'Juarez de Leon Miguel de Jesus',0,NULL,NULL),(2065,'625',NULL,'enero-febrero','2026-02-22',120.00,NULL,'2026-05-04 01:13:26',0.00,'Estrada del Toro Diego Alejandro',0,NULL,NULL),(2066,'626',NULL,'febrero','2026-02-22',60.00,NULL,'2026-05-04 01:13:26',0.00,'Perez Orozco Lilian Delfina',0,NULL,NULL),(2067,'627',NULL,'febrero','2026-02-28',60.00,NULL,'2026-05-04 01:13:26',0.00,'Chavez Lorenzo Yeimi Josefina',0,NULL,NULL),(2068,'628',NULL,'febrero','2026-02-28',60.00,NULL,'2026-05-04 01:13:26',0.00,'Castillo Coy Emilia Elizabeth',0,NULL,NULL),(2069,'629',NULL,'febrero','2026-02-28',60.00,NULL,'2026-05-04 01:13:26',0.00,'Castillo Coy Evelyn Marleny',0,NULL,NULL),(2070,'630',NULL,'febrero','2026-02-28',60.00,NULL,'2026-05-04 01:13:26',0.00,'Gonzalez Maldonado Jorge Daniel',0,NULL,NULL),(2071,'631',NULL,'febrero','2026-02-28',60.00,NULL,'2026-05-04 01:13:26',0.00,'Garcia Mendez Marelin Yoseni',0,NULL,NULL),(2072,'632',NULL,'enero','2026-02-28',60.00,NULL,'2026-05-04 01:13:26',0.00,'Alonzo Lopez Francis Noe Misael',0,NULL,NULL),(2073,'633',NULL,'febrero-marzo','2026-03-01',120.00,NULL,'2026-05-04 01:13:26',0.00,'Garcia Perez Jorge Danilo',0,NULL,NULL),(2074,'634',NULL,'febrero','2026-03-01',60.00,NULL,'2026-05-04 01:13:26',0.00,'Juarez Lucas Alison Alondra',0,NULL,NULL),(2075,'635',NULL,'febrero','2026-03-01',60.00,NULL,'2026-05-04 01:13:26',0.00,'Juarez Lucas Maria',0,NULL,NULL),(2076,'636',NULL,'anulado','2026-03-01',0.00,NULL,'2026-05-04 01:13:26',0.00,'anulado',0,NULL,NULL),(2077,'637',NULL,'febrero','2026-03-01',60.00,NULL,'2026-05-04 01:13:26',0.00,'Vicente Perez Neftali Odiel',0,NULL,NULL),(2078,'638',NULL,'enero-febrero','2026-03-01',120.00,NULL,'2026-05-04 01:13:26',0.00,'Pablo de Leon Ricardo Alberto',0,NULL,NULL),(2079,'639',NULL,'marzo','2026-03-01',60.00,NULL,'2026-05-04 01:13:26',0.00,'Jimenez Perez Antonio Isai',0,NULL,NULL),(2080,'640',NULL,'inscripcion 2026','2026-03-01',100.00,NULL,'2026-05-04 01:13:26',0.00,'Berduo Lopez Kevin Enrique',0,NULL,NULL),(2081,'641',NULL,'febrero','2026-03-03',60.00,NULL,'2026-05-04 01:13:26',0.00,'Mendoza Castillo Andrea Elizabeth',0,NULL,NULL),(2082,'642',NULL,'enero-febrero-marzo-abril','2026-03-06',240.00,NULL,'2026-05-04 01:13:26',0.00,'Galindo Chavez Julia Amparo',0,NULL,NULL),(2083,'643',NULL,'febrero','2026-03-06',60.00,NULL,'2026-05-04 01:13:26',0.00,'Lopez Lucas Blanca Azucena',0,NULL,NULL),(2084,'644',NULL,'febrero','2026-03-06',60.00,NULL,'2026-05-04 01:13:26',0.00,'Melchor Garcia Elias Daniel',0,NULL,NULL),(2085,'645',NULL,'febrero','2026-03-06',60.00,NULL,'2026-05-04 01:13:26',0.00,'Soto Melchor Alexi Esai',0,NULL,NULL),(2086,'646',NULL,'marzo','2026-03-10',60.00,NULL,'2026-05-04 01:13:26',0.00,'Garcia Romero Ivana Jassmin',0,NULL,NULL),(2087,'647',NULL,'marzo','2026-03-10',60.00,NULL,'2026-05-04 01:13:26',0.00,'Guzman Gomez Walfred Antonio',0,NULL,NULL),(2088,'648',NULL,'enero-febrero-marzo','2026-03-10',180.00,NULL,'2026-05-04 01:13:26',0.00,'Orozco Rojas Elmer Nehemias',0,NULL,NULL),(2089,'649',NULL,'anulado','2026-03-10',0.00,NULL,'2026-05-04 01:13:26',0.00,'anulado',0,NULL,NULL),(2090,'650',NULL,'marzo','2026-03-10',60.00,NULL,'2026-05-04 01:13:26',0.00,'Perez Perez Ines',0,NULL,NULL),(2091,'651',NULL,'febrero-marzo-abril','2026-03-10',180.00,NULL,'2026-05-04 01:13:26',0.00,'Molina Perez Diana Aurora',0,NULL,NULL),(2092,'652',NULL,'anulado','2026-03-10',0.00,NULL,'2026-05-04 01:13:26',0.00,'anulado',0,NULL,NULL),(2093,'653',NULL,'enero-febrero','2026-03-10',120.00,NULL,'2026-05-04 01:13:26',0.00,'Chavalan Jasinto Jose Enrique',0,NULL,NULL),(2094,'654',NULL,'febrero','2026-03-10',60.00,NULL,'2026-05-04 01:13:26',0.00,'De Leon Gomez Cecilia',0,NULL,NULL),(2095,'655',NULL,'febrero','2026-03-10',60.00,NULL,'2026-05-04 01:13:26',0.00,'Velasquez Cabrera Eliza Lisbeth',0,NULL,NULL),(2096,'656',NULL,'enero-febrero-marzo','2026-03-10',180.00,NULL,'2026-05-04 01:13:26',0.00,'Lara Lopez Gerson Elias',0,NULL,NULL),(2097,'657',NULL,'abril','2026-03-10',60.00,NULL,'2026-05-04 01:13:26',0.00,'Lara Lopez Gerson Elias',0,NULL,NULL),(2098,'658',NULL,'febrero','2026-03-10',60.00,NULL,'2026-05-04 01:13:26',0.00,'Sales Garcia Kervin Ventura',0,NULL,NULL),(2099,'659',NULL,'febrero-marzo','2026-03-10',120.00,NULL,'2026-05-04 01:13:26',0.00,'Garcia Porrez Marilin Selyna',0,NULL,NULL),(2100,'660',NULL,'febrero','2026-03-10',60.00,NULL,'2026-05-04 01:13:26',0.00,'Juarez de Leon Miguel de Jesus',0,NULL,NULL),(2101,'661',NULL,'febrero-marzo','2026-03-10',120.00,NULL,'2026-05-04 01:13:26',0.00,'Jimenez Gomez Byron Jeremias',0,NULL,NULL),(2102,'662',NULL,'enero-febrero-marzo','2026-03-10',180.00,NULL,'2026-05-04 01:13:26',0.00,'Giron Mendez Jean Carlos',0,NULL,NULL),(2103,'663',NULL,'enero y abono 40 al mes de febrero','2026-03-10',100.00,NULL,'2026-05-04 01:13:26',0.00,'Ramirez Perez Delsy Liliana',0,NULL,NULL),(2104,'664',NULL,'enero-febrero-marzo','2026-03-10',180.00,NULL,'2026-05-04 01:13:26',0.00,'Garcia Lopez Hernan Alexander',0,NULL,NULL),(2105,'665',NULL,'marzo-abril','2026-03-10',120.00,NULL,'2026-05-04 01:13:26',0.00,'Vicente Diaz Nataly Celeste',0,NULL,NULL),(2106,'666',NULL,'enero-febrero-marzo','2026-03-10',180.00,NULL,'2026-05-04 01:13:26',0.00,'Molina Lucas Guillermo',0,NULL,NULL),(2107,'667',NULL,'febrero-marzo','2026-03-14',120.00,NULL,'2026-05-04 01:13:26',0.00,'Lopez Ramirez Nestor Antonio',0,NULL,NULL),(2108,'668',NULL,'febrero','2026-03-14',60.00,NULL,'2026-05-04 01:13:26',0.00,'Velasquez Meza Katerin Elizani',0,NULL,NULL),(2109,'669',NULL,'febrero','2026-03-14',60.00,NULL,'2026-05-04 01:13:26',0.00,'Lopez Lopez Angel Abraham',0,NULL,NULL),(2110,'670',NULL,'febrero','2026-03-14',60.00,NULL,'2026-05-04 01:13:26',0.00,'Mendez Vasquez Sheily Maritza',0,NULL,NULL),(2111,'671',NULL,'enero-febrero','2026-03-15',120.00,NULL,'2026-05-04 01:13:26',0.00,'Cruz Vicente Jimena Dayana',0,NULL,NULL),(2112,'672',NULL,'febrero-marzo-abril','2026-03-16',180.00,NULL,'2026-05-04 01:13:26',0.00,'Cigarroa Barrios Angel David',0,NULL,NULL),(2113,'673',NULL,'marzo','2026-03-20',60.00,NULL,'2026-05-04 01:13:26',0.00,'Melchor Garcia Elias Daniel',0,NULL,NULL),(2114,'674',NULL,'marzo','2026-03-20',60.00,NULL,'2026-05-04 01:13:26',0.00,'Soto Melchor Alexi Esai',0,NULL,NULL),(2115,'675',NULL,'marzo','2026-03-21',60.00,NULL,'2026-05-04 01:13:26',0.00,'Castillo Ovalle Jade Maria',0,NULL,NULL),(2116,'676',NULL,'febrero','2026-03-21',60.00,NULL,'2026-05-04 01:13:27',0.00,'Contreras Lopez Rosa Leticia',0,NULL,NULL),(2117,'677',NULL,'febrero','2026-03-21',60.00,NULL,'2026-05-04 01:13:27',0.00,'Contreras Lopez Sergio Alexander',0,NULL,NULL),(2118,'678',NULL,'febrero','2026-03-21',60.00,NULL,'2026-05-04 01:13:27',0.00,'Rojop Dominguez Juan Miguel',0,NULL,NULL),(2119,'679',NULL,'marzo-abril-mayo','2026-03-21',180.00,NULL,'2026-05-04 01:13:27',0.00,'Vasquez Perez adriana Marisol',0,NULL,NULL),(2120,'680',NULL,'enero- abono a febrero 40','2026-03-22',100.00,NULL,'2026-05-04 01:13:27',0.00,'Lara Tiu Natalia Lucita',0,NULL,NULL),(2121,'681',NULL,'febrero','2026-03-22',60.00,NULL,'2026-05-04 01:13:27',0.00,'Cuyuch Domiguez Sergio Ottoniel',0,NULL,NULL),(2122,'682',NULL,'marzo','2026-03-22',60.00,NULL,'2026-05-04 01:13:27',0.00,'Vicente Perez Neftali Odiel',0,NULL,NULL),(2123,'683',NULL,'marzo','2026-03-22',60.00,NULL,'2026-05-04 01:13:27',0.00,'Perez Orozco Lilian Delfina',0,NULL,NULL),(2124,'684',NULL,'anulado','2026-03-22',0.00,NULL,'2026-05-04 01:13:27',0.00,'anulado',0,NULL,NULL),(2125,'685',NULL,'febrero','2026-03-27',60.00,NULL,'2026-05-04 01:13:27',0.00,'Macario Vicente Yeimi Roxana',0,NULL,NULL),(2126,'686',NULL,'marzo','2026-03-27',60.00,NULL,'2026-05-04 01:13:27',0.00,'Juarez Lucas Maria',0,NULL,NULL),(2127,'687',NULL,'marzo','2026-03-28',60.00,NULL,'2026-05-04 01:13:27',0.00,'Velasquez Meza Katerin Elizani',0,NULL,NULL),(2128,'688',NULL,'marzo','2026-03-28',60.00,NULL,'2026-05-04 01:13:27',0.00,'Castillo Coy Emilia Elizabeth',0,NULL,NULL),(2129,'689',NULL,'marzo','2026-03-28',60.00,NULL,'2026-05-04 01:13:27',0.00,'Castillo Coy Evelyn Marleny',0,NULL,NULL),(2130,'690',NULL,'enro-febrero-marzo','2026-03-29',180.00,NULL,'2026-05-04 01:13:27',0.00,'Suchite Cabrera Cristian Wilfredo',0,NULL,NULL),(2131,'691',NULL,'marzo','2026-03-29',60.00,NULL,'2026-05-04 01:13:27',0.00,'Juarez Lucas Alison Alondra',0,NULL,NULL),(2132,'692',NULL,'junio','2026-03-29',60.00,NULL,'2026-05-04 01:13:27',0.00,'Hernandez Cabrera Hazel Daniela',0,NULL,NULL),(2133,'693',NULL,'febrero','2026-03-29',60.00,NULL,'2026-05-04 01:13:27',0.00,'Perez Perez Milton Aron',0,NULL,NULL),(2134,'694',NULL,'febrero','2026-03-29',60.00,NULL,'2026-05-04 01:13:27',0.00,'De Paz Fuentes Angel Ferreyn',0,NULL,NULL),(2135,'695',NULL,'marzo-abril','2026-04-10',120.00,NULL,'2026-05-04 01:13:27',0.00,'Lopez Lucas Blanca Azucena',0,NULL,NULL),(2136,'696',NULL,'abril-mayo','2026-04-10',120.00,NULL,'2026-05-04 01:13:27',0.00,'Molina Sofia Yohana',0,NULL,NULL),(2137,'697',NULL,'marzo','2026-04-10',60.00,NULL,'2026-05-04 01:13:27',0.00,'Velasquez Cabrera Elisa Lisbeth',0,NULL,NULL),(2138,'698',NULL,'marzo','2026-04-10',60.00,NULL,'2026-05-04 01:13:27',0.00,'Gomez Dueñas Jose Emanuel',0,NULL,NULL),(2139,'699',NULL,'anulado','2026-04-10',0.00,NULL,'2026-05-04 01:13:27',0.00,'anulado',0,NULL,NULL),(2140,'700',NULL,'abril','2026-04-10',60.00,NULL,'2026-05-04 01:13:27',0.00,'Melchor Garcia Elias Daniel',0,NULL,NULL),(2141,'701',NULL,'abril','2026-04-10',60.00,NULL,'2026-05-04 01:13:27',0.00,'Soto Melchor Alexi Esai',0,NULL,NULL),(2142,'702',NULL,'marzo','2026-04-11',60.00,NULL,'2026-05-04 01:13:27',0.00,'Contreras Lopez Rosa Leticia',0,NULL,NULL),(2143,'703',NULL,'marzo','2026-04-11',60.00,NULL,'2026-05-04 01:13:27',0.00,'Contreras Lopez Sergio Alexander',0,NULL,NULL),(2144,'704',NULL,'marzo','2026-04-11',60.00,NULL,'2026-05-04 01:13:27',0.00,'Chavez Lorenzo Yeimi Josefina',0,NULL,NULL),(2145,'705',NULL,'marzo','2026-04-11',60.00,NULL,'2026-05-04 01:13:27',0.00,'Molina Vasquez Lesly Yasmin',0,NULL,NULL),(2146,'706',NULL,'marzo','2026-04-11',60.00,NULL,'2026-05-04 01:13:27',0.00,'Lopez Lopez Angel Abraham',0,NULL,NULL),(2147,'707',NULL,'abril','2026-04-11',60.00,NULL,'2026-05-04 01:13:27',0.00,'Guzman Gomez Walfred Antonio',0,NULL,NULL),(2148,'708',NULL,'marzo','2026-04-11',60.00,NULL,'2026-05-04 01:13:27',0.00,'Garcia Mendez Marelin Yoseni',0,NULL,NULL),(2149,'709',NULL,'completo abril-mayo-junio-julio-agosto-septiembre-abono 20 a octubre','2026-04-11',360.00,NULL,'2026-05-04 01:13:27',0.00,'Cabrera Alonzo Emelin Azucena',0,NULL,NULL),(2150,'710',NULL,'marzo','2026-04-11',60.00,NULL,'2026-05-04 01:13:27',0.00,'Mendez Vasquez Sheily Maritza',0,NULL,NULL),(2151,'711',NULL,'marzo','2026-04-12',60.00,NULL,'2026-05-04 01:13:27',0.00,'De Leon Gomez Cecilia',0,NULL,NULL),(2152,'712',NULL,'marzo-abril','2026-04-12',120.00,NULL,'2026-05-04 01:13:27',0.00,'Estrada del Toro Diego Alejandro',0,NULL,NULL),(2153,'713',NULL,'abril','2026-04-12',60.00,NULL,'2026-05-04 01:13:27',0.00,'Giron Mendez Jean Carlos',0,NULL,NULL),(2154,'714',NULL,'mayo','2026-04-12',60.00,NULL,'2026-05-04 01:13:27',0.00,'Giron Mendez Jean Carlos',0,NULL,NULL),(2155,'715',NULL,'marzo','2026-04-24',60.00,NULL,'2026-05-04 01:13:27',0.00,'Mendoza Castillo Andrea Elizabeth',0,NULL,NULL),(2156,'716',NULL,'febrero-marzo-abril','2026-04-25',180.00,NULL,'2026-05-04 01:13:27',0.00,'Shlaj Lucas Eduardo Apolinario',0,NULL,NULL),(2157,'717',NULL,'marzo','2026-04-25',60.00,NULL,'2026-05-04 01:13:27',0.00,'Sales Garcia Kervin Ventura',0,NULL,NULL),(2158,'718',NULL,'abril','2026-04-25',60.00,NULL,'2026-05-04 01:13:27',0.00,'Castillo Ovalle Jade Maria',0,NULL,NULL),(2159,'719',NULL,'febrero-marzo','2026-04-25',120.00,NULL,'2026-05-04 01:13:27',0.00,'Alonzo Lopez Francis Noe Misael',0,NULL,NULL),(2160,'720',NULL,'abril-mayo','2026-04-25',120.00,NULL,'2026-05-04 01:13:27',0.00,'perez perez ines',0,NULL,NULL),(2161,'105',1,'Febrero 2025','2025-02-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2162,'136',1,'Marzo 2025','2025-03-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2163,'217',1,'Abril 2025','2025-04-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2164,'217',1,'Mayo 2025','2025-05-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2165,'261',1,'Junio 2025','2025-06-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2166,'310',1,'Julio 2025','2025-07-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2167,'356',1,'Agosto 2025','2025-08-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2168,'399',1,'Septiembre 2025','2025-09-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2169,'474',1,'Octubre 2025','2025-10-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2170,'498',1,'Noviembre 2025','2025-11-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2171,'118',2,'Febrero 2025','2025-02-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2172,'118',2,'Marzo 2025','2025-03-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2173,'169',2,'Abril 2025','2025-04-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2174,'238',2,'Mayo 2025','2025-05-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2175,'276',2,'Junio 2025','2025-06-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2176,'334',2,'Julio 2025','2025-07-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2177,'486',2,'Agosto 2025','2025-08-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2178,'486',2,'Septiembre 2025','2025-09-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2179,'486',2,'Octubre 2025','2025-10-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2180,'525',2,'Noviembre 2025','2025-11-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2181,'98',3,'Febrero 2025','2025-02-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2182,'137',3,'Marzo 2025','2025-03-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2183,'260',3,'Abril 2025','2025-04-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2184,'260',3,'Mayo 2025','2025-05-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2185,'307',3,'Junio 2025','2025-06-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2186,'331',3,'Julio 2025','2025-07-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2187,'361',3,'Agosto 2025','2025-08-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2188,'402',3,'Septiembre 2025','2025-09-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2189,'488',3,'Octubre 2025','2025-10-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2190,'522',3,'Noviembre 2025','2025-11-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2191,'76',35,'Febrero 2025','2025-02-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2192,'193',35,'Marzo 2025','2025-03-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2193,'193',35,'Abril 2025','2025-04-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2194,'290',35,'Mayo 2025','2025-05-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2195,'290',35,'Junio 2025','2025-06-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2196,'296',35,'Julio 2025','2025-07-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2197,'297',35,'Agosto 2025','2025-08-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2198,'362',35,'Septiembre 2025','2025-09-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2199,'362',35,'Octubre 2025','2025-10-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2200,'413',35,'Noviembre 2025','2025-11-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2201,'112',36,'Febrero 2025','2025-02-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2202,'196',36,'Marzo 2025','2025-03-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2203,'196',36,'Abril 2025','2025-04-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2204,'314',36,'Mayo 2025','2025-05-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2205,'314',36,'Junio 2025','2025-06-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2206,'314',36,'Julio 2025','2025-07-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2207,'314',36,'Agosto 2025','2025-08-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2208,'478',36,'Septiembre 2025','2025-09-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2209,'478',36,'Octubre 2025','2025-10-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2210,'537',36,'Noviembre 2025','2025-11-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2211,'65',37,'Febrero 2025','2025-02-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2212,'125',37,'Marzo 2025','2025-03-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2213,'190',37,'Abril 2025','2025-04-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2214,'234',37,'Mayo 2025','2025-05-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2215,'272',37,'Junio 2025','2025-06-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2216,'315',37,'Julio 2025','2025-07-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2217,'369',37,'Agosto 2025','2025-08-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2218,'455',37,'Septiembre 2025','2025-09-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2219,'455',37,'Octubre 2025','2025-10-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2220,'540',37,'Noviembre 2025','2025-11-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2221,'77',38,'Febrero 2025','2025-02-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2222,'143-195',38,'Marzo 2025','2025-03-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2223,'195',38,'Abril 2025','2025-04-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2224,'316',38,'Mayo 2025','2025-05-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2225,'316',38,'Junio 2025','2025-06-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2226,'342',38,'Julio 2025','2025-07-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2227,'368',38,'Agosto 2025','2025-08-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2228,'414',38,'Septiembre 2025','2025-09-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2229,'441',38,'Octubre 2025','2025-10-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2230,'441',38,'Noviembre 2025','2025-11-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2231,'114',39,'Febrero 2025','2025-02-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2232,'200',39,'Marzo 2025','2025-03-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2233,'200',39,'Abril 2025','2025-04-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2234,'200',39,'Mayo 2025','2025-05-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2235,'256',39,'Junio 2025','2025-06-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2236,'371',39,'Julio 2025','2025-07-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2237,'371',39,'Agosto 2025','2025-08-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2238,'419',39,'Septiembre 2025','2025-09-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2239,'440',39,'Octubre 2025','2025-10-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2240,'440',39,'Noviembre 2025','2025-11-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2241,'91',40,'Febrero 2025','2025-02-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2242,'129',40,'Marzo 2025','2025-03-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2243,'129',40,'Abril 2025','2025-04-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2244,'205',40,'Mayo 2025','2025-05-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2245,'247',40,'Junio 2025','2025-06-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2246,'299',40,'Julio 2025','2025-07-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2247,'350',40,'Agosto 2025','2025-08-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2248,'396',40,'Septiembre 2025','2025-09-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2249,'458',40,'Octubre 2025','2025-10-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2250,'507',40,'Noviembre 2025','2025-11-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2251,'153',41,'Febrero 2025','2025-02-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2252,'207',41,'Marzo 2025','2025-03-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2253,'250',41,'Abril 2025','2025-04-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2254,'250',41,'Mayo 2025','2025-05-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2255,'301',41,'Junio 2025','2025-06-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2256,'322',41,'Julio 2025','2025-07-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2257,'348',41,'Agosto 2025','2025-08-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2258,'395',41,'Septiembre 2025','2025-09-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2259,'434',41,'Octubre 2025','2025-10-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2260,'434',41,'Noviembre 2025','2025-11-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2261,'82',42,'Febrero 2025','2025-02-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2262,'157',42,'Marzo 2025','2025-03-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2263,'198',42,'Abril 2025','2025-04-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2264,'244',42,'Mayo 2025','2025-05-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2265,'324',42,'Junio 2025','2025-06-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2266,'347',42,'Julio 2025','2025-07-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2267,'376',42,'Agosto 2025','2025-08-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2268,'421',42,'Septiembre 2025','2025-09-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2269,'461',42,'Octubre 2025','2025-10-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2270,'513',42,'Noviembre 2025','2025-11-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2271,'117',43,'Febrero 2025','2025-02-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2272,'199',43,'Marzo 2025','2025-03-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2273,'199',43,'Abril 2025','2025-04-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2274,'254',43,'Mayo 2025','2025-05-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2275,'353',43,'Junio 2025','2025-06-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2276,'375',43,'Julio 2025','2025-07-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2277,'394',43,'Agosto 2025','2025-08-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2278,'415',43,'Septiembre 2025','2025-09-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2279,'435',43,'Octubre 2025','2025-10-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2280,'515',43,'Noviembre 2025','2025-11-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2281,'89',44,'Febrero 2025','2025-02-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2282,'154',44,'Marzo 2025','2025-03-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2283,'209',44,'Abril 2025','2025-04-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2284,'251',44,'Mayo 2025','2025-05-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2285,'321',44,'Junio 2025','2025-06-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2286,'374',44,'Julio 2025','2025-07-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2287,'427',44,'Agosto 2025','2025-08-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2288,'462',44,'Septiembre 2025','2025-09-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2289,'511',44,'Octubre 2025','2025-10-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2290,'511',44,'Noviembre 2025','2025-11-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2291,'83',45,'Febrero 2025','2025-02-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2292,'127',45,'Marzo 2025','2025-03-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2293,'208',45,'Abril 2025','2025-04-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2294,'275',45,'Mayo 2025','2025-05-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2295,'323',45,'Junio 2025','2025-06-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2296,'344',45,'Julio 2025','2025-07-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2297,'416',45,'Agosto 2025','2025-08-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2298,'438',45,'Septiembre 2025','2025-09-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2299,'438',45,'Octubre 2025','2025-10-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2300,'438',45,'Noviembre 2025','2025-11-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2301,'92',46,'Febrero 2025','2025-02-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2302,'162',46,'Marzo 2025','2025-03-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2303,'201',46,'Abril 2025','2025-04-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2304,'248',46,'Mayo 2025','2025-05-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2305,'302',46,'Junio 2025','2025-06-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2306,'352',46,'Julio 2025','2025-07-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2307,'393',46,'Agosto 2025','2025-08-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2308,'459',46,'Septiembre 2025','2025-09-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2309,'514',46,'Octubre 2025','2025-10-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2310,'514',46,'Noviembre 2025','2025-11-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2311,'95',47,'Febrero 2025','2025-02-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2312,'160',47,'Marzo 2025','2025-03-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2313,'197',47,'Abril 2025','2025-04-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2314,'225',47,'Mayo 2025','2025-05-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2315,'304',47,'Junio 2025','2025-06-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2316,'327',47,'Julio 2025','2025-07-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2317,'372',47,'Agosto 2025','2025-08-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2318,'392',47,'Septiembre 2025','2025-09-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2319,'428',47,'Octubre 2025','2025-10-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2320,'493',47,'Noviembre 2025','2025-11-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2321,'115',48,'Febrero 2025','2025-02-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2322,'161',48,'Marzo 2025','2025-03-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2323,'202',48,'Abril 2025','2025-04-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2324,'223',48,'Mayo 2025','2025-05-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2325,'257',48,'Junio 2025','2025-06-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2326,'303',48,'Julio 2025','2025-07-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2327,'370',48,'Agosto 2025','2025-08-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2328,'417',48,'Septiembre 2025','2025-09-01',60.00,NULL,'2026-05-04 01:33:01',0.00,NULL,0,NULL,NULL),(2329,'429',48,'Octubre 2025','2025-10-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2330,'429',48,'Noviembre 2025','2025-11-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2331,'90',49,'Febrero 2025','2025-02-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2332,'152',49,'Marzo 2025','2025-03-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2333,'206',49,'Abril 2025','2025-04-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2334,'206',49,'Mayo 2025','2025-05-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2335,'274',49,'Junio 2025','2025-06-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2336,'354',49,'Julio 2025','2025-07-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2337,'430',49,'Agosto 2025','2025-08-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2338,'430',49,'Septiembre 2025','2025-09-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2339,'490',49,'Octubre 2025','2025-10-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2340,'512',49,'Noviembre 2025','2025-11-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2341,'87',50,'Febrero 2025','2025-02-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2342,'116',50,'Marzo 2025','2025-03-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2343,'204',50,'Abril 2025','2025-04-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2344,'222',50,'Mayo 2025','2025-05-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2345,'300',50,'Junio 2025','2025-06-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2346,'325',50,'Julio 2025','2025-07-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2347,'349',50,'Agosto 2025','2025-08-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2348,'373',50,'Septiembre 2025','2025-09-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2349,'504',50,'Octubre 2025','2025-10-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2350,'504',50,'Noviembre 2025','2025-11-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2351,'81',51,'Febrero 2025','2025-02-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2352,'126',51,'Marzo 2025','2025-03-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2353,'203',51,'Abril 2025','2025-04-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2354,'203',51,'Mayo 2025','2025-05-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2355,'273',51,'Junio 2025','2025-06-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2356,'346',51,'Julio 2025','2025-07-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2357,'397',51,'Agosto 2025','2025-08-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2358,'431',51,'Septiembre 2025','2025-09-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2359,'505',51,'Octubre 2025','2025-10-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2360,'505',51,'Noviembre 2025','2025-11-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2361,'109',52,'Febrero 2025','2025-02-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2362,'140',52,'Marzo 2025','2025-03-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2363,'286',52,'Abril 2025','2025-04-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2364,'286',52,'Mayo 2025','2025-05-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2365,'286',52,'Junio 2025','2025-06-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2366,'338',52,'Julio 2025','2025-07-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2367,'495',52,'Agosto 2025','2025-08-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2368,'495',52,'Septiembre 2025','2025-09-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2369,'495',52,'Octubre 2025','2025-10-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2370,'495',52,'Noviembre 2025','2025-11-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2371,'88',53,'Febrero 2025','2025-02-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2372,'246',53,'Marzo 2025','2025-03-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2373,'246',53,'Abril 2025','2025-04-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2374,'246',53,'Mayo 2025','2025-05-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2375,'351',53,'Junio 2025','2025-06-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2376,'351',53,'Julio 2025','2025-07-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2377,'420',53,'Agosto 2025','2025-08-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2378,'420',53,'Septiembre 2025','2025-09-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2379,'491',53,'Octubre 2025','2025-10-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2380,'506',53,'Noviembre 2025','2025-11-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2381,'85',54,'Febrero 2025','2025-02-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2382,'158',54,'Marzo 2025','2025-03-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2383,'221',54,'Abril 2025','2025-04-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2384,'221',54,'Mayo 2025','2025-05-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2385,'298',54,'Junio 2025','2025-06-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2386,'298',54,'Julio 2025','2025-07-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2387,'418',54,'Agosto 2025','2025-08-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2388,'418',54,'Septiembre 2025','2025-09-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2389,'494',54,'Octubre 2025','2025-10-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2390,'494',54,'Noviembre 2025','2025-11-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2391,'84',55,'Febrero 2025','2025-02-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2392,'156',55,'Marzo 2025','2025-03-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2393,'211',55,'Abril 2025','2025-04-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2394,'258',55,'Mayo 2025','2025-05-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2395,'345',55,'Junio 2025','2025-06-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2396,'460',55,'Julio 2025','2025-07-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2397,'492',55,'Agosto 2025','2025-08-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2398,'492',55,'Septiembre 2025','2025-09-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2399,'492',55,'Octubre 2025','2025-10-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2400,'492',55,'Noviembre 2025','2025-11-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2401,'61',56,'Febrero 2025','2025-02-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2402,'61',56,'Marzo 2025','2025-03-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2403,'61',56,'Abril 2025','2025-04-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2404,'186',56,'Mayo 2025','2025-05-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2405,'319',56,'Junio 2025','2025-06-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2406,'319',56,'Julio 2025','2025-07-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2407,'367',56,'Agosto 2025','2025-08-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2408,'412',56,'Septiembre 2025','2025-09-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2409,'457',56,'Octubre 2025','2025-10-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2410,'508',56,'Noviembre 2025','2025-11-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2411,'123',57,'Febrero 2025','2025-02-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2412,'182',57,'Marzo 2025','2025-03-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2413,'264',57,'Abril 2025','2025-04-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2414,'289',57,'Mayo 2025','2025-05-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2415,'337',57,'Junio 2025','2025-06-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2416,'381',57,'Julio 2025','2025-07-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2417,'425',57,'Agosto 2025','2025-08-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2418,'466',57,'Septiembre 2025','2025-09-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2419,'530',57,'Octubre 2025','2025-10-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2420,'530',57,'Noviembre 2025','2025-11-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2421,'231',58,'Abril 2025','2025-04-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2422,'267',58,'Mayo 2025','2025-05-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2423,'292',58,'Junio 2025','2025-06-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2424,'339',58,'Julio 2025','2025-07-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2425,'383',58,'Agosto 2025','2025-08-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2426,'406',58,'Septiembre 2025','2025-09-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2427,'496',58,'Octubre 2025','2025-10-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2428,'534',58,'Noviembre 2025','2025-11-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2429,'232',59,'Abril 2025','2025-04-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2430,'268',59,'Mayo 2025','2025-05-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2431,'293',59,'Junio 2025','2025-06-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2432,'340',59,'Julio 2025','2025-07-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2433,'384',59,'Agosto 2025','2025-08-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2434,'405',59,'Septiembre 2025','2025-09-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2435,'497',59,'Octubre 2025','2025-10-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2436,'535',59,'Noviembre 2025','2025-11-01',60.00,NULL,'2026-05-04 01:33:02',0.00,NULL,0,NULL,NULL),(2437,'105',1,'Febrero 2025','2025-02-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2438,'136',1,'Marzo 2025','2025-03-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2439,'217',1,'Abril 2025','2025-04-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2440,'217',1,'Mayo 2025','2025-05-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2441,'261',1,'Junio 2025','2025-06-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2442,'310',1,'Julio 2025','2025-07-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2443,'356',1,'Agosto 2025','2025-08-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2444,'399',1,'Septiembre 2025','2025-09-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2445,'474',1,'Octubre 2025','2025-10-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2446,'498',1,'Noviembre 2025','2025-11-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2447,'118',2,'Febrero 2025','2025-02-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2448,'118',2,'Marzo 2025','2025-03-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2449,'169',2,'Abril 2025','2025-04-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2450,'238',2,'Mayo 2025','2025-05-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2451,'276',2,'Junio 2025','2025-06-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2452,'334',2,'Julio 2025','2025-07-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2453,'486',2,'Agosto 2025','2025-08-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2454,'486',2,'Septiembre 2025','2025-09-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2455,'486',2,'Octubre 2025','2025-10-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2456,'525',2,'Noviembre 2025','2025-11-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2457,'98',3,'Febrero 2025','2025-02-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2458,'137',3,'Marzo 2025','2025-03-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2459,'260',3,'Abril 2025','2025-04-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2460,'260',3,'Mayo 2025','2025-05-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2461,'307',3,'Junio 2025','2025-06-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2462,'331',3,'Julio 2025','2025-07-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2463,'361',3,'Agosto 2025','2025-08-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2464,'402',3,'Septiembre 2025','2025-09-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2465,'488',3,'Octubre 2025','2025-10-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2466,'522',3,'Noviembre 2025','2025-11-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2467,'166',4,'Febrero 2025','2025-02-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2468,'166',4,'Marzo 2025','2025-03-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2469,'166',4,'Abril 2025','2025-04-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2470,'403',4,'Mayo 2025','2025-05-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2471,'403',4,'Junio 2025','2025-06-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2472,'480',4,'Julio 2025','2025-07-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2473,'480',4,'Agosto 2025','2025-08-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2474,'480',4,'Septiembre 2025','2025-09-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2475,'480',4,'Octubre 2025','2025-10-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2476,'520',4,'Noviembre 2025','2025-11-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2477,'106',5,'Febrero 2025','2025-02-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2478,'130',5,'Marzo 2025','2025-03-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2479,'240',5,'Abril 2025','2025-04-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2480,'240',5,'Mayo 2025','2025-05-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2481,'333',5,'Junio 2025','2025-06-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2482,'333',5,'Julio 2025','2025-07-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2483,'482',5,'Agosto 2025','2025-08-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2484,'482',5,'Septiembre 2025','2025-09-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2485,'482',5,'Octubre 2025','2025-10-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2486,'499',5,'Noviembre 2025','2025-11-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2487,'99',6,'Febrero 2025','2025-02-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2488,'138',6,'Marzo 2025','2025-03-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2489,'214',6,'Abril 2025','2025-04-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2490,'259',6,'Mayo 2025','2025-05-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2491,'329',6,'Junio 2025','2025-06-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2492,'404',6,'Julio 2025','2025-07-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2493,'447',6,'Agosto 2025','2025-08-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2494,'481',6,'Septiembre 2025','2025-09-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2495,'481',6,'Octubre 2025','2025-10-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2496,'521',6,'Noviembre 2025','2025-11-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2497,'101',7,'Febrero 2025','2025-02-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2498,'163',7,'Marzo 2025','2025-03-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2499,'215',7,'Abril 2025','2025-04-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2500,'243',7,'Mayo 2025','2025-05-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2501,'330',7,'Junio 2025','2025-06-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2502,'330',7,'Julio 2025','2025-07-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2503,'360',7,'Agosto 2025','2025-08-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2504,'401',7,'Septiembre 2025','2025-09-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2505,'483',7,'Octubre 2025','2025-10-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2506,'523',7,'Noviembre 2025','2025-11-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2507,'56',8,'Febrero 2025','2025-02-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2508,'56',8,'Marzo 2025','2025-03-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2509,'56',8,'Abril 2025','2025-04-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2510,'212',8,'Mayo 2025','2025-05-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2511,'212',8,'Junio 2025','2025-06-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2512,'212',8,'Julio 2025','2025-07-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2513,'212',8,'Agosto 2025','2025-08-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2514,'470',8,'Septiembre 2025','2025-09-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2515,'470',8,'Octubre 2025','2025-10-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2516,'471',8,'Noviembre 2025','2025-11-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2517,'103',9,'Febrero 2025','2025-02-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2518,'134',9,'Marzo 2025','2025-03-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2519,'168',9,'Abril 2025','2025-04-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2520,'245',9,'Mayo 2025','2025-05-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2521,'281',9,'Junio 2025','2025-06-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2522,'358',9,'Julio 2025','2025-07-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2523,'398',9,'Agosto 2025','2025-08-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2524,'445',9,'Septiembre 2025','2025-09-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2525,'445',9,'Octubre 2025','2025-10-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2526,'445',9,'Noviembre 2025','2025-11-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2527,'54',10,'Febrero 2025','2025-02-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2528,'54',10,'Marzo 2025','2025-03-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2529,'54',10,'Abril 2025','2025-04-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2530,'242',10,'Mayo 2025','2025-05-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2531,'305',10,'Junio 2025','2025-06-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2532,'359',10,'Julio 2025','2025-07-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2533,'390',10,'Agosto 2025','2025-08-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2534,'472',10,'Septiembre 2025','2025-09-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2535,'472',10,'Octubre 2025','2025-10-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2536,'518',10,'Noviembre 2025','2025-11-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2537,'102',11,'Febrero 2025','2025-02-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2538,'133',11,'Marzo 2025','2025-03-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2539,'173',11,'Abril 2025','2025-04-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2540,'241',11,'Mayo 2025','2025-05-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2541,'308',11,'Junio 2025','2025-06-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2542,'363',11,'Julio 2025','2025-07-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2543,'422',11,'Agosto 2025','2025-08-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2544,'452',11,'Septiembre 2025','2025-09-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2545,'473',11,'Octubre 2025','2025-10-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2546,'517',11,'Noviembre 2025','2025-11-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2547,'119',13,'Febrero 2025','2025-02-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2548,'252',13,'Marzo 2025','2025-03-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2549,'283',13,'Abril 2025','2025-04-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2550,'283',13,'Mayo 2025','2025-05-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2551,'443',13,'Junio 2025','2025-06-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2552,'443',13,'Julio 2025','2025-07-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2553,'443',13,'Agosto 2025','2025-08-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2554,'443',13,'Septiembre 2025','2025-09-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2555,'479',13,'Octubre 2025','2025-10-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2556,'524',13,'Noviembre 2025','2025-11-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2557,'141',14,'Marzo 2025','2025-03-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2558,'141',14,'Abril 2025','2025-04-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2559,'227',14,'Mayo 2025','2025-05-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2560,'227',14,'Junio 2025','2025-06-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2561,'227',14,'Julio 2025','2025-07-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2562,'227',14,'Agosto 2025','2025-08-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2563,'468',14,'Septiembre 2025','2025-09-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2564,'468',14,'Octubre 2025','2025-10-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2565,'531',14,'Noviembre 2025','2025-11-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2566,'96',16,'Febrero 2025','2025-02-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2567,'167',16,'Marzo 2025','2025-03-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2568,'167',16,'Abril 2025','2025-04-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2569,'279',16,'Mayo 2025','2025-05-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2570,'309',16,'Junio 2025','2025-06-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2571,'389',16,'Julio 2025','2025-07-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2572,'446',16,'Agosto 2025','2025-08-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2573,'446',16,'Septiembre 2025','2025-09-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2574,'519',16,'Octubre 2025','2025-10-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2575,'519',16,'Noviembre 2025','2025-11-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2576,'100',17,'Febrero 2025','2025-02-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2577,'131',17,'Marzo 2025','2025-03-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2578,'213',17,'Abril 2025','2025-04-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2579,'249',17,'Mayo 2025','2025-05-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2580,'282',17,'Junio 2025','2025-06-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2581,'306',17,'Julio 2025','2025-07-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2582,'328',17,'Agosto 2025','2025-08-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2583,'448',17,'Septiembre 2025','2025-09-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2584,'467',17,'Octubre 2025','2025-10-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2585,'516',17,'Noviembre 2025','2025-11-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2586,'107',18,'Febrero 2025','2025-02-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2587,'132',18,'Marzo 2025','2025-03-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2588,'171',18,'Abril 2025','2025-04-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2589,'262',18,'Mayo 2025','2025-05-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2590,'280',18,'Junio 2025','2025-06-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2591,'332',18,'Julio 2025','2025-07-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2592,'386',18,'Agosto 2025','2025-08-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2593,'450',18,'Septiembre 2025','2025-09-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2594,'469',18,'Octubre 2025','2025-10-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2595,'527',18,'Noviembre 2025','2025-11-01',60.00,NULL,'2026-05-04 01:36:58',0.00,NULL,0,NULL,NULL),(2596,'66',19,'Febrero 2025','2025-02-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2597,'66',19,'Marzo 2025','2025-03-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2598,'66',19,'Abril 2025','2025-04-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2599,'253',19,'Mayo 2025','2025-05-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2600,'253',19,'Junio 2025','2025-06-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2601,'385',19,'Julio 2025','2025-07-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2602,'385',19,'Agosto 2025','2025-08-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2603,'385',19,'Septiembre 2025','2025-09-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2604,'385',19,'Octubre 2025','2025-10-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2605,'528',19,'Noviembre 2025','2025-11-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2606,'104',20,'Febrero 2025','2025-02-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2607,'174',20,'Marzo 2025','2025-03-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2608,'216',20,'Abril 2025','2025-04-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2609,'278',20,'Mayo 2025','2025-05-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2610,'357',20,'Junio 2025','2025-06-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2611,'357',20,'Julio 2025','2025-07-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2612,'387',20,'Agosto 2025','2025-08-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2613,'451',20,'Septiembre 2025','2025-09-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2614,'475',20,'Octubre 2025','2025-10-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2615,'485',20,'Noviembre 2025','2025-11-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2616,'142',21,'Marzo 2025','2025-03-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2617,'180',21,'Abril 2025','2025-04-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2618,'228',21,'Mayo 2025','2025-05-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2619,'228',21,'Junio 2025','2025-06-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2620,'311',21,'Julio 2025','2025-07-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2621,'380',21,'Agosto 2025','2025-08-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2622,'380',21,'Septiembre 2025','2025-09-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2623,'464',21,'Octubre 2025','2025-10-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2624,'464',21,'Noviembre 2025','2025-11-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2625,'122',22,'Febrero 2025','2025-02-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2626,'181',22,'Marzo 2025','2025-03-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2627,'263',22,'Abril 2025','2025-04-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2628,'288',22,'Mayo 2025','2025-05-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2629,'336',22,'Junio 2025','2025-06-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2630,'382',22,'Julio 2025','2025-07-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2631,'423',22,'Agosto 2025','2025-08-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2632,'465',22,'Septiembre 2025','2025-09-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2633,'529',22,'Octubre 2025','2025-10-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2634,'529',22,'Noviembre 2025','2025-11-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2635,'70',24,'Febrero 2025','2025-02-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2636,'146',24,'Marzo 2025','2025-03-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2637,'219',24,'Abril 2025','2025-04-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2638,'236',24,'Mayo 2025','2025-05-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2639,'270',24,'Junio 2025','2025-06-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2640,'295',24,'Julio 2025','2025-07-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2641,'313',24,'Agosto 2025','2025-08-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2642,'442',24,'Septiembre 2025','2025-09-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2643,'442',24,'Octubre 2025','2025-10-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2644,'442',24,'Noviembre 2025','2025-11-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2645,'79',25,'Febrero 2025','2025-02-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2646,'113',25,'Marzo 2025','2025-03-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2647,'189',25,'Abril 2025','2025-04-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2648,'189',25,'Mayo 2025','2025-05-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2649,'291',25,'Junio 2025','2025-06-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2650,'341',25,'Julio 2025','2025-07-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2651,'365',25,'Agosto 2025','2025-08-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2652,'436',25,'Septiembre 2025','2025-09-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2653,'436',25,'Octubre 2025','2025-10-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2654,'73',26,'Febrero 2025','2025-02-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2655,'148',26,'Marzo 2025','2025-03-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2656,'187',26,'Abril 2025','2025-04-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2657,'239',26,'Mayo 2025','2025-05-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2658,'317',26,'Junio 2025','2025-06-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2659,'366',26,'Julio 2025','2025-07-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2660,'407',26,'Agosto 2025','2025-08-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2661,'456',26,'Septiembre 2025','2025-09-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2662,'536',26,'Octubre 2025','2025-10-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2663,'536',26,'Noviembre 2025','2025-11-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2664,'69',27,'Febrero 2025','2025-02-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2665,'145',27,'Marzo 2025','2025-03-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2666,'184',27,'Abril 2025','2025-04-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2667,'237',27,'Mayo 2025','2025-05-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2668,'294',27,'Junio 2025','2025-06-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2669,'343',27,'Julio 2025','2025-07-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2670,'408',27,'Agosto 2025','2025-08-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2671,'453',27,'Septiembre 2025','2025-09-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2672,'538',27,'Octubre 2025','2025-10-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2673,'538',27,'Noviembre 2025','2025-11-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2674,'71',28,'Febrero 2025','2025-02-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2675,'147',28,'Marzo 2025','2025-03-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2676,'194',28,'Abril 2025','2025-04-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2677,'271',28,'Mayo 2025','2025-05-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2678,'318',28,'Junio 2025','2025-06-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2679,'364',28,'Julio 2025','2025-07-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2680,'409',28,'Agosto 2025','2025-08-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2681,'437',28,'Septiembre 2025','2025-09-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2682,'510',28,'Octubre 2025','2025-10-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2683,'510',28,'Noviembre 2025','2025-11-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2684,'80',29,'Febrero 2025','2025-02-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2685,'149',29,'Marzo 2025','2025-03-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2686,'188',29,'Abril 2025','2025-04-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2687,'296',29,'Mayo 2025','2025-05-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2688,'296',29,'Junio 2025','2025-06-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2689,'391',29,'Julio 2025','2025-07-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2690,'391',29,'Agosto 2025','2025-08-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2691,'411',29,'Septiembre 2025','2025-09-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2692,'439',29,'Octubre 2025','2025-10-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2693,'439',29,'Noviembre 2025','2025-11-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2694,'108',30,'Febrero 2025','2025-02-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2695,'139',30,'Marzo 2025','2025-03-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2696,'170',30,'Abril 2025','2025-04-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2697,'335',30,'Mayo 2025','2025-05-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2698,'335',30,'Junio 2025','2025-06-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2699,'335',30,'Julio 2025','2025-07-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2700,'335',30,'Agosto 2025','2025-08-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2701,'335',30,'Septiembre 2025','2025-09-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2702,'335',30,'Octubre 2025','2025-10-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2703,'335',30,'Noviembre 2025','2025-11-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2704,'121',31,'Febrero 2025','2025-02-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2705,'25',31,'Marzo 2025','2025-03-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2706,'226',31,'Abril 2025','2025-04-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2707,'226',31,'Mayo 2025','2025-05-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2708,'284',31,'Junio 2025','2025-06-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2709,'484',31,'Julio 2025','2025-07-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2710,'484',31,'Agosto 2025','2025-08-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2711,'484',31,'Septiembre 2025','2025-09-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2712,'484',31,'Octubre 2025','2025-10-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2713,'533',31,'Noviembre 2025','2025-11-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2714,'229',32,'Febrero 2025','2025-02-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2715,'229',32,'Marzo 2025','2025-03-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2716,'229',32,'Abril 2025','2025-04-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2717,'229',32,'Mayo 2025','2025-05-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2718,'378',32,'Junio 2025','2025-06-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2719,'378',32,'Julio 2025','2025-07-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2720,'388',32,'Agosto 2025','2025-08-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2721,'501',32,'Septiembre 2025','2025-09-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2722,'501',32,'Octubre 2025','2025-10-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2723,'501',32,'Noviembre 2025','2025-11-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2724,'218',33,'Marzo 2025','2025-03-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2725,'265',33,'Abril 2025','2025-04-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2726,'265',33,'Mayo 2025','2025-05-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2727,'433',33,'Junio 2025','2025-06-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2728,'444',33,'Julio 2025','2025-07-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2729,'444',33,'Agosto 2025','2025-08-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2730,'444',33,'Septiembre 2025','2025-09-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2731,'476',33,'Octubre 2025','2025-10-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2732,'532',33,'Noviembre 2025','2025-11-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2733,'120',34,'Febrero 2025','2025-02-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2734,'178',34,'Marzo 2025','2025-03-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2735,'230',34,'Abril 2025','2025-04-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2736,'230',34,'Mayo 2025','2025-05-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2737,'266',34,'Junio 2025','2025-06-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2738,'285',34,'Julio 2025','2025-07-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2739,'379',34,'Agosto 2025','2025-08-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2740,'424',34,'Septiembre 2025','2025-09-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2741,'503',34,'Octubre 2025','2025-10-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2742,'503',34,'Noviembre 2025','2025-11-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2743,'76',35,'Febrero 2025','2025-02-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2744,'193',35,'Marzo 2025','2025-03-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2745,'193',35,'Abril 2025','2025-04-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2746,'290',35,'Mayo 2025','2025-05-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2747,'290',35,'Junio 2025','2025-06-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2748,'296',35,'Julio 2025','2025-07-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2749,'297',35,'Agosto 2025','2025-08-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2750,'362',35,'Septiembre 2025','2025-09-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2751,'362',35,'Octubre 2025','2025-10-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2752,'413',35,'Noviembre 2025','2025-11-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2753,'112',36,'Febrero 2025','2025-02-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2754,'196',36,'Marzo 2025','2025-03-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2755,'196',36,'Abril 2025','2025-04-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2756,'314',36,'Mayo 2025','2025-05-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2757,'314',36,'Junio 2025','2025-06-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2758,'314',36,'Julio 2025','2025-07-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2759,'314',36,'Agosto 2025','2025-08-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2760,'478',36,'Septiembre 2025','2025-09-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2761,'478',36,'Octubre 2025','2025-10-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2762,'537',36,'Noviembre 2025','2025-11-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2763,'65',37,'Febrero 2025','2025-02-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2764,'125',37,'Marzo 2025','2025-03-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2765,'190',37,'Abril 2025','2025-04-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2766,'234',37,'Mayo 2025','2025-05-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2767,'272',37,'Junio 2025','2025-06-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2768,'315',37,'Julio 2025','2025-07-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2769,'369',37,'Agosto 2025','2025-08-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2770,'455',37,'Septiembre 2025','2025-09-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2771,'455',37,'Octubre 2025','2025-10-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2772,'540',37,'Noviembre 2025','2025-11-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2773,'77',38,'Febrero 2025','2025-02-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2774,'143-195',38,'Marzo 2025','2025-03-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2775,'195',38,'Abril 2025','2025-04-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2776,'316',38,'Mayo 2025','2025-05-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2777,'316',38,'Junio 2025','2025-06-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2778,'342',38,'Julio 2025','2025-07-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2779,'368',38,'Agosto 2025','2025-08-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2780,'414',38,'Septiembre 2025','2025-09-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2781,'441',38,'Octubre 2025','2025-10-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2782,'441',38,'Noviembre 2025','2025-11-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2783,'114',39,'Febrero 2025','2025-02-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2784,'200',39,'Marzo 2025','2025-03-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2785,'200',39,'Abril 2025','2025-04-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2786,'200',39,'Mayo 2025','2025-05-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2787,'256',39,'Junio 2025','2025-06-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2788,'371',39,'Julio 2025','2025-07-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2789,'371',39,'Agosto 2025','2025-08-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2790,'419',39,'Septiembre 2025','2025-09-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2791,'440',39,'Octubre 2025','2025-10-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2792,'440',39,'Noviembre 2025','2025-11-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2793,'91',40,'Febrero 2025','2025-02-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2794,'129',40,'Marzo 2025','2025-03-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2795,'129',40,'Abril 2025','2025-04-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2796,'205',40,'Mayo 2025','2025-05-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2797,'247',40,'Junio 2025','2025-06-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2798,'299',40,'Julio 2025','2025-07-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2799,'350',40,'Agosto 2025','2025-08-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2800,'396',40,'Septiembre 2025','2025-09-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2801,'458',40,'Octubre 2025','2025-10-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2802,'507',40,'Noviembre 2025','2025-11-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2803,'153',41,'Febrero 2025','2025-02-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2804,'207',41,'Marzo 2025','2025-03-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2805,'250',41,'Abril 2025','2025-04-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2806,'250',41,'Mayo 2025','2025-05-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2807,'301',41,'Junio 2025','2025-06-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2808,'322',41,'Julio 2025','2025-07-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2809,'348',41,'Agosto 2025','2025-08-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2810,'395',41,'Septiembre 2025','2025-09-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2811,'434',41,'Octubre 2025','2025-10-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2812,'434',41,'Noviembre 2025','2025-11-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2813,'82',42,'Febrero 2025','2025-02-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2814,'157',42,'Marzo 2025','2025-03-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2815,'198',42,'Abril 2025','2025-04-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2816,'244',42,'Mayo 2025','2025-05-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2817,'324',42,'Junio 2025','2025-06-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2818,'347',42,'Julio 2025','2025-07-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2819,'376',42,'Agosto 2025','2025-08-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2820,'421',42,'Septiembre 2025','2025-09-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2821,'461',42,'Octubre 2025','2025-10-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2822,'513',42,'Noviembre 2025','2025-11-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2823,'117',43,'Febrero 2025','2025-02-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2824,'199',43,'Marzo 2025','2025-03-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2825,'199',43,'Abril 2025','2025-04-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2826,'254',43,'Mayo 2025','2025-05-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2827,'353',43,'Junio 2025','2025-06-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2828,'375',43,'Julio 2025','2025-07-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2829,'394',43,'Agosto 2025','2025-08-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2830,'415',43,'Septiembre 2025','2025-09-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2831,'435',43,'Octubre 2025','2025-10-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2832,'515',43,'Noviembre 2025','2025-11-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2833,'89',44,'Febrero 2025','2025-02-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2834,'154',44,'Marzo 2025','2025-03-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2835,'209',44,'Abril 2025','2025-04-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2836,'251',44,'Mayo 2025','2025-05-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2837,'321',44,'Junio 2025','2025-06-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2838,'374',44,'Julio 2025','2025-07-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2839,'427',44,'Agosto 2025','2025-08-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2840,'462',44,'Septiembre 2025','2025-09-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2841,'511',44,'Octubre 2025','2025-10-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2842,'511',44,'Noviembre 2025','2025-11-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2843,'83',45,'Febrero 2025','2025-02-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2844,'127',45,'Marzo 2025','2025-03-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2845,'208',45,'Abril 2025','2025-04-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2846,'275',45,'Mayo 2025','2025-05-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2847,'323',45,'Junio 2025','2025-06-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2848,'344',45,'Julio 2025','2025-07-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2849,'416',45,'Agosto 2025','2025-08-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2850,'438',45,'Septiembre 2025','2025-09-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2851,'438',45,'Octubre 2025','2025-10-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2852,'438',45,'Noviembre 2025','2025-11-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2853,'92',46,'Febrero 2025','2025-02-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2854,'162',46,'Marzo 2025','2025-03-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2855,'201',46,'Abril 2025','2025-04-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2856,'248',46,'Mayo 2025','2025-05-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2857,'302',46,'Junio 2025','2025-06-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2858,'352',46,'Julio 2025','2025-07-01',60.00,NULL,'2026-05-04 01:36:59',0.00,NULL,0,NULL,NULL),(2859,'393',46,'Agosto 2025','2025-08-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2860,'459',46,'Septiembre 2025','2025-09-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2861,'514',46,'Octubre 2025','2025-10-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2862,'514',46,'Noviembre 2025','2025-11-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2863,'95',47,'Febrero 2025','2025-02-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2864,'160',47,'Marzo 2025','2025-03-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2865,'197',47,'Abril 2025','2025-04-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2866,'225',47,'Mayo 2025','2025-05-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2867,'304',47,'Junio 2025','2025-06-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2868,'327',47,'Julio 2025','2025-07-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2869,'372',47,'Agosto 2025','2025-08-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2870,'392',47,'Septiembre 2025','2025-09-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2871,'428',47,'Octubre 2025','2025-10-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2872,'493',47,'Noviembre 2025','2025-11-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2873,'115',48,'Febrero 2025','2025-02-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2874,'161',48,'Marzo 2025','2025-03-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2875,'202',48,'Abril 2025','2025-04-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2876,'223',48,'Mayo 2025','2025-05-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2877,'257',48,'Junio 2025','2025-06-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2878,'303',48,'Julio 2025','2025-07-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2879,'370',48,'Agosto 2025','2025-08-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2880,'417',48,'Septiembre 2025','2025-09-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2881,'429',48,'Octubre 2025','2025-10-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2882,'429',48,'Noviembre 2025','2025-11-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2883,'90',49,'Febrero 2025','2025-02-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2884,'152',49,'Marzo 2025','2025-03-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2885,'206',49,'Abril 2025','2025-04-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2886,'206',49,'Mayo 2025','2025-05-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2887,'274',49,'Junio 2025','2025-06-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2888,'354',49,'Julio 2025','2025-07-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2889,'430',49,'Agosto 2025','2025-08-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2890,'430',49,'Septiembre 2025','2025-09-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2891,'490',49,'Octubre 2025','2025-10-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2892,'512',49,'Noviembre 2025','2025-11-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2893,'87',50,'Febrero 2025','2025-02-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2894,'116',50,'Marzo 2025','2025-03-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2895,'204',50,'Abril 2025','2025-04-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2896,'222',50,'Mayo 2025','2025-05-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2897,'300',50,'Junio 2025','2025-06-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2898,'325',50,'Julio 2025','2025-07-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2899,'349',50,'Agosto 2025','2025-08-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2900,'373',50,'Septiembre 2025','2025-09-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2901,'504',50,'Octubre 2025','2025-10-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2902,'504',50,'Noviembre 2025','2025-11-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2903,'81',51,'Febrero 2025','2025-02-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2904,'126',51,'Marzo 2025','2025-03-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2905,'203',51,'Abril 2025','2025-04-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2906,'203',51,'Mayo 2025','2025-05-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2907,'273',51,'Junio 2025','2025-06-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2908,'346',51,'Julio 2025','2025-07-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2909,'397',51,'Agosto 2025','2025-08-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2910,'431',51,'Septiembre 2025','2025-09-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2911,'505',51,'Octubre 2025','2025-10-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2912,'505',51,'Noviembre 2025','2025-11-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2913,'109',52,'Febrero 2025','2025-02-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2914,'140',52,'Marzo 2025','2025-03-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2915,'286',52,'Abril 2025','2025-04-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2916,'286',52,'Mayo 2025','2025-05-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2917,'286',52,'Junio 2025','2025-06-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2918,'338',52,'Julio 2025','2025-07-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2919,'495',52,'Agosto 2025','2025-08-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2920,'495',52,'Septiembre 2025','2025-09-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2921,'495',52,'Octubre 2025','2025-10-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2922,'495',52,'Noviembre 2025','2025-11-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2923,'88',53,'Febrero 2025','2025-02-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2924,'246',53,'Marzo 2025','2025-03-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2925,'246',53,'Abril 2025','2025-04-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2926,'246',53,'Mayo 2025','2025-05-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2927,'351',53,'Junio 2025','2025-06-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2928,'351',53,'Julio 2025','2025-07-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2929,'420',53,'Agosto 2025','2025-08-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2930,'420',53,'Septiembre 2025','2025-09-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2931,'491',53,'Octubre 2025','2025-10-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2932,'506',53,'Noviembre 2025','2025-11-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2933,'85',54,'Febrero 2025','2025-02-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2934,'158',54,'Marzo 2025','2025-03-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2935,'221',54,'Abril 2025','2025-04-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2936,'221',54,'Mayo 2025','2025-05-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2937,'298',54,'Junio 2025','2025-06-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2938,'298',54,'Julio 2025','2025-07-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2939,'418',54,'Agosto 2025','2025-08-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2940,'418',54,'Septiembre 2025','2025-09-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2941,'494',54,'Octubre 2025','2025-10-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2942,'494',54,'Noviembre 2025','2025-11-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2943,'84',55,'Febrero 2025','2025-02-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2944,'156',55,'Marzo 2025','2025-03-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2945,'211',55,'Abril 2025','2025-04-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2946,'258',55,'Mayo 2025','2025-05-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2947,'345',55,'Junio 2025','2025-06-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2948,'460',55,'Julio 2025','2025-07-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2949,'492',55,'Agosto 2025','2025-08-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2950,'492',55,'Septiembre 2025','2025-09-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2951,'492',55,'Octubre 2025','2025-10-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2952,'492',55,'Noviembre 2025','2025-11-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2953,'61',56,'Febrero 2025','2025-02-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2954,'61',56,'Marzo 2025','2025-03-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2955,'61',56,'Abril 2025','2025-04-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2956,'186',56,'Mayo 2025','2025-05-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2957,'319',56,'Junio 2025','2025-06-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2958,'319',56,'Julio 2025','2025-07-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2959,'367',56,'Agosto 2025','2025-08-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2960,'412',56,'Septiembre 2025','2025-09-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2961,'457',56,'Octubre 2025','2025-10-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2962,'508',56,'Noviembre 2025','2025-11-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2963,'123',57,'Febrero 2025','2025-02-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2964,'182',57,'Marzo 2025','2025-03-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2965,'264',57,'Abril 2025','2025-04-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2966,'289',57,'Mayo 2025','2025-05-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2967,'337',57,'Junio 2025','2025-06-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2968,'381',57,'Julio 2025','2025-07-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2969,'425',57,'Agosto 2025','2025-08-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2970,'466',57,'Septiembre 2025','2025-09-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2971,'530',57,'Octubre 2025','2025-10-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2972,'530',57,'Noviembre 2025','2025-11-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2973,'231',58,'Abril 2025','2025-04-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2974,'267',58,'Mayo 2025','2025-05-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2975,'292',58,'Junio 2025','2025-06-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2976,'339',58,'Julio 2025','2025-07-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2977,'383',58,'Agosto 2025','2025-08-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2978,'406',58,'Septiembre 2025','2025-09-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2979,'496',58,'Octubre 2025','2025-10-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2980,'534',58,'Noviembre 2025','2025-11-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2981,'232',59,'Abril 2025','2025-04-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2982,'268',59,'Mayo 2025','2025-05-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2983,'293',59,'Junio 2025','2025-06-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2984,'340',59,'Julio 2025','2025-07-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2985,'384',59,'Agosto 2025','2025-08-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2986,'405',59,'Septiembre 2025','2025-09-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2987,'497',59,'Octubre 2025','2025-10-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(2988,'535',59,'Noviembre 2025','2025-11-01',60.00,NULL,'2026-05-04 01:37:00',0.00,NULL,0,NULL,NULL),(3457,'594',1,'Enero 2026','2026-01-01',60.00,NULL,'2026-05-04 01:49:14',0.00,NULL,0,NULL,NULL),(3458,'594',1,'Febrero 2026','2026-02-01',60.00,NULL,'2026-05-04 01:49:14',0.00,NULL,0,NULL,NULL),(3459,'594',1,'Marzo 2026','2026-03-01',60.00,NULL,'2026-05-04 01:49:14',0.00,NULL,0,NULL,NULL),(3460,'609',1,'Abril 2026','2026-04-01',60.00,NULL,'2026-05-04 01:49:14',0.00,NULL,0,NULL,NULL),(3461,'609',1,'Mayo 2026','2026-05-01',60.00,NULL,'2026-05-04 01:49:14',0.00,NULL,0,NULL,NULL),(3462,'692',1,'Junio 2026','2026-06-01',60.00,NULL,'2026-05-04 01:49:14',0.00,NULL,0,NULL,NULL),(3463,'586',2,'Enero 2026','2026-01-01',60.00,NULL,'2026-05-04 01:49:14',0.00,NULL,0,NULL,NULL),(3464,'654',2,'Febrero 2026','2026-02-01',60.00,NULL,'2026-05-04 01:49:14',0.00,NULL,0,NULL,NULL),(3465,'711',2,'Marzo 2026','2026-03-01',60.00,NULL,'2026-05-04 01:49:14',0.00,NULL,0,NULL,NULL),(3466,'624',3,'Enero 2026','2026-01-01',60.00,NULL,'2026-05-04 01:49:14',0.00,NULL,0,NULL,NULL),(3467,'660',3,'Febrero 2026','2026-02-01',60.00,NULL,'2026-05-04 01:49:14',0.00,NULL,0,NULL,NULL),(3468,'680',4,'Enero 2026','2026-01-01',60.00,NULL,'2026-05-04 01:49:14',0.00,NULL,0,NULL,NULL),(3469,'680',4,'Febrero 2026','2026-02-01',60.00,NULL,'2026-05-04 01:49:14',0.00,NULL,0,NULL,NULL),(3470,'625',5,'Enero 2026','2026-01-01',60.00,NULL,'2026-05-04 01:49:14',0.00,NULL,0,NULL,NULL),(3471,'625',5,'Febrero 2026','2026-02-01',60.00,NULL,'2026-05-04 01:49:14',0.00,NULL,0,NULL,NULL),(3472,'712',5,'Marzo 2026','2026-03-01',60.00,NULL,'2026-05-04 01:49:14',0.00,NULL,0,NULL,NULL),(3473,'712',5,'Abril 2026','2026-04-01',60.00,NULL,'2026-05-04 01:49:14',0.00,NULL,0,NULL,NULL),(3474,'621',6,'Enero 2026','2026-01-01',60.00,NULL,'2026-05-04 01:49:14',0.00,NULL,0,NULL,NULL),(3475,'681',6,'Febrero 2026','2026-02-01',60.00,NULL,'2026-05-04 01:49:14',0.00,NULL,0,NULL,NULL),(3476,'600',7,'Enero 2026','2026-01-01',60.00,NULL,'2026-05-04 01:49:14',0.00,NULL,0,NULL,NULL),(3477,'633',7,'Febrero 2026','2026-02-01',60.00,NULL,'2026-05-04 01:49:14',0.00,NULL,0,NULL,NULL),(3478,'633',7,'Marzo 2026','2026-03-01',60.00,NULL,'2026-05-04 01:49:14',0.00,NULL,0,NULL,NULL),(3479,'593',8,'Enero 2026','2026-01-01',60.00,NULL,'2026-05-04 01:49:14',0.00,NULL,0,NULL,NULL),(3480,'627',8,'Febrero 2026','2026-02-01',60.00,NULL,'2026-05-04 01:49:14',0.00,NULL,0,NULL,NULL),(3481,'704',8,'Marzo 2026','2026-03-01',60.00,NULL,'2026-05-04 01:49:14',0.00,NULL,0,NULL,NULL),(3482,'610',9,'Enero 2026','2026-01-01',60.00,NULL,'2026-05-04 01:49:14',0.00,NULL,0,NULL,NULL),(3483,'693',9,'Febrero 2026','2026-02-01',60.00,NULL,'2026-05-04 01:49:14',0.00,NULL,0,NULL,NULL),(3484,'619',10,'Enero 2026','2026-01-01',60.00,NULL,'2026-05-04 01:49:14',0.00,NULL,0,NULL,NULL),(3485,'716',10,'Febrero 2026','2026-02-01',60.00,NULL,'2026-05-04 01:49:14',0.00,NULL,0,NULL,NULL),(3486,'716',10,'Marzo 2026','2026-03-01',60.00,NULL,'2026-05-04 01:49:14',0.00,NULL,0,NULL,NULL),(3487,'716',10,'Abril 2026','2026-04-01',60.00,NULL,'2026-05-04 01:49:14',0.00,NULL,0,NULL,NULL),(3488,'595',11,'Enero 2026','2026-01-01',60.00,NULL,'2026-05-04 01:49:14',0.00,NULL,0,NULL,NULL),(3489,'634',11,'Febrero 2026','2026-02-01',60.00,NULL,'2026-05-04 01:49:14',0.00,NULL,0,NULL,NULL),(3490,'691',11,'Marzo 2026','2026-03-01',60.00,NULL,'2026-05-04 01:49:14',0.00,NULL,0,NULL,NULL),(3491,'589',12,'Enero 2026','2026-01-01',60.00,NULL,'2026-05-04 01:49:14',0.00,NULL,0,NULL,NULL),(3492,'655',12,'Febrero 2026','2026-02-01',60.00,NULL,'2026-05-04 01:49:14',0.00,NULL,0,NULL,NULL),(3493,'697',12,'Marzo 2026','2026-03-01',60.00,NULL,'2026-05-04 01:49:14',0.00,NULL,0,NULL,NULL),(3494,'690',13,'Enero 2026','2026-01-01',60.00,NULL,'2026-05-04 01:49:14',0.00,NULL,0,NULL,NULL),(3495,'690',13,'Febrero 2026','2026-02-01',60.00,NULL,'2026-05-04 01:49:14',0.00,NULL,0,NULL,NULL),(3496,'690',13,'Marzo 2026','2026-03-01',60.00,NULL,'2026-05-04 01:49:14',0.00,NULL,0,NULL,NULL),(3497,'580',14,'Enero 2026','2026-01-01',60.00,NULL,'2026-05-04 01:49:14',0.00,NULL,0,NULL,NULL),(3498,'580',14,'Febrero 2026','2026-02-01',60.00,NULL,'2026-05-04 01:49:14',0.00,NULL,0,NULL,NULL),(3499,'648',15,'Enero 2026','2026-01-01',60.00,NULL,'2026-05-04 01:49:14',0.00,NULL,0,NULL,NULL),(3500,'648',15,'Febrero 2026','2026-02-01',60.00,NULL,'2026-05-04 01:49:14',0.00,NULL,0,NULL,NULL),(3501,'648',15,'Marzo 2026','2026-03-01',60.00,NULL,'2026-05-04 01:49:14',0.00,NULL,0,NULL,NULL),(3502,'551',16,'Enero 2026','2026-01-01',60.00,NULL,'2026-05-04 01:49:14',0.00,NULL,0,NULL,NULL),(3503,'606',16,'Febrero 2026','2026-02-01',60.00,NULL,'2026-05-04 01:49:14',0.00,NULL,0,NULL,NULL),(3504,'675',16,'Marzo 2026','2026-03-01',60.00,NULL,'2026-05-04 01:49:14',0.00,NULL,0,NULL,NULL),(3505,'718',16,'Abril 2026','2026-04-01',60.00,NULL,'2026-05-04 01:49:14',0.00,NULL,0,NULL,NULL),(3506,'563',17,'Enero 2026','2026-01-01',60.00,NULL,'2026-05-04 01:49:14',0.00,NULL,0,NULL,NULL),(3507,'622',17,'Febrero 2026','2026-02-01',60.00,NULL,'2026-05-04 01:49:14',0.00,NULL,0,NULL,NULL),(3508,'646',17,'Marzo 2026','2026-03-01',60.00,NULL,'2026-05-04 01:49:14',0.00,NULL,0,NULL,NULL),(3509,'596',18,'Enero 2026','2026-01-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3510,'694',18,'Febrero 2026','2026-02-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3511,'666',19,'Enero 2026','2026-01-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3512,'666',19,'Febrero 2026','2026-02-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3513,'666',19,'Marzo 2026','2026-03-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3514,'566',20,'Enero 2026','2026-01-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3515,'672',20,'Febrero 2026','2026-02-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3516,'672',20,'Marzo 2026','2026-03-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3517,'672',20,'Abril 2026','2026-04-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3518,'598',21,'Enero 2026','2026-01-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3519,'598',21,'Febrero 2026','2026-02-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3520,'639',21,'Marzo 2026','2026-03-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3521,'554',22,'Enero 2026','2026-01-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3522,'677',22,'Febrero 2026','2026-02-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3523,'703',22,'Marzo 2026','2026-03-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3524,'656',24,'Enero 2026','2026-01-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3525,'656',24,'Febrero 2026','2026-02-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3526,'656',24,'Marzo 2026','2026-03-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3527,'657',24,'Abril 2026','2026-04-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3528,'577',26,'Enero 2026','2026-01-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3529,'667',26,'Febrero 2026','2026-02-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3530,'667',26,'Marzo 2026','2026-03-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3531,'584',27,'Enero 2026','2026-01-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3532,'620',27,'Febrero 2026','2026-02-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3533,'590',28,'Enero 2026','2026-01-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3534,'658',28,'Febrero 2026','2026-02-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3535,'717',28,'Marzo 2026','2026-03-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3536,'583',29,'Enero 2026','2026-01-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3537,'668',29,'Febrero 2026','2026-02-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3538,'687',29,'Marzo 2026','2026-03-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3539,'568',30,'Enero 2026','2026-01-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3540,'568',30,'Febrero 2026','2026-02-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3541,'568',30,'Marzo 2026','2026-03-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3542,'568',30,'Abril 2026','2026-04-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3543,'568',30,'Mayo 2026','2026-05-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3544,'568',30,'Junio 2026','2026-06-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3545,'568',30,'Julio 2026','2026-07-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3546,'568',30,'Agosto 2026','2026-08-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3547,'568-571',30,'Septiembre 2026','2026-09-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3548,'571',30,'Octubre 2026','2026-10-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3549,'571',30,'Noviembre 2026','2026-11-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3550,'638',31,'Enero 2026','2026-01-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3551,'638',31,'Febrero 2026','2026-02-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3552,'567',32,'Enero 2026','2026-01-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3553,'637',32,'Febrero 2026','2026-02-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3554,'682',32,'Marzo 2026','2026-03-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3555,'726',32,'Abril 2026','2026-04-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3556,'569',33,'Enero 2026','2026-01-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3557,'569',33,'Febrero 2026','2026-02-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3558,'665',33,'Marzo 2026','2026-03-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3559,'665',33,'Abril 2026','2026-04-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3560,'611',34,'Enero 2026','2026-01-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3561,'597',35,'Enero 2026','2026-01-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3562,'651',35,'Febrero 2026','2026-02-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3563,'651',35,'Marzo 2026','2026-03-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3564,'651',35,'Abril 2026','2026-04-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3565,'612',36,'Enero 2026','2026-01-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3566,'612',36,'Febrero 2026','2026-02-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3567,'570',37,'Enero 2026','2026-01-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3568,'626',37,'Febrero 2026','2026-02-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3569,'683',37,'Marzo 2026','2026-03-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3570,'653',38,'Enero 2026','2026-01-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3571,'653',38,'Febrero 2026','2026-02-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3572,'560',39,'Enero 2026','2026-01-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3573,'630',39,'Febrero 2026','2026-02-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3574,'556',40,'Enero 2026','2026-01-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3575,'608',40,'Febrero 2026','2026-02-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3576,'647',40,'Marzo 2026','2026-03-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3577,'707',40,'Abril 2026','2026-04-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3578,'614',41,'Enero 2026','2026-01-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3579,'659',41,'Febrero 2026','2026-02-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3580,'659',41,'Marzo 2026','2026-03-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3581,'729',41,'Abril 2026','2026-04-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3582,'579',42,'Enero 2026','2026-01-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3583,'631',42,'Febrero 2026','2026-02-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3584,'708',42,'Marzo 2026','2026-03-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3585,'663',43,'Enero 2026','2026-01-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3586,'663',43,'Febrero 2026','2026-02-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3587,'578',44,'Enero 2026','2026-01-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3588,'670',44,'Febrero 2026','2026-02-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3589,'710',44,'Marzo 2026','2026-03-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3590,'728',44,'Abril 2026','2026-04-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3591,'557',45,'Enero 2026','2026-01-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3592,'557',45,'Febrero 2026','2026-02-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3593,'557',45,'Marzo 2026','2026-03-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3594,'558-709',45,'Abril 2026','2026-04-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3595,'709',45,'Mayo 2026','2026-05-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3596,'709',45,'Junio 2026','2026-06-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3597,'709',45,'Julio 2026','2026-07-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3598,'709',45,'Agosto 2026','2026-08-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3599,'709',45,'Septiembre 2026','2026-09-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3600,'709',45,'Octubre 2026','2026-10-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3601,'591',46,'Enero 2026','2026-01-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3602,'669',46,'Febrero 2026','2026-02-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3603,'706',46,'Marzo 2026','2026-03-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3604,'732',46,'Abril 2026','2026-04-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3605,'555',47,'Enero 2026','2026-01-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3606,'555',47,'Febrero 2026','2026-02-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3607,'650',47,'Marzo 2026','2026-03-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3608,'720',47,'Abril 2026','2026-04-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3609,'720',47,'Mayo 2026','2026-05-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3610,'662',48,'Enero 2026','2026-01-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3611,'662',48,'Febrero 2026','2026-02-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3612,'662',48,'Marzo 2026','2026-03-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3613,'713',48,'Abril 2026','2026-04-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3614,'714',48,'Mayo 2026','2026-05-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3615,'605',49,'Enero 2026','2026-01-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3616,'605',49,'Febrero 2026','2026-02-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3617,'705',49,'Marzo 2026','2026-03-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3618,'561',50,'Enero 2026','2026-01-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3619,'561',50,'Febrero 2026','2026-02-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3620,'731',50,'Marzo 2026','2026-03-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3621,'731',50,'Abril 2026','2026-04-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3622,'559',51,'Enero 2026','2026-01-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3623,'559',51,'Febrero 2026','2026-02-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3624,'730',51,'Marzo 2026','2026-03-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3625,'730',51,'Abril 2026','2026-04-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3626,'730',51,'Mayo 2026','2026-05-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3627,'730',51,'Junio 2026','2026-06-01',60.00,'e¿djkasn','2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3628,'632',52,'Enero 2026','2026-01-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3629,'719',52,'Febrero 2026','2026-02-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3630,'719',52,'Marzo 2026','2026-03-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3631,'727',52,'Abril 2026','2026-04-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3632,'592',53,'Enero 2026','2026-01-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3633,'678',53,'Febrero 2026','2026-02-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3634,'585',54,'Enero 2026','2026-01-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3635,'585',54,'Febrero 2026','2026-02-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3636,'679',54,'Marzo 2026','2026-03-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3637,'679',54,'Abril 2026','2026-04-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3638,'679',54,'Mayo 2026','2026-05-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3639,'671',55,'Enero 2026','2026-01-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3640,'671',55,'Febrero 2026','2026-02-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3641,'552',56,'Enero 2026','2026-01-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3642,'661',56,'Febrero 2026','2026-02-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3643,'661',56,'Marzo 2026','2026-03-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3644,'553',57,'Enero 2026','2026-01-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3645,'676',57,'Febrero 2026','2026-02-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3646,'702',57,'Marzo 2026','2026-03-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3647,'572',58,'Enero 2026','2026-01-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3648,'628',58,'Febrero 2026','2026-02-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3649,'688',58,'Marzo 2026','2026-03-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3650,'573',59,'Enero 2026','2026-01-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3651,'629',59,'Febrero 2026','2026-02-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3652,'689',59,'Marzo 2026','2026-03-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3653,'588',60,'Enero 2026','2026-01-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3654,'643',60,'Febrero 2026','2026-02-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3655,'695',60,'Marzo 2026','2026-03-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3656,'695',60,'Abril 2026','2026-04-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3657,'616',62,'Enero 2026','2026-01-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3658,'685',62,'Febrero 2026','2026-02-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3659,'642',63,'Enero 2026','2026-01-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3660,'642',63,'Febrero 2026','2026-02-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3661,'642',63,'Marzo 2026','2026-03-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3662,'642',63,'Abril 2026','2026-04-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3663,'575',64,'Enero 2026','2026-01-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3664,'575',64,'Febrero 2026','2026-02-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3665,'576',64,'Marzo 2026','2026-03-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3666,'696',64,'Abril 2026','2026-04-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3667,'696',64,'Mayo 2026','2026-05-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3668,'587',65,'Enero 2026','2026-01-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3669,'635',65,'Febrero 2026','2026-02-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3670,'686',65,'Marzo 2026','2026-03-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3671,'617',66,'Enero 2026','2026-01-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3672,'615',67,'Enero 2026','2026-01-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3673,'615',67,'Febrero 2026','2026-02-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3674,'664',68,'Enero 2026','2026-01-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3675,'664',68,'Febrero 2026','2026-02-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3676,'664',68,'Marzo 2026','2026-03-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3677,'618',69,'Enero 2026','2026-01-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3678,'618',69,'Febrero 2026','2026-02-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3679,'698',69,'Marzo 2026','2026-03-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3680,'603',70,'Enero 2026','2026-01-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3681,'644',70,'Febrero 2026','2026-02-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3682,'673',70,'Marzo 2026','2026-03-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3683,'700',70,'Abril 2026','2026-04-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3684,'604',71,'Enero 2026','2026-01-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3685,'645',71,'Febrero 2026','2026-02-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3686,'674',71,'Marzo 2026','2026-03-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3687,'701',71,'Abril 2026','2026-04-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3688,'613',72,'Enero 2026','2026-01-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3689,'641',72,'Febrero 2026','2026-02-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3690,'715',72,'Marzo 2026','2026-03-01',60.00,NULL,'2026-05-04 01:49:15',0.00,NULL,0,NULL,NULL),(3691,'733',61,'Enero - Febrero','2026-05-03',120.00,NULL,'2026-05-04 01:54:00',0.00,NULL,0,NULL,NULL),(3692,'734',1,'Julio','2026-05-04',60.00,NULL,'2026-05-04 18:49:28',0.00,NULL,0,NULL,NULL),(3693,'735',9,'Marzo - Abril','2026-05-04',120.00,NULL,'2026-05-04 18:51:09',0.00,NULL,0,NULL,NULL),(3694,'736',3,'Marzo - Abril','2026-05-04',120.00,NULL,'2026-05-04 18:51:21',0.00,NULL,0,NULL,NULL),(3695,'737',14,'Marzo - Abril - Mayo','2026-05-04',180.00,NULL,'2026-05-04 18:51:32',0.00,NULL,0,NULL,NULL),(3696,'738',75,'inscripcion','2026-05-04',100.00,NULL,'2026-05-04 18:53:31',0.00,NULL,0,NULL,NULL),(3697,'739',17,'Abril','2026-05-05',60.00,NULL,'2026-05-05 14:32:10',0.00,NULL,0,NULL,NULL),(3698,'740',53,'Marzo - Abril - Mayo - Junio','2026-05-06',240.00,NULL,'2026-05-06 23:22:26',0.00,NULL,0,NULL,NULL),(3699,'741',1,'Cuota de inscripción','2026-05-06',100.00,'Cuota de inscripción','2026-05-06 23:49:57',0.00,NULL,0,NULL,NULL),(3700,'742',53,'ANULADO — Julio','2026-05-06',60.00,'ANULADO','2026-05-07 00:06:47',0.00,NULL,1,'2026-05-07 00:15:30',NULL),(3701,'743',53,'ANULADO — Julio - Agosto - Septiembre - Octubre - Noviembre','2026-05-06',300.00,'ANULADO','2026-05-07 00:16:01',0.00,NULL,1,'2026-05-07 00:16:18',NULL),(3702,'744',53,'Agosto','2026-05-06',60.00,NULL,'2026-05-07 01:03:23',0.00,NULL,0,NULL,NULL);
/*!40000 ALTER TABLE `recibos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recibos_diplomados`
--

DROP TABLE IF EXISTS `recibos_diplomados`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `recibos_diplomados` (
  `id` int NOT NULL AUTO_INCREMENT,
  `no_recibo` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `alumno_id` int DEFAULT NULL,
  `diplomado` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `descripcion` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `total` decimal(10,2) DEFAULT NULL,
  `observaciones` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recibos_diplomados`
--

LOCK TABLES `recibos_diplomados` WRITE;
/*!40000 ALTER TABLE `recibos_diplomados` DISABLE KEYS */;
INSERT INTO `recibos_diplomados` VALUES (1,'1',37,NULL,'Certificado TAC 2025','2025-09-25',25.00,NULL,'2026-05-03 21:00:46'),(2,'2',35,NULL,'Certificado TAC 2025','2025-09-25',25.00,NULL,'2026-05-03 21:00:46'),(3,'3',28,NULL,'Certificado TAC 2025','2025-09-25',25.00,NULL,'2026-05-03 21:00:46'),(4,'4',45,NULL,'Certificado TAC 2025','2025-09-25',25.00,NULL,'2026-05-03 21:00:46'),(5,'5',29,NULL,'Certificado TAC 2025','2025-09-25',25.00,NULL,'2026-05-03 21:00:46'),(6,'6',38,NULL,'Certificado TAC 2025','2025-09-25',25.00,NULL,'2026-05-03 21:00:46'),(7,'7',24,NULL,'Certificado TAC 2025','2025-09-25',25.00,NULL,'2026-05-03 21:00:46'),(8,'8',50,NULL,'Certificado TAC 2025','2025-09-25',25.00,NULL,'2026-05-03 21:00:46'),(9,'9',9,NULL,'Certificado TAC 2025','2025-09-26',25.00,NULL,'2026-05-03 21:00:46'),(10,'10',11,NULL,'Certificado TAC 2025','2025-09-26',25.00,NULL,'2026-05-03 21:00:46'),(11,'11',20,NULL,'Certificado TAC 2025','2025-09-27',25.00,NULL,'2026-05-03 21:00:46'),(12,'12',16,NULL,'Certificado TAC 2025','2025-09-27',25.00,NULL,'2026-05-03 21:00:46'),(13,'13',56,NULL,'Certificado TAC 2025','2025-10-04',25.00,NULL,'2026-05-03 21:00:46'),(14,'14',39,NULL,'Certificado TAC 2025','2025-10-04',25.00,NULL,'2026-05-03 21:00:46'),(15,'15',54,NULL,'Certificado TAC 2025','2025-10-04',25.00,NULL,'2026-05-03 21:00:46'),(16,'16',42,NULL,'Certificado TAC 2025','2025-10-04',25.00,NULL,'2026-05-03 21:00:46'),(17,'17',44,NULL,'Certificado TAC 2025','2025-10-04',25.00,NULL,'2026-05-03 21:00:46'),(18,'18',17,NULL,'Certificado TAC 2025','2025-10-09',25.00,NULL,'2026-05-03 21:00:46'),(19,'19',14,NULL,'Certificado TAC 2025','2025-10-09',25.00,NULL,'2026-05-03 21:00:46'),(20,'20',18,NULL,'Certificado TAC 2025','2025-10-09',25.00,NULL,'2026-05-03 21:00:46'),(21,'21',8,NULL,'Certificado TAC 2025','2025-10-09',25.00,NULL,'2026-05-03 21:00:46'),(22,'22',21,NULL,'Certificado TAC 2025','2025-10-09',25.00,NULL,'2026-05-03 21:00:46'),(23,'23',10,NULL,'Certificado TAC 2025','2025-10-09',25.00,NULL,'2026-05-03 21:00:46'),(24,'24',30,NULL,'Certificado TAC 2025','2025-10-09',25.00,NULL,'2026-05-03 21:00:46'),(25,'25',1,NULL,'Certificado TAC 2025','2025-10-09',25.00,NULL,'2026-05-03 21:00:46'),(26,'26',33,NULL,'Certificado TAC 2025','2025-10-09',25.00,NULL,'2026-05-03 21:00:46'),(27,'27',36,NULL,'Certificado TAC 2025','2025-10-09',25.00,NULL,'2026-05-03 21:00:46'),(28,'28',13,NULL,'Certificado TAC 2025','2025-10-09',25.00,NULL,'2026-05-03 21:00:46'),(29,'29',4,NULL,'Certificado TAC 2025','2025-10-09',25.00,NULL,'2026-05-03 21:00:46'),(30,'32',5,NULL,'Certificado TAC 2025','2025-10-09',25.00,NULL,'2026-05-03 21:00:46'),(31,'33',7,NULL,'Certificado TAC 2025','2025-10-09',25.00,NULL,'2026-05-03 21:00:46'),(32,'34',31,NULL,'Certificado TAC 2025','2025-10-11',25.00,NULL,'2026-05-03 21:00:46'),(33,'36',3,NULL,'Certificado TAC 2025','2025-10-13',25.00,NULL,'2026-05-03 21:00:46'),(34,'37',2,NULL,'Certificado TAC 2025','2025-10-13',25.00,NULL,'2026-05-03 21:00:46'),(35,'38',51,NULL,'Certificado TAC 2025','2025-10-18',25.00,NULL,'2026-05-03 21:00:46'),(36,'39',49,NULL,'Certificado TAC 2025','2025-10-18',25.00,NULL,'2026-05-03 21:00:46'),(37,'40',47,NULL,'Certificado TAC 2025','2025-10-18',25.00,NULL,'2026-05-03 21:00:46'),(38,'41',48,NULL,'Certificado TAC 2025','2025-10-18',25.00,NULL,'2026-05-03 21:00:46'),(39,'42',46,NULL,'Certificado TAC 2025','2025-10-18',25.00,NULL,'2026-05-03 21:00:46'),(40,'43',52,NULL,'Certificado TAC 2025','2025-10-19',25.00,NULL,'2026-05-03 21:00:46'),(41,'44',32,NULL,'Certificado TAC 2025','2025-10-19',25.00,NULL,'2026-05-03 21:00:46'),(42,'46',53,NULL,'Certificado TAC 2025','2025-11-07',25.00,NULL,'2026-05-03 21:00:46'),(43,'47',40,NULL,'Certificado TAC 2025','2025-11-07',25.00,NULL,'2026-05-03 21:00:46'),(44,'49',55,NULL,'Certificado TAC 2025','2025-11-07',25.00,NULL,'2026-05-03 21:00:46'),(45,'50',43,NULL,'Certificado TAC 2025','2025-11-07',25.00,NULL,'2026-05-03 21:00:46'),(46,'52',58,NULL,'Certificado TAC 2025','2025-11-09',25.00,NULL,'2026-05-03 21:00:46'),(47,'54',22,NULL,'Certificado TAC 2025','2025-11-09',25.00,NULL,'2026-05-03 21:00:46'),(48,'55',57,NULL,'Certificado TAC 2025','2025-11-09',25.00,NULL,'2026-05-03 21:00:46'),(49,'56',26,NULL,'Certificado TAC 2025','2025-11-15',25.00,NULL,'2026-05-03 21:00:46');
/*!40000 ALTER TABLE `recibos_diplomados` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuarios` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rol` enum('admin','alumno','oficina','maestro') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'alumno',
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=78 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuarios`
--

LOCK TABLES `usuarios` WRITE;
/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
INSERT INTO `usuarios` VALUES (1,'Admin TestImport1','admin@test.com','$2b$10$3PmD43.NcbIPQUtuL3nYL.xR7ZUPGStKe3ozPmF9he2OHpKlz2T.i','admin',1,'2026-05-03 14:33:43'),(2,'Hernandez Cabrera Hazel Daniela','hernandez1','$2b$10$RMDHzfETy1ZlFO9mk2DjdOpUBY5vESFEmq2venuSQi5.4fAouqbX6','alumno',1,'2026-05-03 15:28:12'),(3,'De Leon Gomez Cecilia','de2','$2b$10$Wsa9NyaI9VOH2vMpmmGovOOxJfuGdaB/9PFk/yNdmNwbazXwEVmKq','alumno',1,'2026-05-03 15:28:12'),(4,'Juarez de Leon Miguel de Jesus','juarez3','$2b$10$LisrzSxUvQKSXWjOqf72X.ZlJZw86vTLwIg0VnIjSn8Ognr87To/e','alumno',1,'2026-05-03 15:28:12'),(5,'Lara Tiu Natalia Lucita','lara4','$2b$10$RdaP.7h56Xp/qDm.CxJss.k4yVcNKRt1BzYKyahm0HZ/6u8YKMDLe','alumno',1,'2026-05-03 15:28:12'),(6,'Estrada del Toro Diego Alejandro','estrada5','$2b$10$7qr/0UxaT/IMAOWvt5unJu2A0VLm6nHhn5gkSpz60z4Radl9ahqsm','alumno',1,'2026-05-03 15:28:12'),(7,'Cuyuch Domiguez Sergio Ottoniel','cuyuch6','$2b$10$ni2WTjjyFsT9V9NkE4Y6ouSuiufp6I2B8dxx8ASYyJTA5yMwuLlRe','alumno',1,'2026-05-03 15:28:12'),(8,'Garcia Perez Jorge Danilo','garcia7','$2b$10$WL0xZI3SS.k5Eqlk8gk.te/olY9bJ8GGixnkvEtILkF5Oktyf6bKG','alumno',1,'2026-05-03 15:28:12'),(9,'Chavez Lorenzo Yeimi Josefina','chavez8','$2b$10$oHJbtTebureFm5iqnqMgpu/MC6IJL215Jrlymg42liLY5TFW4J9UG','alumno',1,'2026-05-03 15:28:12'),(10,'Perez Perez Milton Aron','perez9','$2b$10$9X80Zy5JAatDg5P4zHPpMuG2o2Kx69C5rA1nfnuIlYfKU/J/5WVBC','alumno',1,'2026-05-03 15:28:13'),(11,'Shlaj Lucas Eduardo Apolinario','shlaj10','$2b$10$qWI0GyVhJHDhlWJKrVOgQOecRBAOIWQ2puph5i1nsjCaMCW6rf1Om','alumno',1,'2026-05-03 15:28:13'),(12,'Juarez Lucas Alison Alondra','juarez11','$2b$10$We7DJ5FmTUTX5IkMTZ16F.jSz4wWdO1xFZWD9jZZhHy//hjW4nnCi','alumno',1,'2026-05-03 15:28:13'),(13,'Velasquez Cabrera Elisa Lisbeth','velasquez12','$2b$10$bqvO76LNvbBP5r1OLGDPluDi/s.edfKDX8B53QviWWkner.uVVMm6','alumno',1,'2026-05-03 15:28:13'),(14,'Suchite Cabrera Cristian Wilfredo','suchite13','$2b$10$tLKi3LRCBrFsVESZ4Exame5OqzCJDyCPAmbMaCapiZMxV2/O5LxAK','alumno',1,'2026-05-03 15:28:13'),(15,'Cabrera Giron Doris Aimar','cabrera14','$2b$10$sqeiwzLStbXhnKR/0a5NJ.vmR1EziVxjH8ZzYqsvYs7g4yQMpuhkq','alumno',1,'2026-05-03 15:28:13'),(16,'Orozco Rojas Elmer Nehemias','orozco15','$2b$10$jQ4n9i3u0.ngAlZIT2jUGOBhqNqYP.XeG.teQjlSG/i0SPt4Sy9Fe','alumno',1,'2026-05-03 15:28:13'),(17,'Castillo Ovalle Jade Maria','castillo16','$2b$10$.qlC.y2yoV5y91E3YxYMbOeZ.VkzlVp6uWZFmmJwLtaHFyZ0yFQcK','alumno',1,'2026-05-03 15:28:13'),(18,'Garcia Romero Ivana Jassmin','garcia17','$2b$10$TUIg0heZxC2U/f65gaIl4OW1HfuBIaBzK4DcP3IVMKUVxWz.JVQfK','alumno',1,'2026-05-03 15:28:13'),(19,'De Paz Fuentes Angel Ferreyn','de18','$2b$10$yBhuskuU5Kd.YdVZjydpRe8teTQXQpcad0DHIsZAiMVedCUvzlcbW','alumno',1,'2026-05-03 15:28:13'),(20,'Molina Guillermo Lucas','molina19','$2b$10$gy/eedl0TrJ0Oy88DHX.v.F3SEPywDJXVcs/2I.SkvSTOPXxcC/Ey','alumno',1,'2026-05-03 15:28:14'),(21,'Cigarroa Barrios Angel David','cigarroa20','$2b$10$86CVjvXv0rISceMdLExbg.Ng3gA7qyr0TxuuDxC76a2Rx6gcUNzju','alumno',1,'2026-05-03 15:28:14'),(22,'Jimenez Perez Antonio Isai','jimenez21','$2b$10$ZK9QMLxPNtc29wVzPHqtgOqTiZu6VIMBvMXm8SiZj7kkOMWp5pq8W','alumno',1,'2026-05-03 15:28:14'),(23,'Contreras Lopez Sergio Alexander','contreras22','$2b$10$DIRJ1K9hAzBLND2KVsNPVO19uSRWsOiKDGQXt89MkNnK7la0EuWTK','alumno',1,'2026-05-03 15:28:14'),(24,'Rojop Garcia Fatima Nalleli','rojop23','$2b$10$H22Uqo5bmQrlKrdQ44doNOjteXm787ofkxwo1F7TKS0HFRyeUY3la','alumno',1,'2026-05-03 15:28:14'),(25,'Lara Lopez Gerson Elias','lara24','$2b$10$r4W0HBpXhxHmXYa.yTFMIu0rKzbKoUMODMhjF4mq.QUKNbWE.S.HO','alumno',1,'2026-05-03 15:28:14'),(26,'Cuyuch Ordoñez Estefani Yoana','cuyuch25','$2b$10$XopOoiWZADk026YbVHxbyO9JdhNNFjvdwUhvoZvjJOaFwXADsqZJ2','alumno',1,'2026-05-03 15:28:14'),(27,'Lopez Ramirez Nestor Antonio','lopez26','$2b$10$y6MK.kxGckF5T8vhsxVGT.5sLnAMZW2kg10DI/GhrZGvOYBtW8A.S','alumno',1,'2026-05-03 15:28:14'),(28,'Cabrera Lopez Brayan Yobani','cabrera27','$2b$10$nNfGSHonqZjRvhhlp292.e6Ikl2qgSG9PMfToxozfieYaY8ovg.Sa','alumno',1,'2026-05-03 15:28:14'),(29,'Sales Garcia Kervin Ventura','sales28','$2b$10$RZUhMJc33oxf/UYq9T94x.AJezwfK8NfFr8duDhYTnAHbYI06EXXe','alumno',1,'2026-05-03 15:28:14'),(30,'Velasquez Meza Katerin Elizani','velasquez29','$2b$10$/KQp8u6hKOOL2hRjfOkjYOjJV0X885nybPYfz2UOIYbgYWP/h73qG','alumno',1,'2026-05-03 15:28:14'),(31,'Vasquez Paxtor Juan Miguel','vasquez30','$2b$10$i7m36groitH34UF1WAb8f.Pcy8HPc16C0Htv2/fJii8PQR9v10ZQO','alumno',1,'2026-05-03 15:28:15'),(32,'Pablo de Leon Ricardo Alberto','pablo31','$2b$10$XisbEN6NuOZD5WK..xtM8uCxGFJCMzH99fjrRSjn5he9yLShUy8h6','alumno',1,'2026-05-03 15:28:15'),(33,'Vicente Perez Neftali Odiel','vicente32','$2b$10$956Rba8gX/RrnYU5ouSLZ.7jJhHzMJtF8Abt5ngiLGGEVWKSC0i7G','alumno',1,'2026-05-03 15:28:15'),(34,'Vicente Diaz Nataly Celeste','vicente33','$2b$10$7UqZWyN.o9AAzpcFZ.1tXuTYZMFiRdo58LC/FPwkC8.ZFHLxqueTy','alumno',1,'2026-05-03 15:28:15'),(35,'Gomez Maria Ines','gomez34','$2b$10$L/0gLRTpQrfCITppqomHuuKLBz7bl2HCD3JaY8Ot8KyFp1srFigq2','alumno',1,'2026-05-03 15:28:15'),(36,'Molina Perez Diana Aurora','molina35','$2b$10$SN5spwsK.p.1Kfkd2psx0eW0Jve97jE327M1anoKJskIzU5qE7sCG','alumno',1,'2026-05-03 15:28:15'),(37,'de Leon Molina Marvin Estuardo','de36','$2b$10$NloQ9LwJmI0ttjB77vBax.chVnatJeTRgYSr534vaxVcqtFV5eB9O','alumno',1,'2026-05-03 15:28:15'),(38,'Perez Orozco Lilian Delfina','perez37','$2b$10$gj9nax/TfVfEr7vUJbrgVe895VHgDpybpERJYVX6DqLH3CoH2SfK2','alumno',1,'2026-05-03 15:28:15'),(39,'Chavalan Jasinto Jose Enrique','chavalan38','$2b$10$/Uuu6UfQT4wi76/HsBrQceLJGMVmyoSDtQ6KhppGHx6R6VylBnQNa','alumno',1,'2026-05-03 15:28:15'),(40,'Gonzalez Maldonado Jorge Daniel','gonzalez39','$2b$10$HafJJz1dg6Z8.lQnitNazuTX1o0cpvdZI7uvbFSQ3dm0xNcdHboPS','alumno',1,'2026-05-03 15:28:15'),(41,'Guzman Gomez Walfred Antonio','guzman40','$2b$10$ZtNpZCT3O8lPEDVgXNYyWOkxGbhvk6BR1sVDggrKTLMxlBY9vAM6u','alumno',1,'2026-05-03 15:28:16'),(42,'Garcia Porrez Marilin Selyna','garcia41','$2b$10$snh/4sitqa97l1BA487rve8gXQA5Adzx9R569jdPbmtFEKXAltlGO','alumno',1,'2026-05-03 15:28:16'),(43,'Garcia Mendez Marelin Yoseni','garcia42','$2b$10$/s0Xwl1Q0X.IkkMjd8sjw.0AGfVHgUGFUdS0g2yiwT.4wYk4QYX4y','alumno',1,'2026-05-03 15:28:16'),(44,'Ramirez Perez Delsy Liliana','ramirez43','$2b$10$xHseFgWNlDkhdpGA3Tozqev1YceMa0uikOOAhO4YpFC0LssT8hETO','alumno',1,'2026-05-03 15:28:16'),(45,'Mendez Vasquez Sheily Maritza','mendez44','$2b$10$WOERMso8eqj23eLvzDJqcuRQol5vO8BVF2OGlvHBF.vTvlqNzrOmu','alumno',1,'2026-05-03 15:28:16'),(46,'Cabrera Alonzo Emelin Azucena','cabrera45','$2b$10$FqGR4ba.PjqH3wQx.CLmOuzpRH6QLAjbQH5E8SAZIbCDDwLA8aPqq','alumno',1,'2026-05-03 15:28:16'),(47,'Lopez Lopez Angel Abraham','lopez46','$2b$10$zTXhqT0ogIcQN0RofFwr3.bseM9A/Hq5ulPNsCYJgBWkH70KI/bGm','alumno',1,'2026-05-03 15:28:16'),(48,'Perez Ines','perez47','$2b$10$2nosBBM8RznSqVXgGFJE3.2Vls2ZiMOVHW1qU/5LxHLgAbRZDFwsa','alumno',1,'2026-05-03 15:28:16'),(49,'Giron Mendez Jean Carlos','giron48','$2b$10$cMK9D5Z483Ukge3JtmI9VeH/XKSD3G07Fz0Gcc6quf8qw5qH8dhdy','alumno',1,'2026-05-03 15:28:16'),(50,'Molina Vasquez Lesly Yasmin','molina49','$2b$10$W67TJCvFwvwRWCKsDYmKjeUmNgosdXwjZ5hDF//sKY8Pu30AKa492','alumno',1,'2026-05-03 15:28:16'),(51,'Lopez Garcia Eduardo Alberto','lopez50','$2b$10$PVxCSRg9jEE1AUu6KHL6kedMwoCR1Wvoox9KUf6yWEKAsGROuJ3/K','alumno',1,'2026-05-03 15:28:17'),(52,'Garcia Perez Nancy Marisol','garcia51','$2b$10$LIup0IC8ou36y0S8YlTYdODh.Cf.Ns/DSePlu9oq1oKF4uetFn.uC','alumno',1,'2026-05-03 15:28:17'),(53,'Alonzo Lopez Francis Noe Misael','alonzo52','$2b$10$yRcUXCDXibHKWKBu5sTPa.nb5NcGgKCg7cVjhMYmI/N5PJflmXHLW','alumno',1,'2026-05-03 15:28:17'),(54,'Rojop Dominguez Juan Miguel','rojop53','$2b$10$DvEZgvII8hkVBaTFMhaQBeUVXNGt3W3oDtZodu8DQWtWgwXiO/A5i','alumno',1,'2026-05-03 15:28:17'),(55,'Vasquez Perez Adriana Marisol','vasquez54','$2b$10$IrQCMWPu1Riow7y.v5s8KufDyVIaL9yf748vuz9NE8U97larSlknu','alumno',1,'2026-05-03 15:28:17'),(56,'Cruz Vicente Jimena Dayana','cruz55','$2b$10$3lurlgZlVqRB4xvVnP1xCuvyufADkM6Dr7/R24w0Vx2DujAtS9Lea','alumno',1,'2026-05-03 15:28:17'),(57,'Jimenez Gomez Byron Jeremias','jimenez56','$2b$10$TmznzYPyMGYjKztbIHE0ruuQBdCEhfZyTdhHlvckWR/GAKt0rgBcS','alumno',1,'2026-05-03 15:28:17'),(58,'Contreras Lopez Rosa Leticia','contreras57','$2b$10$f8Ua2Q/GvWqLUhnPFHthWuBljPjyOIkZ7mRkbL8OYcYtQOfxEGtZm','alumno',1,'2026-05-03 15:28:17'),(59,'Castillo Coy Emilia Elizabeth','castillo58','$2b$10$eBEKOwwr83g9jT4f8/JJDOkLYb.ikglXzUAzKzkAOYpaAo6Fsb9Zu','alumno',1,'2026-05-03 15:28:17'),(60,'Castillo Coy Evelyn Marleny','castillo59','$2b$10$0iIPNoQbQJ1SIFhq2IgQuev60CF/9P1BET9pVdsx/rkIwHP9Q1MAa','alumno',1,'2026-05-03 15:28:17'),(61,'Lopez Lucas Blanca Azucena','lopez60','$2b$10$I0UFTBplsgcsdYc9J.flnOi7Th8Ud4mnXI7NFcrXJuRTM4uicAYlO','alumno',1,'2026-05-03 15:28:18'),(62,'Felipe Gomez Jaqueline Mauricia','felipe61','$2b$10$/Bux.2gYbwFor.Q66JGK7ei5yo4QwVLODwHdV1UDwGTU2EGK5UQvS','alumno',1,'2026-05-03 15:28:18'),(63,'Macario Vicente Yeimi Roxana','macario62','$2b$10$ZQux0Sh5p.n7MpKAkfsYJusPsCC.B7xhO9goh9oj1Q155nkcvKyn6','alumno',1,'2026-05-03 15:28:18'),(64,'Galindo Chavez Julia Amparo','galindo63','$2b$10$zP98Bp8WVDep5PCzNZKASeQwnH4Yb0.MWPI/nqp7Qu4j.mieMgqF.','alumno',1,'2026-05-03 15:28:18'),(65,'Molina Sofia Joanna','molina64','$2b$10$ksnlu/lW5xBnOy3J/T89h.cM3h/78QMimQuYQMW1bgUu9I8bI9zDy','alumno',1,'2026-05-03 15:28:18'),(66,'Juarez Maria Lucas','juarez65','$2b$10$bbNaBxBrXAa.IaJZetVOuu3YupVKdcOpjikK1yMnom5ylIzD.HvFq','alumno',1,'2026-05-03 15:28:18'),(67,'Ramirez Lopez Crisbel Maricruz','ramirez66','$2b$10$CXiIGuvYdv989X8pqM8jI.Tzuv6amHWxj/5ziy57muvK8RkTgpSlO','alumno',1,'2026-05-03 15:28:18'),(68,'Bonilla Garcia Lea Raquel','bonilla67','$2b$10$lxOfaSZOdoDzl7w4nYtbBOJ/E41Z5svRes3NB98NC7rVAZaPfxBXS','alumno',1,'2026-05-03 15:28:18'),(69,'Garcia Lopez Hernan Alexander','garcia68','$2b$10$Q1jLRK.t2V.tR96vu93/COtp4Ndr/ennbIgJz4rJW1BU3JO8uNijC','alumno',1,'2026-05-03 15:28:18'),(70,'Gomez Dueñas Jose Emanuel','gomez69','$2b$10$2A7Ac019c9s.3fh7yqnSVeM77AMJel0YrDc05EPTHZNYmkLJIuSbi','alumno',1,'2026-05-03 15:28:18'),(71,'Melchor Garcia Elias Daniel','melchor70','$2b$10$rwRMRn6Nz5t2xBVao75ejOaTryneQkzaLT6cVg94fY2i4GOV6atXS','alumno',1,'2026-05-03 15:28:19'),(72,'Soto Melchor Alexi Esai','soto71','$2b$10$CdsFQdDMgTTLrLrzPwCrt.8wcqvMb.WZG2zuRUE1fdDYt6Z3RzBTu','alumno',1,'2026-05-03 15:28:19'),(73,'Mendoza Castillo Andrea Elizabeth','mendoza72','$2b$10$DUE3GnxGEpeqfielj.nVwOk12uAbeEzqHugUkMSe3FtMhUf5uyFwm','alumno',1,'2026-05-03 15:28:19'),(74,'Berduo Lopez Kevin Enrique','berduo73','$2b$10$hrQAr5/gVyi7DEc1LhvHBuZFBXJ5mD1rAW8O2EBUFIPnN0JQsvHIm','alumno',1,'2026-05-03 15:28:19'),(75,'Lopez Hernandez Esperanza Isabel','lopez74','$2b$10$fyoKQ147zLZHkTzi.fTDg.Of9J23jloUZ.LE3W.VLZoNlcykCQlry','alumno',1,'2026-05-03 15:28:19'),(76,'Rony Castllo','rony75','$2b$10$5CgrOWVx/bP/I6rcbOqPZ.MKam19LA2/WpuDgwBifxRzJs5zZmYJy','alumno',1,'2026-05-04 18:52:48'),(77,'Rony','rony123@gmail.com','$2b$10$0jQB2wmHrH0SbIU2FMCJUOVggIJLJHAFkcVwDDyZT4j0hIcQLMkn.','oficina',1,'2026-05-04 19:07:20');
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'testimport1'
--

--
-- Dumping routines for database 'testimport1'
--

--
-- Current Database: `sistec_jalapa`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `sistec_jalapa` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `sistec_jalapa`;

--
-- Table structure for table `alumnos`
--

DROP TABLE IF EXISTS `alumnos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `alumnos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `clave` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `codigo_estudiante` varchar(7) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nombre` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `apellido` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fecha_inicio` date DEFAULT NULL,
  `fecha_nacimiento` date DEFAULT NULL,
  `encargado` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `telefono` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `diplomado` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tac` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `asesor` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `direccion` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `establecimiento` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `observaciones` text COLLATE utf8mb4_unicode_ci,
  `dia_clases1` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dia_clases2` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `horario` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `laboratorio` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `estado` enum('activo','inactivo','retirado') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'activo',
  `cuota_mensual` decimal(10,2) NOT NULL DEFAULT '0.00',
  `usuario_id` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `clave` (`clave`),
  UNIQUE KEY `codigo_estudiante` (`codigo_estudiante`),
  CONSTRAINT `chk_codigo_estudiante` CHECK (((`codigo_estudiante` is null) or regexp_like(`codigo_estudiante`,_utf8mb4'^[A-Z][0-9]{3}[A-Z]{3}$')))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alumnos`
--

LOCK TABLES `alumnos` WRITE;
/*!40000 ALTER TABLE `alumnos` DISABLE KEYS */;
INSERT INTO `alumnos` VALUES (1,'1','D721DZY','Rony Alexander','Castillo','2026-02-02','2004-08-04','Rony Castillo','54341561','Operador Windows','1','Ronaldo Garcia','Barrio san Jose Genova','Instituto Kjell','','lunes',NULL,'07:00 a 12:00','','activo',80.00,2,'2026-05-04 17:39:22');
/*!40000 ALTER TABLE `alumnos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `asistencia_semanal`
--

DROP TABLE IF EXISTS `asistencia_semanal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `asistencia_semanal` (
  `id` int NOT NULL AUTO_INCREMENT,
  `alumno_id` int NOT NULL,
  `anio` smallint NOT NULL,
  `mes` tinyint NOT NULL,
  `semana` tinyint NOT NULL,
  `estado` char(1) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_asist_sem` (`alumno_id`,`anio`,`mes`,`semana`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `asistencia_semanal`
--

LOCK TABLES `asistencia_semanal` WRITE;
/*!40000 ALTER TABLE `asistencia_semanal` DISABLE KEYS */;
INSERT INTO `asistencia_semanal` VALUES (1,1,2026,1,1,'x'),(2,1,2026,1,2,'r'),(3,1,2026,1,3,'e'),(4,1,2026,1,4,'p'),(5,1,2026,2,1,'f');
/*!40000 ALTER TABLE `asistencia_semanal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `avisos`
--

DROP TABLE IF EXISTS `avisos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `avisos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `autor_id` int DEFAULT NULL,
  `autor_nombre` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `autor_rol` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `titulo` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mensaje` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `scope` enum('global','horario','laboratorio','diplomado','dia','alumno') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'global',
  `filtro_dia` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `filtro_horario` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `filtro_laboratorio` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `filtro_diplomado` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `filtro_alumno_id` int DEFAULT NULL,
  `expira_at` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_avisos_scope` (`scope`),
  KEY `idx_avisos_expira` (`expira_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `avisos`
--

LOCK TABLES `avisos` WRITE;
/*!40000 ALTER TABLE `avisos` DISABLE KEYS */;
/*!40000 ALTER TABLE `avisos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bitacora`
--

DROP TABLE IF EXISTS `bitacora`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bitacora` (
  `id` int NOT NULL AUTO_INCREMENT,
  `usuario_id` int DEFAULT NULL,
  `usuario_nombre` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Sistema',
  `accion` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `modulo` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci,
  `ip` varchar(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bitacora`
--

LOCK TABLES `bitacora` WRITE;
/*!40000 ALTER TABLE `bitacora` DISABLE KEYS */;
INSERT INTO `bitacora` VALUES (1,1,'Admin Sistec Jalapa','crear','Catálogos','Horario: lunes 07:00 a 12:00','::1','2026-05-04 17:34:36'),(2,1,'Admin Sistec Jalapa','crear','Catálogos','Horario: martes 07:00 a 12:00','::1','2026-05-04 17:35:29'),(3,1,'Admin Sistec Jalapa','crear','Catálogos','Horario: lunes-martes 10:00 a 12:00','::1','2026-05-04 17:35:44'),(4,1,'Admin Sistec Jalapa','crear','Catálogos','nombre: 1','::1','2026-05-04 17:35:52'),(5,1,'Admin Sistec Jalapa','crear','Catálogos','nombre: Instituto Kjell','::1','2026-05-04 17:36:11'),(6,1,'Admin Sistec Jalapa','crear','Catálogos','nombre: No estudio','::1','2026-05-04 17:36:21'),(7,1,'Admin Sistec Jalapa','crear','Catálogos','Cuota: Q60 (—)','::1','2026-05-04 17:36:39'),(8,1,'Admin Sistec Jalapa','crear','Catálogos','Cuota: Q80 (—)','::1','2026-05-04 17:36:44'),(9,1,'Admin Sistec Jalapa','crear','Catálogos','Cuenta bancaria: Banrural 3646031711 (Ruth Noemi Pu Rojas)','::1','2026-05-04 17:37:30'),(10,1,'Admin Sistec Jalapa','crear','Alumnos','Alumno creado: Rony Alexander Castillo (clave 1, código D721DZY)','::1','2026-05-04 17:39:22'),(11,1,'Admin Sistec Jalapa','editar','Alumnos','Alumno editado ID 1: Rony Alexander Castillo','::1','2026-05-04 17:39:42'),(12,1,'Admin Sistec Jalapa','guardar','Asistencia','Asistencia guardada: 5 celdas año 2026','::1','2026-05-04 17:40:35');
/*!40000 ALTER TABLE `bitacora` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cat_cuentas_bancarias`
--

DROP TABLE IF EXISTS `cat_cuentas_bancarias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cat_cuentas_bancarias` (
  `id` int NOT NULL AUTO_INCREMENT,
  `numero_cuenta` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nombre` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo_cuenta` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cat_cuentas_bancarias`
--

LOCK TABLES `cat_cuentas_bancarias` WRITE;
/*!40000 ALTER TABLE `cat_cuentas_bancarias` DISABLE KEYS */;
INSERT INTO `cat_cuentas_bancarias` VALUES (1,'3646031711','Ruth Noemi Pu Rojas','Banrural',1,'2026-05-04 17:37:30');
/*!40000 ALTER TABLE `cat_cuentas_bancarias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cat_cuotas`
--

DROP TABLE IF EXISTS `cat_cuotas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cat_cuotas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `monto` decimal(10,2) NOT NULL,
  `descripcion` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cat_cuotas`
--

LOCK TABLES `cat_cuotas` WRITE;
/*!40000 ALTER TABLE `cat_cuotas` DISABLE KEYS */;
INSERT INTO `cat_cuotas` VALUES (1,60.00,'',1,'2026-05-04 17:36:39'),(2,80.00,'',1,'2026-05-04 17:36:44');
/*!40000 ALTER TABLE `cat_cuotas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cat_establecimientos`
--

DROP TABLE IF EXISTS `cat_establecimientos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cat_establecimientos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nombre` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cat_establecimientos`
--

LOCK TABLES `cat_establecimientos` WRITE;
/*!40000 ALTER TABLE `cat_establecimientos` DISABLE KEYS */;
INSERT INTO `cat_establecimientos` VALUES (1,'Instituto Kjell',1,'2026-05-04 17:36:11'),(2,'No estudio',1,'2026-05-04 17:36:21');
/*!40000 ALTER TABLE `cat_establecimientos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cat_horarios`
--

DROP TABLE IF EXISTS `cat_horarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cat_horarios` (
  `id` int NOT NULL AUTO_INCREMENT,
  `dia1` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dia2` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hora_inicio` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `hora_fin` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cat_horarios`
--

LOCK TABLES `cat_horarios` WRITE;
/*!40000 ALTER TABLE `cat_horarios` DISABLE KEYS */;
INSERT INTO `cat_horarios` VALUES (1,'lunes',NULL,'07:00','12:00',1,'2026-05-04 17:34:36'),(2,'martes',NULL,'07:00','12:00',1,'2026-05-04 17:35:29'),(3,'lunes','martes','10:00','12:00',1,'2026-05-04 17:35:44');
/*!40000 ALTER TABLE `cat_horarios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cat_laboratorios`
--

DROP TABLE IF EXISTS `cat_laboratorios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cat_laboratorios` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nombre` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cat_laboratorios`
--

LOCK TABLES `cat_laboratorios` WRITE;
/*!40000 ALTER TABLE `cat_laboratorios` DISABLE KEYS */;
INSERT INTO `cat_laboratorios` VALUES (1,'1',1,'2026-05-04 17:35:52');
/*!40000 ALTER TABLE `cat_laboratorios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cierre_gastos`
--

DROP TABLE IF EXISTS `cierre_gastos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cierre_gastos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `cierre_id` int NOT NULL,
  `descripcion` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `monto` decimal(10,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id`),
  KEY `idx_cierre_gastos` (`cierre_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cierre_gastos`
--

LOCK TABLES `cierre_gastos` WRITE;
/*!40000 ALTER TABLE `cierre_gastos` DISABLE KEYS */;
/*!40000 ALTER TABLE `cierre_gastos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cierres_diarios`
--

DROP TABLE IF EXISTS `cierres_diarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cierres_diarios` (
  `id` int NOT NULL AUTO_INCREMENT,
  `modulo` enum('recibos','papeleria') COLLATE utf8mb4_unicode_ci NOT NULL,
  `fecha` date NOT NULL,
  `total_dia` decimal(10,2) NOT NULL DEFAULT '0.00',
  `total_gastos` decimal(10,2) NOT NULL DEFAULT '0.00',
  `total_depositar` decimal(10,2) NOT NULL DEFAULT '0.00',
  `cuenta_id` int DEFAULT NULL,
  `cuenta_snapshot` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ultimo_recibo` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `observaciones` text COLLATE utf8mb4_unicode_ci,
  `estado` enum('pendiente','revisado') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pendiente',
  `creado_por_id` int DEFAULT NULL,
  `creado_por_nombre` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `revisado_por_id` int DEFAULT NULL,
  `revisado_por_nombre` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `revisado_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_cierre` (`modulo`,`fecha`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cierres_diarios`
--

LOCK TABLES `cierres_diarios` WRITE;
/*!40000 ALTER TABLE `cierres_diarios` DISABLE KEYS */;
/*!40000 ALTER TABLE `cierres_diarios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `config_pagos`
--

DROP TABLE IF EXISTS `config_pagos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `config_pagos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `anio` int NOT NULL,
  `scope_tipo` enum('global','diplomado','horario','laboratorio','dia','alumno') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'global',
  `scope_valor` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mes_inicio` tinyint NOT NULL,
  `mes_fin` tinyint NOT NULL,
  `multiplicador` decimal(4,2) NOT NULL DEFAULT '1.00',
  `descripcion` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_cfg_anio` (`anio`),
  KEY `idx_cfg_scope` (`scope_tipo`,`scope_valor`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `config_pagos`
--

LOCK TABLES `config_pagos` WRITE;
/*!40000 ALTER TABLE `config_pagos` DISABLE KEYS */;
/*!40000 ALTER TABLE `config_pagos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `configuracion`
--

DROP TABLE IF EXISTS `configuracion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `configuracion` (
  `id` int NOT NULL AUTO_INCREMENT,
  `clave` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `valor` text COLLATE utf8mb4_unicode_ci,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `clave` (`clave`)
) ENGINE=InnoDB AUTO_INCREMENT=157 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `configuracion`
--

LOCK TABLES `configuracion` WRITE;
/*!40000 ALTER TABLE `configuracion` DISABLE KEYS */;
INSERT INTO `configuracion` VALUES (1,'inst_nombre','EDUGUAT','2026-05-04 17:33:17'),(2,'inst_direccion','Ciudad de Guatemala, Guatemala','2026-05-04 17:33:17'),(3,'inst_telefono','Tel: 2222-3333','2026-05-04 17:33:17'),(4,'inst_email','','2026-05-04 17:33:17');
/*!40000 ALTER TABLE `configuracion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `constancia_plantillas`
--

DROP TABLE IF EXISTS `constancia_plantillas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `constancia_plantillas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ubicacion` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Guatemala',
  `saludo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Estimado(a) Director(a):',
  `cuerpo` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `despedida` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Atentamente,',
  `firma_nombre` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Secretaría',
  `firma_cargo` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mostrar_fecha` tinyint(1) NOT NULL DEFAULT '1',
  `mostrar_firma` tinyint(1) NOT NULL DEFAULT '1',
  `mostrar_telefono` tinyint(1) NOT NULL DEFAULT '1',
  `espacio_post_encabezado` tinyint NOT NULL DEFAULT '3',
  `espacio_post_fecha` tinyint NOT NULL DEFAULT '2',
  `espacio_post_saludo` tinyint NOT NULL DEFAULT '1',
  `espacio_post_cuerpo` tinyint NOT NULL DEFAULT '2',
  `espacio_post_despedida` tinyint NOT NULL DEFAULT '3',
  `activa` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `constancia_plantillas`
--

LOCK TABLES `constancia_plantillas` WRITE;
/*!40000 ALTER TABLE `constancia_plantillas` DISABLE KEYS */;
INSERT INTO `constancia_plantillas` VALUES (1,'Constancia de Inscripción','Guatemala','A quien corresponda:','Por medio de la presente hacemos constar que el alumno(a) {{nombre_completo}}, estudiante del establecimiento {{establecimiento}}, se encuentra inscrito(a) actualmente en el curso de Tecnología {{tac}}, en el horario de {{horario}} los días {{dias}} en el laboratorio {{laboratorio}}.\n\nLa presente constancia se extiende a solicitud del interesado para los usos que estime convenientes.','Atentamente,','Secretaría','',1,1,1,3,2,1,2,3,1,'2026-05-04 17:33:18','2026-05-04 17:33:18');
/*!40000 ALTER TABLE `constancia_plantillas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dip_diplomado_objetivos`
--

DROP TABLE IF EXISTS `dip_diplomado_objetivos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dip_diplomado_objetivos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `diplomado_id` int NOT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `orden` smallint NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_dip_obj` (`diplomado_id`,`orden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dip_diplomado_objetivos`
--

LOCK TABLES `dip_diplomado_objetivos` WRITE;
/*!40000 ALTER TABLE `dip_diplomado_objetivos` DISABLE KEYS */;
/*!40000 ALTER TABLE `dip_diplomado_objetivos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dip_diplomados`
--

DROP TABLE IF EXISTS `dip_diplomados`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dip_diplomados` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `objetivo_general` text COLLATE utf8mb4_unicode_ci,
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dip_diplomados`
--

LOCK TABLES `dip_diplomados` WRITE;
/*!40000 ALTER TABLE `dip_diplomados` DISABLE KEYS */;
INSERT INTO `dip_diplomados` VALUES (1,'Operador Windows','',1,'2026-05-04 17:33:17'),(2,'Programador','',1,'2026-05-04 17:33:17'),(3,'Diseño Gráfico','',1,'2026-05-04 17:33:18');
/*!40000 ALTER TABLE `dip_diplomados` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dip_examenes`
--

DROP TABLE IF EXISTS `dip_examenes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dip_examenes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `diplomado_id` int NOT NULL,
  `nombre` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `orden` smallint NOT NULL DEFAULT '0',
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_dip_exam` (`diplomado_id`,`orden`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dip_examenes`
--

LOCK TABLES `dip_examenes` WRITE;
/*!40000 ALTER TABLE `dip_examenes` DISABLE KEYS */;
INSERT INTO `dip_examenes` VALUES (1,1,'Windows',0,1,'2026-05-04 17:33:17'),(2,1,'Word',1,1,'2026-05-04 17:33:17'),(3,1,'Publisher',2,1,'2026-05-04 17:33:17'),(4,1,'PowerPoint',3,1,'2026-05-04 17:33:17'),(5,1,'Parcial',4,1,'2026-05-04 17:33:17'),(6,1,'Excel',5,1,'2026-05-04 17:33:17'),(7,1,'Examen Final',6,1,'2026-05-04 17:33:17'),(8,2,'Scratch',0,1,'2026-05-04 17:33:17'),(9,2,'Python',1,1,'2026-05-04 17:33:17'),(10,2,'Parcial',2,1,'2026-05-04 17:33:17'),(11,2,'C#',3,1,'2026-05-04 17:33:17'),(12,2,'Examen Final',4,1,'2026-05-04 17:33:18'),(13,3,'Photoshop',0,1,'2026-05-04 17:33:18'),(14,3,'Illustrator',1,1,'2026-05-04 17:33:18'),(15,3,'Parcial',2,1,'2026-05-04 17:33:18'),(16,3,'Filmora',3,1,'2026-05-04 17:33:18'),(17,3,'Examen Final',4,1,'2026-05-04 17:33:18');
/*!40000 ALTER TABLE `dip_examenes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dip_programa_contenido`
--

DROP TABLE IF EXISTS `dip_programa_contenido`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dip_programa_contenido` (
  `id` int NOT NULL AUTO_INCREMENT,
  `programa_id` int NOT NULL,
  `semana_num` tinyint NOT NULL,
  `contenido` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_dip_prog_cont` (`programa_id`,`semana_num`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dip_programa_contenido`
--

LOCK TABLES `dip_programa_contenido` WRITE;
/*!40000 ALTER TABLE `dip_programa_contenido` DISABLE KEYS */;
/*!40000 ALTER TABLE `dip_programa_contenido` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dip_programa_objetivos`
--

DROP TABLE IF EXISTS `dip_programa_objetivos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dip_programa_objetivos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `programa_id` int NOT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `orden` smallint NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_prog_obj` (`programa_id`,`orden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dip_programa_objetivos`
--

LOCK TABLES `dip_programa_objetivos` WRITE;
/*!40000 ALTER TABLE `dip_programa_objetivos` DISABLE KEYS */;
/*!40000 ALTER TABLE `dip_programa_objetivos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dip_programas`
--

DROP TABLE IF EXISTS `dip_programas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dip_programas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `diplomado_id` int NOT NULL,
  `nombre` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `objetivo_general` text COLLATE utf8mb4_unicode_ci,
  `duracion_semanas` tinyint NOT NULL DEFAULT '1',
  `orden` smallint NOT NULL DEFAULT '0',
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_prog_dip` (`diplomado_id`,`orden`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dip_programas`
--

LOCK TABLES `dip_programas` WRITE;
/*!40000 ALTER TABLE `dip_programas` DISABLE KEYS */;
INSERT INTO `dip_programas` VALUES (1,1,'Windows','',1,0,1,'2026-05-04 17:33:17'),(2,1,'Word','',1,1,1,'2026-05-04 17:33:17'),(3,1,'Publisher','',1,2,1,'2026-05-04 17:33:17'),(4,1,'PowerPoint','',1,3,1,'2026-05-04 17:33:17'),(5,1,'Parcial','',1,4,1,'2026-05-04 17:33:17'),(6,1,'Excel','',1,5,1,'2026-05-04 17:33:17'),(7,1,'Examen Final','',1,6,1,'2026-05-04 17:33:17'),(8,2,'Scratch','',1,0,1,'2026-05-04 17:33:17'),(9,2,'Python','',1,1,1,'2026-05-04 17:33:17'),(10,2,'Parcial','',1,2,1,'2026-05-04 17:33:17'),(11,2,'C#','',1,3,1,'2026-05-04 17:33:17'),(12,2,'Examen Final','',1,4,1,'2026-05-04 17:33:18'),(13,3,'Photoshop','',1,0,1,'2026-05-04 17:33:18'),(14,3,'Illustrator','',1,1,1,'2026-05-04 17:33:18'),(15,3,'Parcial','',1,2,1,'2026-05-04 17:33:18'),(16,3,'Filmora','',1,3,1,'2026-05-04 17:33:18'),(17,3,'Examen Final','',1,4,1,'2026-05-04 17:33:18');
/*!40000 ALTER TABLE `dip_programas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `diplomado_notas`
--

DROP TABLE IF EXISTS `diplomado_notas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `diplomado_notas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `alumno_id` int NOT NULL,
  `anio` smallint NOT NULL,
  `materia` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nota` smallint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_dip_n` (`alumno_id`,`anio`,`materia`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `diplomado_notas`
--

LOCK TABLES `diplomado_notas` WRITE;
/*!40000 ALTER TABLE `diplomado_notas` DISABLE KEYS */;
/*!40000 ALTER TABLE `diplomado_notas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inscritos_tac`
--

DROP TABLE IF EXISTS `inscritos_tac`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inscritos_tac` (
  `id` int NOT NULL AUTO_INCREMENT,
  `alumno_id` int NOT NULL,
  `anio` smallint NOT NULL,
  `tac` tinyint NOT NULL,
  `estado` enum('inscrito','no_inscrito','pendiente') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'no_inscrito',
  `fecha_actualizacion` datetime DEFAULT NULL,
  `observaciones` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_inscritos_tac` (`alumno_id`,`anio`,`tac`),
  KEY `idx_inscritos_anio_tac` (`anio`,`tac`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inscritos_tac`
--

LOCK TABLES `inscritos_tac` WRITE;
/*!40000 ALTER TABLE `inscritos_tac` DISABLE KEYS */;
/*!40000 ALTER TABLE `inscritos_tac` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `instituciones`
--

DROP TABLE IF EXISTS `instituciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `instituciones` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `resolucion` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `ubicacion` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `extras` longtext COLLATE utf8mb4_unicode_ci,
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `instituciones`
--

LOCK TABLES `instituciones` WRITE;
/*!40000 ALTER TABLE `instituciones` DISABLE KEYS */;
/*!40000 ALTER TABLE `instituciones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mecanografia_notas`
--

DROP TABLE IF EXISTS `mecanografia_notas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mecanografia_notas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `alumno_id` int NOT NULL,
  `anio` smallint NOT NULL,
  `l1` smallint DEFAULT NULL,
  `l2` smallint DEFAULT NULL,
  `l3` smallint DEFAULT NULL,
  `l4` smallint DEFAULT NULL,
  `l5` smallint DEFAULT NULL,
  `l6` smallint DEFAULT NULL,
  `l7` smallint DEFAULT NULL,
  `l8` smallint DEFAULT NULL,
  `l9` smallint DEFAULT NULL,
  `l10` smallint DEFAULT NULL,
  `l11` smallint DEFAULT NULL,
  `l12` smallint DEFAULT NULL,
  `l13` smallint DEFAULT NULL,
  `l14` smallint DEFAULT NULL,
  `l15` smallint DEFAULT NULL,
  `l16` smallint DEFAULT NULL,
  `l17` smallint DEFAULT NULL,
  `l18` smallint DEFAULT NULL,
  `l19` smallint DEFAULT NULL,
  `l20` smallint DEFAULT NULL,
  `examen` smallint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_mec_n` (`alumno_id`,`anio`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mecanografia_notas`
--

LOCK TABLES `mecanografia_notas` WRITE;
/*!40000 ALTER TABLE `mecanografia_notas` DISABLE KEYS */;
/*!40000 ALTER TABLE `mecanografia_notas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mensualidades`
--

DROP TABLE IF EXISTS `mensualidades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mensualidades` (
  `id` int NOT NULL AUTO_INCREMENT,
  `alumno_id` int NOT NULL,
  `mes` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `anio` smallint NOT NULL,
  `monto` decimal(10,2) NOT NULL DEFAULT '0.00',
  `pagado` tinyint(1) NOT NULL DEFAULT '0',
  `anulado` tinyint(1) NOT NULL DEFAULT '0',
  `descuento_100` tinyint(1) NOT NULL DEFAULT '0',
  `no_recibo` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fecha_pago` date DEFAULT NULL,
  `monto_abonado` decimal(10,2) NOT NULL DEFAULT '0.00',
  `acreditado` tinyint(1) NOT NULL DEFAULT '0',
  `acreditado_msg` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_mens` (`alumno_id`,`mes`,`anio`)
) ENGINE=InnoDB AUTO_INCREMENT=469 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mensualidades`
--

LOCK TABLES `mensualidades` WRITE;
/*!40000 ALTER TABLE `mensualidades` DISABLE KEYS */;
INSERT INTO `mensualidades` VALUES (1,1,'enero',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(2,1,'febrero',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(3,1,'marzo',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(4,1,'abril',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(5,1,'mayo',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(6,1,'junio',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(7,1,'julio',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(8,1,'agosto',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(9,1,'septiembre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(10,1,'octubre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(11,1,'noviembre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL),(12,1,'diciembre',2026,80.00,0,0,0,NULL,NULL,0.00,0,NULL);
/*!40000 ALTER TABLE `mensualidades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mis_tablas`
--

DROP TABLE IF EXISTS `mis_tablas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mis_tablas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci,
  `encabezado` text COLLATE utf8mb4_unicode_ci,
  `columnas` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `filas` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mis_tablas`
--

LOCK TABLES `mis_tablas` WRITE;
/*!40000 ALTER TABLE `mis_tablas` DISABLE KEYS */;
/*!40000 ALTER TABLE `mis_tablas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notas_tac_anual`
--

DROP TABLE IF EXISTS `notas_tac_anual`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notas_tac_anual` (
  `id` int NOT NULL AUTO_INCREMENT,
  `alumno_id` int NOT NULL,
  `anio` smallint NOT NULL,
  `nota1` smallint DEFAULT NULL,
  `nota2` smallint DEFAULT NULL,
  `nota3` smallint DEFAULT NULL,
  `nota4` smallint DEFAULT NULL,
  `tac` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_tac_a` (`alumno_id`,`anio`,`tac`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notas_tac_anual`
--

LOCK TABLES `notas_tac_anual` WRITE;
/*!40000 ALTER TABLE `notas_tac_anual` DISABLE KEYS */;
/*!40000 ALTER TABLE `notas_tac_anual` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `papeleria`
--

DROP TABLE IF EXISTS `papeleria`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `papeleria` (
  `id` int NOT NULL AUTO_INCREMENT,
  `no_recibo` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `alumno_id` int DEFAULT NULL,
  `descripcion` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `total` decimal(10,2) DEFAULT NULL,
  `observaciones` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `alumno_texto` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `anulado` tinyint(1) NOT NULL DEFAULT '0',
  `anulado_at` timestamp NULL DEFAULT NULL,
  `no_deposito` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `papeleria`
--

LOCK TABLES `papeleria` WRITE;
/*!40000 ALTER TABLE `papeleria` DISABLE KEYS */;
/*!40000 ALTER TABLE `papeleria` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_resets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `usuario_id` int NOT NULL,
  `token` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expira_at` datetime NOT NULL,
  `usado` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `token` (`token`),
  KEY `idx_pwres_user` (`usuario_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recibos`
--

DROP TABLE IF EXISTS `recibos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `recibos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `no_recibo` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `alumno_id` int DEFAULT NULL,
  `meses` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `total` decimal(10,2) DEFAULT NULL,
  `observaciones` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `descuento` decimal(10,2) NOT NULL DEFAULT '0.00',
  `alumno_texto` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `anulado` tinyint(1) NOT NULL DEFAULT '0',
  `anulado_at` timestamp NULL DEFAULT NULL,
  `no_deposito` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recibos`
--

LOCK TABLES `recibos` WRITE;
/*!40000 ALTER TABLE `recibos` DISABLE KEYS */;
/*!40000 ALTER TABLE `recibos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recibos_diplomados`
--

DROP TABLE IF EXISTS `recibos_diplomados`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `recibos_diplomados` (
  `id` int NOT NULL AUTO_INCREMENT,
  `no_recibo` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `alumno_id` int DEFAULT NULL,
  `diplomado` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `descripcion` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `total` decimal(10,2) DEFAULT NULL,
  `observaciones` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recibos_diplomados`
--

LOCK TABLES `recibos_diplomados` WRITE;
/*!40000 ALTER TABLE `recibos_diplomados` DISABLE KEYS */;
/*!40000 ALTER TABLE `recibos_diplomados` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuarios` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rol` enum('admin','alumno','oficina','maestro') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'alumno',
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuarios`
--

LOCK TABLES `usuarios` WRITE;
/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
INSERT INTO `usuarios` VALUES (1,'Admin Sistec Jalapa','sistecjalapa@gmail.com','$2b$10$8y5tTpgyIS1j7Aqfxv6fs.LhWOjOHqMV9Rb63SdR/lBIV1XHuFCu.','admin',1,'2026-05-04 17:33:18'),(2,'Rony Alexander Castillo','rony1','$2b$10$iqk.2mxPHOBGabQ5CzRmkO8g6HJzKuxzgUjtAvTppHmnIuyE0oRHS','alumno',1,'2026-05-04 17:39:22');
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'sistec_jalapa'
--

--
-- Dumping routines for database 'sistec_jalapa'
--

--
-- Current Database: `eduguat_meta`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `eduguat_meta` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `eduguat_meta`;

--
-- Table structure for table `backups`
--

DROP TABLE IF EXISTS `backups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `backups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `filename` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `filepath` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `size_bytes` bigint NOT NULL DEFAULT '0',
  `tipo` enum('manual','automatico') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'manual',
  `estado` enum('ok','error') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ok',
  `error_msg` text COLLATE utf8mb4_unicode_ci,
  `drive_file_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `drive_link` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `drive_status` enum('pendiente','ok','error') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pendiente',
  `usuario_id` int DEFAULT NULL,
  `usuario_nombre` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_tipo` (`tipo`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backups`
--

LOCK TABLES `backups` WRITE;
/*!40000 ALTER TABLE `backups` DISABLE KEYS */;
INSERT INTO `backups` VALUES (10,'eduguat-manual-20260507-102502.sql.gz','C:\\Users\\rotak\\OneDrive - INTECAP\\Escritorio\\EDUGUAT\\server\\backups\\eduguat-manual-20260507-102502.sql.gz',176838,'manual','ok',NULL,'1zwzHyw-jzyW4t9g1prWFHR9z1GKeoffI','https://drive.google.com/file/d/1zwzHyw-jzyW4t9g1prWFHR9z1GKeoffI/view?usp=drivesdk','ok',1,'Administrador','2026-05-07 16:25:07'),(11,'eduguat-manual-20260507-150004.sql.gz','C:\\Users\\rotak\\OneDrive - INTECAP\\Escritorio\\EDUGUAT\\server\\backups\\eduguat-manual-20260507-150004.sql.gz',175683,'manual','ok','Drive: File not found: 1ev7HJilJvjMeXjgDJaXqt41Cv0zc37l7wh.',NULL,NULL,'error',1,'Administrador','2026-05-07 21:00:09');
/*!40000 ALTER TABLE `backups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sedes`
--

DROP TABLE IF EXISTS `sedes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sedes` (
  `id` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nombre` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `info` text COLLATE utf8mb4_unicode_ci,
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `modulos` longtext COLLATE utf8mb4_unicode_ci,
  `email_admin` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sedes`
--

LOCK TABLES `sedes` WRITE;
/*!40000 ALTER TABLE `sedes` DISABLE KEYS */;
INSERT INTO `sedes` VALUES ('m_lozano','M Lozano',NULL,1,NULL,NULL,'2026-04-29 20:40:56','2026-04-29 20:40:56'),('sistec_jalapa','Sistec Jalapa','sistec jalapa sistema',1,NULL,'sistecjalapa@gmail.com','2026-05-04 17:33:16','2026-05-04 17:33:16'),('sistec_jutiapa','Sistec Jutiapa',NULL,1,NULL,NULL,'2026-04-29 20:40:56','2026-04-29 20:40:56'),('sistec_xela','Sistec Xela','Centro de Xela, Tel. 4141-5252',0,NULL,'sistecxela@gmail.com','2026-04-29 20:45:39','2026-04-30 02:29:23'),('sistema_escolar','Sistec Flores',NULL,1,NULL,NULL,'2026-04-29 20:40:56','2026-04-29 20:40:56'),('testimport1','TestImport1','test importacion 1',1,NULL,'admin@test.com','2026-05-03 14:33:41','2026-05-03 14:33:41');
/*!40000 ALTER TABLE `sedes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'eduguat_meta'
--

--
-- Dumping routines for database 'eduguat_meta'
--
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-05-08  7:29:56
